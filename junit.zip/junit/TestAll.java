package jp.ne.yec.seagullLC.stagia.test.junit;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import jp.ne.yec.seagullLC.stagia.test.junit.logic.shinsei.SetsubiLogic.TestSetsubiLogic;
import jp.ne.yec.seagullLC.stagia.test.junit.logic.shinsei.ShinseiLogic.TestShinseiLogic;
import jp.ne.yec.seagullLC.stagia.test.junit.service.ryokin.RyoshuKampuKeshikomiService.TestRyoshuKampuKeshikomiService;
import jp.ne.yec.seagullLC.stagia.test.junit.service.ryokin.TestRyokinSeisanService.TestRyokinSeisanService;
import jp.ne.yec.seagullLC.stagia.test.junit.service.shinsei.HaitaService.TestHaitaService;
import jp.ne.yec.seagullLC.stagia.test.junit.service.shinsei.MeisaiIchiranService.TestMeisaiIchiranService;
import jp.ne.yec.seagullLC.stagia.test.junit.service.shinsei.MeisaiJohoSetteiService.TestMeisaiJohoSetteiService;
import jp.ne.yec.seagullLC.stagia.test.junit.service.shinsei.SaibanService.TestSaibanService;
import jp.ne.yec.seagullLC.stagia.test.junit.service.shinsei.SetsubiService.TestSetsubiService;
import jp.ne.yec.seagullLC.stagia.test.junit.service.shinsei.ShinseiIchiranService.TestShinseiIchiranService;
import jp.ne.yec.seagullLC.stagia.test.junit.service.shinsei.ShinseiKakuninService.TestShinseiKakuninService;
import jp.ne.yec.seagullLC.stagia.test.junit.service.shinsei.ShinseiKanryoService.TestShinseiKanryoService;
import jp.ne.yec.seagullLC.stagia.test.junit.service.shinsei.ShinseiRirekiService.TestShinseiRirekiService;
import jp.ne.yec.seagullLC.stagia.test.junit.service.shinsei.ShinseishaJohoService.TestShinseishaJohoService;

@RunWith(Suite.class)
@Suite.SuiteClasses({
	TestSetsubiLogic.class,
	TestShinseiLogic.class,
	TestRyoshuKampuKeshikomiService.class,
	TestRyokinSeisanService.class,
	TestHaitaService.class,
//	TestMeisaiIchiranService.class,
//	TestMeisaiJohoSetteiService.class,
//	TestSaibanService.class,
//	TestSetsubiService.class,
//	TestShinseiIchiranService.class,
//	TestShinseiKakuninService.class,
//	TestShinseiKanryoService.class,
//	TestShinseiRirekiService.class,
//	TestShinseishaJohoService.class
	})

public class TestAll {

}
