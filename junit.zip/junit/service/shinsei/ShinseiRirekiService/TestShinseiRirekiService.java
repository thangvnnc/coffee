package jp.ne.yec.seagullLC.stagia.test.junit.service.shinsei.ShinseiRirekiService;

import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.seagullLC.stagia.beans.shinsei.ShinseiMeisaiDto;
import jp.ne.yec.seagullLC.stagia.service.shinsei.ShinseiRirekiService;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestShinseiRirekiService extends JunitBase{

	@Autowired
	ShinseiRirekiService shinseiRirekiService;

	@Test
	@DisplayName("対象明細の履歴情報を取得します.")
	@TestInitDataFile("TestGetShinseiMeisaiRirekiList_Init.xlsx")

	public void TestGetShinseiMeisaiRirekiList() throws Exception{
		short kanriCode = 10;
		int  shinseiNum = 531;
		short meisaiNum = 10;
		List<ShinseiMeisaiDto> list = shinseiRirekiService.getShinseiMeisaiRirekiList(kanriCode, shinseiNum, meisaiNum);
		exportJsonData(list, "TestGetShinseiMeisaiRirekiList.json");
	}
}
