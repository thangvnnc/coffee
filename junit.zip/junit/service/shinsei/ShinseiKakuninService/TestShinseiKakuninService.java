package jp.ne.yec.seagullLC.stagia.test.junit.service.shinsei.ShinseiKakuninService;

import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Queue;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.google.gson.reflect.TypeToken;

import jp.ne.yec.seagullLC.stagia.beans.shinsei.ShinseiDto;
import jp.ne.yec.seagullLC.stagia.beans.shinsei.ShinseiMeisaiDto;
import jp.ne.yec.seagullLC.stagia.service.shinsei.ShinseiKakuninService;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestShinseiKakuninService extends JunitBase{
	@Autowired
	ShinseiKakuninService shinseiKakuninService;

//	@Test
//	// chưa đủ 40%
//	public void TestSetKashidashiTaniAndCopyMensu() throws Exception{
//		ShinseiDto key = readJson("TestSetKashidashiTaniAndCopyMensu_shinseiMap_ShinseiDto.pra", new TypeToken<ShinseiDto>() {}.getType());
//		List<ShinseiMeisaiDto> value = readJson("TestSetKashidashiTaniAndCopyMensu_shinseiMap_ListShinseiMeisaiDto.pra", new TypeToken<List<ShinseiMeisaiDto>>() {}.getType());
//		Map<ShinseiDto, List<ShinseiMeisaiDto>> shinseiMap = new HashMap<>();
//		shinseiMap.put(key, value);
//		shinseiKakuninService.setKashidashiTaniAndCopyMensu(shinseiMap);
//	}
//
//	@Test
//	// chưa đủ 90%
//	public void TestSetShinseiNumber() throws Exception{
//		ShinseiDto key = readJson("TestSetShinseiNumber_shinseiMap_ShinseiDto.pra", new TypeToken<ShinseiDto>() {}.getType());
//		List<ShinseiMeisaiDto> value = readJson("TestSetShinseiNumber_shinseiMap_ListShinseiMeisaiDto.pra", new TypeToken<List<ShinseiMeisaiDto>>() {}.getType());
//		Map<ShinseiDto, List<ShinseiMeisaiDto>> shinseiMap = new HashMap<>();
//		shinseiMap.put(key, value);
//		Map<Short, Queue<Integer>> shinseiNumberMap = readJson("TestSetShinseiNumber_shinseiNumberMap.pra", new TypeToken<Map<Short, Queue<Integer>>>() {}.getType());;
//		shinseiKakuninService.setShinseiNumber(shinseiMap, shinseiNumberMap);
//	}
//
//	@Test
//	@TestInitDataFile("TestGetMaxMeisaiNumber_Init.xlsx")
//	public void TestGetMaxMeisaiNumber() throws Exception{
//		int ret = shinseiKakuninService.getMaxMeisaiNumber((short)10, 773);
//		assertEquals(ret, 2);
//	}

	@Test
	@TestInitDataFile("TestInsertShinseiData_Step1_Init.xlsx")
	public void TestInsertShinseiData_Step1() throws Exception{
		ShinseiDto key = readJson("TestInsertShinseiData_shinseiMap_ShinseiDto.pra", new TypeToken<ShinseiDto>() {}.getType());
		List<ShinseiMeisaiDto> value = readJson("TestInsertShinseiData_shinseiMap_ListShinseiMeisaiDto.pra", new TypeToken<List<ShinseiMeisaiDto>>() {}.getType());
		Map<ShinseiDto, List<ShinseiMeisaiDto>> shinseiMap = new HashMap<>();
		shinseiMap.put(key, value);
		shinseiKakuninService.insertShinseiData(shinseiMap, false, "1-tnt");
	}



}
