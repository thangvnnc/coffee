package jp.ne.yec.seagullLC.stagia.test.junit.service.shinsei.SetsubiService;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.google.common.reflect.TypeToken;

import jp.ne.yec.seagullLC.stagia.beans.shinsei.SetsubiInfoDto;
import jp.ne.yec.seagullLC.stagia.beans.shinsei.SetsubiShinseiDto;
import jp.ne.yec.seagullLC.stagia.beans.shinsei.ShinseiDto;
import jp.ne.yec.seagullLC.stagia.beans.shinsei.ShinseiMeisaiDto;
import jp.ne.yec.seagullLC.stagia.beans.shinsei.ShisetsuKomaDto;
import jp.ne.yec.seagullLC.stagia.entity.MRyokinKeisanKomoku;
import jp.ne.yec.seagullLC.stagia.entity.MRyokinKeisanNaiyo;
import jp.ne.yec.seagullLC.stagia.entity.MRyokinKeisanShiki;
import jp.ne.yec.seagullLC.stagia.service.shinsei.SetsubiService;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestSetsubiService extends JunitBase{

	@Autowired
	SetsubiService setsubiService;

	@Test
	@DisplayName("引数の管理コードに合致する利用者の受付場所規定値を返却します.")
	@TestInitDataFile("TestGetRiyoshaUketsukeBasho_Init.xlsx")
	public void TestGetRiyoshaUketsukeBasho() throws Exception{
		Short riyoshaUketsukeBasho = setsubiService.getRiyoshaUketsukeBasho((short) 10);
		Short exp = 901;
		assertEquals(exp, riyoshaUketsukeBasho);
	}

	@Test
	@TestInitDataFile("TestgetRyokinKeisanKomoku_Init.xlsx")
	public void TestGetMRyokinKeisanKomoku() throws Exception{
		short kanriCode = 10;
		List<MRyokinKeisanKomoku> list = setsubiService.getMRyokinKeisanKomoku(kanriCode);
		exportJsonData(list, "TestGetMRyokinKeisanKomoku.json");
	}

	@Test
	@DisplayName("M_料金計算式を取得します.")
	@TestInitDataFile("TestGetMRyokinKeisanShiki_Init.xlsx")
	public void TestGetMRyokinKeisanShiki() throws Exception{
		short kanriCode = 10;
		List<MRyokinKeisanShiki> list = setsubiService.getMRyokinKeisanShiki(kanriCode);
		exportJsonData(list, "TestGetMRyokinKeisanShiki.json");
	}

	@Test
	@DisplayName("管理コードを条件にM_料金計算内容を取得し返却します.")
	@TestInitDataFile("TestGetMRyokinKeisanNaiyo_Init.xlsx")
	public void TestGetMRyokinKeisanNaiyo() throws Exception{
		short kanriCode = 10;
		List<MRyokinKeisanNaiyo> list = setsubiService.getMRyokinKeisanNaiyo(kanriCode);
		exportJsonData(list, "TestGetMRyokinKeisanNaiyo.json");
	}

	@Test
	public void TestGetShinseiSetsubiList() throws Exception{
		ShinseiMeisaiDto meisaiDto = readJson("TestGetShinseiSetsubiList_meisaiDto.pra", new TypeToken<ShinseiMeisaiDto>(){}.getType());
		List<SetsubiShinseiDto> list = setsubiService.getShinseiSetsubiList(meisaiDto);
		exportJsonData(list, "TestGetShinseiSetsubiList.json");
	}

	@Test
	@TestInitDataFile("TestGetAvailableSetsubi_Step1_Init.xlsx")
	public void TestGetAvailableSetsubi_Step1() throws Exception{
		ShinseiDto shinseiDto = readJson("TestGetAvailableSetsubi_Step1_shinseiDto.pra", new TypeToken<ShinseiDto>(){}.getType());
		ShinseiMeisaiDto meisaiDto = readJson("TestGetAvailableSetsubi_Step1_meisaiDto.pra", new TypeToken<ShinseiMeisaiDto>(){}.getType());;
		List<ShinseiMeisaiDto> meisaiDtos = readJson("TestGetAvailableSetsubi_Step1_meisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>(){}.getType());
		List<ShisetsuKomaDto> selectedKomas = readJson("TestGetAvailableSetsubi_Step1_selectedKomas.pra", new TypeToken<List<ShisetsuKomaDto>>(){}.getType());
		List<SetsubiInfoDto> list = setsubiService.getAvailableSetsubi(shinseiDto, meisaiDto, meisaiDtos, selectedKomas, false);
		exportJsonData(list, "TestGetAvailableSetsubi_Step1.json");
	}

	@Test
	@TestInitDataFile("TestGetAvailableSetsubi_Step2_Init.xlsx")
	public void TestGetAvailableSetsubi_Step2() throws Exception{
		ShinseiDto shinseiDto = readJson("TestGetAvailableSetsubi_Step2_shinseiDto.pra", new TypeToken<ShinseiDto>(){}.getType());
		ShinseiMeisaiDto meisaiDto = readJson("TestGetAvailableSetsubi_Step2_meisaiDto.pra", new TypeToken<ShinseiMeisaiDto>(){}.getType());;
		List<ShinseiMeisaiDto> meisaiDtos = readJson("TestGetAvailableSetsubi_Step2_meisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>(){}.getType());
		List<ShisetsuKomaDto> selectedKomas = readJson("TestGetAvailableSetsubi_Step2_selectedKomas.pra", new TypeToken<List<ShisetsuKomaDto>>(){}.getType());
		List<SetsubiInfoDto> list = setsubiService.getAvailableSetsubi(shinseiDto, meisaiDto, meisaiDtos, selectedKomas, true);
		exportJsonData(list, "TestGetAvailableSetsubi_Step2.json");
	}

	@Test
	@TestInitDataFile("TestGetAvailableSetsubi_Step3_Init.xlsx")
	public void TestGetAvailableSetsubi_Step3() throws Exception{
		ShinseiDto shinseiDto = readJson("TestGetAvailableSetsubi_Step3_shinseiDto.pra", new TypeToken<ShinseiDto>(){}.getType());
		ShinseiMeisaiDto meisaiDto = readJson("TestGetAvailableSetsubi_Step3_meisaiDto.pra", new TypeToken<ShinseiMeisaiDto>(){}.getType());;
		List<ShinseiMeisaiDto> meisaiDtos = readJson("TestGetAvailableSetsubi_Step3_meisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>(){}.getType());
		List<ShisetsuKomaDto> selectedKomas = readJson("TestGetAvailableSetsubi_Step3_selectedKomas.pra", new TypeToken<List<ShisetsuKomaDto>>(){}.getType());
		List<SetsubiInfoDto> list = setsubiService.getAvailableSetsubi(shinseiDto, meisaiDto, meisaiDtos, selectedKomas, true);
		assertEquals(0, list.size());
	}

	@Test
	@TestInitDataFile("TestIsNothingAvailableSetsubi_Step1_Init.xlsx")
	public void TestIsNothingAvailableSetsubi_Step1() throws Exception{
		String shinseiShurui = "2";
		ShinseiMeisaiDto meisaiDto = readJson("TestIsNothingAvailableSetsubi_Step1_meisaiDto.pra", new TypeToken<ShinseiMeisaiDto>() {}.getType());
		boolean isShokuin = false;

		boolean ret = setsubiService.isNothingAvailableSetsubi(shinseiShurui, meisaiDto, isShokuin);
		assertEquals(false, ret);
	}

	@Test
	public void TestIsNothingAvailableSetsubi_Step2() throws Exception{
		String shinseiShurui = "2";
		ShinseiMeisaiDto meisaiDto = new ShinseiMeisaiDto();
		boolean isShokuin = true;

		boolean ret = setsubiService.isNothingAvailableSetsubi(shinseiShurui, meisaiDto, isShokuin);
		assertEquals(true, ret);
	}

}
