package jp.ne.yec.seagullLC.stagia.test.junit.service.shinsei.HaitaService;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.transaction.TransactionConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;

import com.google.common.reflect.TypeToken;

import jp.ne.yec.seagullLC.stagia.beans.shinsei.ShinseiMeisaiDto;
import jp.ne.yec.seagullLC.stagia.logic.transaction.TSetsubiHaitaWorkLogic;
import jp.ne.yec.seagullLC.stagia.service.shinsei.HaitaService;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestHaitaService extends JunitBase{

	@Autowired
	HaitaService haitaService;

	@Test
	@TestInitDataFile("TestInsShisetsuHaitaInfo_Step1_Init.xlsx")
	public void TestInsShisetsuHaitaInfo_Step1() throws Exception{
		List<ShinseiMeisaiDto> meisaiDtos = readJson("TestInsShisetsuHaitaInfo_Step1_meisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>() {}.getType());
		haitaService.insShisetsuHaitaInfo(meisaiDtos, "769529A597C9137B8DB58C290D2C52B7", "1-tnt");
	}

	@Test
	@TestInitDataFile("TestInsShisetsuHaitaInfo_Step2_Init.xlsx")
	public void TestInsShisetsuHaitaInfo_Step2() throws Exception{
		List<ShinseiMeisaiDto> meisaiDtos = readJson("TestInsShisetsuHaitaInfo_Step2_meisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>() {}.getType());
		haitaService.insShisetsuHaitaInfo(meisaiDtos, "769529A597C9137B8DB58C290D2C52B7", "1-tnt");
	}

	@Test
	@TestInitDataFile("TestInsShisetsuHaitaInfo_Step3_Init.xlsx")
	public void TestInsShisetsuHaitaInfo_Step3() throws Exception{
		List<ShinseiMeisaiDto> meisaiDtos = readJson("TestInsShisetsuHaitaInfo_Step3_meisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>() {}.getType());
		haitaService.insShisetsuHaitaInfo(meisaiDtos, "769529A597C9137B8DB58C290D2C52B7", "1-tnt");
	}

	@Test
	@TestInitDataFile("TestInsShisetsuHaitaInfo_Step4_Init.xlsx")
	public void TestInsShisetsuHaitaInfo_Step4() throws Exception{
		List<ShinseiMeisaiDto> meisaiDtos = readJson("TestInsShisetsuHaitaInfo_Step4_meisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>() {}.getType());
		haitaService.insShisetsuHaitaInfo(meisaiDtos, "769529A597C9137B8DB58C290D2C52B7", "1-tnt");
	}

	@Test
	@TestInitDataFile("TestInsShisetsuHaitaInfo_Step5_Init.xlsx")
	public void TestInsShisetsuHaitaInfo_Step5() throws Exception{
		List<ShinseiMeisaiDto> meisaiDtos = readJson("TestInsShisetsuHaitaInfo_Step5_meisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>() {}.getType());
		haitaService.insShisetsuHaitaInfo(meisaiDtos, "769529A597C9137B8DB58C290D2C52B7", "1-tnt");
	}

	@Test
	@TestInitDataFile("TestInsShisetsuHaitaInfo_Step6_Init.xlsx")
	public void TestInsShisetsuHaitaInfo_Step6() throws Exception{
		try{
			List<ShinseiMeisaiDto> meisaiDtos = readJson("TestInsShisetsuHaitaInfo_Step6_meisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>() {}.getType());
			haitaService.insShisetsuHaitaInfo(meisaiDtos, "769529A597C9137B8DB58C290D2C52B7", "1-tnt");
		}catch (Exception e) {
			String message = "申請対象の施設は更新された可能性があります。お手数ですが、時間をおいてから再度申請を行ってください。";
			assertEquals(message, e.getMessage());
		}
	}

	@Test
	@TestInitDataFile("TestInsSetsubiHaitaInfo_Step1_Init.xlsx")
	public void TestInsSetsubiHaitaInfo_Step1() throws Exception{
		List<ShinseiMeisaiDto> meisaiDtos = readJson("TestInsSetsubiHaitaInfo_Step1_meisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>() {}.getType());
		haitaService.insSetsubiHaitaInfo(meisaiDtos, "F26092F71344F75A9ED595A0C52472C3", "1-tnt");
	}

	@Test
	@TestInitDataFile("TestInsSetsubiHaitaInfo_Step2_Init.xlsx")
	public void TestInsSetsubiHaitaInfo_Step2() throws Exception{
		List<ShinseiMeisaiDto> meisaiDtos = readJson("TestInsSetsubiHaitaInfo_Step2_meisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>() {}.getType());
		try
		{
			haitaService.insSetsubiHaitaInfo(meisaiDtos, "F26092F71344F75A9ED595A0C52472C3", "1-tnt");
		}
		catch (Exception ex) {
			String messsageExp = "申請対象の設備は更新された可能性があります。お手数ですが、時間をおいてから再度申請を行ってください。";
			assertEquals(messsageExp, ex.getMessage());
		}
	}

	@Test
	@TestInitDataFile("TestDelHaitaInfo_Init.xlsx")
	public void TestDelHaitaInfo() throws Exception{
		haitaService.delHaitaInfo("769529A597C9137B8DB58C290D2C52B7");
	}

//	@Test
//	public void TestInsSetsubHenkoiHaitaInfo() throws Exception{
//		List<ShinseiMeisaiDto> meisaiDtos = readJson("TestInsSetsubiHaitaInfo_Step2_meisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>() {}.getType());
//		haitaService.insSetsubHenkoiHaitaInfo(meisaiDtos, meisaiDtos, "sessionId", "1-tnt");
//	}
//
//	@Test
//	@TestInitDataFile("TestInsKyukanBashoHaitaInfoInit.xlsx")
//	public void TestInsKyukanBashoHaitaInfo() throws Exception{
//		List<Short> bashoCodes = readArrShort("TestInsKyukanBashoHaitaInfo_bashoCode.txt");
//		List<String> sessionIds = readArrString("TestInsKyukanBashoHaitaInfo_sessionId.txt");
//
//		for (int idx = 0; idx < bashoCodes.size(); idx++)
//		{
//			try
//			{
//				List<LocalDate> kyukanbiList = new ArrayList<LocalDate>();
//				kyukanbiList.add(LocalDate.of(2018, 06, 16));
//				kyukanbiList.add(LocalDate.of(2018, 06, 23));
//				kyukanbiList.add(LocalDate.of(2018, 06, 24));
//				kyukanbiList.add(LocalDate.of(2018, 06, 25));
//				kyukanbiList.add(LocalDate.of(2018, 01, 01));
//				haitaService.insKyukanBashoHaitaInfo(bashoCodes.get(idx), kyukanbiList, sessionIds.get(idx), "test");
//			}
//			catch (Exception ex) {
//				assertNotNull(ex);
//			}
//		}
//	}
//
//	@Test
//	@TestInitDataFile("TestInsKyukanBashoHaitaInfoInit.xlsx")
//	public void TestDelHaitaInfo() throws Exception{
//		List<String> sessionIds = readArrString	("TestDelHaitaInfo_sessionId.txt");
//		for (String sessionId : sessionIds) {
//			haitaService.delHaitaInfo(sessionId);
//		}
//	}
}
