package jp.ne.yec.seagullLC.stagia.test.junit.service.shinsei.ShinseiIchiranService;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.google.common.reflect.TypeToken;

import jp.ne.yec.seagullLC.stagia.beans.enums.ShinseiKubun;
import jp.ne.yec.seagullLC.stagia.beans.shinsei.ShinseiDto;
import jp.ne.yec.seagullLC.stagia.beans.shinsei.ShinseiIchiranDto;
import jp.ne.yec.seagullLC.stagia.entity.MWebSettei;
import jp.ne.yec.seagullLC.stagia.service.shinsei.ShinseiIchiranService;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
// Run all
public class TestShinseiIchiranService extends JunitBase{

	@Autowired
	ShinseiIchiranService shinseiIchiranService;

	@Test
	@DisplayName("ログインIDを元に申請情報を取得し、返却します.</BR>")
	@TestInitDataFile("TestGetShinseiIchiranDtoMap_Step1_Init.xlsx")
	public void TestGetShinseiIchiranDtoMap_Step1() throws Exception{
		Map<ShinseiKubun, List<ShinseiIchiranDto>> map = shinseiIchiranService.getShinseiIchiranDtoMap("tnt");
		exportJsonData(map, "TestGetShinseiIchiranDtoMap_Step1.json");
	}

	@Test
	@DisplayName("ログインIDを元に申請情報を取得し、返却します.</BR>")
	@TestInitDataFile("TestGetShinseiIchiranDtoMap_Step2_Init.xlsx")
	public void TestGetShinseiIchiranDtoMap_Step2() throws Exception{
		Map<ShinseiKubun, List<ShinseiIchiranDto>> map = shinseiIchiranService.getShinseiIchiranDtoMap("tnt");
		exportJsonData(map, "TestGetShinseiIchiranDtoMap_Step2.json");
	}

	@Test
	@DisplayName("管理毎のM_WEB設定をMapで返却します.")
	@TestInitDataFile("TestGetMWebSetteiMapMap_Init.xlsx")
	public void TestGetMWebSetteiMapMap() throws Exception{
		List<Short> kanriCodes = new ArrayList<>();
		kanriCodes.add((short)10);
		Map<Short, MWebSettei> map = shinseiIchiranService.getMWebSetteiMapMap(kanriCodes);
		exportJsonData(map, "TestGetMWebSetteiMapMap.json");
	}

	@Test
	@TestInitDataFile("TestGetSelectShinseiInfo_Init.xlsx")
	public void TestGetSelectShinseiInfo() throws Exception{
		ShinseiDto shinseiDto = shinseiIchiranService.getSelectShinseiInfo((short)10, 772, false);
		exportJsonData(shinseiDto, "TestGetSelectShinseiInfo.json");
	}

	@Test
	@DisplayName("画面で選択された引数の管理コード、申請番号を基に照会用の申請情報を取得し、返却します.")
	@TestInitDataFile("TestGetSelectShinseiInfoForShokai_Init.xlsx")
	public void TestGetSelectShinseiInfoForShokai() throws Exception{
		ShinseiDto shinseiDto = shinseiIchiranService.getSelectShinseiInfoForShokai((short)10, 772, false);
		exportJsonData(shinseiDto, "TestGetSelectShinseiInfoForShokai.json");
	}

	@Test
	@DisplayName("引数の明細を取消します.")
	@TestInitDataFile("TestDelete_Init.xlsx")
	public void TestDelete() throws Exception{
		ShinseiIchiranDto ichiranDto = readJson("TestDelete_ichiranDto.pra", new TypeToken<ShinseiIchiranDto>() {}.getType());
		shinseiIchiranService.delete(ichiranDto, "1-tnt", false);
	}

	@Test
	@DisplayName("ログインIDを元に領収有りの申請情報を取得し、IDをキーとしたMapを返却します.")
	@TestInitDataFile("TestGetRyoshuAriShinseiIchiranDtoMap_Init.xlsx")
	public void TestGetRyoshuAriShinseiIchiranDtoMap() throws Exception{
		Set<Integer> ret = shinseiIchiranService.getRyoshuAriShinseiIchiranDtoMap("tnt");
		assertEquals(38228, ret.iterator().next().intValue());
	}
}
