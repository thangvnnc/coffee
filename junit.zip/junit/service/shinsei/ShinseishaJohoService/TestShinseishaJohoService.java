package jp.ne.yec.seagullLC.stagia.test.junit.service.shinsei.ShinseishaJohoService;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.seagullLC.stagia.entity.MBasho;
import jp.ne.yec.seagullLC.stagia.entity.MKanri;
import jp.ne.yec.seagullLC.stagia.service.shinsei.ShinseishaJohoService;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestShinseishaJohoService extends JunitBase{

	@Autowired
	ShinseishaJohoService shinseishaJohoService;

	@Test
	@DisplayName("受付可能なM_場所を返却します.")
	@TestInitDataFile("TestGetUketsukeBasho_Init.xlsx")
	public void TestGetUketsukeBasho() throws Exception{
		List<MBasho> list = shinseishaJohoService.getUketsukeBasho();
		exportJsonData(list, "TestGetUketsukeBasho.json");
	}

	@Test
	@DisplayName("M管理を取得します.")
	@TestInitDataFile("TestGetMKanri_Init.xlsx")
	public void TestGetMKanri() throws Exception{
		List<Short> liShorts = new ArrayList<Short>();
		Short KanriCode = 10;
		liShorts.add(KanriCode);
		List<MKanri> list = shinseishaJohoService.getMKanri(liShorts);
		exportJsonData(list, "TestGetMKanri.json");
	}

//	@Test
//	@DisplayName("ログインIDで取得した利用者情報をShinseiDtoに設定します.")
//	public void TestSetUserInformation() throws Exception{
//		shinseishaJohoService.setUserInformation(shinseiDto, shinseiMeisaiDtos);;
//	}
//
//	@Test
//	@DisplayName("設定されたログインIDより、料金計算を行います.")
//	public void TestSetRyokinInformation() throws Exception{
//		shinseishaJohoService.setRyokinInformation(shinseiDto, shinseiMeisaiDtos);;
//	}
}
