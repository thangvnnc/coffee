package jp.ne.yec.seagullLC.stagia.test.junit.service.shinsei.ShinseiKanryoService;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.google.common.reflect.TypeToken;

import jp.ne.yec.seagullLC.stagia.beans.shinsei.ShinseiDto;
import jp.ne.yec.seagullLC.stagia.beans.shinsei.ShinseiMeisaiDto;
import jp.ne.yec.seagullLC.stagia.entity.TShinsei;
import jp.ne.yec.seagullLC.stagia.entity.TShinseiMeisai;
import jp.ne.yec.seagullLC.stagia.service.shinsei.ShinseiKanryoService;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestShinseiKanryoService extends JunitBase{

	@Autowired
	ShinseiKanryoService shinseiKanryoService;

	@Test
	@DisplayName("引数のMapから本予約のみを再抽出します.")
	public void TestGetHonyoyakuShinseiMap() throws Exception{
		ShinseiDto key = readJson("TestGetHonyoyakuShinseiMap_shinseiMap_ShinseiDto.pra", new TypeToken<ShinseiDto>() {}.getType());
		List<ShinseiMeisaiDto> value = readJson("TestGetHonyoyakuShinseiMap_shinseiMap_ListShinseiMeisaiDto.pra", new TypeToken<List<ShinseiMeisaiDto>>() {}.getType());
		Map<ShinseiDto, List<ShinseiMeisaiDto>> shinseiMap = new HashMap<>();
		shinseiMap.put(key, value);
		Map<TShinsei, List<? extends TShinseiMeisai>> ret = shinseiKanryoService.getHonyoyakuShinseiMap(shinseiMap);
		exportJsonData(ret, "TestGetHonyoyakuShinseiMap.json");
	}
}
