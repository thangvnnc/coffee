package jp.ne.yec.seagullLC.stagia.test.junit.service.riyosha;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.google.gson.reflect.TypeToken;

import jp.ne.yec.sane.beans.StringCodeNamePair;
import jp.ne.yec.seagullLC.stagia.beans.enums.domain.NijutorokuHanteiHani;
import jp.ne.yec.seagullLC.stagia.beans.riyosha.OverLapCheckInfoDto;
import jp.ne.yec.seagullLC.stagia.beans.riyosha.RiyoshaDto;
import jp.ne.yec.seagullLC.stagia.entity.MKanri;
import jp.ne.yec.seagullLC.stagia.service.riyosha.RiyoshaService;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestRiyoshaService extends JunitBase{

	@Autowired
	RiyoshaService riyoshaService;

	@Test
	@DisplayName("銀行名リストを生成し返却します.")
	@TestInitDataFile("TestGetGinkoNameListInit.xlsx")
	public void TestGetGinkoNameList() throws Exception {
		List<List<StringCodeNamePair>> jsonData = new ArrayList<List<StringCodeNamePair>>();
		List<StringCodeNamePair> ret = riyoshaService.getGinkoNameList();
		assertEquals(2, ret.size());
		jsonData.add(ret);
		exportJsonData(jsonData, "TestGetGinkoNameList.json");
	}

	@Test
	@DisplayName("引数の銀行コードを基に、支店名リストを取得し返却します.")
	@TestInitDataFile("TestGetShitenNameListInit.xlsx")
	public void TestGetShitenNameList() throws Exception {
		List<List<StringCodeNamePair>> jsonData = new ArrayList<List<StringCodeNamePair>>();
		// Gọi hàm đọc dữ liệu parameter từ file
		List<Short> params = new ArrayList<Short>();
		params.add((short)1);

		// Gọi hàm

	 	List<StringCodeNamePair> ret = riyoshaService.getShitenNameList(params.get(0));
	 	assertEquals(2, ret.size());
	 	jsonData.add(ret);
		exportJsonData(jsonData, "TestGetShitenNameList.json");
	}

	@Test
	@DisplayName("引数の銀行コードを基に、支店名リストを取得し返却します.")
	@TestInitDataFile("TestToDtoRiyoshaInit.xlsx")
	public void TestToDtoRiyosha() throws Exception {
		List<RiyoshaDto> jsonData = new ArrayList<RiyoshaDto>();
		// Gọi hàm đọc dữ liệu parameter từ file
		List<String> params = new ArrayList<String>();
		params.add("sicvn");

		// Gọi hàm

		RiyoshaDto ret = riyoshaService.toDtoRiyosha(params.get(0));
	 	assertNotNull(ret);
	 	jsonData.add(ret);
		exportJsonData(jsonData, "TestToDtoRiyosha.json");
	}


	@Test
	@DisplayName("銀行名リストを生成し返却します.")
	@TestInitDataFile("TestGetGinkoNameListInit.xlsx")
	public void TestOverLapCheckInfoDto() throws Exception {
		List<OverLapCheckInfoDto> jsonData = new ArrayList<OverLapCheckInfoDto>();
		OverLapCheckInfoDto ret = riyoshaService.getOverLapCheckInfo();
		assertNotNull(ret);
		jsonData.add(ret);
		exportJsonData(jsonData, "TestOverLapCheckInfoDto.json");
	}

	@Test
	@DisplayName("ログイン職員が参照可能な管理名を取得します（職員用）")
	public void TestGetKanriNameListShokuin() throws Exception {
		List<List<MKanri>> jsonData = new ArrayList<List<MKanri>>();
		List<Short> kanriCodes = new ArrayList<>();
		List<MKanri> ret = riyoshaService.getKanriNameListShokuin(kanriCodes);
		assertEquals(2, ret.size());
		jsonData.add(ret);
		exportJsonData(jsonData, "TestGetKanriNameListShokuin.json");
	}

	@Test
	@DisplayName("管理コード元に料金体系を取得します")
	public void TestGetRyokinTaikeiList() throws Exception {
		List<List<StringCodeNamePair>> jsonData = new ArrayList<List<StringCodeNamePair>>();
		// Gọi hàm đọc dữ liệu parameter từ file
	    List<Short> params = new ArrayList<Short>();
	    params.add((short)1);


    	List<StringCodeNamePair> ret = riyoshaService.getRyokinTaikeiList(params.get(0));
    	assertEquals(2, ret.size());
    	jsonData.add(ret);
	    exportJsonData(jsonData, "TestGetRyokinTaikeiList.json");
	}

	@Test
	@DisplayName("使用目的を取得します")
	@TestInitDataFile("TestGetShiyoMokutekiListInit.xlsx")
	public void TestGetShiyoMokutekiList() throws Exception {
		List<List<StringCodeNamePair>> jsonData = new ArrayList<List<StringCodeNamePair>>();
		List<StringCodeNamePair> ret = riyoshaService.getShiyoMokutekiList();
		assertEquals(4, ret.size());
		jsonData.add(ret);
	    exportJsonData(jsonData, "TestGetShiyoMokutekiList.json");
	}

	@Test
	@DisplayName("停止理由名を取得します")
	@TestInitDataFile("TestGetTeishiRiyuListInit.xlsx")
	public void TestGetTeishiRiyuList() throws Exception {
		List<List<StringCodeNamePair>> jsonData = new ArrayList<List<StringCodeNamePair>>();
		List<StringCodeNamePair> ret = riyoshaService.getTeishiRiyuList();
		assertNotNull(ret);
		jsonData.add(ret);
		 exportJsonData(jsonData, "TestGetTeishiRiyuList.json");
	}

	@Test
	@DisplayName("管理コード元に料金計算項目名を取得します")
	public void TestGetRyokinKeisanKomokuList() throws Exception {
		// Gọi hàm đọc dữ liệu parameter từ file
		List<List<StringCodeNamePair>> jsonData = new ArrayList<List<StringCodeNamePair>>();
	    List<Short> params = new ArrayList<Short>();
	    params.add((short)1);


    	List<StringCodeNamePair> ret = riyoshaService.getRyokinKeisanKomokuList(params.get(0));
    	assertEquals(2, ret.size());
    	jsonData.add(ret);
	    exportJsonData(jsonData, "TestGetRyokinKeisanKomokuList.json");
	}

	@Test
	@DisplayName("管理コード、料金計算項目コード元に料金計算内容を取得します")
	public void TestGetRyokinKeisanList() throws Exception {
		// Gọi hàm đọc dữ liệu kanriCodes từ file
		List<List<StringCodeNamePair>> jsonData = new ArrayList<List<StringCodeNamePair>>();
	    List<Short> kanriCodes = new ArrayList<Short>();
	    kanriCodes.add((short)1);

	    // Gọi hàm đọc dữ liệu ryokinKeisanKomoku từ file
	    List<Short> ryokinKeisanKomokus = new ArrayList<Short>();
	    ryokinKeisanKomokus.add((short)1);


    	List<StringCodeNamePair> ret = riyoshaService.getRyokinKeisanList(kanriCodes.get(0), ryokinKeisanKomokus.get(0));
    	assertEquals(2, ret.size());
    	jsonData.add(ret);

	    exportJsonData(jsonData, "TestGetRyokinKeisanList.json");
	}

	@Test
	@DisplayName("利用者グループリストを取得します")
	@TestInitDataFile("TestGetRiyoshaGroupListInit.xlsx")
	public void TestGetRiyoshaGroupList() throws Exception {
		List<List<StringCodeNamePair>> jsonData = new ArrayList<List<StringCodeNamePair>>();
		List<StringCodeNamePair> ret = riyoshaService.getRiyoshaGroupList();
		assertEquals(10, ret.size());
		jsonData.add(ret);
		exportJsonData(jsonData, "TestGetRiyoshaGroupList.json");
	}

	@Test
	@DisplayName("申請グループリストを取得します")
	@TestInitDataFile("TestGetShinseiGroupInit.xlsx")
	public void TestGetShinseiGroup() throws Exception {
		List<List<StringCodeNamePair>> jsonData = new ArrayList<List<StringCodeNamePair>>();
		List<StringCodeNamePair> ret = riyoshaService.getShinseiGroup();
		assertEquals(5, ret.size());
		jsonData.add(ret);
		exportJsonData(jsonData, "TestGetShinseiGroup.json");
	}

	@Test
	@DisplayName("引数で指定された利用者の存在有無を確認します.")
	public void TestInsertRiyoshaByRiyosha() throws Exception{

		RiyoshaDtoTest riyoshaDtotest = readJson("TestInsertRiyoshaByRiyosha_riyoshaDto.json", new TypeToken<RiyoshaDtoTest>(){}.getType());
		RiyoshaDto riyoshaDto = new RiyoshaDto();
		riyoshaDto.setLoginId("sicvn");
		riyoshaDto.setKannriCode(riyoshaDtotest.getKannriCode());
		riyoshaDto.setPassword(riyoshaDtotest.getPassword());
		riyoshaDto.setSelectedTorokuKubun(riyoshaDtotest.getSelectedTorokuKubun());
		riyoshaDto.setSelectedGinkoCode(riyoshaDtotest.getSelectedGinkoCode());
		riyoshaDto.setSelectedShitenCode(riyoshaDtotest.getSelectedShitenCode());
		riyoshaDto.setSelectedKozaShubetsu(riyoshaDtotest.getSelectedKozaShubetsu());
		riyoshaDto.setSelectedRiyoshaGroupCode(riyoshaDtotest.getSelectedRiyoshaGroupCode());
		riyoshaDto.setSelectedSoshinTiming(riyoshaDtotest.getSelectedSoshinTiming());
		riyoshaDto.setSelectedShinseiGroupCode(riyoshaDtotest.getSelectedShinseiGroupCode());
		riyoshaDto.setUserName(riyoshaDtotest.getUserName());
		riyoshaDto.setMaxKoseiinCode(riyoshaDtotest.getMaxKoseiinCode());
		riyoshaDto.setKoseiinJohoDto(riyoshaDtotest.getKoseiinJohoDto());
		riyoshaDto.setRiyoKanoShinseiGroupDto(riyoshaDtotest.getRiyoKanoShinseiGroupDto());
		riyoshaDto.setKanribetsuRiyoshaJohoDto(riyoshaDtotest.getKanribetsuRiyoshaJohoDto());
		riyoshaDto.setRyokinSetteiDto(riyoshaDtotest.getRyokinSetteiDto());
		riyoshaDto.setRiyoshaUketoriMailDto(riyoshaDtotest.getRiyoshaUketoriMailDto());
		// カレンダー用
		riyoshaDto.setDatepick(riyoshaDtotest.getDatepick());
		riyoshaDto.setDatepickStart(riyoshaDtotest.getDatepickStart());
		riyoshaDto.setDatepickEnd(riyoshaDtotest.getDatepickEnd());

		// 職員検索用
		//String loginId;
		riyoshaDto.setShokuinKanaName(riyoshaDtotest.getShokuinKanaName());
		riyoshaDto.setKanrimei(riyoshaDtotest.getKanrimei());

		List<NijutorokuHanteiHani> nijutorokuHanteiHanis = new ArrayList<NijutorokuHanteiHani>();
		nijutorokuHanteiHanis.add(NijutorokuHanteiHani.NONE);
		//RiyoshaDto riyoshaDto NijutorokuHanteiHani nijutorokuHanteiHani

		riyoshaService.insertRiyoshaByRiyosha(riyoshaDto, nijutorokuHanteiHanis.get(0));

	}

	@Test
	@DisplayName("引数で指定された利用者の存在有無を確認します.")
	public void TestUpdateRiyoshaByRiyosha() throws Exception{
		List<RiyoshaDto> riyoshaDtos = new ArrayList<RiyoshaDto>();
		RiyoshaDto riyoshaDto = new RiyoshaDto();
		riyoshaDtos.add(riyoshaDto);

		List<RiyoshaDto> beforeRiyoshaDtos = new ArrayList<RiyoshaDto>();
		RiyoshaDto beforeRiyoshaDto = new RiyoshaDto();
		beforeRiyoshaDtos.add(beforeRiyoshaDto);

		List<NijutorokuHanteiHani> nijutorokuHanteiHanis = new ArrayList<NijutorokuHanteiHani>();
		nijutorokuHanteiHanis.add(NijutorokuHanteiHani.KONZAI);

		//RiyoshaDto riyoshaDto, RiyoshaDto beforeRiyoshaDto, NijutorokuHanteiHani nijutorokuHanteiHani

		riyoshaService.updateRiyoshaByRiyosha(riyoshaDtos.get(0), beforeRiyoshaDtos.get(0), nijutorokuHanteiHanis.get(0));

	}
//
	@Test
	@DisplayName("引数で指定された利用者の存在有無を確認します.")
	public void TestInsertRiyoshaByShokuin() throws Exception{
		List<RiyoshaDto> riyoshaDtos = new ArrayList<RiyoshaDto>();
		RiyoshaDto riyoshaDto = new RiyoshaDto();
		riyoshaDtos.add(riyoshaDto);

		List<String> shokuinLoginIds = new ArrayList<String>();
		shokuinLoginIds.add("LoginId1");
		shokuinLoginIds.add("LoginId2");

		List<NijutorokuHanteiHani> nijutorokuHanteiHanis = new ArrayList<NijutorokuHanteiHani>();
		nijutorokuHanteiHanis.add(NijutorokuHanteiHani.KONZAI);

		//RiyoshaDto riyoshaDto, String shokuinLoginId 	NijutorokuHanteiHani nijutorokuHanteiHani
		riyoshaService.insertRiyoshaByShokuin(riyoshaDtos.get(0), shokuinLoginIds.get(0), nijutorokuHanteiHanis.get(0));
	}

	@Test
	@DisplayName("引数で指定された利用者の存在有無を確認します.")
	public void TestUpdateRiyoshaByShokuin() throws Exception{
		List<RiyoshaDto> riyoshaDtos = new ArrayList<RiyoshaDto>();
		RiyoshaDto riyoshaDto = new RiyoshaDto();
		riyoshaDtos.add(riyoshaDto);

		List<RiyoshaDto> beforeRiyoshaDtos = new ArrayList<RiyoshaDto>();
		RiyoshaDto beforeRiyoshaDto = new RiyoshaDto();
		beforeRiyoshaDtos.add(beforeRiyoshaDto);


		List<String> shokuinLoginIds = new ArrayList<String>();
		shokuinLoginIds.add("LoginId1");
		shokuinLoginIds.add("LoginId2");


		List<NijutorokuHanteiHani> nijutorokuHanteiHanis = new ArrayList<NijutorokuHanteiHani>();
		nijutorokuHanteiHanis.add(NijutorokuHanteiHani.KONZAI);

		//RiyoshaDto riyoshaDto, RiyoshaDto beforeRiyoshaDto, String shokuinLoginId,
		//NijutorokuHanteiHani nijutorokuHanteiHani

			riyoshaService.updateRiyoshaByShokuin(riyoshaDtos.get(0), beforeRiyoshaDtos.get(0), shokuinLoginIds.get(0), nijutorokuHanteiHanis.get(0));

	}

	@Test
	@DisplayName("引数で指定された利用者の存在有無を確認します.")
	public void TestLogicalDeleteRiyosha() throws Exception{
		List<RiyoshaDto> riyoshaDtos = new ArrayList<RiyoshaDto>();
		RiyoshaDto riyoshaDto = new RiyoshaDto();
		riyoshaDtos.add(riyoshaDto);


		List<String> shokuinLoginIds = new ArrayList<String>();
		shokuinLoginIds.add("LoginId1");
		shokuinLoginIds.add("LoginId2");
		//RiyoshaDto riyoshaDto, String shokuinLoginId

			riyoshaService.logicalDeleteRiyosha(riyoshaDtos.get(0), shokuinLoginIds.get(0));

	}
}
