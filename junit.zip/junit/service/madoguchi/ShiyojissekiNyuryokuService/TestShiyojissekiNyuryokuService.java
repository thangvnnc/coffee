package jp.ne.yec.seagullLC.stagia.test.junit.service.madoguchi.ShiyojissekiNyuryokuService;

import static org.junit.Assert.*;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.seagullLC.stagia.beans.madoguchi.ShinseiMeisaiDtoForMadoguchi;
import jp.ne.yec.seagullLC.stagia.entity.MBasho;
import jp.ne.yec.seagullLC.stagia.entity.MKanri;
import jp.ne.yec.seagullLC.stagia.entity.MShisetsu;
import jp.ne.yec.seagullLC.stagia.service.madoguchi.ShiyojissekiNyuryokuService;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestShiyojissekiNyuryokuService extends JunitBase{

	@Autowired
	ShiyojissekiNyuryokuService shiyojissekiNyuryokuService;

	@Test
	@DisplayName("場所名を取得します")
	public void TestGetJissekiKanrimeiList() throws Exception{
		List<List<MKanri>> jsonData = new ArrayList<List<MKanri>>();
		List<Short> kanriCodes = new ArrayList<>();
		List<MKanri> list = shiyojissekiNyuryokuService.getJissekiKanrimeiList(kanriCodes);
		assertEquals(2, list.size());
		jsonData.add(list);
		exportJsonData(jsonData, "TestGetJissekiKanrimeiList.json");
	}

	@Test
	@DisplayName("場所名を取得します")
	public void TestGetBashomeiList() throws Exception{
		List<List<MBasho>> jsonData = new ArrayList<List<MBasho>>();
		List<MBasho> list = shiyojissekiNyuryokuService.getBashomeiList();
		assertEquals(2, list.size());
		jsonData.add(list);
		exportJsonData(jsonData, "TestGetBashomeiList.json");
	}

	@Test
	@DisplayName("施設名を取得します")
	public void TestGetShisetsumeiList() throws Exception{
		List<List<MShisetsu>> jsonData = new ArrayList<List<MShisetsu>>();
		List<Short> listKanriCode = new ArrayList<Short>();
		listKanriCode.add((short)1);
		listKanriCode.add((short)2);

		List<Short> listBashoCode = new ArrayList<Short>();
		listBashoCode.add((short)1);
		listBashoCode.add((short)2);


		List<MShisetsu> list = shiyojissekiNyuryokuService.getShisetsumeiList(
				listKanriCode.get(0),
				listBashoCode.get(0)
				);
		assertEquals(2, list.size());
		jsonData.add(list);

		exportJsonData(jsonData, "TestGetShisetsumeiList.json");
	}

	@Test
	@DisplayName("申請番号(From)、申請番号(To)、管理コード、場所コード、施設コード、使用日(From)、使用日(To)、受付日(From)、受付日(To)、使用日実績有無を元に予約のT_申請明細を取得します.")
	public void TestGetShinseiMeisaiList() throws Exception{
		List<List<ShinseiMeisaiDtoForMadoguchi>> jsonData = new ArrayList<List<ShinseiMeisaiDtoForMadoguchi>>();
		List<List<Integer>> listShinseiBangoFromlst = new ArrayList<List<Integer>>();
		List<Integer> listShinseiBangoFrom = new ArrayList<Integer>();
		listShinseiBangoFrom.add(2016000445);
		listShinseiBangoFromlst.add(listShinseiBangoFrom);
		listShinseiBangoFromlst.add(listShinseiBangoFrom);
		listShinseiBangoFromlst.add(null);

		List<List<Integer>> listShinseiBangoTolst = new ArrayList<List<Integer>>();
		List<Integer> listShinseiBangoTo = new ArrayList<Integer>();
		listShinseiBangoTo.add(2016003117);
		listShinseiBangoTolst.add(listShinseiBangoTo);
		listShinseiBangoTolst.add(null);
		listShinseiBangoTolst.add(listShinseiBangoTo);

		List<List<Short>> listKanriCodes = new ArrayList<List<Short>>();
		List<Short> listKanriCode = new ArrayList<Short>();
		listKanriCode.add((short)1);
		listKanriCode.add((short)2);
		listKanriCodes.add(listKanriCode);
		listKanriCodes.add(listKanriCode);

		List<List<Short>> listBashoCodes = new ArrayList<List<Short>>();
		List<Short> listBashoCode = new ArrayList<Short>();
		listKanriCode.add((short)1);
		listKanriCode.add((short)2);
		listBashoCodes.add(listBashoCode);
		listBashoCodes.add(listBashoCode);

		List<List<Short>> listShisetsuCodes = new ArrayList<List<Short>>();
		List<Short> listShisetsuCode = new ArrayList<Short>();
		listKanriCode.add((short)10);
		listShisetsuCodes.add(listShisetsuCode);
		listShisetsuCodes.add(listShisetsuCode);

		List<List<Boolean>> listShiyojissekiUmuFlgs = new ArrayList<List<Boolean>>();
		List<Boolean> listShiyojissekiUmuFlg = new ArrayList<Boolean>();
		listShiyojissekiUmuFlg.add(true);
		listShiyojissekiUmuFlg.add(false);
		listShiyojissekiUmuFlgs.add(listShiyojissekiUmuFlg);
		listShiyojissekiUmuFlgs.add(listShiyojissekiUmuFlg);

		List<Date> shiyoDateFroms = new ArrayList<Date>();
		List<Date> shiyoDatetos = new ArrayList<Date>();
		String datefrom = 2018 + "/" + 04 + "/" + 01;
		String dateto = 2018 + "/" + 06 + "/" + 30;
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
		Date shiyoDateFrom = formatter.parse(datefrom);
		shiyoDateFroms.add(shiyoDateFrom);
		shiyoDateFroms.add(shiyoDateFrom);
		shiyoDateFroms.add(null);

		Date shiyoDateTo = formatter.parse(dateto);
		shiyoDatetos.add(shiyoDateFrom);
		shiyoDatetos.add(null);
		shiyoDatetos.add(shiyoDateFrom);

		List<Date> uketukebiFroms = new ArrayList<Date>();
		List<Date> uketukebiTos = new ArrayList<Date>();
		String dateketukebifrom = 2018 + "/" + 04 + "/" + 01;
		String dateketukebito = 2018 + "/" + 06 + "/" + 30;
		Date uketukebiFrom = formatter.parse(dateketukebifrom);
		uketukebiFroms.add(uketukebiFrom);
		uketukebiFroms.add(uketukebiFrom);
		uketukebiFroms.add(null);

		Date uketukebiTo = formatter.parse(dateketukebito);
		uketukebiTos.add(uketukebiTo);
		uketukebiTos.add(null);
		uketukebiTos.add(uketukebiTo);

		boolean isShokuinLogin = false;


		List<ShinseiMeisaiDtoForMadoguchi> list = shiyojissekiNyuryokuService.getShinseiMeisaiList(
				listShinseiBangoFromlst.get(0).get(0),
				listShinseiBangoTolst.get(0).get(0),
				listKanriCodes.get(0).get(0),
				listBashoCodes.get(0).get(0),
				listShisetsuCodes.get(0).get(0),
				shiyoDateFroms.get(0),
				shiyoDatetos.get(0),
				uketukebiFroms.get(0),
				uketukebiTos.get(0),
				listShiyojissekiUmuFlgs.get(0).get(0),
				isShokuinLogin
				);
		assertEquals(2, list.size());
		jsonData.add(list);
		exportJsonData(jsonData, "TestGetShinseiMeisaiList.json");
	}

	@Test
	@DisplayName("管理コードを元に審査理由取得します")
	public void TestUpdateTShinseiMeisaiList() throws Exception {
		List<List<ShinseiMeisaiDtoForMadoguchi>> shinseiMeisaiEntityList = new ArrayList<List<ShinseiMeisaiDtoForMadoguchi>>();
		List<ShinseiMeisaiDtoForMadoguchi> shinseiMeisaiEntitys = new ArrayList<ShinseiMeisaiDtoForMadoguchi>();
		ShinseiMeisaiDtoForMadoguchi shinseiMeisaiEntity = new ShinseiMeisaiDtoForMadoguchi();
		shinseiMeisaiEntitys.add(shinseiMeisaiEntity);
		shinseiMeisaiEntityList.add(shinseiMeisaiEntitys);

		String updateBy = "";
		// List<ShinseiMeisaiDtoForMadoguchi> shinseiMeisaiEntityList
			shiyojissekiNyuryokuService.updateTShinseiMeisaiList(shinseiMeisaiEntityList.get(0), updateBy);
	}
}
