package jp.ne.yec.seagullLC.stagia.test.junit.service.madoguchi.MitsumoriSakuseiService;

import static org.junit.Assert.*;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.seagullLC.stagia.beans.criteria.MitsumoriSearchDto;
import jp.ne.yec.seagullLC.stagia.beans.shinsei.ShinseiDto;
import jp.ne.yec.seagullLC.stagia.beans.shinsei.ShinseiMeisaiDto;
import jp.ne.yec.seagullLC.stagia.entity.MBasho;
import jp.ne.yec.seagullLC.stagia.entity.MKanri;
import jp.ne.yec.seagullLC.stagia.entity.MKashidashiTani;
import jp.ne.yec.seagullLC.stagia.entity.MShisetsu;
import jp.ne.yec.seagullLC.stagia.service.madoguchi.MitsumoriSakuseiService;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = { "classpath:TestApplicationContext.xml" })
@WebAppConfiguration
public class TestMitsumoriSakuseiService extends JunitBase {

	@Autowired
	MitsumoriSakuseiService mitsumoriSakuseiService;

	@Test
	@DisplayName("M_管理を取得します")
	public void TestGetMKanri() throws Exception {
		List<List<MKanri>> jsonData = new ArrayList<List<MKanri>>();
		List<Short> kanriCodes = new ArrayList<>();
		List<MKanri> list = mitsumoriSakuseiService.getMKanri(kanriCodes);
		assertEquals(2, list.size());
		jsonData.add(list);
		exportJsonData(jsonData, "TestGetMKanri.json");
	}

	@Test
	@DisplayName("M_場所を取得します")
	@TestInitDataFile("TestGetMBashoInit.xlsx")
	public void TestGetMBasho() throws Exception {
		List<List<MBasho>> jsonData = new ArrayList<List<MBasho>>();
		List<MBasho> list = mitsumoriSakuseiService.getMBasho();
		assertEquals(2, list.size());
		jsonData.add(list);
		exportJsonData(jsonData, "TestGetMBasho.json");
	}

	@Test
	@DisplayName(" 管理、場所コード別のM_施設を保持するMapを返却します")
	@TestInitDataFile("TestGetMShisetsuMapInit.xlsx")
	public void TestGetMShisetsuMap() throws Exception {
		List<Map<Short, Map<Short, List<MShisetsu>>>> jsonData = new ArrayList<Map<Short, Map<Short, List<MShisetsu>>>>();
		List<Short> kanriCodes = new ArrayList<Short>();
		kanriCodes.add((short)10);
		kanriCodes.add((short)14);
		kanriCodes.add((short)20);

		Map<Short, Map<Short, List<MShisetsu>>> map = mitsumoriSakuseiService.getMShisetsuMap(kanriCodes);
		assertEquals(2, map.size());
		jsonData.add(map);
		exportJsonData(jsonData, "TestGetMShisetsuMap.json");
	}

	@Test
	@DisplayName("管理、施設コード別のM_貸出単位を保持するMapを返却します")
	@TestInitDataFile("TestGetMKashidashitaniLogicInit.xlsx")
	public void TestGetMKashidashiTaniMap() throws Exception {
		List<Map<Short, Map<Short, List<MKashidashiTani>>>> jsonData = new ArrayList<Map<Short, Map<Short, List<MKashidashiTani>>>>();
		List<Short> kanriCodes = new ArrayList<Short>();
		kanriCodes.add((short)10);
		kanriCodes.add((short)14);
		kanriCodes.add((short)20);


		Map<Short, Map<Short, List<MKashidashiTani>>> map =
				mitsumoriSakuseiService.getMKashidashiTaniMap(kanriCodes);
		assertEquals(2, map.size());
		jsonData.add(map);

		exportJsonData(jsonData, "TestGetMKashidashiTaniMap.json");
	}

	@Test
	@DisplayName("引数を条件として、申請明細Dtoを取得します.")
	@TestInitDataFile("TestGetMShinseiMeisaiInit.xlsx")
	public void TestGetShinseiMeisai() throws Exception {

		List<List<ShinseiMeisaiDto>> jsonData = new ArrayList<List<ShinseiMeisaiDto>>();
		List<Short> listKanriCode = new ArrayList<Short>();
		listKanriCode.add((short)10);
		listKanriCode.add((short)20);

		List<Integer> listShinseiNumber = new ArrayList<Integer>();
		listShinseiNumber.add(444);
		listShinseiNumber.add(2016000446);

		boolean isShokuinLogin = false;


		List<ShinseiMeisaiDto> list = mitsumoriSakuseiService.getShinseiMeisai(
				listKanriCode.get(0),
				listShinseiNumber.get(0),
				isShokuinLogin
				);
		assertEquals(2, list.size());
		jsonData.add(list);

			exportJsonData(jsonData, "TestGetShinseiMeisai.json");
	}

	@Test
	@DisplayName("最新の申請DTOを取得します.")
	public void TestGetUketsukeBasho() throws Exception {
		List<MBasho> jsonData = new ArrayList<MBasho>();
		Short uketsukeBashoCode = 1;

		MBasho mBasho = mitsumoriSakuseiService.getUketsukeBasho(uketsukeBashoCode);
		assertNotNull(mBasho);
		jsonData.add(mBasho);
		exportJsonData(jsonData, "TestGetUketsukeBasho.json");
	}

	@Test
	@DisplayName("最新の申請DTOを取得します.")
	public void TestGetLatestShinseiDto() throws Exception {

		List<ShinseiDto> jsonData = new ArrayList<ShinseiDto>();
		List<Short> listKanriCode = new ArrayList<Short>();
		listKanriCode.add((short)1);
		listKanriCode.add((short)2);

		List<Integer> listShinseiNumber = new ArrayList<Integer>();
		listShinseiNumber.add(1);
		listShinseiNumber.add(2);

		boolean isShokuinLogin = false;


		ShinseiDto shinseiDto = mitsumoriSakuseiService.getLatestShinseiDto(
				listKanriCode.get(0),
				listShinseiNumber.get(0),
				isShokuinLogin
				);
		assertNotNull(shinseiDto);
		jsonData.add(shinseiDto);
		exportJsonData(jsonData, "TestGetLatestShinseiDto.json");
	}

	@Test
	@DisplayName("最新の申請DTOを取得します.")
	public void TestGetShinseiRirekiList() throws Exception {
		List<List<ShinseiDto>> jsonData = new ArrayList<List<ShinseiDto>>();
		List<MitsumoriSearchDto> searchDto = new ArrayList<MitsumoriSearchDto>();
		MitsumoriSearchDto mitsumoriSearchDto = new MitsumoriSearchDto();
		searchDto.add(mitsumoriSearchDto);

		List<Map<Short, MKanri>> mKanriMaps = new ArrayList<Map<Short, MKanri>>();
		List<Short> mKanriMapKey = new ArrayList<Short>();
		mKanriMapKey.add((short)1);
		mKanriMapKey.add((short)2);

		List<MKanri> mKanriMapValue = new ArrayList<MKanri>();
		MKanri mKanri = new MKanri();
		mKanri.setKanriCode((short) 1);
		mKanri.setKanriName("aaa");
		mKanriMapValue.add(mKanri);

		MKanri mKanri1 = new MKanri();
		mKanri1.setKanriCode((short) 2);
		mKanri1.setKanriName("bbb");
		mKanriMapValue.add(mKanri1);

		for(int mapIdx = 0; mapIdx < mKanriMapKey.size(); mapIdx++)
		{
			Map<Short, MKanri> mKanriMap = new HashMap<Short, MKanri>();
			mKanriMap.put(mKanriMapKey.get(mapIdx), mKanriMapValue.get(mapIdx));
			mKanriMaps.add(mKanriMap);
		}
		//MitsumoriSearchDto searchDto, Map<Short, MKanri> mKanriMap
			List<ShinseiDto> shinseiDto = mitsumoriSakuseiService.getShinseiRirekiList(
					searchDto.get(0),
					mKanriMaps.get(0)
					);
			assertEquals(2, shinseiDto.size());
			jsonData.add(shinseiDto);
		exportJsonData(jsonData, "TestGetShinseiRirekiList.json");
	}

	@Test
	@DisplayName("最新の申請DTOを取得します.")
	public void TestMakeMitsumoriMeisaiDto() throws Exception {

		List<ShinseiMeisaiDto> jsonData = new ArrayList<ShinseiMeisaiDto>();
		List<String> names = new ArrayList<String>();
		names.add("1");
		names.add("2");

		List<MShisetsu> MShisetsus = new ArrayList<MShisetsu>();
		MShisetsu mShisetsu = new MShisetsu();
		MShisetsus.add(mShisetsu);

		List<MKashidashiTani> MKashidashiTanis = new ArrayList<MKashidashiTani>();
		MKashidashiTani MKashidashiTani = new MKashidashiTani();
		MKashidashiTanis.add(MKashidashiTani);

		List<Date> dates = new ArrayList<Date>();
		String date = 2018 + "/" + 06 + "/" + 19;
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
		Date shunoDate = formatter.parse(date);
		dates.add(shunoDate);

		List<String> shiyoTimeStart = new ArrayList<String>();
		shiyoTimeStart.add("1700");

		List<String> shiyoTimeEnd = new ArrayList<String>();
		shiyoTimeEnd.add("1300");

		List<Integer> ints = new ArrayList<Integer>();
		ints.add(1);

		Short uketsukeBashoCode = 1;

		// String name, MShisetsu mShisetsu, MKashidashiTani kashidashiTani,
		// Date shiyoDate, String shiyoTimeStart, String shiyoTimeEnd, int int
		ShinseiMeisaiDto shinseiDto = mitsumoriSakuseiService.makeMitsumoriMeisaiDto(
				names.get(0),
				MShisetsus.get(0),
				MKashidashiTanis.get(0),
				dates.get(0),
				shiyoTimeStart.get(0),
				shiyoTimeEnd.get(0),
				ints.get(0),
				uketsukeBashoCode
				);
		assertNotNull(shinseiDto);
		jsonData.add(shinseiDto);

		exportJsonData(jsonData, "TestMakeMitsumoriMeisaiDto.json");
	}

	@Test
	@DisplayName("最新の申請DTOを取得します.")
	public void TestSetShinseiInitialData() throws Exception {
		List<ShinseiDto> shinseiDtos = new ArrayList<ShinseiDto>();
		ShinseiDto shinseiDto = new ShinseiDto();
		shinseiDtos.add(shinseiDto);

		// ShinseiDto shinseiDto
			mitsumoriSakuseiService.setShinseiInitialData(shinseiDtos.get(0));
	}

	@Test
	@DisplayName("最新の申請DTOを取得します.")
	@TestInitDataFile("TestSetLatestVersionInit")
	public void TestSetLatestVersion() throws Exception {
		List<ShinseiDto> shinseiDtos = new ArrayList<ShinseiDto>();
		ShinseiDto shinseiDto = new ShinseiDto();
		shinseiDtos.add(shinseiDto);

		List<ShinseiDto> shinseiBeforeChange = new ArrayList<ShinseiDto>();
		ShinseiDto shinseiBefore = new ShinseiDto();
		shinseiBeforeChange.add(shinseiBefore);

		List<List<ShinseiMeisaiDto>> meisaiDtos = new ArrayList<List<ShinseiMeisaiDto>>();
		List<ShinseiMeisaiDto> meisaiDtoList = new ArrayList<ShinseiMeisaiDto>();
		ShinseiMeisaiDto ShinseiMeisaiDto = new ShinseiMeisaiDto();
		meisaiDtoList.add(ShinseiMeisaiDto);
		meisaiDtos.add(meisaiDtoList);


		List<Map<Integer, ShinseiMeisaiDto>> shinseiMapList = new ArrayList<Map<Integer, ShinseiMeisaiDto>>();
		List<Integer> shinseiMapKey = new ArrayList<Integer>();
		shinseiMapKey.add(1);
		shinseiMapKey.add(2);

		List<ShinseiMeisaiDto> shinseiMaps = new ArrayList<ShinseiMeisaiDto>();
		ShinseiMeisaiDto ShinseiMeisai = new ShinseiMeisaiDto();
		ShinseiMeisaiDto ShinseiMeisai1 = new ShinseiMeisaiDto();
		shinseiMaps.add(ShinseiMeisai);
		shinseiMaps.add(ShinseiMeisai1);

		for(int mapIdx = 0; mapIdx < shinseiMapKey.size(); mapIdx++)
		{
			Map<Integer, ShinseiMeisaiDto> shinseiMap = new HashMap<Integer, ShinseiMeisaiDto>();
			shinseiMap.put(shinseiMapKey.get(mapIdx),shinseiMaps.get(mapIdx));
			shinseiMapList.add(shinseiMap);
		}

		List<Map<Short, List<MKashidashiTani>>> kashidashiTaniMapList = new ArrayList<Map<Short, List<MKashidashiTani>>>();
		List<Short> kashidashiTaniMapKey = new ArrayList<Short>();
		kashidashiTaniMapKey.add((short)1);
		//kashidashiTaniMapKey.add((short)2);

		List<List<MKashidashiTani>> kashidashiTaniMaps = new ArrayList<List<MKashidashiTani>>();
		List<MKashidashiTani> kashidashiTaniMapValue = new ArrayList<MKashidashiTani>();
		MKashidashiTani MKashidashiTani = new MKashidashiTani();
		kashidashiTaniMapValue.add(MKashidashiTani);
		kashidashiTaniMaps.add(kashidashiTaniMapValue);

		for(int mapIdx = 0; mapIdx < kashidashiTaniMapKey.size(); mapIdx++)
		{
			Map<Short, List<MKashidashiTani>> kashidashiTaniMap = new HashMap<Short, List<MKashidashiTani>>();
			kashidashiTaniMap.put(kashidashiTaniMapKey.get(mapIdx),kashidashiTaniMaps.get(mapIdx));
			kashidashiTaniMapList.add(kashidashiTaniMap);
		}


		// ShinseiDto shinseiDto, ShinseiDto shinseiBeforeChange, List<ShinseiMeisaiDto> meisaiDtos,
		// Map<Integer, ShinseiMeisaiDto> meisaiBeforeChange, Map<Short, List<MKashidashiTani>> kashidashiTaniMap
			mitsumoriSakuseiService.setLatestVersion(
					shinseiDtos.get(0),
					shinseiBeforeChange.get(0),
					meisaiDtos.get(0),
					shinseiMapList.get(0),
					kashidashiTaniMapList.get(0)
					);
	}

	@Test
	@DisplayName("最新の申請DTOを取得します.")
	public void TestSetTKanribetsuRiyoshaJohoInfo() throws Exception {
		List<List<ShinseiMeisaiDto>> addedDtos = new ArrayList<List<ShinseiMeisaiDto>>();
		List<ShinseiMeisaiDto> addedDtolist = new ArrayList<ShinseiMeisaiDto>();
		ShinseiMeisaiDto shinseiMeisaiDto = new ShinseiMeisaiDto();
		addedDtolist.add(shinseiMeisaiDto);
		addedDtos.add(addedDtolist);

		List<String> loginIds = new ArrayList<String>();
		loginIds.add("1");
		//loginIds.add("2");

		List<Date> toshoUketsukeDates = new ArrayList<Date>();
		String date = 2018 + "/" + 06 + "/" + 20;
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
		Date shunoDate = formatter.parse(date);
		toshoUketsukeDates.add(shunoDate);

		// String loginId, List<ShinseiMeisaiDto> addedDtos, Date toshoUketsukeDate
			mitsumoriSakuseiService.setTKanribetsuRiyoshaJohoInfo(loginIds.get(0), addedDtos.get(0), toshoUketsukeDates.get(0));
	}
}
