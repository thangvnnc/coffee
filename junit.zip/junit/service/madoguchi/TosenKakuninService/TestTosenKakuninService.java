package jp.ne.yec.seagullLC.stagia.test.junit.service.madoguchi.TosenKakuninService;

import static org.junit.Assert.*;

import java.time.YearMonth;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.seagullLC.stagia.beans.shinsei.ShinseiDto;
import jp.ne.yec.seagullLC.stagia.beans.shinsei.ShinseiMeisaiDto;
import jp.ne.yec.seagullLC.stagia.service.madoguchi.TosenKakuninService;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestTosenKakuninService extends JunitBase{

	@Autowired
	TosenKakuninService tosenKakuninService;

	@Test
	@DisplayName("管理コードと申請番号を元に申請Dtoを取得します.")
	public void TestGetShinseiMeisai() throws Exception{
		List<List<ShinseiMeisaiDto>> jsonData = new ArrayList<List<ShinseiMeisaiDto>>();
		List<String> listLoginId = new ArrayList<String>();
		listLoginId.add("1");
		listLoginId.add("2");

		List<YearMonth> shiyoMonthFroms = new ArrayList<YearMonth>();
		YearMonth shiyoMonthFrom = YearMonth.now();
		shiyoMonthFroms.add(shiyoMonthFrom);
		shiyoMonthFroms.add(null);

		YearMonth shiyoMonthFrom1 = YearMonth.of(0000,12);
		shiyoMonthFroms.add(shiyoMonthFrom1);

		List<YearMonth> shiyoMonthTos = new ArrayList<YearMonth>();
		YearMonth shiyoMonthTo = YearMonth.now();
		shiyoMonthTos.add(shiyoMonthTo);
		shiyoMonthTos.add(null);

		YearMonth shiyoMonthTo1 = YearMonth.of(0000, 12);
		shiyoMonthTos.add(shiyoMonthTo1);

		boolean isShokuinLogin = false;


		List<ShinseiMeisaiDto> list = tosenKakuninService.getShinseiMeisai(
				listLoginId.get(0),
				shiyoMonthFroms.get(0),
				shiyoMonthTos.get(0),
				isShokuinLogin
				);
		assertEquals(2, list.size());
		jsonData.add(list);

		exportJsonData(jsonData, "TestGetShinseiMeisai.json");

	}

	@Test
	@DisplayName("管理コードと申請番号を元に申請Dtoを取得します.")
	public void TestGetKanrimeiList() throws Exception{
		List<ShinseiDto> jsonData = new ArrayList<ShinseiDto>();
		List<Short> listKanriCode = new ArrayList<Short>();// readArrShort("TestGetKanrimeiList_kanriCode.txt");
		listKanriCode.add((short)1);
		listKanriCode.add((short)2);

		List<Integer> listShinseiNumber = new ArrayList<Integer>();//readArrInteger("TestGetKanrimeiList_shinseiNumber.txt");
		listShinseiNumber.add(1);
		listShinseiNumber.add(2);

		ShinseiDto shinseiDto = tosenKakuninService.getShinseiDto(
				listKanriCode.get(0),
				listShinseiNumber.get(0)
				);
		assertNotNull(shinseiDto);
		jsonData.add(shinseiDto);
		exportJsonData(jsonData, "TestGetKanrimeiList.json");

	}

	@Test
	@DisplayName("管理コードと申請番号を元に申請Dtoを取得します.")
	public void TestUpdateTShinseiList() throws Exception{
		List<List<ShinseiDto>> shinseiDtoList = new ArrayList<List<ShinseiDto>>();
		List<ShinseiDto> shinseiDtos = new ArrayList<ShinseiDto>();
		ShinseiDto shinseiDto = new ShinseiDto();
		shinseiDtos.add(shinseiDto);
		shinseiDtoList.add(shinseiDtos);

		String updateBy = "";
		//List<ShinseiDto> shinseiDtoList

		tosenKakuninService.updateTShinseiList(shinseiDtoList.get(0), updateBy);

	}
}
