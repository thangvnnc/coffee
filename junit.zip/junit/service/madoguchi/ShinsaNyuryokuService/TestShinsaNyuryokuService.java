package jp.ne.yec.seagullLC.stagia.test.junit.service.madoguchi.ShinsaNyuryokuService;

import static org.junit.Assert.*;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.seagullLC.stagia.beans.madoguchi.ShinseiMeisaiDtoForMadoguchi;
import jp.ne.yec.seagullLC.stagia.entity.MBasho;
import jp.ne.yec.seagullLC.stagia.entity.MKanri;
import jp.ne.yec.seagullLC.stagia.entity.MShinsaRiyu;
import jp.ne.yec.seagullLC.stagia.entity.MShisetsu;
import jp.ne.yec.seagullLC.stagia.service.madoguchi.ShinsaNyuryokuService;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = { "classpath:TestApplicationContext.xml" })
@WebAppConfiguration
public class TestShinsaNyuryokuService extends JunitBase {

	@Autowired
	ShinsaNyuryokuService shinsaNyuryokuService;

	@Test
	@DisplayName("場所名を取得します")
	public void TestGetKanrimeiList() throws Exception {
		List<List<MKanri>> jsonData = new ArrayList<List<MKanri>>();
		List<Short> kanriCodes = new ArrayList<>();
		List<MKanri> list = shinsaNyuryokuService.getKanrimeiList(kanriCodes);
		assertEquals(2, list.size());
		jsonData.add(list);
		exportJsonData(jsonData, "TestGetKanrimeiList.json");
	}

	@Test
	@DisplayName("場所名を取得します")
	@TestInitDataFile("TestGetMBashoInit.xlsx")
	public void TestGetBashomeiList() throws Exception {
		List<List<MBasho>> jsonData = new ArrayList<List<MBasho>>();
		List<MBasho> list = shinsaNyuryokuService.getBashomeiList();
		assertEquals(2, list.size());
		jsonData.add(list);
		exportJsonData(jsonData, "TestGetBashomeiList.json");
	}

	@Test
	@DisplayName("施設名を取得します")
	@TestInitDataFile("TestGetShisetsumeiListInit.xlsx")
	public void TestGetShisetsumeiList() throws Exception {
		List<List<MShisetsu>> jsonData = new ArrayList<List<MShisetsu>>();
		List<Short> listKanriCode = new ArrayList<Short>();
		listKanriCode.add((short)10);
		listKanriCode.add((short)14);

		List<Short> listBashoCode = new ArrayList<Short>();
		listBashoCode.add((short)10);
		listBashoCode.add((short)30);


		List<MShisetsu> list = shinsaNyuryokuService.getShisetsumeiList(listKanriCode.get(0), listBashoCode.get(0));
		assertEquals(2, list.size());
		jsonData.add(list);

		exportJsonData(jsonData, "TestGetShisetsumeiList.json");
	}

	@Test
	@DisplayName("申請番号(From)、申請番号(To)、管理コード、場所コード、施設コード、使用日(From)、使用日(To)、受付日(From)、受付日(To)、審査区分を元に仮予約のT_申請明細を取得します.")
	@TestInitDataFile("TestGetShinseiMeisaiListInit.xlsx")
	public void TestGetShinseiMeisaiList() throws Exception {
		List<List<ShinseiMeisaiDtoForMadoguchi>> jsonData = new ArrayList<List<ShinseiMeisaiDtoForMadoguchi>>();
		List<Integer> listShinseiBangoFrom = new ArrayList<Integer>();
		listShinseiBangoFrom.add(1);
		listShinseiBangoFrom.add(2);

		List<Integer> listShinseiBangoTo = new ArrayList<Integer>();
		listShinseiBangoTo.add(1);
		listShinseiBangoTo.add(2);

		List<Short> listKanriCode = new ArrayList<Short>();
		listKanriCode.add((short)1);
		listKanriCode.add((short)2);

		List<Short> listBashoCode = new ArrayList<Short>();
		listBashoCode.add((short)1);
		listBashoCode.add((short)2);

		List<Short> listShisetsuCode = new ArrayList<Short>();
		listShisetsuCode.add((short)1);
		listShisetsuCode.add((short)2);

		List<String> shinsaKubunCodeList = new ArrayList<String>();
		shinsaKubunCodeList.add("1");
		shinsaKubunCodeList.add("2");

		String date = 2018 + "/" + 06 + "/" + 19;
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
		Date shiyoDateFrom = formatter.parse(date);

		String date1 = 2018 + "/" + 06 + "/" + 19;
		Date shiyoDateTo = formatter.parse(date1);

		String date2 = 2018 + "/" + 06 + "/" + 19;
		Date uketukebiFrom = formatter.parse(date2);

		String date3 = 2018 + "/" + 06 + "/" + 19;
		Date uketukebiTo = formatter.parse(date3);

		boolean isShokuinLogin = false;


			List<ShinseiMeisaiDtoForMadoguchi> list = shinsaNyuryokuService.getShinseiMeisaiList(
					listShinseiBangoFrom.get(0),
					listShinseiBangoTo.get(0),
					listKanriCode.get(0),
					listBashoCode.get(0),
					listShisetsuCode.get(0),
					shiyoDateFrom,
					shiyoDateTo,
					uketukebiFrom,
					uketukebiTo,
					shinsaKubunCodeList,
					isShokuinLogin
					);
			assertEquals(2, list.size());
			jsonData.add(list);

		exportJsonData(jsonData, "TestGetShinseiMeisaiList.json");
	}

	@Test
	@DisplayName("管理コードを元に審査理由取得します")
	@TestInitDataFile("TestGetShinsaRiyuListInit.xlsx")
	public void TestGetShinsaRiyuList() throws Exception {
		List<List<MShinsaRiyu>> jsonData = new ArrayList<List<MShinsaRiyu>>();
		List<Short> listKanriCode = new ArrayList<Short>();
		listKanriCode.add((short)1);
		listKanriCode.add((short)2);

		List<MShinsaRiyu> list = shinsaNyuryokuService.getShinsaRiyuList(listKanriCode.get(0));
		assertEquals(2, list.size());
		jsonData.add(list);

		exportJsonData(jsonData, "TestGetShinsaRiyuList.json");
	}

	@Test
	@DisplayName("管理コードを元に審査理由取得します")
	public void TestUpdateTShinseiMeisaiList() throws Exception {
		List<List<ShinseiMeisaiDtoForMadoguchi>> shinseiMeisaiEntityList = new ArrayList<List<ShinseiMeisaiDtoForMadoguchi>>();
		List<ShinseiMeisaiDtoForMadoguchi> shinseiMeisaiEntitys = new ArrayList<ShinseiMeisaiDtoForMadoguchi>();
		ShinseiMeisaiDtoForMadoguchi shinseiMeisaiEntity = new ShinseiMeisaiDtoForMadoguchi();
		shinseiMeisaiEntitys.add(shinseiMeisaiEntity);
		shinseiMeisaiEntityList.add(shinseiMeisaiEntitys);

		String updateBy = "";
		// List<ShinseiMeisaiDtoForMadoguchi> shinseiMeisaiEntityList
		shinsaNyuryokuService.updateTShinseiMeisaiList(shinseiMeisaiEntityList.get(0), updateBy);
	}
}
