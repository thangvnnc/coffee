package jp.ne.yec.seagullLC.stagia.test.junit.service.madoguchi.KariYoyakuTogoService;

import static org.junit.Assert.*;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.seagullLC.stagia.beans.shinsei.ShinseiDto;
import jp.ne.yec.seagullLC.stagia.beans.shinsei.ShinseiMeisaiDto;
import jp.ne.yec.seagullLC.stagia.entity.MKanri;
import jp.ne.yec.seagullLC.stagia.service.madoguchi.KariYoyakuTogoService;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = { "classpath:TestApplicationContext.xml" })
@WebAppConfiguration
public class TestKariYoyakuTogoService extends JunitBase {

	@Autowired
	KariYoyakuTogoService kariYoyakuTogoService;

	@Test
	@DisplayName("ログイン職員が参照可能な管理名を取得します")
	public void TestGetKanrimeiList() throws Exception {
		List<List<MKanri>> jsonData = new ArrayList<List<MKanri>>();
		List<Short> kanriCodes = new ArrayList<>();
		List<MKanri> list = kariYoyakuTogoService.getKanrimeiList(kanriCodes);
		assertEquals(2, list.size());
		jsonData.add(list);
		exportJsonData(jsonData, "TestGetKanrimeiList.json");
	}

	@Test
	@DisplayName("ログインID、管理コード、使用日(From)、使用日(To)を元に仮予約のT_申請明細を取得します.")
	@TestInitDataFile("TestGetShinseiMeisaiInit.xlsx")
	public void TestGetShinseiMeisai() throws Exception {
		List<List<ShinseiMeisaiDto>> jsonData = new ArrayList<List<ShinseiMeisaiDto>>();

		List<String> listLoginId = new ArrayList<String>();
		listLoginId.add("1");

		List<Short> listKanriCode = new ArrayList<Short>();
		listKanriCode.add((short)70);

		String date = 2018 + "/" + 04 + "/" + 19;
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
		Date shiyoDateFrom = formatter.parse(date);
		Date shiyoDateTo = new Date();

		boolean isShokuinLogin = false;

		List<ShinseiMeisaiDto> list = kariYoyakuTogoService.getShinseiMeisai(
				listLoginId.get(0),
				listKanriCode.get(0),
				shiyoDateFrom,
				shiyoDateTo,
				isShokuinLogin
				);
		assertEquals(2, list.size());
		jsonData.add(list);
		exportJsonData(jsonData, "TestGetShinseiMeisai.json");
	}

	@Test
	@DisplayName("管理コードと申請番号を元に申請Dtoを取得します.")
	public void TestGetShinseiDto() throws Exception {
		List<ShinseiDto> jsonData = new ArrayList<ShinseiDto>();
		List<Short> listKanriCode = new ArrayList<Short>();
		listKanriCode.add((short)10);

		List<Integer> listShinseiNumber = new ArrayList<Integer>();
		listShinseiNumber.add(1);

			ShinseiDto shinseiDto = kariYoyakuTogoService.getShinseiDto(
					listKanriCode.get(0),
					listShinseiNumber.get(0)
					);
			assertNotNull(shinseiDto);
			jsonData.add(shinseiDto);
		exportJsonData(jsonData, "TestGetShinseiDto.json");
	}

	@Test
	@DisplayName("管理コードと収納日をもとに券売機情報を取得します")
	public void TestUpdateAndInsertShinseiInfo() throws Exception {
		List<List<ShinseiMeisaiDto>> shinseiMeisaiDtoLists = new ArrayList<List<ShinseiMeisaiDto>>();
		List<ShinseiMeisaiDto> shinseiMeisaiDtoList = new ArrayList<ShinseiMeisaiDto>();
		ShinseiMeisaiDto shinseiMeisaiDto = new ShinseiMeisaiDto();
		shinseiMeisaiDtoList.add(shinseiMeisaiDto);
		shinseiMeisaiDtoLists.add(shinseiMeisaiDtoList);

		List<Map<ShinseiDto, List<ShinseiMeisaiDto>>> shinseiMaps = new ArrayList<Map<ShinseiDto, List<ShinseiMeisaiDto>>>();
		Map<ShinseiDto, List<ShinseiMeisaiDto>> shinseiMap = new HashMap<ShinseiDto, List<ShinseiMeisaiDto>>();
		ShinseiDto ShinseiDto = new ShinseiDto();
		List<ShinseiMeisaiDto> shinseiMeisaiDtos = new ArrayList<ShinseiMeisaiDto>();
		ShinseiMeisaiDto shinseiMeisai = new ShinseiMeisaiDto();
		shinseiMeisaiDtos.add(shinseiMeisaiDto);
		shinseiMap.put(ShinseiDto, shinseiMeisaiDtos);
		shinseiMaps.add(shinseiMap);

		String updateBy = "";

		// List<ShinseiMeisaiDto> shinseiMeisaiDtoList,
		// Map<ShinseiDto, List<ShinseiMeisaiDto>> shinseiMap

			kariYoyakuTogoService.updateAndInsertShinseiInfo(shinseiMeisaiDtoLists.get(0), shinseiMaps.get(0), updateBy);

	}
}
