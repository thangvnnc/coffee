package jp.ne.yec.seagullLC.stagia.test.junit.service.app.TorokuService;

import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.seagullLC.stagia.service.app.TorokuService;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = { "classpath:TestApplicationContext.xml" })
@WebAppConfiguration
public class TestTorokuService extends JunitBase {

	@Autowired
	TorokuService torokuService;

//	@Test
//	public void TestAppSearchDetail() throws Exception {
//		Map<String, String> mapUnitTest = new HashMap<String, String>();
//		List<String[][]> jsonData = new ArrayList<String[][]>();
//		String[][] map = torokuService.appSearchDetail(mapUnitTest);
//		jsonData.add(map);
//		exportJsonData(jsonData, "TestAppSearchDetail.json");
//	}
//
//	@Test
//	public void TestAppSearchDetailMic() throws Exception {
//		Map<String, String> mapUnitTest = new HashMap<String, String>();
//		List<Map<String, String>> jsonData = new ArrayList<Map<String, String>>();
//		Map<String, String> map = torokuService.appSearchDetailMic(mapUnitTest);
//		jsonData.add(map);
//		exportJsonData(jsonData, "TestAppSearchDetailMic.json");
//	}
}
