package jp.ne.yec.seagullLC.stagia.test.junit.service.app.MoshikomiIchiranService;

import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.seagullLC.stagia.service.app.MoshikomiIchiranService;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = { "classpath:TestApplicationContext.xml" })
@WebAppConfiguration
public class TestMoshikomiIchiranService extends JunitBase {

	@Autowired
	MoshikomiIchiranService moshikomiIchiranService;

//	@Test
//	public void TestAppGetSinsei() throws Exception {
//		List<String> listText = new ArrayList<String>();
//		listText.add("1");
//
//		List<Map<String, String>[]> jsonData = new ArrayList<Map<String, String>[]>();
//		for (String text : listText) {
//			Map<String, String>[] map = moshikomiIchiranService.appGetSinsei(text);
//			jsonData.add(map);
//		}
//
//		exportJsonData(jsonData, "TestAppGetItemIndex.json");
//	}

}
