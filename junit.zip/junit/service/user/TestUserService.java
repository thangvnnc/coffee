package jp.ne.yec.seagullLC.stagia.test.junit.service.user;

import static org.junit.Assert.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.seagullLC.stagia.entity.MChusenGroup;
import jp.ne.yec.seagullLC.stagia.entity.MShisetsuUketsuke;
import jp.ne.yec.seagullLC.stagia.entity.MShokuin;
import jp.ne.yec.seagullLC.stagia.entity.MShokuinKengen;
import jp.ne.yec.seagullLC.stagia.entity.MSystem;
import jp.ne.yec.seagullLC.stagia.entity.MWebKyushibi;
import jp.ne.yec.seagullLC.stagia.entity.TRiyosha;
import jp.ne.yec.seagullLC.stagia.service.user.UserService;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestUserService extends JunitBase{

	@Autowired
	UserService userService;

	@Test
	@TestInitDataFile("TestGetTRiyoshaInit.xlsx")
	public void TestGetTRiyoshaStep1() throws Exception {
		TRiyosha tRiyosha = userService.getTRiyosha("5");
		exportJsonData(tRiyosha, "TestGetTRiyoshaStep1.json");
	}

	@Test
	@TestInitDataFile("TestGetTRiyoshaInit.xlsx")
	public void TestGetTRiyoshaStep2() throws Exception {
		TRiyosha tRiyosha = userService.getTRiyosha("6");
		exportJsonData(tRiyosha, "TestGetTRiyoshaStep2.json");
		writeAppend("1", "log.txt", "D:/log");
	}

	@Test
	@TestInitDataFile("TestGetMChusenGroupMapInit.xlsx")
	public void TestGetMChusenGroupMapStep1() throws Exception {
		Map<Short, Map<Short, MChusenGroup>> map = userService.getMChusenGroupMap((short)1);
		exportJsonData(map, "TestGetMChusenGroupMapStep1.json");
	}

	@Test
	@TestInitDataFile("TestGetMChusenGroupMapInit.xlsx")
	public void TestGetMChusenGroupMapStep2() throws Exception {
		Map<Short, Map<Short, MChusenGroup>> map = userService.getMChusenGroupMap((short)99);
		assertEquals(0, map.size());
	}

	@Test
	@TestInitDataFile("TestGetMChusenGroupMap_ListInit.xlsx")
	public void TestGetMChusenGroupMap_ListStep1() throws Exception {
		List<List<Short>> kanriCodeLists = new ArrayList<List<Short>>();
		List<Short> kanriCodeListItemExist = new ArrayList<>();
		kanriCodeListItemExist.add((short)10);
		kanriCodeListItemExist.add((short)14);
		kanriCodeListItemExist.add((short)24);
		kanriCodeLists.add(kanriCodeListItemExist);

		Map<Short, Map<Short, MChusenGroup>> map = userService.getMChusenGroupMap(kanriCodeListItemExist);
		exportJsonData(map, "TestGetMChusenGroupMap_ListStep1.json");
	}

	@Test
	@TestInitDataFile("TestGetMChusenGroupMap_ListInit.xlsx")
	public void TestGetMChusenGroupMap_ListStep2() throws Exception {
		List<Short> kanriCodeListItemEmpty = new ArrayList<>();
		kanriCodeListItemEmpty.add((short)2);

		Map<Short, Map<Short, MChusenGroup>> map = userService.getMChusenGroupMap(kanriCodeListItemEmpty);
		assertEquals(0, map.size());
	}

	@Test
	@TestInitDataFile("TestGetMShisetsuUketsukeMapInit.xlsx")
	public void TestGetMShisetsuUketsukeMap() throws Exception {
		Map<Short, Map<Short, Map<Short, MShisetsuUketsuke>>> map = userService.getMShisetsuUketsukeMap((short)1);
		exportJsonData(map, "TestGetMShisetsuUketsukeMap.json");
	}

	@Test
	@TestInitDataFile("TestGetMShisetsuUketsukeMap_ListInit.xlsx")
	public void TestGetMShisetsuUketsukeMap_List() throws Exception {
		List<Short> kanriCodeLists = new ArrayList<>();
		kanriCodeLists.add((short)10);
		Map<Short, Map<Short, Map<Short, MShisetsuUketsuke>>> map = userService.getMShisetsuUketsukeMap(kanriCodeLists);

		exportJsonData(map, "TestGetMShisetsuUketsukeMap_List.json");

	}

	@Test
	@TestInitDataFile("TestGetMShokuinKengenInit.xlsx")
	public void TestGetMShokuinKengen() throws Exception {
		Map<Short, MShokuinKengen> map = userService.getMShokuinKengen("1");
		exportJsonData(map, "TestGetMShokuinKengen.json");
	}

	@Test
	@TestInitDataFile("TestGetMShokuinInit.xlsx")
	public void TestGetMShokuin() throws Exception {
		MShokuin mShokuin = userService.getMShokuin("1");
		exportJsonData(mShokuin, "TestGetMShokuin.json");
	}

	@Test
	@TestInitDataFile("TestGetMSystemInit.xlsx")
	public void TestGetMSystem() throws Exception {
		MSystem mSystem = userService.getMSystem();
		exportJsonData(mSystem, "TestGetMSystem.json");
	}
	@Test

	@TestInitDataFile("TestGetMWebKyushibiInit.xlsx")
	public void TestGetMWebKyushibi() throws Exception {
		LocalDate localDate = LocalDate.of(2018, 1, 1);
		MWebKyushibi mWebKyushibi = userService.getMWebKyushibi(localDate);
		exportJsonData(mWebKyushibi, "TestGetMWebKyushibi.json");
	}
}
