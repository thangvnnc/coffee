package jp.ne.yec.seagullLC.stagia.test.junit.service.unei.KihonSetteiService;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestKihonSetteiService extends JunitBase{

	@Autowired
	//KihonSetteiService kihonSetteiService;

	@Test
	@DisplayName("休館基本設定画面の初期表示情報を取得します。")
	public void TestGetInitData() throws Exception{
		//KyukanSetteiDto kyukanSetteiDto = kihonSetteiService.getInitData();
	}
}
