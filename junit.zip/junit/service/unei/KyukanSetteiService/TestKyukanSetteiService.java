package jp.ne.yec.seagullLC.stagia.test.junit.service.unei.KyukanSetteiService;

import static org.junit.Assert.*;

import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.YearMonth;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.seagullLC.stagia.beans.unei.KyukanCalendarDto;
import jp.ne.yec.seagullLC.stagia.beans.unei.KyukanSetteiDataDto;
import jp.ne.yec.seagullLC.stagia.beans.unei.KyukanSetteiDto;
import jp.ne.yec.seagullLC.stagia.service.unei.KyukanSetteiService;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestKyukanSetteiService extends JunitBase{

	@Autowired
	KyukanSetteiService kyukanSetteiService;

	@Test
	@DisplayName("引数の場所コード、年月を基に該当する休館日のリストを取得します。")
	@TestInitDataFile("TestGetKyukanInfoInit.xlsx")
	public void TestGetKyukanInfo() throws Exception{
		List<KyukanCalendarDto> jsonData = new ArrayList<KyukanCalendarDto>();
		List<Short> list = new ArrayList<Short>();
		list.add((short)10);
		list.add((short)20);
		YearMonth targetYM = YearMonth.of(2018, 07);

		KyukanCalendarDto kyukanCalendarDto = kyukanSetteiService.getKyukanInfo(list.get(0), targetYM);
		assertNotNull(kyukanCalendarDto);

		jsonData.add(kyukanCalendarDto);
		exportJsonData(jsonData, "TestGetKyukanInfo.json");
	}

	@Test
	@DisplayName("休館設定画面の初期表示データを取得します。</BR>")
	@TestInitDataFile("TestGetInitDataInit.xlsx")
	public void TestGetInitData() throws Exception{
		List<KyukanSetteiDto> jsonData = new ArrayList<KyukanSetteiDto>();
		KyukanSetteiDto kyukanSetteiDto = kyukanSetteiService.getInitData();
		assertNotNull(kyukanSetteiDto);
		jsonData.add(kyukanSetteiDto);
		exportJsonData(jsonData, "TestGetInitData.json");
	}

	@Test
	@DisplayName("休館設定画面の初期表示データを取得します。</BR>")
	@TestInitDataFile("TestkyukanBashoSetteiInit.xlsx")
	public void TestkyukanBashoSettei() throws Exception{
		List<KyukanSetteiDataDto> kyukanSetteiDataDtos = new ArrayList<KyukanSetteiDataDto>();
		KyukanSetteiDataDto kyukanSetteiDataDto1 = new KyukanSetteiDataDto();
		kyukanSetteiDataDto1.setBashoCode((short)10);

		List<LocalDate> LocalDates1 = new ArrayList<LocalDate>();
		for (int dateIdx = 1; dateIdx < 2; dateIdx++)
		{
			String date = 2017 + "/" + 06 + "/" + dateIdx;
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
			Date MudanDate = formatter.parse(date);

			Instant instant = Instant.ofEpochMilli(MudanDate.getTime());
			LocalDate baseDate = LocalDateTime.ofInstant(instant, ZoneId.systemDefault()).toLocalDate();
			LocalDates1.add(baseDate);
		}

		kyukanSetteiDataDto1.setInsKyukanbi(LocalDates1);

		kyukanSetteiDataDto1.setDelKyukanbi(LocalDates1);
		kyukanSetteiDataDtos.add(kyukanSetteiDataDto1);

		KyukanSetteiDataDto kyukanSetteiDataDto = new KyukanSetteiDataDto();
		kyukanSetteiDataDto.setBashoCode((short)10);

		List<LocalDate> LocalDates = new ArrayList<LocalDate>();
		for (int dateIdx = 1; dateIdx < 2; dateIdx++)
		{
			String date = 2018 + "/" + 06 + "/" + dateIdx;
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
			Date MudanDate = formatter.parse(date);

			Instant instant = Instant.ofEpochMilli(MudanDate.getTime());
			LocalDate baseDate = LocalDateTime.ofInstant(instant, ZoneId.systemDefault()).toLocalDate();
			LocalDates.add(baseDate);
		}

		kyukanSetteiDataDto.setInsKyukanbi(LocalDates);

		kyukanSetteiDataDtos.add(kyukanSetteiDataDto);

		List<String> updateBys = new ArrayList<String>();
		updateBys.add("8000");


		//KyukanSetteiDataDto kyukanSetteiDataDto, String updatedBy
		kyukanSetteiService.kyukanBashoSettei(kyukanSetteiDataDtos.get(0), updateBys.get(0));

	}

//	@Test
//	@DisplayName("引数の場所コード、年月を基に該当する休館日のリストを取得します。")
//	@TestInitDataFile("InitKyukanIkkatsuSetteiDataInit.xlsx")
//	public void TestGetInitKyukanIkkatsuSetteiData() throws Exception{
//		List<KyukanSetteiDto> jsonData = new ArrayList<KyukanSetteiDto>();
//		KyukanSetteiDto kyukanSetteiDto = kyukanSetteiService.getInitKyukanIkkatsuSetteiData();
//		assertNotNull(kyukanSetteiDto);
//		jsonData.add(kyukanSetteiDto);
//		exportJsonData(jsonData, "TestGetInitKyukanIkkatsuSetteiData.json");
//	}
//
//	@Test
//	@DisplayName("引数の場所コード、年月を基に該当する休館日のリストを取得します。")
//	@TestInitDataFile("InitKyukanIkkatsuSetteiDataInit.xlsx")
//	public void TestGetgetDDChoiceData() throws Exception{
//
//		List<KyukanSetteiDto> ksDtos = new ArrayList<>();
//		KyukanSetteiDto ksDto = kyukanSetteiService.getInitKyukanIkkatsuSetteiData();
//		ksDto.setChangeDDKubun(UneiConstants.CHANGE_DD_KANRI);
//		StringCodeNamePair KanriCodePair = new StringCodeNamePair();
//		KanriCodePair.setCode("10");
//		ksDto.setSelectedKanri(KanriCodePair);
//		StringCodeNamePair bashoPair = new StringCodeNamePair();
//		bashoPair.setCode("10");
//		ksDto.setSelectedBasho(bashoPair);
//		ksDtos.add(ksDto);
//
//		KyukanSetteiDto ksDto1 = kyukanSetteiService.getInitKyukanIkkatsuSetteiData();
//		ksDto1.setChangeDDKubun(UneiConstants.CHANGE_DD_BASHO);
//		StringCodeNamePair KanriCodePair1 = new StringCodeNamePair();
//		KanriCodePair1.setCode("10");
//		ksDto1.setSelectedKanri(KanriCodePair);
//		StringCodeNamePair bashoPair1 = new StringCodeNamePair();
//		bashoPair1.setCode("10");
//		ksDto1.setSelectedBasho(bashoPair1);
//		ksDtos.add(ksDto1);
//
//		KyukanSetteiDto ksDto2 = kyukanSetteiService.getInitKyukanIkkatsuSetteiData();
//		ksDto2.setChangeDDKubun(UneiConstants.CHANGE_DD_SHISETSU);
//		StringCodeNamePair ShisetsuPair = new StringCodeNamePair();
//		ShisetsuPair.setCode("10");
//		ksDto2.setSelectedShisetsu(ShisetsuPair);
//		StringCodeNamePair KanriCodePair2 = new StringCodeNamePair();
//		KanriCodePair2.setCode("10");
//		ksDto2.setSelectedKanri(KanriCodePair2);
//		ksDtos.add(ksDto2);
//
//		kyukanSetteiService.getDDChoiceData(ksDtos.get(0));
//
//	}
//
//	@Test
//	@DisplayName("引数の場所コード、年月を基に該当する休館日のリストを取得します。")
//	@TestInitDataFile("TestgetKyukanIkkatsuSetteiDataInit.xlsx")
//	public void TestGetKyukanIkkatsuSetteiData() throws Exception{
//		List<List<KyukanSetteiDataDto>> jsonData = new ArrayList<List<KyukanSetteiDataDto>>();
//		List<KyukanSetteiDataDto> setteiDtos = new ArrayList<>();
//		KyukanSetteiDataDto setteiDto = new KyukanSetteiDataDto();
//		setteiDto.setKanriCode((short)10);
//		setteiDto.setBashoCode((short)10);
//		setteiDto.setShisetsuCode((short)10);
//		setteiDto.setHeisaShurui("10");
//		List<LocalDate> heisaDateList = new ArrayList<>();
//		heisaDateList.add(CreateLocalDate(2018, 06, 01));
//		heisaDateList.add(CreateLocalDate(2018, 06, 30));
//		setteiDto.setHeisaDateList(heisaDateList);
//		setteiDtos.add(setteiDto);
//
//		KyukanSetteiDataDto setteiDto2 = new KyukanSetteiDataDto();
//		setteiDto2.setKanriCode((short)10);
//		setteiDto2.setBashoCode((short)10);
//		setteiDto2.setShisetsuCode((short)40);
//		setteiDto2.setHeisaShurui("10");
//		List<LocalDate> heisaDateList2 = new ArrayList<>();
//		heisaDateList2.add(CreateLocalDate(2018, 06, 01));
//		heisaDateList2.add(CreateLocalDate(2018, 06, 30));
//		setteiDto2.setHeisaDateList(heisaDateList2);
//		setteiDtos.add(setteiDto2);
//
//		List<KyukanSetteiDataDto> kyukanSetteiDto = kyukanSetteiService.getKyukanIkkatsuSetteiData(setteiDtos.get(0));
//
//		assertEquals(2, kyukanSetteiDto.size());
//		jsonData.add(kyukanSetteiDto);
//
//		exportJsonData(jsonData, "TestGetKyukanIkkatsuSetteiData.json");
//	}
//
//
//	@Test
//	@DisplayName("引数の場所コード、年月を基に該当する休館日のリストを取得します。")
//	@TestInitDataFile("TestGetkyukanIkkatsuSetteiInit.xlsx")
//	public void TestGetkyukanIkkatsuSettei() throws Exception{
//		List<List<KyukanSetteiDataDto>> ikkatsuSetteiList = new ArrayList<>();
//		List<KyukanSetteiDataDto> kyukanSetteiDatas = new ArrayList<>();
//		KyukanSetteiDataDto setteiDto = new KyukanSetteiDataDto();
//		setteiDto.setKanriCode((short)10);
//		setteiDto.setBashoCode((short)10);
//		setteiDto.setShisetsuCode((short)10);
//		setteiDto.setHeisaShurui("10");
//		setteiDto.setKashidashiTaniCode((short)0);
//		List<LocalDate> heisaDateList = new ArrayList<>();
//		heisaDateList.add(CreateLocalDate(2018, 06, 27));
//		setteiDto.setHeisaDateList(heisaDateList);
//		setteiDto.setStartDate(CreateLocalDate(2018, 06, 01));
//		setteiDto.setEndDate(CreateLocalDate(2018, 06, 30));
//		List<String > heisaShuruiCodes = new ArrayList<>();
//		heisaShuruiCodes.add("0");
//		setteiDto.setHeisaShuruiCodes(heisaShuruiCodes);
//		kyukanSetteiDatas.add(setteiDto);
//
//		KyukanSetteiDataDto setteiDto1 = new KyukanSetteiDataDto();
//		setteiDto1.setKanriCode((short)10);
//		setteiDto1.setBashoCode((short)10);
//		setteiDto1.setShisetsuCode(null);
//		setteiDto1.setHeisaShurui("10");
//		setteiDto1.setKashidashiTaniCode(null);
//		List<LocalDate> heisaDateList1 = new ArrayList<>();
//		heisaDateList1.add(CreateLocalDate(2018, 06, 27));
//		setteiDto1.setHeisaDateList(heisaDateList);
//		setteiDto1.setStartDate(CreateLocalDate(2018, 06, 01));
//		setteiDto1.setEndDate(CreateLocalDate(2018, 06, 30));
//		setteiDto.setHeisaShuruiCodes(null);
//		kyukanSetteiDatas.add(setteiDto1);

		// TBD gọi hàm đọc parameter từ json
//		for (int idx = 0; idx < kyukanSetteiDatas.size(); idx++)
//		{
//			List<KyukanSetteiDataDto> ret = kyukanSetteiService.getShisetsuHeisaInfo(kyukanSetteiDatas.get(idx));
//			ikkatsuSetteiList.add(ret);
//		}

//		ikkatsuSetteiList.get(0).get(0).setKanriCode((short)50);
//		ikkatsuSetteiList.get(0).get(0).setHeisaShurui("0");
//
//		List<String> updateBys = new ArrayList<String>();
//		updateBys.add("8000");
//
//		try
//		{
//			kyukanSetteiService.kyukanIkkatsuSettei(ikkatsuSetteiList.get(0), updateBys.get(0));
//		}
//		catch(Exception ex)
//		{
//			assertEquals("閉鎖種類[休館]を設定する日付[2018/6/27]には既に申請が入っています。申請を確認してください。", ex.getMessage());
//		}
//	}

//	@Test
//	@DisplayName("引数の場所コード、年月を基に該当する休館日のリストを取得します。")
//	@TestInitDataFile("TestGetkyukanIkkatsuSetteiInit.xlsx")
//	public void TestGetkyukanIkkatsuSettei_1() throws Exception{
//		List<List<KyukanSetteiDataDto>> ikkatsuSetteiList = new ArrayList<>();
//		List<KyukanSetteiDataDto> kyukanSetteiDatas = new ArrayList<>();
//		KyukanSetteiDataDto setteiDto = new KyukanSetteiDataDto();
//		setteiDto.setKanriCode((short)10);
//		setteiDto.setBashoCode((short)10);
//		setteiDto.setShisetsuCode((short)10);
//		setteiDto.setHeisaShurui("10");
//		setteiDto.setKashidashiTaniCode((short)0);
//		List<LocalDate> heisaDateList = new ArrayList<>();
//		heisaDateList.add(CreateLocalDate(2018, 06, 27));
//		setteiDto.setHeisaDateList(heisaDateList);
//		setteiDto.setStartDate(CreateLocalDate(2018, 06, 01));
//		setteiDto.setEndDate(CreateLocalDate(2018, 06, 30));
//		List<String > heisaShuruiCodes = new ArrayList<>();
//		heisaShuruiCodes.add("0");
//		setteiDto.setHeisaShuruiCodes(heisaShuruiCodes);
//		kyukanSetteiDatas.add(setteiDto);
//
//		KyukanSetteiDataDto setteiDto1 = new KyukanSetteiDataDto();
//		setteiDto1.setKanriCode((short)10);
//		setteiDto1.setBashoCode((short)10);
//		setteiDto1.setShisetsuCode(null);
//		setteiDto1.setHeisaShurui("10");
//		setteiDto1.setKashidashiTaniCode(null);
//		List<LocalDate> heisaDateList1 = new ArrayList<>();
//		heisaDateList1.add(CreateLocalDate(2018, 06, 27));
//		setteiDto1.setHeisaDateList(heisaDateList);
//		setteiDto1.setStartDate(CreateLocalDate(2018, 06, 01));
//		setteiDto1.setEndDate(CreateLocalDate(2018, 06, 30));
//		setteiDto.setHeisaShuruiCodes(null);
//		kyukanSetteiDatas.add(setteiDto1);
//
//		// TBD gọi hàm đọc parameter từ json
////		for (int idx = 0; idx < kyukanSetteiDatas.size(); idx++)
////		{
////			List<KyukanSetteiDataDto> ret = kyukanSetteiService.getShisetsuHeisaInfo(kyukanSetteiDatas.get(idx));
////			ikkatsuSetteiList.add(ret);
////		}
//		List<String> updateBys = new ArrayList<String>();
//		updateBys.add("8000");
//		try
//		{
//			kyukanSetteiService.kyukanIkkatsuSettei(ikkatsuSetteiList.get(0), updateBys.get(0));
//		}
//		catch(Exception ex)
//		{
//			assertEquals("指定された条件で、既に登録されている日付・時間帯が存在します。登録済みの施設閉鎖情報を確認してください。", ex.getMessage());
//		}
//
//	}
//
//	@Test
//	@DisplayName("引数の場所コード、年月を基に該当する休館日のリストを取得します。")
//	@TestInitDataFile("TestGetkyukanIkkatsuSetteiInit.xlsx")
//	public void TestGetkyukanIkkatsuSettei_2() throws Exception{
//		List<List<KyukanSetteiDataDto>> ikkatsuSetteiList = new ArrayList<>();
//		List<KyukanSetteiDataDto> kyukanSetteiDatas = new ArrayList<>();
//		KyukanSetteiDataDto setteiDto = new KyukanSetteiDataDto();
//		setteiDto.setKanriCode((short)10);
//		setteiDto.setBashoCode((short)10);
//		setteiDto.setShisetsuCode((short)10);
//		setteiDto.setHeisaShurui("10");
//		setteiDto.setKashidashiTaniCode((short)0);
//		List<LocalDate> heisaDateList = new ArrayList<>();
//		heisaDateList.add(CreateLocalDate(2018, 06, 27));
//		setteiDto.setHeisaDateList(heisaDateList);
//		setteiDto.setStartDate(CreateLocalDate(2018, 06, 01));
//		setteiDto.setEndDate(CreateLocalDate(2018, 06, 30));
//		List<String > heisaShuruiCodes = new ArrayList<>();
//		heisaShuruiCodes.add("0");
//		setteiDto.setHeisaShuruiCodes(heisaShuruiCodes);
//		kyukanSetteiDatas.add(setteiDto);
//
//		KyukanSetteiDataDto setteiDto1 = new KyukanSetteiDataDto();
//		setteiDto1.setKanriCode((short)10);
//		setteiDto1.setBashoCode((short)10);
//		setteiDto1.setShisetsuCode(null);
//		setteiDto1.setHeisaShurui("10");
//		setteiDto1.setKashidashiTaniCode(null);
//		List<LocalDate> heisaDateList1 = new ArrayList<>();
//		heisaDateList1.add(CreateLocalDate(2018, 06, 27));
//		setteiDto1.setHeisaDateList(heisaDateList);
//		setteiDto1.setStartDate(CreateLocalDate(2018, 06, 01));
//		setteiDto1.setEndDate(CreateLocalDate(2018, 06, 30));
//		setteiDto.setHeisaShuruiCodes(null);
//		kyukanSetteiDatas.add(setteiDto1);
//
//		// TBD gọi hàm đọc parameter từ json
////		for (int idx = 0; idx < kyukanSetteiDatas.size(); idx++)
////		{
////			List<KyukanSetteiDataDto> ret = kyukanSetteiService.getShisetsuHeisaInfo(kyukanSetteiDatas.get(idx));
////			ikkatsuSetteiList.add(ret);
////		}
//
//		ikkatsuSetteiList.get(0).get(0).setKanriCode((short)100);
//		ikkatsuSetteiList.get(0).get(0).setHeisaShurui("0");
//
//		List<String> updateBys = new ArrayList<String>();
//		updateBys.add("8000");
//
//		kyukanSetteiService.kyukanIkkatsuSettei(ikkatsuSetteiList.get(0), updateBys.get(0));
//
//	}
//
//
//	@Test
//	@DisplayName("引数の場所コード、年月を基に該当する休館日のリストを取得します。")
//	@TestInitDataFile("TestGetShisetsuHeisaInfoInit.xlsx")
//	public void TestGetShisetsuHeisaInfo() throws Exception{
//		List<List<KyukanSetteiDataDto>> jsonData = new ArrayList<List<KyukanSetteiDataDto>>();
//		List<KyukanSetteiDataDto> kyukanSetteiDatas = new ArrayList<>();
//		KyukanSetteiDataDto setteiDto = new KyukanSetteiDataDto();
//		setteiDto.setKanriCode((short)10);
//		setteiDto.setBashoCode((short)10);
//		setteiDto.setShisetsuCode((short)10);
//		setteiDto.setHeisaShurui("10");
//		setteiDto.setKashidashiTaniCode((short)0);
//		List<LocalDate> heisaDateList = new ArrayList<>();
//		heisaDateList.add(CreateLocalDate(2018, 06, 27));
//		setteiDto.setHeisaDateList(heisaDateList);
//		setteiDto.setStartDate(CreateLocalDate(2018, 06, 01));
//		setteiDto.setEndDate(CreateLocalDate(2018, 06, 30));
//		List<String > heisaShuruiCodes = new ArrayList<>();
//		heisaShuruiCodes.add("0");
//		setteiDto.setHeisaShuruiCodes(heisaShuruiCodes);
//		kyukanSetteiDatas.add(setteiDto);
//
//		KyukanSetteiDataDto setteiDto1 = new KyukanSetteiDataDto();
//		setteiDto1.setKanriCode((short)10);
//		setteiDto1.setBashoCode((short)10);
//		setteiDto1.setShisetsuCode(null);
//		setteiDto1.setHeisaShurui("10");
//		setteiDto1.setKashidashiTaniCode(null);
//		List<LocalDate> heisaDateList1 = new ArrayList<>();
//		heisaDateList1.add(CreateLocalDate(2018, 06, 27));
//		setteiDto1.setHeisaDateList(heisaDateList);
//		setteiDto1.setStartDate(CreateLocalDate(2018, 06, 01));
//		setteiDto1.setEndDate(CreateLocalDate(2018, 06, 30));
//		setteiDto.setHeisaShuruiCodes(null);
//		kyukanSetteiDatas.add(setteiDto1);
//
//
//		List<KyukanSetteiDataDto> ret = kyukanSetteiService.getShisetsuHeisaInfo(kyukanSetteiDatas.get(0));
//		assertEquals(2, ret.size());
//		jsonData.add(ret);
//		exportJsonData(jsonData, "TestGetShisetsuHeisaInfo.json");
//	}
//
//	@Test
//	@DisplayName("引数の場所コード、年月を基に該当する休館日のリストを取得します。")
//	@TestInitDataFile("TestGetShisetsuHeisaInfoInit.xlsx")
//	public void TestDelShisetsuHeisaInfo() throws Exception{
//		List<KyukanSetteiDataDto> kyukanSetteiDatas = new ArrayList<>();
//		KyukanSetteiDataDto setteiDto = new KyukanSetteiDataDto();
//		setteiDto.setKanriCode((short)10);
//		setteiDto.setBashoCode((short)10);
//		setteiDto.setShisetsuCode((short)10);
//		setteiDto.setHeisaShurui("10");
//		setteiDto.setKashidashiTaniCode((short)0);
//		List<LocalDate> heisaDateList = new ArrayList<>();
//		heisaDateList.add(CreateLocalDate(2018, 06, 27));
//		setteiDto.setHeisaDateList(heisaDateList);
//		setteiDto.setStartDate(CreateLocalDate(2018, 06, 01));
//		setteiDto.setEndDate(CreateLocalDate(2018, 06, 30));
//		List<String > heisaShuruiCodes = new ArrayList<>();
//		heisaShuruiCodes.add("0");
//		setteiDto.setHeisaShuruiCodes(heisaShuruiCodes);
//		kyukanSetteiDatas.add(setteiDto);
//
//		KyukanSetteiDataDto setteiDto1 = new KyukanSetteiDataDto();
//		setteiDto1.setKanriCode((short)10);
//		setteiDto1.setBashoCode((short)10);
//		setteiDto1.setShisetsuCode(null);
//		setteiDto1.setHeisaShurui("10");
//		setteiDto1.setKashidashiTaniCode(null);
//		List<LocalDate> heisaDateList1 = new ArrayList<>();
//		heisaDateList1.add(CreateLocalDate(2018, 06, 27));
//		setteiDto1.setHeisaDateList(heisaDateList);
//		setteiDto1.setStartDate(CreateLocalDate(2018, 06, 01));
//		setteiDto1.setEndDate(CreateLocalDate(2018, 06, 30));
//		setteiDto.setHeisaShuruiCodes(null);
//		kyukanSetteiDatas.add(setteiDto1);
//
//		try
//		{
//			kyukanSetteiService.delShisetsuHeisaInfo(kyukanSetteiDatas);
//		}
//		catch(Exception ex)
//		{
//			assertEquals("変更済みであるため、削除ができませんでした。再度検索からやり直してください。", ex.getMessage());
//		}
//
//	}

}
