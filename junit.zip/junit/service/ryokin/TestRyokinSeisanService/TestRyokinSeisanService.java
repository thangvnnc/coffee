package jp.ne.yec.seagullLC.stagia.test.junit.service.ryokin.TestRyokinSeisanService;

import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.seagullLC.stagia.entity.MBasho;
import jp.ne.yec.seagullLC.stagia.entity.MKanri;
import jp.ne.yec.seagullLC.stagia.entity.TShinseiMeisai;
import jp.ne.yec.seagullLC.stagia.service.ryokin.RyokinSeisanService;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestRyokinSeisanService extends JunitBase{

	@Autowired
	RyokinSeisanService ryokinSeisanService;

	@Test
	@DisplayName("M_管理を取得します。")
	@TestInitDataFile("TestGetMKanri_Init.xlsx")
	public void TestGetMKanri() throws Exception {
		Short kanriCode = 10;
		MKanri ret = ryokinSeisanService.getMKanri(kanriCode);
		exportJsonData(ret, "TestGetMKanri.json");
	}

	@Test
	@DisplayName("取消明細も含め引数に紐付くT_申請明細を取得します.")
	@TestInitDataFile("TestGetTShinseiMeisai_Init.xlsx")
	public void TestGetTShinseiMeisai() throws Exception {
		short kanriCode = 10;
		int shinseiNumber = 444;;
		List<TShinseiMeisai> ret = ryokinSeisanService.getTShinseiMeisai(kanriCode, shinseiNumber);
		exportJsonData(ret, "TestGetTShinseiMeisai.json");
	}

	@Test
	@DisplayName("全てのM_場所を返却します.")
	@TestInitDataFile("TestgetMBashoList_Init.xlsx")
	public void TestGetMBasho() throws Exception {
		List<MBasho> ret = ryokinSeisanService.getMBasho();
		exportJsonData(ret, "TestGetMBasho.json");
	}

//	@Test
//	@DisplayName("引数のT_申請明細.id毎のM_場所のMapを返却します.")
//	public void TestGetBashoMap() throws Exception {
//
//		Map<Integer, MBasho> ret = ryokinSeisanService.getBashoMap(mBashos, shinseiMeisais);
//		exportJsonData(ret, "TestGetBashoMap.json");
//	}
//
//	@Test
//	@DisplayName("引数のT_申請明細.id毎のM_貸出単位のMapを返却します.")
//	public void TestGetKashidashiTaniMap() throws Exception {
//		List<List<TShinseiMeisai>> shinseiMeisaiLists = new ArrayList<>();
//		List<TShinseiMeisai> shinseiMeisais = new ArrayList<>();
//		shinseiMeisais.add(new TShinseiMeisai());
//		shinseiMeisaiLists.add(shinseiMeisais);
//
//		List<Map<Integer, MKashidashiTani>> exports = new ArrayList<>();
//		for (int idx = 0; idx < shinseiMeisaiLists.size(); idx++)
//		{
//			Map<Integer, MKashidashiTani> ret = ryokinSeisanService.getKashidashiTaniMap(shinseiMeisaiLists.get(idx));
//			exports.add(ret);
//		}
//		exportJsonData(exports, "TestGetKashidashiTaniMap.json");
//	}
//
//	@Test
//	@DisplayName("引数のT_申請明細.id毎のM_施設のMapを返却します.")
//	public void TestGetShisetsuMap() throws Exception {
//		List<List<TShinseiMeisai>> shinseiMeisaiLists = new ArrayList<>();
//		List<TShinseiMeisai> shinseiMeisais = new ArrayList<>();
//		shinseiMeisais.add(new TShinseiMeisai());
//		shinseiMeisaiLists.add(shinseiMeisais);
//
//		List<Map<Integer, MShisetsu>> exports = new ArrayList<>();
//		for (int idx = 0; idx < shinseiMeisaiLists.size(); idx++)
//		{
//			Map<Integer, MShisetsu> ret = ryokinSeisanService.getShisetsuMap(shinseiMeisaiLists.get(idx));
//			exports.add(ret);
//		}
//		exportJsonData(exports, "TestGetShisetsuMap.json");
//	}
//
//	@Test
//	@DisplayName("引数に紐付くT_料金を返却します.")
//	public void TestGetRyokinSeisanDtos() throws Exception {
//		List<Map<Integer, TShinseiMeisai>> tShinseiMeisaiMaps = new ArrayList<>();
//		Map<Integer, TShinseiMeisai> tShinseiMeisaiMap = new HashMap<>();
//		TShinseiMeisai tShinseiMeisai = new TShinseiMeisai();
//		tShinseiMeisaiMap.put(10, tShinseiMeisai);
//		tShinseiMeisaiMaps.add(tShinseiMeisaiMap);
//
//		List<Boolean> isEnabledCancelRyokins = new ArrayList<>();
//		isEnabledCancelRyokins.add(true);
//
//		List<List<RyokinSeisanDto>> exports = new ArrayList<>();
//		for (int idx = 0; idx < tShinseiMeisaiMaps.size(); idx++)
//		{
//			List<RyokinSeisanDto> ret = ryokinSeisanService.getRyokinSeisanDtos(tShinseiMeisaiMaps.get(idx), isEnabledCancelRyokins.get(idx));
//			exports.add(ret);
//		}
//		exportJsonData(exports, "TestGetShisetsuMap.json");
//	}
//
//	@Test
//	@DisplayName("dtoを元にキャンセル料金精算用のDTOを作成し返却します.")
//	public void TestMakeCancelRyokinDto() throws Exception {
//		List<RyokinSeisanDto> ryokinSeisanDtos = new ArrayList<>();
//		ryokinSeisanDtos.add(new RyokinSeisanDto());
//
//		List<RyokinSeisanDto> exports = new ArrayList<>();
//		for (int idx = 0; idx < ryokinSeisanDtos.size(); idx++)
//		{
//			RyokinSeisanDto ret = ryokinSeisanService.makeCancelRyokinDto(ryokinSeisanDtos.get(idx));
//			exports.add(ret);
//		}
//		exportJsonData(exports, "TestMakeCancelRyokinDto.json");
//	}
//
//	@Test
//	@DisplayName("引数に紐付く領収DTOをT_領収明細Listをセットした状態で返却します.")
//	public void TestGetRyoshuDtos() throws Exception {
//		List<List<Integer>> params = new ArrayList<List<Integer>>();
//		List<Integer> ids = new ArrayList<>();
//		ids.add(1);
//		params.add(ids);
//
//		List<List<RyoshuDto>> exports = new ArrayList<>();
//		for (int item = 0; item < params.size(); item ++)
//		{
//			List<RyoshuDto> ret = ryokinSeisanService.getRyoshuDtos(params.get(item));
//			exports.add(ret);
//		}
//
//		exportJsonData(exports, "TestGetRyoshuDtos.json");
//	}
//
//	@Test
//	@DisplayName("引数に紐付く還付DTOをT_還付明細Listをセットした状態で返却します.")
//	public void TestGetKampuDtos() throws Exception {
//
//		List<List<Integer>> idLists = new ArrayList<List<Integer>>();
//		List<Integer> ids = new ArrayList<>();
//		ids.add(1);
//		idLists.add(ids);
//
//		List<List<KampuDto>> exports = new ArrayList<>();
//		for (int item = 0; item < idLists.size(); item ++)
//		{
//			List<KampuDto> ret = ryokinSeisanService.getKampuDtos(idLists.get(item));
//			exports.add(ret);
//		}
//		exportJsonData(exports, "TestGetKampuDtos.json");
//	}
//
//	@Test
//	@DisplayName("M_還付理由を返却します.")
//	public void TestGetMKampuRiyu() throws Exception {
//		List<Short> kanriCodes = new ArrayList<>();
//		kanriCodes.add((short)1);
//
//		List<List<MKampuRiyu>> exports = new ArrayList<>();
//		for (int item = 0; item < kanriCodes.size(); item ++)
//		{
//			List<MKampuRiyu> ret = ryokinSeisanService.getMKampuRiyu(kanriCodes.get(item));
//			exports.add(ret);
//		}
//		exportJsonData(exports, "TestGetMKampuRiyu.json");
//	}
//
//	@Test
//	@DisplayName("管理コード施設コード別のMapにM_還付期間を格納し返却します.")
//	public void TestGetKampuKikan() throws Exception {
//		List<List<TShinseiMeisai>> tShinseiMeisaiLists = new ArrayList<>();
//		List<TShinseiMeisai> tShinseiMeisais = new ArrayList<>();
//		tShinseiMeisais.add(new TShinseiMeisai());
//		tShinseiMeisaiLists.add(tShinseiMeisais);
//
//		List<Map<Short, Map<Short, List<MKampuKikan>>>> exports = new ArrayList<>();
//		for (int item = 0; item < tShinseiMeisaiLists.size(); item ++)
//		{
//			Map<Short, Map<Short, List<MKampuKikan>>> ret = ryokinSeisanService.getKampuKikan(tShinseiMeisaiLists.get(item));
//			exports.add(ret);
//		}
//		exportJsonData(exports, "TestGetKampuKikan.json");
//	}
//
//	@Test
//	@DisplayName("引数より適用する還付率を返却します. 対象が存在しなかった場合、nullを返却します.")
//	public void TestGetkampuRitsu() throws Exception {
//		List<TShinseiMeisai> meisais = new ArrayList<>();
//		meisais.add(new TShinseiMeisai());
//
//		List<Date> toshoUketsukeDates = new ArrayList<>();
//		toshoUketsukeDates.add(new Date());
//
//		List<MShisetsu> mShisetsus = new ArrayList<>();
//		mShisetsus.add(new MShisetsu());
//
//		List<Map<Short, Map<Short, List<MKampuKikan>>>> kampuKikanListMaps = new ArrayList<>();
//		Map<Short, Map<Short, List<MKampuKikan>>> kampuKikanListMap = new HashMap<>();
//		Map<Short, List<MKampuKikan>> mKampuKikanMap = new HashMap<>();
//		List<MKampuKikan> mKampuKikans = new ArrayList<>();
//		mKampuKikans.add(new MKampuKikan());
//		mKampuKikanMap.put((short) 10, mKampuKikans);
//		kampuKikanListMap.put((short) 10, mKampuKikanMap);
//
//		List<Optional<Short>> exports = new ArrayList<>();
//		for (int item = 0; item < meisais.size(); item ++)
//		{
//			 Optional<Short> ret = ryokinSeisanService.getkampuRitsu(meisais.get(item), toshoUketsukeDates.get(item), mShisetsus.get(item), kampuKikanListMaps.get(item));
//			 exports.add(ret);
//		}
//		exportJsonData(exports, "TestGetkampuRitsu.json");
//	}
//
//	@Test
//	@DisplayName("M_銀行を返却します.")
//	public void TestGetMGinko() throws Exception {
//		List<List<MGinko>> exports = new ArrayList<>();
//		List<MGinko> ret = ryokinSeisanService.getMGinko();
//		exports.add(ret);
//		exportJsonData(exports, "TestGetMGinko.json");
//	}
//
//	@Test
//	@DisplayName("M_支店を銀行コード毎に格納したMapを返却します.")
//	public void TestGetMShiten() throws Exception {
//		List<Map<Short, List<MShiten>>> exports = new ArrayList<>();
//		Map<Short, List<MShiten>> ret = ryokinSeisanService.getMShiten();
//		exports.add(ret);
//		exportJsonData(exports, "TestGetMShiten.json");
//	}


//	@Test
//	@DisplayName("Sessionの受付場所既定値に該当するM_場所を返却します. 存在しない場合、uketsukeBashoListの１つ目の要素を返却します.")
//	public void TestGetUketsukeBashoKiteichi() throws Exception {
//
//		List<List<MBasho>> mBashoLists = new ArrayList<>();
//		List<MBasho> uketsukeBashoList = new ArrayList<>();
//		uketsukeBashoList.add(new MBasho());
//		mBashoLists.add(uketsukeBashoList);
//
//		List<MBasho> exports = new ArrayList<>();
//		for (int item = 0; item < mBashoLists.size(); item ++)
//		{
//			MBasho ret = ryokinSeisanService.getUketsukeBashoKiteichi(mBashoLists.get(item));
//			exports.add(ret);
//		}
//		exportJsonData(exports, "TestGetUketsukeBashoKiteichi.json");
//	}

//	@Test
//	@DisplayName(" 引数の料金精算DTO、T_領収、T_領収明細、T_還付、T_還付明細のデータ更新を行います.")
//	public void TestInsertUpdateRyoshuKampuData() throws Exception {
//		List<List<RyokinSeisanDto>> ryokinSeisanDtoLists = new ArrayList<>();
//		List<RyokinSeisanDto> ryokinSeisanDtos = new ArrayList<>();
//		ryokinSeisanDtos.add(new RyokinSeisanDto());
//		ryokinSeisanDtoLists.add(ryokinSeisanDtos);
//
//		List<List<RyoshuDto>> insertRyoshuLists = new ArrayList<>();
//		List<RyoshuDto> ryoshuDtos = new ArrayList<>();
//		ryoshuDtos.add(new RyoshuDto());
//		insertRyoshuLists.add(ryoshuDtos);
//
//		List<List<RyoshuDto>> modifiedRyoshuLists = new ArrayList<>();
//		List<RyoshuDto> ryoshuDtos2 = new ArrayList<>();
//		ryoshuDtos2.add(new RyoshuDto());
//		modifiedRyoshuLists.add(ryoshuDtos2);
//
//		List<Queue<Integer>> ryoshuNumberQueues = new ArrayList<>();
//		Queue<Integer> qIntegers = new ArrayDeque<>();
//		qIntegers.add(1);
//		ryoshuNumberQueues.add(qIntegers);
//
//		List<List<KampuDto>> insertKampuLists = new ArrayList<>();
//		List<KampuDto> kampuDtos = new ArrayList<>();
//		kampuDtos.add(new KampuDto());
//		insertKampuLists.add(kampuDtos);
//
//		List<List<KampuDto>> modifiedKampuLists = new ArrayList<>();
//		List<KampuDto> kampuDtos2 = new ArrayList<>();
//		kampuDtos2.add(new KampuDto());
//		modifiedKampuLists.add(kampuDtos2);
//
//		List<Queue<Integer>> kampuNumberQueues = new ArrayList<>();
//		Queue<Integer> qIntegers2 = new ArrayDeque<>();
//		qIntegers2.add(1);
//		kampuNumberQueues.add(qIntegers2);
//
//		for (int item = 0; item < ryokinSeisanDtoLists.size(); item ++)
//		{
//			ryokinSeisanService.insertUpdateRyoshuKampuData(
//				ryokinSeisanDtoLists.get(item),
//				insertRyoshuLists.get(item),
//				modifiedRyoshuLists.get(item),
//				ryoshuNumberQueues.get(item),
//				insertKampuLists.get(item),
//				modifiedKampuLists.get(item),
//				kampuNumberQueues.get(item)
//				);
//		}
//	}

}
