package jp.ne.yec.seagullLC.stagia.test.junit.service.ryokin.RyoshuKampuKeshikomiService;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.seagullLC.stagia.entity.MBasho;
import jp.ne.yec.seagullLC.stagia.entity.MKanri;
import jp.ne.yec.seagullLC.stagia.entity.MKashidashiTani;
import jp.ne.yec.seagullLC.stagia.entity.MShisetsu;
import jp.ne.yec.seagullLC.stagia.service.ryokin.RyoshuKampuKeshikomiService;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestRyoshuKampuKeshikomiService extends JunitBase{

	@Autowired
	RyoshuKampuKeshikomiService ryoshuKampuKeshikomiService;

	@Test
	@TestInitDataFile("TestGetKanriByUserAuthority_Init.xlsx")
	public void TestGetKanriByUserAuthority() throws Exception {
		List<Short> kanriCodes = new ArrayList<Short>();
		Short KanriCode = 10;
		kanriCodes.add(KanriCode);
		List<MKanri> ret = ryoshuKampuKeshikomiService.getKanriByUserAuthority(kanriCodes);
		exportJsonData(ret, "TestGetKanriByUserAuthority.json");
	}

	@Test
	@TestInitDataFile("TestGetMBasho_Init.xlsx")
	public void TestGetMBasho() throws Exception {
		List<Short> bashoCodes = new ArrayList<Short>();
		bashoCodes.add((short)10);
		List<MBasho> ret = ryoshuKampuKeshikomiService.getMBasho(bashoCodes);
		exportJsonData(ret, "TestGetMBasho.json");
	}

	@Test
	@TestInitDataFile("TestGetUketsukeBashoByUserAuthority_Init.xlsx")
	public void TestGetUketsukeBashoByUserAuthority() throws Exception {
		List<MBasho> ret = ryoshuKampuKeshikomiService.getUketsukeBashoByUserAuthority();
		exportJsonData(ret, "TestGetUketsukeBashoByUserAuthority.json");
	}

	@Test
	@TestInitDataFile("TestGetShisetsuByKanri_Init.xlsx")
	public void TestGetShisetsuByKanri() throws Exception {
		List<Short> kanriCodes = new ArrayList<>();
		kanriCodes.add((short)10);
		List<MShisetsu> ret = ryoshuKampuKeshikomiService.getShisetsuByKanri(kanriCodes);
		exportJsonData(ret, "TestGetShisetsuByKanri.json");
	}

	@Test
	@TestInitDataFile("TestGetKashidashiTaniByKanri_Init.xlsx")
	public void TestGetKashidashiTaniByKanri() throws Exception {
		List<Short> kanriCodes = new ArrayList<>();
		kanriCodes.add((short)10);
		List<MKashidashiTani> ret = ryoshuKampuKeshikomiService.getKashidashiTaniByKanri(kanriCodes);
		exportJsonData(ret, "TestGetKashidashiTaniByKanri.json");
	}
}
