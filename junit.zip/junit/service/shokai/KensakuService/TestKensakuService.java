package jp.ne.yec.seagullLC.stagia.test.junit.service.shokai.KensakuService;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.beans.StringCodeNamePair;
import jp.ne.yec.seagullLC.stagia.beans.riyosha.KoseiinJohoDto;
import jp.ne.yec.seagullLC.stagia.beans.riyosha.RiyoshaDto;
import jp.ne.yec.seagullLC.stagia.beans.shinsei.ShinseiDto;
import jp.ne.yec.seagullLC.stagia.beans.shinsei.ShinseiIchiranDto;
import jp.ne.yec.seagullLC.stagia.beans.shokai.SearchConditionsDto;
import jp.ne.yec.seagullLC.stagia.beans.shokai.SearchRiyoshaConditionsDto;
import jp.ne.yec.seagullLC.stagia.beans.shokai.ShokuinDto;
import jp.ne.yec.seagullLC.stagia.entity.MChusenGroup;
import jp.ne.yec.seagullLC.stagia.entity.MKanri;
import jp.ne.yec.seagullLC.stagia.entity.TShinsei;
import jp.ne.yec.seagullLC.stagia.service.shokai.KensakuService;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestKensakuService extends JunitBase{

	@Autowired
	KensakuService kensakuService;

	@Test
	@DisplayName("引数の管理コード、申請番号を基にT_申請を取得します.")
	@TestInitDataFile("TestGetTShinseiInit.xlsx")
	public void TestGetTShinsei() throws Exception{
		List<TShinsei> jsonData = new ArrayList<TShinsei>();
		List<Short> listKanriCode = new ArrayList<Short>();
		listKanriCode.add((short)10);

		List<Integer> listShinseiNumber = new ArrayList<Integer>();
		listShinseiNumber.add(1);


		TShinsei tShinsei = kensakuService.getTShinsei(listKanriCode.get(0), listShinseiNumber.get(0));
		assertNotNull(tShinsei);
		jsonData.add(tShinsei);
		exportJsonData(jsonData, "TestGetTShinsei.json");
	}

	@Test
	@DisplayName("構成員を保持する利用者が存在するかチェックし、結果を返却します.")
	@TestInitDataFile("TestIsExistsKoseiinInit.xlsx")
	public void TestIsExistsKoseiin() throws Exception{
		List<Boolean> jsonData = new ArrayList<Boolean>();
		Boolean exist = kensakuService.isExistsKoseiin();
		assertTrue(exist);
		jsonData.add(exist);
		exportJsonData(jsonData, "TestIsExistsKoseiin.json");
	}

	@Test
	@DisplayName("構成員を保持する利用者が存在するかチェックし、結果を返却します.")
	@TestInitDataFile("TestIsExistsKoseiinInit_null.xlsx")
	public void TestIsExistsKoseiin_null() throws Exception{
		List<Boolean> jsonData = new ArrayList<Boolean>();
		Boolean exist = kensakuService.isExistsKoseiin();
		assertTrue(exist);
		jsonData.add(exist);
		exportJsonData(jsonData, "TestIsExistsKoseiin_null.json");
	}

	@Test
	@DisplayName("口座情報を保持する利用者が存在するかチェックし、結果を返却します.")
	@TestInitDataFile("TestIsExistsRiyoshaKozaInfoInit.xlsx")
	public void TestIsExistsRiyoshaKozaInfo() throws Exception{
		List<Boolean> jsonData = new ArrayList<Boolean>();
		Boolean exist = kensakuService.isExistsRiyoshaKozaInfo();
		assertTrue(exist);
		jsonData.add(exist);
		exportJsonData(jsonData, "TestIsExistsRiyoshaKozaInfo.json");
	}

	@Test
	@DisplayName("口座情報を保持する利用者が存在するかチェックし、結果を返却します.")
	@TestInitDataFile("TestIsExistsRiyoshaKozaInfoInit_null.xlsx")
	public void TestIsExistsRiyoshaKozaInfo_null() throws Exception{
		List<Boolean> jsonData = new ArrayList<Boolean>();
		Boolean exist = kensakuService.isExistsRiyoshaKozaInfo();
		assertTrue(exist);
		jsonData.add(exist);
		exportJsonData(jsonData, "TestIsExistsRiyoshaKozaInfo_null.json");
	}

	@Test
	@DisplayName("画面で選択された申請情報を引数の管理コード、申請番号を基に取得し、返却します.")
	@TestInitDataFile("TestGetSelectShinseiInfoInit.xlsx")
	public void TestGetSelectShinseiInfo() throws Exception{
		List<ShinseiDto> jsonData = new ArrayList<ShinseiDto>();
		List<Short> listKanriCode = new ArrayList<Short>();
		listKanriCode.add((short)10);

		List<Integer> listShinseiNumber =  new ArrayList<Integer>();
		listShinseiNumber.add(444);

		List<Short> uketsukeBashoCode = new ArrayList<Short>();
		listKanriCode.add((short)10);

		boolean isShokuinLogin = false;

		ShinseiDto ShinseiDto = kensakuService.getSelectShinseiInfo(
				listKanriCode.get(0),
				listShinseiNumber.get(0),
				uketsukeBashoCode.get(0),
				isShokuinLogin
				);
		assertNotNull(ShinseiDto);
		jsonData.add(ShinseiDto);
		exportJsonData(jsonData, "TestGetSelectShinseiInfo.json");
	}

	@Test
	@DisplayName("引数の銀行コードを基に支店マスタを取得します.")
	@TestInitDataFile("TestGetMShitenListInit.xlsx")
	public void TestGetMShitenList() throws Exception{
		List<List<StringCodeNamePair>> jsonData = new ArrayList<List<StringCodeNamePair>>();
		List<Short> listGinkoCode = new ArrayList<Short>();
		listGinkoCode.add((short)1);
		listGinkoCode.add((short)2);


		List<StringCodeNamePair> list = kensakuService.getMShitenList(listGinkoCode.get(0));
		assertEquals(2, list.size());
		jsonData.add(list);
		exportJsonData(jsonData, "TestGetMShitenList.json");
	}

	@Test
	@DisplayName("銀行マスタを取得します.")
	@TestInitDataFile("TestGetMGinkoListInit.xlsx")
	public void TestGetMGinkoList() throws Exception{
		List<List<StringCodeNamePair>> jsonData = new ArrayList<List<StringCodeNamePair>>();
		List<StringCodeNamePair> list = kensakuService.getMGinkoList();
		assertEquals(2, list.size());
		jsonData.add(list);
		exportJsonData(jsonData, "TestGetMGinkoList.json");
	}

	@Test
	@DisplayName("使用目的を取得します")
	@TestInitDataFile("TestGetShiyoMokutekiListInit.xlsx")
	public void TestGetShiyoMokutekiList() throws Exception{
		List<List<StringCodeNamePair>> jsonData = new ArrayList<List<StringCodeNamePair>>();
		List<StringCodeNamePair> list = kensakuService.getShiyoMokutekiList();
		assertEquals(2, list.size());
		jsonData.add(list);
		exportJsonData(jsonData, "TestGetShiyoMokutekiList.json");
	}

	@Test
	@DisplayName("抽選グループコードを元に抽選グループを取得します")
	@TestInitDataFile("TestGetChusenGroupInit.xlsx")
	public void TestGetChusenGroup() throws Exception{
		List<MChusenGroup> jsonData = new ArrayList<MChusenGroup>();
		List<Short> listChusenGroupCode = new ArrayList<Short>();
		listChusenGroupCode.add((short)12);
		listChusenGroupCode.add((short)13);
		listChusenGroupCode.add((short)71);
		listChusenGroupCode.add((short)72);
		listChusenGroupCode.add((short)73);


		MChusenGroup mChusenGroup = kensakuService.getChusenGroup(listChusenGroupCode.get(0));
		assertNotNull(mChusenGroup);
		jsonData.add(mChusenGroup);

		exportJsonData(jsonData, "TestGetChusenGroup.json");
	}

	@Test
	@DisplayName("抽選グループを取得します")
	@TestInitDataFile("TestGetChusenGroupInit.xlsx")
	public void TestGetChusenGroupList() throws Exception{
		List<List<StringCodeNamePair>> jsonData = new ArrayList<List<StringCodeNamePair>>();
		List<StringCodeNamePair> list = kensakuService.getChusenGroupList();
		assertEquals(2, list.size());
		jsonData.add(list);
		exportJsonData(jsonData, "TestGetChusenGroupList.json");
	}

	@Test
	@DisplayName("申請受付場所を取得します")
	@TestInitDataFile("TestGetShinseiUketsukeBashoListInit.xlsx")
	public void TestGetShinseiUketsukeBashoList() throws Exception{
		List<List<StringCodeNamePair>> jsonData = new ArrayList<List<StringCodeNamePair>>();
		List<StringCodeNamePair> list = kensakuService.getShinseiUketsukeBashoList();
		assertEquals(2, list.size());
		jsonData.add(list);
		exportJsonData(jsonData, "TestGetShinseiUketsukeBashoList.json");
	}

	@Test
	@DisplayName("貸出単位を取得します")
	@TestInitDataFile("TestGetKashidashiTaniListInit.xlsx")
	public void TestGetKashidashiTaniList() throws Exception{
		List<List<StringCodeNamePair>> jsonData = new ArrayList<List<StringCodeNamePair>>();
		List<Short> listKanriCode = new ArrayList<Short>();
		listKanriCode.add((short)10);
		listKanriCode.add((short)10);

		List<Short> listShisetsuCode = new ArrayList<Short>();
		listShisetsuCode.add((short)10);
		listShisetsuCode.add((short)10);

		List<StringCodeNamePair> list = kensakuService.getKashidashiTaniList(
				listKanriCode.get(0),
				listShisetsuCode.get(0)
				);
		assertEquals(2, list.size());
		jsonData.add(list);
		exportJsonData(jsonData, "TestGetKashidashiTaniList.json");
	}

	@Test
	@DisplayName("施設名を取得します")
	@TestInitDataFile("TestGetShisetsumeiListInit.xlsx")
	public void TestGetShisetsumeiList() throws Exception{
		List<List<StringCodeNamePair>> jsonData = new ArrayList<List<StringCodeNamePair>>();
		List<Short> listBashoCode = new ArrayList<Short>();
		listBashoCode.add((short)10);
		listBashoCode.add((short)10);

		List<Short> listShisetsuCode = new ArrayList<Short>();
		listShisetsuCode.add((short)10);
		listShisetsuCode.add((short)20);


		List<StringCodeNamePair> list = kensakuService.getShisetsumeiList(
				listBashoCode.get(0),
				listShisetsuCode.get(0)
				);
		assertEquals(2, list.size());
		jsonData.add(list);

		exportJsonData(jsonData, "TestGetShisetsumeiList.json");
	}

	@Test
	@DisplayName("場所名を取得します")
	public void TestGetBashomeiList() throws Exception{
		List<List<StringCodeNamePair>> jsonData = new ArrayList<List<StringCodeNamePair>>();
		List<StringCodeNamePair> list = kensakuService.getBashomeiList();
		assertEquals(2, list.size());
		jsonData.add(list);
		exportJsonData(jsonData, "TestGetBashomeiList.json");
	}

	@Test
	@DisplayName("ログイン職員が参照可能な管理名を取得します")
	public void TestGetKanrimeiList() throws Exception{
		List<List<MKanri>> jsonData = new ArrayList<List<MKanri>>();
		List<Short> kanriCodes = new ArrayList<>();
		List<MKanri> list = kensakuService.getKanrimeiList(kanriCodes);
		assertEquals(2, list.size());
		jsonData.add(list);
		exportJsonData(jsonData, "TestGetKanrimeiList.json");
	}

	@Test
	@DisplayName("ログイン職員が参照可能な管理名を取得します")
	public void TestGetShinseiMeisaiListByDispCondition() throws Exception{
		List<List<ShinseiIchiranDto>> jsonData = new ArrayList<List<ShinseiIchiranDto>>();
		List<SearchConditionsDto> conditionsDtos = new ArrayList<SearchConditionsDto>();
		SearchConditionsDto conditionsDto = new SearchConditionsDto();
		conditionsDtos.add(conditionsDto);

		//SearchConditionsDto conditionsDto

		List<ShinseiIchiranDto> list = kensakuService.getShinseiMeisaiListByDispCondition(conditionsDtos.get(0));
		assertEquals(2, list.size());
		jsonData.add(list);
		exportJsonData(jsonData, "TestGetShinseiMeisaiListByDispCondition.json");
	}

	@Test
	@DisplayName("ログイン職員が参照可能な管理名を取得します")
	public void TestGetRiyoshaListByDispCondition() throws Exception{
		List<List<RiyoshaDto>> jsonData = new ArrayList<List<RiyoshaDto>>();
		List<SearchRiyoshaConditionsDto> conditionsDtos = new ArrayList<SearchRiyoshaConditionsDto>();
		SearchRiyoshaConditionsDto conditionsDto = new SearchRiyoshaConditionsDto();
		conditionsDtos.add(conditionsDto);

		//SearchRiyoshaConditionsDto conditionsDto
		List<RiyoshaDto>  list = kensakuService.getRiyoshaListByDispCondition(conditionsDtos.get(0));
		assertEquals(2, list.size());
		jsonData.add(list);
		exportJsonData(jsonData, "TestGetRiyoshaListByDispCondition.json");
	}

	@Test
	@DisplayName("ログイン職員が参照可能な管理名を取得します")
	public void TestGetKoseiinListByDispCondition() throws Exception{
		List<List<KoseiinJohoDto>> jsonData = new ArrayList<List<KoseiinJohoDto>>();
		List<SearchConditionsDto> conditionsDtos = new ArrayList<SearchConditionsDto>();
		SearchConditionsDto conditionsDto = new SearchConditionsDto();
		conditionsDtos.add(conditionsDto);

		//SearchRiyoshaConditionsDto conditionsDto
		List<KoseiinJohoDto> list = kensakuService.getKoseiinListByDispCondition(conditionsDtos.get(0));
		assertEquals(2, list.size());
		jsonData.add(list);
		exportJsonData(jsonData, "TestGetKoseiinListByDispCondition.json");
	}

	@Test
	@DisplayName("ログイン職員が参照可能な管理名を取得します")
	public void TestGetShokuinKensaku() throws Exception{
		List<List<ShokuinDto>> jsonData = new ArrayList<List<ShokuinDto>>();
		List<String> loginId = new ArrayList<String>();
		loginId.add("1");
		loginId.add("2");

		List<String> sLoginIdMuchSelectCode =  new ArrayList<String>();
		loginId.add("1");
		loginId.add("2");

		List<String> shokuinKanaName =  new ArrayList<String>();
		loginId.add("1");
		loginId.add("2");

		List<String> loginKind =  new ArrayList<String>();
		loginId.add("1");
		loginId.add("2");

		List<List<MKanri>> conditionsDtoslst = new ArrayList<List<MKanri>>();
		List<MKanri> conditionsDtos = new ArrayList<MKanri>();
		MKanri conditionsDto = new MKanri();
		conditionsDtos.add(conditionsDto);
		conditionsDtoslst.add(conditionsDtos);

		//String loginId, String sLoginIdMuchSelectCode,
		//String shokuinKanaName, List<MKanri> kanriCodePairs, String loginKind

		List<ShokuinDto> list = kensakuService.getShokuinKensaku(loginId.get(0),
																 sLoginIdMuchSelectCode.get(0),
																 shokuinKanaName.get(0),
																 conditionsDtoslst.get(0),
																 loginKind.get(0));
		assertEquals(2, list.size());
		jsonData.add(list);
		exportJsonData(jsonData, "TestGetShokuinKensaku.json");
	}

}
