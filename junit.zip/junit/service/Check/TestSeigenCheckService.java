package jp.ne.yec.seagullLC.stagia.test.junit.service.Check;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.seagullLC.stagia.beans.shinsei.ShinseiMeisaiDto;
import jp.ne.yec.seagullLC.stagia.service.check.SeigenCheckService;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = { "classpath:TestApplicationContext.xml" })
@WebAppConfiguration
public class TestSeigenCheckService extends JunitBase {

	@Autowired
	SeigenCheckService seigenCheckService;

	@Test
	@DisplayName("ログイン職員が参照可能な管理名を取得します")
	public void TestShinseiSeigenCheck() throws Exception {
//		List<List<MKanri>> jsonData = new ArrayList<List<MKanri>>();
//
//		String loginId = "";
//		Short riyoshaGroupCode = 1;
//
//		List<Map<ShinseiShurui, List<T>>> shinseiMaps = new ArrayList<Map<ShinseiShurui, List<T>>>();
//		Map<ShinseiShurui, List<T>> shinseiMap = new HashMap<ShinseiShurui, List<T>>();
//		ShinseiShurui ShinseiDto = ShinseiShurui.CHUSEN;
//		List<ShinseiMeisaiDto> shinseiMeisaiDtos = new ArrayList<ShinseiMeisaiDto>();
//		ShinseiMeisaiDto shinseiMeisai = new ShinseiMeisaiDto();
//		shinseiMeisaiDtos.add(shinseiMeisai);
//		shinseiMap.put(ShinseiDto, shinseiMeisaiDtos);
//		shinseiMaps.add(shinseiMap);
//
//		Date uketsukeDate = new Date();
//
//		//String loginId, Short riyoshaGroupCode,
//		//Map<ShinseiShurui, List<T>> meisaiMap, Date uketsukeDate
//		List<ShinseiMeisaiDto extends TShinseiMeisai> list = seigenCheckService.shinseiSeigenCheck(loginId, riyoshaGroupCode, shinseiMaps.get(0), uketsukeDate);
//		assertEquals(2, list.size());
//		jsonData.add(list);
//		exportJsonData(jsonData, "TestGetKanrimeiList.json");
	}

	@Test
	@DisplayName("ログインID、管理コード、使用日(From)、使用日(To)を元に仮予約のT_申請明細を取得します.")
	@TestInitDataFile("TestGetShinseiMeisaiInit.xlsx")
	public void TestGetShinseiMeisai() throws Exception {
		List<List<ShinseiMeisaiDto>> jsonData = new ArrayList<List<ShinseiMeisaiDto>>();

		List<String> listLoginId = new ArrayList<String>();
		listLoginId.add("1");

		List<List<ShinseiMeisaiDto>> shinseiMeisaiDtos = new ArrayList<>();
		List<ShinseiMeisaiDto> shinseiMeisaiDto = new ArrayList<>();
		shinseiMeisaiDtos.add(shinseiMeisaiDto);

		seigenCheckService.riyoshaSeigenCheck(listLoginId.get(0), shinseiMeisaiDtos.get(0));

	}
}
