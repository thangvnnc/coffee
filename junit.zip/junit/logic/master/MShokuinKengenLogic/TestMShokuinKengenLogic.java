package jp.ne.yec.seagullLC.stagia.test.junit.logic.master.MShokuinKengenLogic;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.beans.shokai.ShokuinDto;
import jp.ne.yec.seagullLC.stagia.entity.MKanri;
import jp.ne.yec.seagullLC.stagia.entity.MShokuinKengen;
import jp.ne.yec.seagullLC.stagia.logic.master.MShokuinKengenLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestMShokuinKengenLogic extends JunitBase {

	@Autowired
	MShokuinKengenLogic mShokuinKengenLogic;

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetShokuinkengen.xlsx")
	public void TestgetShokuinkengen() throws Exception
	{
		String loginId = "0_test";
		List<MShokuinKengen> ret = mShokuinKengenLogic.getShokuinkengen(loginId);
		exportJsonData(ret, "TestgetShokuinkengen.json");
	}

	@Test
	@DisplayName("検索条件なしで場所マスタを取得し、返却します")
	@TestInitDataFile("TestgetShokuinkengen.xlsx")
	public void TestInsertMShokuinKengen() throws Exception
	{
		Map<Short, MKanri> mMapMKanri = new HashMap<>();
		MKanri mKanri = new MKanri();
		mKanri.setKanriCode((short)12);
		mMapMKanri.put((short) 12, mKanri);

		ShokuinDto shokuinDto = new ShokuinDto();
		shokuinDto.setLoginId("abc");
		String updatedBys = "test";
	
		mShokuinKengenLogic.insertMShokuinKengen(mMapMKanri, shokuinDto, updatedBys);
	}
	
	@Test
	@DisplayName("検索条件なしで場所マスタを取得し、返却します")
	@TestInitDataFile("TestgetShokuinkengen.xlsx")
	public void TestInsertMShokuinKengen2() throws Exception
	{
		Map<Short, MKanri> mMapMKanri = new HashMap<>();
		MKanri mKanri = new MKanri();
		mKanri.setKanriCode((short)10);
		mMapMKanri.put((short) 10, mKanri);

		ShokuinDto shokuinDto = new ShokuinDto();
		shokuinDto.setLoginId("abc");
		List<MKanri> listKanri = new ArrayList<>();
		listKanri.add(mKanri);
		shokuinDto.setKanriCodeCK(listKanri);
		String updatedBys = "test";
	
		mShokuinKengenLogic.insertMShokuinKengen(mMapMKanri, shokuinDto, updatedBys);
	}

	@Test
	@DisplayName("検索条件なしで場所マスタを取得し、返却します")
	@TestInitDataFile("TestgetShokuinkengen.xlsx")
	public void TestUpdateMShokuinKengen() throws Exception
	{
		Map<Short, MKanri> mMapMKanri = new HashMap<>();
		MKanri mKanri = new MKanri();
		mKanri.setKanriCode((short)10);
		mMapMKanri.put((short) 10, mKanri);

		ShokuinDto shokuinDto = new ShokuinDto();
		shokuinDto.setLoginId("0_test");
		
		List<MShokuinKengen> mShokuinKengenList = new ArrayList<>();
		MShokuinKengen mSho = new MShokuinKengen();
		mSho.setKanriCode((short)10);
		mSho.setVersion(2);
		mShokuinKengenList.add(mSho);
		
		shokuinDto.setMShokuinKengenList(mShokuinKengenList);
		List<MKanri> listKanri = new ArrayList<>();
		listKanri.add(mKanri);
		shokuinDto.setKanriCodeCK(listKanri);
		shokuinDto.setVersion(2);
		
		String updatedBys = "test";
		
		mShokuinKengenLogic.updateMShokuinKengen(mMapMKanri, shokuinDto, updatedBys);
	}
	
	@Test
	@DisplayName("検索条件なしで場所マスタを取得し、返却します")
	@TestInitDataFile("TestgetShokuinkengen.xlsx")
	public void TestUpdateMShokuinKengen2() throws Exception
	{
		Map<Short, MKanri> mMapMKanri = new HashMap<>();
		MKanri mKanri = new MKanri();
		mKanri.setKanriCode((short)10);
		mMapMKanri.put((short) 10, mKanri);

		ShokuinDto shokuinDto = new ShokuinDto();
		shokuinDto.setLoginId("0");
		
		List<MShokuinKengen> mShokuinKengenList = new ArrayList<>();
		MShokuinKengen mSho = new MShokuinKengen();
		mSho.setKanriCode((short)12);
		//mSho.setVersion(1);
		mShokuinKengenList.add(mSho);
		
		shokuinDto.setMShokuinKengenList(mShokuinKengenList);
		List<MKanri> listKanri = new ArrayList<>();
		listKanri.add(mKanri);
		shokuinDto.setKanriCodeCK(listKanri);
		//shokuinDto.setVersion(1);
		
		String updatedBys = "test";
		
		mShokuinKengenLogic.updateMShokuinKengen(mMapMKanri, shokuinDto, updatedBys);
	}
	
	@Test
	@DisplayName("検索条件なしで場所マスタを取得し、返却します")
	@TestInitDataFile("TestgetShokuinkengen2.xlsx")
	public void TestUpdateMShokuinKengen3() throws Exception
	{
		Map<Short, MKanri> mMapMKanri = new HashMap<>();
		MKanri mKanri = new MKanri();
		mKanri.setKanriCode((short)10);
		mMapMKanri.put((short) 10, mKanri);

		ShokuinDto shokuinDto = new ShokuinDto();
		shokuinDto.setLoginId("0_test");
		
		List<MShokuinKengen> mShokuinKengenList = new ArrayList<>();
		MShokuinKengen mSho = new MShokuinKengen();
		mSho.setKanriCode((short)10);
		mSho.setVersion(2);
		mSho.setAllowedUpdate(false);
		mShokuinKengenList.add(mSho);
		
		shokuinDto.setMShokuinKengenList(mShokuinKengenList);
		List<MKanri> listKanri = new ArrayList<>();
		listKanri.add(mKanri);
		shokuinDto.setKanriCodeCK(listKanri);
		shokuinDto.setVersion(2);
		String updatedBys = "test";
		
		mShokuinKengenLogic.updateMShokuinKengen(mMapMKanri, shokuinDto, updatedBys);
	}
	
	@Test
	@DisplayName("検索条件なしで場所マスタを取得し、返却します")
	//@TestInitDataFile("TestgetShokuinkengen.xlsx")
	public void TestgetDao() throws Exception
	{
		GenericDao<MShokuinKengen, ?> ret = mShokuinKengenLogic.getDao();
	}
}