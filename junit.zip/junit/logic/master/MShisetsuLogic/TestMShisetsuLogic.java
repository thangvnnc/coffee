package jp.ne.yec.seagullLC.stagia.test.junit.logic.master.MShisetsuLogic;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.beans.StringCodeNamePair;
import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.entity.MShisetsu;
import jp.ne.yec.seagullLC.stagia.logic.master.MShisetsuLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestMShisetsuLogic extends JunitBase {

	@Autowired
	MShisetsuLogic mShisetsuLogic;

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetMShisetsuList.xlsx")
	public void TestgetMShisetsuList() throws Exception
	{
		List<MShisetsu> ret =  mShisetsuLogic.getMShisetsuList();
		exportJsonData(ret, "TestgetMShisetsuList.json");
	}

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetMShisetsuList.xlsx")
	public void TestgetMShisetsuList_Short() throws Exception
	{
		short kanriCode = 10;
		List<MShisetsu> ret =  mShisetsuLogic.getMShisetsuList(kanriCode);
		exportJsonData(ret, "TestgetMShisetsuList_Short.json");
	}
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetMShisetsuList.xlsx")
	public void TestgetMShisetsuListByKanriCode() throws Exception
	{
		List<Short> kanriCodes = new ArrayList<>();
		kanriCodes.add((short)10);
		
		List<MShisetsu>  ret = mShisetsuLogic.getMShisetsuListByKanriCode(kanriCodes);
		exportJsonData(ret, "TestgetMShisetsuListByKanriCode.json");
	}

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetMShisetsuList.xlsx")
	public void TestgetMShisetsuListByBashoCode() throws Exception
	{
		List<Short> bashoCodes = new ArrayList<>();
		bashoCodes.add((short)10);

		List<MShisetsu> ret = mShisetsuLogic.getMShisetsuListByBashoCode(bashoCodes);
		exportJsonData(ret, "TestgetMShisetsuListByBashoCode.json");
	}

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetMShisetsuList.xlsx")
	public void TestgetMShisetsuListByBashoCode_List() throws Exception
	{
		Short kanriCode = 10;
		Short bashoCode = 10;
		List<MShisetsu> ret  = mShisetsuLogic.getMShisetsuListByBashoCode(kanriCode, bashoCode);
		exportJsonData(ret, "TestgetMShisetsuListByBashoCode_List.json");
	}

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetMShisetsuList.xlsx")
	public void TestgetStringCodeNamePairList() throws Exception
	{
		Short kanriCode = 10;
		Short bashoCode = 10;
		List<StringCodeNamePair> ret = mShisetsuLogic. getStringCodeNamePairList(kanriCode,bashoCode);
		exportJsonData(ret, "TestgetStringCodeNamePairList.json");
	}

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetMShisetsuList.xlsx")
	public void TestgetMShisetsu() throws Exception
	{
		short kanriCode = 10;
		short shisetsuCode = 10;
		MShisetsu  ret = mShisetsuLogic. getMShisetsu(kanriCode,shisetsuCode);
		exportJsonData(ret, "TestgetMShisetsu.json");
	}

	@Test
	@DisplayName("検索条件なしで場所マスタを取得し、返却します")
	@TestInitDataFile("TestgetMShisetsuList.xlsx")
	public void TestGetMShisetsuList() throws Exception
	{
		Map<Short, List<Short>> kanriShisetsuCodeMap = new HashMap<>();
		List<Short> shorts2 = new ArrayList<>();
		shorts2.add((short)10);
		kanriShisetsuCodeMap.put((short) 10, shorts2);

		List<MShisetsu> ret = mShisetsuLogic.getMShisetsuList(kanriShisetsuCodeMap);
		exportJsonData(ret, "TestGetMShisetsuList.json");
	}

	@Test
	@DisplayName("検索条件なしで場所マスタを取得し、返却します")
	//@TestInitDataFile("TestgetMBashoList.xlsx")
	public void TestgetDao() throws Exception
	{
		GenericDao<MShisetsu, ?> ret = mShisetsuLogic.getDao();
	}
}