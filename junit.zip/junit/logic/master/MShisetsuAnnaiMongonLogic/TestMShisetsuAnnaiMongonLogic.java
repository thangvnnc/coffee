package jp.ne.yec.seagullLC.stagia.test.junit.logic.master.MShisetsuAnnaiMongonLogic;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.entity.MShisetsuAnnaiMongon;
import jp.ne.yec.seagullLC.stagia.logic.master.MShisetsuAnnaiMongonLogic;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestMShisetsuAnnaiMongonLogic extends JunitBase {


	@Autowired
	MShisetsuAnnaiMongonLogic mShisetsuAnnaiMongonLogic;

	@Test
	@DisplayName("引数なしでM_料金体系を取得します.")
	//@TestInitDataFile("TestRiyoshaServiceInit.xlsx")
	public void TestGetDAO() throws Exception {
		GenericDao<MShisetsuAnnaiMongon, ?> ret = mShisetsuAnnaiMongonLogic.getDao();
		//assertEquals(mRyokinTaikeiDao, ret);
	}
}

