package jp.ne.yec.seagullLC.stagia.test.junit.logic.master.MSetSetsubiLogic;

import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.beans.shinsei.SetSetsubiInfoDto;
import jp.ne.yec.seagullLC.stagia.entity.MSetSetsubi;
import jp.ne.yec.seagullLC.stagia.logic.master.MSetSetsubiLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestMSetSetsubiLogic extends JunitBase {

	@Autowired
	MSetSetsubiLogic mSetSetsubiLogic;

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetSetSetsubiInit.xlsx")
	public void TestgetSetSetsubi() throws Exception
	{
		Short kanriCode = 10;
		Short bashoCode = 10;
		
		List<SetSetsubiInfoDto>  ret = mSetSetsubiLogic.getSetSetsubi(kanriCode, bashoCode);
		exportJsonData(ret, "TestgetSetSetsubi.json");
	}
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	//@TestInitDataFile("TestgetMBashoList.xlsx")
	public void TestgetDao() throws Exception
	{
		GenericDao<MSetSetsubi, ?> ret =  mSetSetsubiLogic.getDao();
	}
}