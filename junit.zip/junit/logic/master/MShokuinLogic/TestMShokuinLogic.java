package jp.ne.yec.seagullLC.stagia.test.junit.logic.master.MShokuinLogic;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.beans.shokai.ShokuinDto;
import jp.ne.yec.seagullLC.stagia.entity.MShokuin;
import jp.ne.yec.seagullLC.stagia.logic.master.MShokuinLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestMShokuinLogic extends JunitBase {

	@Autowired
	MShokuinLogic mShokuinLogic;

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	//@TestInitDataFile("TestgetMBashoList.xlsx")
	public void TestgetDao() throws Exception
	{
		GenericDao<MShokuin, ?> ret = mShokuinLogic.getDao();
	}

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestlogicalDeleteShokuin.xlsx")
	public void TestgetMRyokinTaikeiList() throws Exception
	{
		String loginId = "0_test";

		MShokuin ret =  mShokuinLogic.getMShokuin(loginId);
		exportJsonData(ret, "TestgetMRyokinTaikeiList.json");
	}

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestlogicalDeleteShokuin.xlsx")
	public void TestgetShokuinKensaku() throws Exception
	{
		List<Short> kanriCodes = new ArrayList<>();
		kanriCodes.add((short)10);
		String loginId = "1";
		String sLoginIdMuchSelectCode= "0";
		String shokuinKanaName= "test";
		String loginKind = "0";
	
		List<ShokuinDto> ret =  mShokuinLogic.getShokuinKensaku(loginId,sLoginIdMuchSelectCode,
								shokuinKanaName,kanriCodes,loginKind);
		exportJsonData(ret, "TestgetShokuinKensaku.json");
	}
	
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestlogicalDeleteShokuin.xlsx")
	public void TestgetShokuinKensaku2() throws Exception
	{
		List<Short> kanriCodes = null;
		String loginId = "1";
		String sLoginIdMuchSelectCode= "1";
		String shokuinKanaName= null;
		String loginKind = "0";
	
		List<ShokuinDto> ret =  mShokuinLogic.getShokuinKensaku(loginId,sLoginIdMuchSelectCode,
								shokuinKanaName,kanriCodes,loginKind);
		exportJsonData(ret, "TestgetShokuinKensaku2.json");
	}
	
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestlogicalDeleteShokuin.xlsx")
	public void TestgetShokuinKensaku3() throws Exception
	{
		List<Short> kanriCodes = null;
		String loginId = null;
		String sLoginIdMuchSelectCode= null;
		String shokuinKanaName= null;
		String loginKind = "0";
	
		List<ShokuinDto> ret =  mShokuinLogic.getShokuinKensaku(loginId,sLoginIdMuchSelectCode,
								shokuinKanaName,kanriCodes,loginKind);
		exportJsonData(ret, "TestgetShokuinKensaku3.json");
	}
	
	
	
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestlogicalDeleteShokuin.xlsx")
	public void TestgetShokuinKensaku4() throws Exception
	{
		List<Short> kanriCodes = null;
		String loginId = "1";
		String sLoginIdMuchSelectCode = "ads";
		String shokuinKanaName= null;
		String loginKind = "0";
	
		List<ShokuinDto> ret =  mShokuinLogic.getShokuinKensaku(loginId,sLoginIdMuchSelectCode,
								shokuinKanaName,kanriCodes,loginKind);
		exportJsonData(ret, "TestgetShokuinKensaku4.json");
	}
	
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestlogicalDeleteShokuin.xlsx")
	public void TestgetShokuinKensaku5() throws Exception
	{
		List<Short> kanriCodes = null;
		String loginId = null;
		String sLoginIdMuchSelectCode= "0";
		String shokuinKanaName= null;
		String loginKind = "0";
	
		List<ShokuinDto> ret =  mShokuinLogic.getShokuinKensaku(loginId,sLoginIdMuchSelectCode,
								shokuinKanaName,kanriCodes,loginKind);
		exportJsonData(ret, "TestgetShokuinKensaku5.json");
	}
	
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestlogicalDeleteShokuin.xlsx")
	public void TestgetShokuinKensaku6() throws Exception
	{
		List<Short> kanriCodes = null;
		String loginId = "1";
		String sLoginIdMuchSelectCode= null;
		String shokuinKanaName= null;
		String loginKind = "0";
	
		List<ShokuinDto> ret =  mShokuinLogic.getShokuinKensaku(loginId,sLoginIdMuchSelectCode,
								shokuinKanaName,kanriCodes,loginKind);
		exportJsonData(ret, "TestgetShokuinKensaku6.json");
	}

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestlogicalDeleteShokuin.xlsx")
	public void TestlogicalDeleteShokuin() throws Exception
	{
		String updatedBy = "a";

		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/M/d HH:mm");
		Date dateCreate = new Date();
		dateCreate = dateFormat.parse("2018/1/22 14:17");
		long timeCreate = dateCreate.getTime();
		Timestamp tCreate = new Timestamp(timeCreate);

		Date dateUpdate = new Date();
		dateUpdate = dateFormat.parse("2018/1/22 14:19");
		long timeUpdate= dateUpdate.getTime();
		Timestamp tUpdate = new Timestamp(timeUpdate);
		
		ShokuinDto shokuinDto = new ShokuinDto();
		shokuinDto.setVersion(1);
		shokuinDto.setLoginId("1111");
		//shokuinDto.setDeleted(false);
		//shokuinDto.setSyokuinKanaName("test");
		//shokuinDto.setUketsukeBashoCode((short)10);
		//shokuinDto.setUpdatedBy("test");
		//shokuinDto.setCreatedBy("test");
		//shokuinDto.setCreatedAt(tCreate);
		//shokuinDto.setUpdatedAt(tUpdate);
		
		mShokuinLogic.logicalDeleteShokuin(shokuinDto, updatedBy);
	}
}