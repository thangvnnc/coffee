package jp.ne.yec.seagullLC.stagia.test.junit.logic.master.MShisetsuKasanLogic;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.entity.MShisetsuKasan;
import jp.ne.yec.seagullLC.stagia.logic.master.MShisetsuKasanLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestMShisetsuKasanLogic extends JunitBase {

	@Autowired
	MShisetsuKasanLogic mShisetsuKasanLogic;

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetMShisetsuKasan.xlsx")
	public void TestgetMShisetsuKasan() throws Exception
	{
		Short kanriCode = 10;
		Short shisetsuCode = 10;
		Date ryokinKeisanKijunDate  = new Date();
		List<MShisetsuKasan>  ret = mShisetsuKasanLogic.getMShisetsuKasan(kanriCode, shisetsuCode, ryokinKeisanKijunDate);
		exportJsonData(ret, "TestgetMShisetsuKasan.json");
	}

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetMShisetsuKasan.xlsx")
	public void TestgetNyujoRyokinSettingCount() throws Exception
	{
		Short kanriCode = 10;
		long  ret =  mShisetsuKasanLogic.getNyujoRyokinSettingCount(kanriCode);
		assertEquals(1, ret);
	}

	@Test
	@DisplayName("検索条件なしで場所マスタを取得し、返却します")
	@TestInitDataFile("TestgetMShisetsuKasan.xlsx")
	public void TestGetMShisetsuKasan_map() throws Exception
	{
		Map<Short, List<Short>> kanriShisetsuCodeMap = new HashMap<>();
		List<Short> kanriShisetsuCodes = new ArrayList<>();
		kanriShisetsuCodes.add((short)10);
		kanriShisetsuCodeMap.put((short)10, kanriShisetsuCodes);

		List<MShisetsuKasan> ret = mShisetsuKasanLogic.getMShisetsuKasan(kanriShisetsuCodeMap);
		exportJsonData(ret, "TestGetMShisetsuKasan_map.json");
	}

	@Test
	@DisplayName("検索条件なしで場所マスタを取得し、返却します")
	//@TestInitDataFile("TestgetMBashoList.xlsx")
	public void TestgetDao() throws Exception
	{
		GenericDao<MShisetsuKasan, ?> ret = mShisetsuKasanLogic.getDao() ;
	}
}