package jp.ne.yec.seagullLC.stagia.test.junit.logic.master.MGinkoLogic;

import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.beans.StringCodeNamePair;
import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.entity.MGinko;
import jp.ne.yec.seagullLC.stagia.logic.master.MGinkoLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestMGinkoLogic extends JunitBase {

	@Autowired
	MGinkoLogic mGinkoLogic;

	@Test
	@DisplayName("検索条件なしでM_銀行を取得し、返却します")
	@TestInitDataFile("TestgetMGinkoList.xlsx")
	public void TestgetMGinkoList() throws Exception
	{
		List<MGinko>  ret = mGinkoLogic.getMGinkoList();
		exportJsonData(ret, "TestgetMGinkoList.json");
	}

	@Test
	@DisplayName("検索条件なしでM_銀行を取得しStringCodeNamePairの形式で返却します")
	@TestInitDataFile("TestgetMGinkoList.xlsx")
	public void TestgetStringCodeNamePairList() throws Exception
	{
		List<StringCodeNamePair>  ret = mGinkoLogic.getStringCodeNamePairList();
		exportJsonData(ret, "TestgetStringCodeNamePairList.json");
	}


	@Test
	@DisplayName("  データ更新に使用するDaoを取得します")
	//@TestInitDataFile("TestgetMBashoList.xlsx")
	public void TestgetDao() throws Exception
	{
		GenericDao<MGinko, ?>  ret = mGinkoLogic.getDao();
	}
}