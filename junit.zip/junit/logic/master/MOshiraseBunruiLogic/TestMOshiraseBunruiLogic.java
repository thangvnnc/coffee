package jp.ne.yec.seagullLC.stagia.test.junit.logic.master.MOshiraseBunruiLogic;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.beans.StringCodeNamePair;
import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.entity.MOshiraseBunrui;
import jp.ne.yec.seagullLC.stagia.logic.master.MOshiraseBunruiLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestMOshiraseBunruiLogic extends JunitBase {

	@Autowired
	MOshiraseBunruiLogic mOshiraseBunruiLogic;

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetMOshiraseBunruiList.xlsx")
	public void TestgetMOshiraseBunruiList() throws Exception
	{
		List<MOshiraseBunrui> ret =  mOshiraseBunruiLogic.getMOshiraseBunruiList();
		exportJsonData(ret, "TestgetMOshiraseBunruiList.json");
	}

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetMOshiraseBunruiList.xlsx")
	public void TestgetMKomaList() throws Exception
	{
		List<StringCodeNamePair> ret =  mOshiraseBunruiLogic.getStringCodeNamePairList();
		exportJsonData(ret, "TestgetMKomaList.json");
	}
	
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetMOshiraseBunruiList.xlsx")
	public void TestToStringCodeNamePair() throws Exception
	{
		List<MOshiraseBunrui> list = new ArrayList<>();
		MOshiraseBunrui mOshiraseBunrui = new MOshiraseBunrui();
		mOshiraseBunrui.setOshiraseBunruiCode((short)1);
		mOshiraseBunrui.setOshiraseBunruiName("運用");
		list.add(mOshiraseBunrui);
		
		List<StringCodeNamePair> ret =  mOshiraseBunruiLogic.toStringCodeNamePair(list);
		exportJsonData(ret, "TestToStringCodeNamePair.json");
	}
	
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	//@TestInitDataFile("TestgetMBashoList.xlsx")
	public void TestgetDao() throws Exception
	{
		GenericDao<MOshiraseBunrui, ?> ret =  mOshiraseBunruiLogic.getDao();
	}
}