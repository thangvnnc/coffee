package jp.ne.yec.seagullLC.stagia.test.junit.logic.master.MShinseinaiSeigenLogic;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.entity.MShinseinaiSeigen;
import jp.ne.yec.seagullLC.stagia.logic.master.MShinseinaiSeigenLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestMShinseinaiSeigenLogic extends JunitBase {


	@Autowired
	MShinseinaiSeigenLogic mShinseinaiSeigenLogic;

	@Test
	@DisplayName("引数なしでM_料金体系を取得します.")
	@TestInitDataFile("TestgetMShinseinaiSeigen.xlsx")
	public void TestgetMShinseinaiSeigen() throws Exception
	{
		List<Short> seigenGroupCodes = new ArrayList<>();
		seigenGroupCodes.add((short)10);

		List<MShinseinaiSeigen> ret = mShinseinaiSeigenLogic.getMShinseinaiSeigen(seigenGroupCodes);
		exportJsonData(ret, "TestgetMShinseinaiSeigen.json");
	}

	@Test
	@DisplayName("引数なしでM_料金体系を取得します.")
	//@TestInitDataFile("TestRiyoshaServiceInit.xlsx")
	public void TestGetDAO() throws Exception
	{
		GenericDao<MShinseinaiSeigen, ?> ret = mShinseinaiSeigenLogic.getDao();
		//assertEquals(mRyokinTaikeiDao, ret);
	}
}

