package jp.ne.yec.seagullLC.stagia.test.junit.logic.master.MChusenGroupLogic;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.beans.StringCodeNamePair;
import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.entity.MChusenGroup;
import jp.ne.yec.seagullLC.stagia.logic.master.MChusenGroupLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestMChusenGroupLogic extends JunitBase {

	@Autowired
	MChusenGroupLogic mChusenGroupLogic;

	@Test
	@DisplayName("検索条件無しで「M_抽選グループ」の件数を取得します")
	@TestInitDataFile("TestMChusenGroupLogic.xlsx")
	public void TestgetMChusenGCount() throws Exception
	{
		long ret = mChusenGroupLogic.getMChusenGCount();
		assertEquals(5, ret);
	}

	@Test
	@DisplayName("有効な「M_抽選グループ」を返却します")
	@TestInitDataFile("TestMChusenGroupLogicList.xlsx")
	public void TestgetValidMChusenGroup() throws Exception
	{
		List<MChusenGroup> ret = mChusenGroupLogic.getValidMChusenGroup();
		exportJsonData(ret, "TestgetValidMChusenGroup.json");
	}

	@Test
	@DisplayName("検索条件なしでM_抽選グループを取得します")
	@TestInitDataFile("TestMChusenGroupLogic.xlsx")
	public void TestgetAllMChusenGroupList() throws Exception
	{
		List<MChusenGroup> ret = mChusenGroupLogic.getAllMChusenGroupList();
		exportJsonData(ret, "TestgetAllMChusenGroupList.json");
	}

	@Test
	@DisplayName("有効な「M_抽選グループ」を返却します")
	@TestInitDataFile("TestMChusenGroupLogic.xlsx")
	public void TestgetStringCodeNamePairList() throws Exception
	{
		List<StringCodeNamePair> ret = mChusenGroupLogic.getStringCodeNamePairList();
		exportJsonData(ret, "TestgetStringCodeNamePairList.json");
	}

	@Test
	@DisplayName("有効な「M_抽選グループ」を返却します")
	@TestInitDataFile("TestMChusenGroupLogic.xlsx")
	public void TestgetMChusenGroupByChusenGroupCode() throws Exception
	{
		List<Short> chusenGroupCodes = new ArrayList<Short> ();
		Short chusenGroupCode = 12;
		chusenGroupCodes.add(chusenGroupCode);
		List<MChusenGroup> ret = mChusenGroupLogic. getMChusenGroupByChusenGroupCode(chusenGroupCodes);
		exportJsonData(ret, "TestgetMChusenGroupByChusenGroupCode.json");
	}

	@Test
	@DisplayName("有効な「M_抽選グループ」を返却します")
	@TestInitDataFile("TestMChusenGroupLogic.xlsx")
	public void TestgetMChusenGroupByChusenGroupCodes() throws Exception
	{
		Short chusenGroupCode = 12;
		MChusenGroup ret = mChusenGroupLogic.getMChusenGroupByChusenGroupCode(chusenGroupCode);
		exportJsonData(ret, "TestgetMChusenGroupByChusenGroupCodes.json");
	}

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	// @TestInitDataFile("TestRiyoshaServiceInit.xlsx")
	public void TestgetDao() throws Exception
	{
		GenericDao<MChusenGroup, ?> ret = mChusenGroupLogic.getDao();
	}
}