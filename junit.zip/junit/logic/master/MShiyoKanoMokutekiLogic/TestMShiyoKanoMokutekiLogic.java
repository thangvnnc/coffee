package jp.ne.yec.seagullLC.stagia.test.junit.logic.master.MShiyoKanoMokutekiLogic;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.entity.MShiyoKanoMokuteki;
import jp.ne.yec.seagullLC.stagia.logic.master.MShiyoKanoMokutekiLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestMShiyoKanoMokutekiLogic extends JunitBase {

	@Autowired
	MShiyoKanoMokutekiLogic mShiyoKanoMokutekiLogic;

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetMShiyoKanoMokuteki.xlsx")
	public void TestgetMShiyoKanoMokutekiByKanriCodeList() throws Exception
	{
		List<Short> kanriCodes = new ArrayList<>();
		kanriCodes.add((short) 10);

		List<MShiyoKanoMokuteki>  ret = mShiyoKanoMokutekiLogic.getMShiyoKanoMokutekiByKanriCodeList(kanriCodes);
		exportJsonData(ret,	"TestgetMShiyoKanoMokutekiByKanriCodeList.json");
	}

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetMShiyoKanoMokuteki.xlsx")
	public void TestgetMShiyoKanoMokutekiByMokutekiCodeList() throws Exception
	{
		List<Short> mokutekiCodes = new ArrayList<>();
		mokutekiCodes.add((short) 1010);
		List<MShiyoKanoMokuteki>  ret = mShiyoKanoMokutekiLogic.getMShiyoKanoMokutekiByMokutekiCodeList(mokutekiCodes);
		exportJsonData(ret, "TestgetMShiyoKanoMokutekiByMokutekiCodeList.json");
	}

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	//@TestInitDataFile("TestgetMBashoList.xlsx")
	public void TestgetDao() throws Exception
	{
		GenericDao<MShiyoKanoMokuteki, ?> ret =  mShiyoKanoMokutekiLogic.getDao();
	}
}