package jp.ne.yec.seagullLC.stagia.test.junit.logic.master.MKampuRiyuLogic;

import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.entity.MKampuRiyu;
import jp.ne.yec.seagullLC.stagia.logic.master.MKampuRiyuLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestMKampuRiyuLogic extends JunitBase {

	@Autowired
	MKampuRiyuLogic mKampuRiyuLogic;

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetMKampuRiyu.xlsx")
	public void TestgetMKampuRiyu() throws Exception
	{
		Short kanriCode = 10;
		List<MKampuRiyu> ret = mKampuRiyuLogic.getMKampuRiyu(kanriCode);
		exportJsonData(ret, "TestgetMKampuRiyu.json");
	}
	@Test
	@DisplayName("  データ更新に使用するDaoを取得します")
	//@TestInitDataFile("TestgetMBashoList.xlsx")
	public void TestgetDao() throws Exception
	{
		GenericDao<MKampuRiyu, ?> ret =  mKampuRiyuLogic.getDao();
	}
}