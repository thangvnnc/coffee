package jp.ne.yec.seagullLC.stagia.test.junit.logic.master.MWebSetteiLogic;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.entity.MWebSettei;
import jp.ne.yec.seagullLC.stagia.logic.master.MWebSetteiLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestMWebSetteiLogic extends JunitBase {

	@Autowired
	MWebSetteiLogic mWebSetteiLogic;

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetMWebSettei.xlsx")
	public void TestgetMWebSettei() throws Exception
	{
		List<Short> kanriCodes = new ArrayList<>();
		kanriCodes.add((short)10);

		List<MWebSettei> exports = new ArrayList<>();
		for(int item = 0; item < kanriCodes.size(); item ++)
		{
			Short kanriCode=  kanriCodes.get(item);
			MWebSettei ret = mWebSetteiLogic.getMWebSettei(kanriCode);
			exports.add(ret);
		}
		exportJsonData(exports, "TestgetMWebSettei.json");
	}

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetMWebSettei.xlsx")
	public void TestgetMWebSettei_List() throws Exception
	{
		List<List<Short>> kanriCodeLists = new ArrayList<>();
		List<Short> kanriCodes = new ArrayList<>();
		kanriCodes.add((short)10);
		kanriCodeLists.add(kanriCodes);

		List<List<MWebSettei>> exports = new ArrayList<>();
		for(int item = 0; item < kanriCodeLists.size(); item ++)
		{
			List<MWebSettei> ret = mWebSetteiLogic.getMWebSettei(kanriCodeLists.get(item));
			exports.add(ret);
		}
		exportJsonData(exports, "TestgetMWebSettei_List.json");
	}

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	//@TestInitDataFile("TestgetMBashoList.xlsx")
	public void TestgetDao() throws Exception
	{
		GenericDao<MWebSettei, ?> ret = mWebSetteiLogic.getDao();
	}
}