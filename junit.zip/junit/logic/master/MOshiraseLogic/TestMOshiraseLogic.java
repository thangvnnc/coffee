package jp.ne.yec.seagullLC.stagia.test.junit.logic.master.MOshiraseLogic;

import static org.junit.Assert.*;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.seagullLC.stagia.beans.unei.OshiraseViewDto;
import jp.ne.yec.seagullLC.stagia.logic.master.MOshiraseLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestMOshiraseLogic extends JunitBase {

	@Autowired
	MOshiraseLogic mOshiraseLogic;

//	@Test
//	@DisplayName("検索条件なしでM_管理を取得します")
//	@TestInitDataFile("TestgetMOshirase.xlsx")
//	public void TestgetMOshirase() throws Exception
//	{
//		Integer oshiraseId = 1;
//		MOshirase ret = mOshiraseLogic.getMOshirase(oshiraseId);
//		exportJsonData(ret, "TestgetMOshirase.json");
//	}
//
//	@Test
//	@DisplayName("検索条件なしでM_管理を取得します")
//	@TestInitDataFile("TestgetMOshiraseN.xlsx")
//	public void TestupdDeleted() throws Exception
//	{
//		Integer oshiraseId = 1;
//		Integer version = 2;
//		String updatedBy = "3333";
//		mOshiraseLogic.updDeleted(oshiraseId, version, updatedBy);
//	}

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetOshiraseByDispConditionInit.xlsx")
	public void TestgetOshiraseByDispCondition1() throws Exception
	{
		String hyojisakiShurui = "2";

		LocalDate hyojiStartDate = null;
		LocalDate hyojiEndDate = null;

		Boolean isIncludeDeleted = false;
		List<Short> kanriCodess = new ArrayList<Short>();
		kanriCodess.add((short)10);
		String loginId = "3333";
		String loginKind = "0";
		List<Short> shinseiGroupCodes = new ArrayList<Short>();
		shinseiGroupCodes.add((short)1);

		List<OshiraseViewDto> ret = mOshiraseLogic.getOshiraseByDispCondition(hyojisakiShurui,
					hyojiStartDate, hyojiEndDate, isIncludeDeleted, kanriCodess, loginId, loginKind,
					shinseiGroupCodes);
		exportJsonData(ret, "TestgetOshiraseByDispCondition1.json");
	}

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetOshiraseByDispConditionInit2.xlsx")
	public void TestgetOshiraseByDispCondition2() throws Exception
	{
		String hyojisakiShurui = "3";

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("M/d/yyyy");
		LocalDate hyojiStartDate = LocalDate.parse("1/1/2018", formatter);
		LocalDate hyojiEndDate =  LocalDate.parse("3/28/2018", formatter);

		Boolean isIncludeDeleted = true;
		List<Short> kanriCodess = new ArrayList<Short>();
		kanriCodess.add((short)10);
		String loginId = "3333";
		String loginKind = "0";
		List<Short> shinseiGroupCodes = new ArrayList<Short>();
		shinseiGroupCodes.add((short)1);

		List<OshiraseViewDto> ret = mOshiraseLogic.getOshiraseByDispCondition(hyojisakiShurui,
					hyojiStartDate, hyojiEndDate, isIncludeDeleted, kanriCodess, loginId, loginKind,
					shinseiGroupCodes);
		exportJsonData(ret, "TestgetOshiraseByDispCondition2.json");
	}

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetOshiraseByDispConditionInit3.xlsx")
	public void TestgetOshiraseByDispCondition3() throws Exception
	{
		String hyojisakiShurui = "6";

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("M/d/yyyy");
		LocalDate hyojiStartDate = LocalDate.parse("1/1/2018", formatter);
		LocalDate hyojiEndDate =  LocalDate.parse("3/28/2018", formatter);

		Boolean isIncludeDeleted = true;
		List<Short> kanriCodess = new ArrayList<Short>();
		kanriCodess.add((short)10);
		String loginId = null;
		String loginKind = "0";
		List<Short> shinseiGroupCodes = new ArrayList<Short>();
		shinseiGroupCodes.add((short)1);

		List<OshiraseViewDto> ret = mOshiraseLogic.getOshiraseByDispCondition(hyojisakiShurui,
					hyojiStartDate, hyojiEndDate, isIncludeDeleted, kanriCodess, loginId, loginKind,
					shinseiGroupCodes);
		exportJsonData(ret, "TestgetOshiraseByDispCondition3.json");
	}

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetOshiraseByDispConditionInit4.xlsx")
	public void TestgetOshiraseByDispCondition4() throws Exception
	{
		String hyojisakiShurui = "5";

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("M/d/yyyy");
		LocalDate hyojiStartDate = LocalDate.parse("1/1/2018", formatter);
		LocalDate hyojiEndDate =  LocalDate.parse("3/28/2018", formatter);

		Boolean isIncludeDeleted = true;
		List<Short> kanriCodess = new ArrayList<Short>();
		kanriCodess.add((short)10);
		String loginId = "3333";
		String loginKind = "0";
		List<Short> shinseiGroupCodes = new ArrayList<Short>();
		shinseiGroupCodes.add((short)1);

		List<OshiraseViewDto> ret = mOshiraseLogic.getOshiraseByDispCondition(hyojisakiShurui,
					hyojiStartDate, hyojiEndDate, isIncludeDeleted, kanriCodess, loginId, loginKind,
					shinseiGroupCodes);
		exportJsonData(ret, "TestgetOshiraseByDispCondition4.json");
	}

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetOshiraseByDispConditionInit5.xlsx")
	public void TestgetOshiraseByDispCondition5() throws Exception
	{
		String hyojisakiShurui = "1";

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("M/d/yyyy");
		LocalDate hyojiStartDate = LocalDate.parse("1/1/2018", formatter);
		LocalDate hyojiEndDate =  LocalDate.parse("3/28/2018", formatter);

		Boolean isIncludeDeleted = true;
		List<Short> kanriCodess = new ArrayList<Short>();
		kanriCodess.add((short)10);
		String loginId = "3333";
		String loginKind = "0";
		List<Short> shinseiGroupCodes = new ArrayList<Short>();
		shinseiGroupCodes.add((short)1);

		List<OshiraseViewDto> ret = mOshiraseLogic.getOshiraseByDispCondition(hyojisakiShurui,
					hyojiStartDate, hyojiEndDate, isIncludeDeleted, kanriCodess, loginId, loginKind,
					shinseiGroupCodes);
		exportJsonData(ret, "TestgetOshiraseByDispCondition5.json");
	}

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetOshiraseByDispConditionInit5.xlsx")
	public void TestgetOshiraseByDispCondition6() throws Exception
	{
		String hyojisakiShurui = "4";

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("M/d/yyyy");
		LocalDate hyojiStartDate = LocalDate.parse("1/1/2018", formatter);
		LocalDate hyojiEndDate =  LocalDate.parse("3/28/2018", formatter);

		Boolean isIncludeDeleted = true;
		List<Short> kanriCodess = new ArrayList<Short>();
		kanriCodess.add((short)10);
		String loginId = "3333";
		String loginKind = "0";
		List<Short> shinseiGroupCodes = new ArrayList<Short>();
		shinseiGroupCodes.add((short)1);

		List<OshiraseViewDto> ret = mOshiraseLogic.getOshiraseByDispCondition(hyojisakiShurui,
					hyojiStartDate, hyojiEndDate, isIncludeDeleted, kanriCodess, loginId, loginKind,
					shinseiGroupCodes);
		assertEquals(0, ret.size());
	}

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetOshiraseByDispConditionInit2.xlsx")
	public void TestgetOshiraseByDispCondition7() throws Exception
	{
		String hyojisakiShurui = "2";

		LocalDate hyojiStartDate = null;
		LocalDate hyojiEndDate = null;

		Boolean isIncludeDeleted = false;
		List<Short> kanriCodess = null;

		String loginId = "3333";
		String loginKind = "0";
		List<Short> shinseiGroupCodes = new ArrayList<Short>();
		shinseiGroupCodes.add((short)1);

		List<OshiraseViewDto> ret = mOshiraseLogic.getOshiraseByDispCondition(hyojisakiShurui,
					hyojiStartDate, hyojiEndDate, isIncludeDeleted, kanriCodess, loginId, loginKind,
					shinseiGroupCodes);
		assertEquals(0, ret.size());
	}

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetOshiraseByDispConditionInit4.xlsx")
	public void TestgetOshiraseByDispCondition8() throws Exception
	{
		String hyojisakiShurui = "5";

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("M/d/yyyy");
		LocalDate hyojiStartDate = LocalDate.parse("1/1/2018", formatter);
		LocalDate hyojiEndDate =  LocalDate.parse("3/28/2018", formatter);

		Boolean isIncludeDeleted = true;
		List<Short> kanriCodess = new ArrayList<Short>();
		kanriCodess.add((short)10);
		String loginId = "3333";
		String loginKind = "0";
		List<Short> shinseiGroupCodes = null;

		List<OshiraseViewDto> ret = mOshiraseLogic.getOshiraseByDispCondition(hyojisakiShurui,
					hyojiStartDate, hyojiEndDate, isIncludeDeleted, kanriCodess, loginId, loginKind,
					shinseiGroupCodes);
		exportJsonData(ret, "TestgetOshiraseByDispCondition8.json");
	}
	
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetOshiraseByDispConditionInit6.xlsx")
	public void TestgetOshiraseByDispCondition9() throws Exception
	{
		String hyojisakiShurui = "0";

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("M/d/yyyy");
		LocalDate hyojiStartDate = LocalDate.parse("1/1/2018", formatter);
		LocalDate hyojiEndDate =  LocalDate.parse("3/28/2018", formatter);

		Boolean isIncludeDeleted = true;
		List<Short> kanriCodess = new ArrayList<Short>();
		kanriCodess.add((short)10);
		String loginId = "3333";
		String loginKind = "0";
		List<Short> shinseiGroupCodes = new ArrayList<Short>();
		shinseiGroupCodes.add((short)1);

		List<OshiraseViewDto> ret = mOshiraseLogic.getOshiraseByDispCondition(hyojisakiShurui,
					hyojiStartDate, hyojiEndDate, isIncludeDeleted, kanriCodess, loginId, loginKind,
					shinseiGroupCodes);
		assertEquals(0, ret.size());
	}

//	@Test
//	@DisplayName("検索条件なしでM_管理を取得します")
//	@TestInitDataFile("TestgetMOshirase.xlsx")
//	public void TesgetHeaderMsg() throws Exception
//	{
//		LocalDate baseDate = LocalDate.now();
//		List<StagiaMessageDto>  ret = mOshiraseLogic.getHeaderMsg(baseDate);
//		exportJsonData(ret, "TesgetHeaderMsg.json");
//	}
//
//	@Test
//	@DisplayName("検索条件なしでM_管理を取得します")
//	@TestInitDataFile("TestgetMOshirase.xlsx")
//	public void TesgetHeaderMsg_List() throws Exception
//	{
//		LocalDate baseDate = LocalDate.now();
//		Boolean isShokuin = true;
//		String loginId = "6";
//		List<Short> inConditions = new ArrayList<Short>();
//		Short inCondition = 10;
//		inConditions.add(inCondition);
//		List<StagiaMessageDto> ret = mOshiraseLogic.getHeaderMsg(isShokuin, loginId, baseDate,
//					inConditions);
//		exportJsonData(ret, "TesgetHeaderMsg_List.json");
//	}
//
//	@Test
//	@DisplayName("検索条件なしでM_管理を取得します")
//	@TestInitDataFile("TestgetMOshirase.xlsx")
//	public void TesgetMessage() throws Exception
//	{
//		LocalDate baseDate = LocalDate.now();
//		List<StagiaMessageDto> ret =  mOshiraseLogic.getMessage(baseDate);
//		exportJsonData(ret, "TesgetMessage.json");
//	}
//	@Test
//	@DisplayName("検索条件なしでM_管理を取得します")
//	@TestInitDataFile("TestgetMOshirase.xlsx")
//	public void TesgetMessage_List() throws Exception
//	{
//		LocalDate baseDate = LocalDate.now();
//		Boolean isShokuin = true;
//		String loginId = "6";
//		List<Short> inConditions = new ArrayList<Short>();
//		Short inCondition = 10;
//		inConditions.add(inCondition);
//		List<StagiaMessageDto> ret = mOshiraseLogic.getMessage(isShokuin, loginId, baseDate,
//				inConditions);
//		exportJsonData(ret, "TesgetMessage_List.json");
//	}
//	@Test
//	@DisplayName("データ更新に使用するDaoを取得します")
//	// @TestInitDataFile("TestRiyoshaServiceInit.xlsx")
//	public void TestgetDao() throws Exception
//	{
//		GenericDao<MOshirase, ?> ret = mOshiraseLogic.getDao();
//	}
}