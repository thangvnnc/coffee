package jp.ne.yec.seagullLC.stagia.test.junit.logic.unei.KyukanSetteiLogic;

import static org.junit.Assert.*;

import java.time.LocalDate;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.seagullLC.stagia.beans.unei.KyukanCalendarRowDto;
import jp.ne.yec.seagullLC.stagia.logic.unei.KyukanSetteiLogic;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = { "classpath:TestApplicationContext.xml" })
@WebAppConfiguration
public class TestKyukanSetteiLogic extends JunitBase {

	@Autowired
	KyukanSetteiLogic kyukanSetteiLogic;

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	//@TestInitDataFile("TestgetMBashoList.xlsx")
	public void TestMakeKyukanCalendar() throws Exception
	{
		List<List<KyukanCalendarRowDto>> jsonData = new ArrayList<List<KyukanCalendarRowDto>>();
		List<List<List<LocalDate>>> params = new ArrayList<List<List<LocalDate>>>();
		List<List<LocalDate>> LocalDateList = new ArrayList<List<LocalDate>>();
		List<LocalDate> LocalDates = new ArrayList<LocalDate>();
		LocalDate localDate = LocalDate.now();
		LocalDates.add(localDate);
		LocalDateList.add(LocalDates);

		LocalDate localDate2 = CreateLocalDate(2018, 05, 01);
		LocalDates.add(localDate2);
		LocalDateList.add(LocalDates);

		LocalDate localDate3 = CreateLocalDate(2018, 04, 01);
		LocalDates.add(localDate3);
		LocalDateList.add(LocalDates);

		params.add(LocalDateList);

		List<List<LocalDate>> yoyakuLists = new ArrayList<List<LocalDate>>();
		List<LocalDate> yoyakuList = new ArrayList<LocalDate>();

		LocalDate localDateYoyakuList2 = CreateLocalDate(2018, 05, 01);
		yoyakuList.add(localDateYoyakuList2);
		yoyakuLists.add(yoyakuList);

		List<List<LocalDate>> kyukanLists = new ArrayList<List<LocalDate>>();
		List<LocalDate> kyukanList = new ArrayList<LocalDate>();

		LocalDate localDatekyukanList = LocalDate.now();
		kyukanList.add(localDatekyukanList);
		kyukanLists.add(kyukanList);

		List<YearMonth> yearMonths = new ArrayList<YearMonth>();
		YearMonth yearMonth = YearMonth.now();
		yearMonths.add(yearMonth);



			//List<List<LocalDate>> kyukanCalendar, YearMonth targetYM
			//, List<LocalDate> kyukanList, List<LocalDate> yoyakuList
		List<KyukanCalendarRowDto>  ret = kyukanSetteiLogic.makeKyukanCalendar(params.get(0), yearMonths.get(0), kyukanLists.get(0), yoyakuLists.get(0) );
		assertEquals(2, ret.size());
		jsonData.add(ret);
		exportJsonData(jsonData, "TestMakeKyukanCalendar.json");
	}

	@Test
	@DisplayName("日曜始まりのカレンダー２次元配列を作成します")
	public void TestGetDateList() throws Exception {
		List<List<List<LocalDate>>> jsonData = new ArrayList<List<List<LocalDate>>>();
		List<YearMonth> params = new ArrayList<YearMonth>();

		YearMonth yearMonth = YearMonth.now();
		params.add(yearMonth);

		YearMonth yearMonth1 = YearMonth.of(2018, 04);
		params.add(yearMonth1);

		YearMonth yearMonth2 = YearMonth.of(2018, 07);
		params.add(yearMonth2);


		List<List<LocalDate>> list = kyukanSetteiLogic.getDateList(params.get(0));
		assertEquals(2, list.size());
		jsonData.add(list);

		exportJsonData(jsonData, "TestGetDateList.json");
	}
}
