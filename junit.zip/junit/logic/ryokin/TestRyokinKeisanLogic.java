package jp.ne.yec.seagullLC.stagia.test.junit.logic.ryokin;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.seagullLC.stagia.entity.TRyokinJidoSettei;
import jp.ne.yec.seagullLC.stagia.logic.ryokin.RyokinKeisanLogic;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestRyokinKeisanLogic extends JunitBase {


	@Autowired
	RyokinKeisanLogic ryokinKeisanLogic;

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	//@TestInitDataFile("TestgetMBashoList.xlsx")
	public void TestRyokinSetteiEntityToRyokinSetteiDto() throws Exception
	{
		List<List<TRyokinJidoSettei>> params = new ArrayList<List<TRyokinJidoSettei>>();
		List<TRyokinJidoSettei> ryokinJidoSetteiEntitys = new ArrayList<TRyokinJidoSettei>();
		TRyokinJidoSettei ryokinJidoSetteiEntity = new TRyokinJidoSettei();
		ryokinJidoSetteiEntitys.add(ryokinJidoSetteiEntity);
		params.add(ryokinJidoSetteiEntitys);

//		for (int item = 0; item < params.size(); item++)
//		{
//			List<RyokinSetteiDto> ret = ryokinKeisanLogic.setCalculateShisetsuRyokin(params.get(item));
//		}
		//assertEquals(4, ret);

		//Map<String, List<MBasho>> assertMap = new HashMap<String, List<MBasho>>();
		//assertMap.put("StringCodeNamePair", ret);
		//assertList("TestgetMBashoList.xlsx", assertMap);
	}
}

