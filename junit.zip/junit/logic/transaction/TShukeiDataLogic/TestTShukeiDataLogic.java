package jp.ne.yec.seagullLC.stagia.test.junit.logic.transaction.TShukeiDataLogic;

import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.entity.TShukeiData;
import jp.ne.yec.seagullLC.stagia.logic.transaction.TShukeiDataLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = { "classpath:TestApplicationContext.xml" })
@WebAppConfiguration
public class TestTShukeiDataLogic extends JunitBase {

	@Autowired
	TShukeiDataLogic tShukeiDataLogic;

	@Test
	@DisplayName("引数よりTShukeiDataを取得します.")
	@TestInitDataFile("TestGetTShukeiDataInit.xlsx")
	public void TestGetTShukeiData() throws Exception {
		short kanriCode = 10;
		int shinseiNumber = 462;
		List<TShukeiData> ret = tShukeiDataLogic.getTShukeiData(kanriCode, shinseiNumber);
		exportJsonData(ret, "TestGetTShukeiData.json");
	}
	
	@Test
	public void TestgetDao() throws Exception {
		GenericDao<TShukeiData, ?> ret =  tShukeiDataLogic.getDao();
	}
}
