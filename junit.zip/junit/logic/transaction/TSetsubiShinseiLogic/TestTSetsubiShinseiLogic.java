package jp.ne.yec.seagullLC.stagia.test.junit.logic.transaction.TSetsubiShinseiLogic;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.beans.shinsei.SetsubiShinseiDto;
import jp.ne.yec.seagullLC.stagia.entity.TSetsubiShinsei;
import jp.ne.yec.seagullLC.stagia.logic.transaction.TSetsubiShinseiLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = { "classpath:TestApplicationContext.xml" })
@WebAppConfiguration
public class TestTSetsubiShinseiLogic extends JunitBase {

	@Autowired
	TSetsubiShinseiLogic tSetsubiShinseiLogic;

	@Test
	@DisplayName("引数の明細IDリストを基にT設備申請コマ情報を取得し返却します.")
	@TestInitDataFile("TestGetIdListInit.xlsx")
	public void TestGetIdList() throws Exception
	{
		List<Integer> ids = new ArrayList<>();
		ids.add(37836);
		ids.add(37832);
		ids.add(37833);
		List<Integer> ret = tSetsubiShinseiLogic.getIdList(ids);
		exportJsonData(ret, "TestGetIdList.json");
	}

	@Test
	@DisplayName("引数の明細IDリストを基にT設備申請コマ情報を取得し返却します.")
	@TestInitDataFile("TestGetSetsubiShinseiListInit.xlsx")
	public void TestGetSetsubiShinseiList() throws Exception {
		List<Integer> ids = new ArrayList<>();
		ids.add(37836);
		List<SetsubiShinseiDto> ret = tSetsubiShinseiLogic.getSetsubiShinseiList(ids);
		exportJsonData(ret, " TestGetSetsubiShinseiList.json");
	}
	@Test
	@DisplayName("引数の明細IDリストを基にT設備申請コマ情報を取得し返却します.")
	public void TestgetDao() throws Exception {
		GenericDao<TSetsubiShinsei, ?> ret = tSetsubiShinseiLogic.getDao() ;
	 //Stagia2 - TestJUnit 2018/06/21
	}
}
