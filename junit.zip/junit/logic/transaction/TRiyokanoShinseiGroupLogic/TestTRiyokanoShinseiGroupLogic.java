package jp.ne.yec.seagullLC.stagia.test.junit.logic.transaction.TRiyokanoShinseiGroupLogic;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.entity.TRiyokanoShinseiGroup;
import jp.ne.yec.seagullLC.stagia.logic.transaction.TRiyokanoShinseiGroupLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestTRiyokanoShinseiGroupLogic extends JunitBase {

	@Autowired
	TRiyokanoShinseiGroupLogic tRiyokanoShinseiGroupLogic;
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetTRiyokanoShinseiGroupListInit.xlsx")
	public void TestgetTRiyokanoShinseiGroupList() throws Exception
	{
		String loginId = "1";
		
		List<TRiyokanoShinseiGroup> ret =  tRiyokanoShinseiGroupLogic.getTRiyokanoShinseiGroupList(loginId);
		exportJsonData(ret, "TestgetTRiyokanoShinseiGroupList.json");	
	}
	
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestinsertTRiyokanoShinseiGroupInit.xlsx")
	public void TestinsertTRiyokanoShinseiGroup() throws Exception
	{
		String loginId = "185";
		TRiyokanoShinseiGroup tRiyokanoShinseiGroup = new TRiyokanoShinseiGroup();
		tRiyokanoShinseiGroup.setLoginId("185");
		tRiyokanoShinseiGroup.setShinseiGroupCode((short)1);
		
		List<TRiyokanoShinseiGroup> ret =  new ArrayList<>();
		ret.add(tRiyokanoShinseiGroup);
		tRiyokanoShinseiGroupLogic.insertTRiyokanoShinseiGroup(ret, loginId);
		
	}
	
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestdeleteTRiyokanoShinseiGroupInit.xlsx")
	public void TestdeleteTRiyokanoShinseiGroup() throws Exception
	{
		String loginId = "1";
		List<TRiyokanoShinseiGroup> ret =  tRiyokanoShinseiGroupLogic.getTRiyokanoShinseiGroupList(loginId);
		tRiyokanoShinseiGroupLogic.deleteTRiyokanoShinseiGroup(ret);
	}
	
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	//@TestInitDataFile("TestgetMBashoList.xlsx")
	public void TestgetDao() throws Exception
	{
		GenericDao<TRiyokanoShinseiGroup, ?> ret = tRiyokanoShinseiGroupLogic.getDao();
	}
}