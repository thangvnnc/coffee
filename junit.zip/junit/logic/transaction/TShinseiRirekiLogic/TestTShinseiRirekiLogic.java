package jp.ne.yec.seagullLC.stagia.test.junit.logic.transaction.TShinseiRirekiLogic;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.entity.TShinseiRireki;
import jp.ne.yec.seagullLC.stagia.logic.transaction.TShinseiRirekiLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestTShinseiRirekiLogic extends JunitBase {

	@Autowired
	TShinseiRirekiLogic tShinseiRirekiLogic;

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestGetTShinseiRirekiInit.xlsx")
	public void TestGetTShinseiRireki() throws Exception
	{
		Map<Short, List<Integer>> kanriRyoshuMap = new HashMap<Short, List<Integer>>();
		List<Integer> kanriRyoshuValue = new ArrayList<>();
		kanriRyoshuValue.add(531);
		kanriRyoshuMap.put((short)10, kanriRyoshuValue);
		List<TShinseiRireki> ret = tShinseiRirekiLogic.getTShinseiRireki(kanriRyoshuMap);
		exportJsonData(ret, "TestGetTShinseiRireki.json");
	}
	
	@Test
	@TestInitDataFile("TestGetTShinseiRireki_ShortInit.xlsx")
	public void TestGetTShinseiRireki_Short() throws Exception
	{
		short kanriCode = 10;
		int  shinseiNum = 531;
		List<TShinseiRireki> ret = tShinseiRirekiLogic.getTShinseiRireki(kanriCode, shinseiNum);
		exportJsonData(ret, "TestGetTShinseiRireki_Short.json");
	}
	
	@Test
	@DisplayName("引数の明細IDリストを基にT設備申請コマ情報を取得し返却します.")
	public void TestgetDao() throws Exception {
		GenericDao<TShinseiRireki, ?> ret = tShinseiRirekiLogic.getDao();

	}
}