package jp.ne.yec.seagullLC.stagia.test.junit.logic.transaction.TRyoshuMeisaiLogic;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.entity.TRyoshu;
import jp.ne.yec.seagullLC.stagia.entity.TRyoshuMeisai;
import jp.ne.yec.seagullLC.stagia.logic.transaction.TRyoshuLogic;
import jp.ne.yec.seagullLC.stagia.logic.transaction.TRyoshuMeisaiLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = { "classpath:TestApplicationContext.xml" })
@WebAppConfiguration
public class TestTRyoshuMeisaiLogic extends JunitBase {

	@Autowired
	TRyoshuMeisaiLogic tRyoshuMeisaiLogic;
	@Autowired
	TRyoshuLogic tRyoshuLogic;
	
	@Test
	@DisplayName("IDを検索条件としてTRyoshuMeisaiを取得します.")
	@TestInitDataFile("TestGetTRyoshuMeisaiByIdInit.xlsx")
	public void TestGetTRyoshuMeisai() throws Exception {
		
		List<TRyoshu> listTRyoshu = new ArrayList<>();
		TRyoshu tRyoshu = new TRyoshu();
		tRyoshu.setKanriCode((short)10);
		tRyoshu.setRyoshuNumber(420);
		listTRyoshu.add(tRyoshu);
		List<? extends TRyoshu> tRyoshus = listTRyoshu;
		
		List<TRyoshuMeisai> ret = tRyoshuMeisaiLogic.getTRyoshuMeisai(tRyoshus);
		
		exportJsonData(ret, "TestGetTRyoshuMeisai.json");
	}

	@Test
	@DisplayName("IDを検索条件としてTRyoshuMeisaiを取得します.")
	@TestInitDataFile("TestGetTRyoshuMeisaiByIdInit.xlsx")
	public void TestGetTRyoshuMeisaiById() throws Exception {
		List<Integer> ids = new ArrayList<>();
		ids.add(37987);
		ids.add(37988);
		List<List<Integer>> listIds = new ArrayList<>();
		listIds.add(ids);
		
		List<TRyoshuMeisai> ret = tRyoshuMeisaiLogic.getTRyoshuMeisaiById(listIds.get(0));
		
		exportJsonData(ret, "TestGetTRyoshuMeisaiById.json");
	}

	@Test
	@DisplayName("IDを検索条件としてTRyoshuMeisaiを取得します.")
	public void TestgetDao() throws Exception {
		GenericDao<TRyoshuMeisai, ?> ret = tRyoshuMeisaiLogic.getDao();
	}
}
