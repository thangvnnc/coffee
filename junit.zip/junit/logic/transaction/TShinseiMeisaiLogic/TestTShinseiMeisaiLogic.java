package jp.ne.yec.seagullLC.stagia.test.junit.logic.transaction.TShinseiMeisaiLogic;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.beans.enums.domain.BatchShurui;
import jp.ne.yec.seagullLC.stagia.beans.enums.domain.ShinseiShurui;
import jp.ne.yec.seagullLC.stagia.beans.madoguchi.ShinseiMeisaiDtoForMadoguchi;
import jp.ne.yec.seagullLC.stagia.beans.shinsei.ShinseiIchiranDto;
import jp.ne.yec.seagullLC.stagia.beans.shinsei.ShinseiMeisaiDto;
import jp.ne.yec.seagullLC.stagia.beans.unei.BatchKidoViewDto;
import jp.ne.yec.seagullLC.stagia.entity.MHaitaKashidashiTani;
import jp.ne.yec.seagullLC.stagia.entity.TShinsei;
import jp.ne.yec.seagullLC.stagia.entity.TShinseiMeisai;
import jp.ne.yec.seagullLC.stagia.entity.TShisetsuHeisa;
import jp.ne.yec.seagullLC.stagia.logic.transaction.TShinseiMeisaiLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = { "classpath:TestApplicationContext.xml" })
@WebAppConfiguration
public class TestTShinseiMeisaiLogic extends JunitBase {

	@Autowired
	TShinseiMeisaiLogic tShinseiMeisaiLogic;

	@Test
	@DisplayName("引数の条件を基に住民機能の申請一覧画面に表示するための情報をT申請明細より取得し返却します. 返却リストは管理コード、申請番号、明細番号の昇順となります.")
	@TestInitDataFile("TestGetShinseiIchiranDtoByLoginIdInit.xlsx")
	public void TestGetShinseiIchiranDtoByLoginId() throws Exception {
		String loginId = "1";
		List<ShinseiIchiranDto> ret = tShinseiMeisaiLogic.getShinseiIchiranDtoByLoginId(loginId);
		exportJsonData(ret, "TestGetShinseiIchiranDtoByLoginId.json");
	}

	@Test 
	@DisplayName("引数の条件に合致するT_申請明細を返却します")
	@TestInitDataFile("TestGetTShinseiMeisaiInit.xlsx")
	public void TestGetTShinseiMeisai() throws Exception {
		short kanriCode = 10;
		int shinseiNumber = 444;;
		List<TShinseiMeisai> ret = tShinseiMeisaiLogic.getTShinseiMeisai(kanriCode, shinseiNumber);
		exportJsonData(ret, "TestGetTShinseiMeisai.json");
	}

	@Test
	@DisplayName("引数の条件に合致する取消されていないT_申請明細を返却します.")
	@TestInitDataFile("TestGetValidTShinseiMeisaiInit.xlsx")
	public void TestGetValidTShinseiMeisai() throws Exception {
		short kanriCode = 10;
		int shinseiNumber = 444;
		List<TShinseiMeisai> ret = tShinseiMeisaiLogic.getValidTShinseiMeisai(kanriCode, shinseiNumber);
		exportJsonData(ret, "TestGetValidTShinseiMeisai.json");
	}

	@Test
	@DisplayName("引数の条件に合致する取消されていない仮予約のT_申請明細を返却します.")
	@TestInitDataFile("TestGetTShinseiMeisaiList3praInit.xlsx")
	public void TestGetTShinseiMeisaiList3pra() throws Exception {
		String loginId = "1";
		short kanriCode = 10;
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/M/d");
		Date shiyoDateFrom = new Date();
		shiyoDateFrom = formatter.parse("2017/5/14");
		Date shiyoDateTo = new Date();
		shiyoDateTo = formatter.parse("2017/5/17");

		List<TShinseiMeisai> ret = tShinseiMeisaiLogic.getTShinseiMeisaiList(loginId, kanriCode,
				shiyoDateFrom, shiyoDateTo);
		exportJsonData(ret, "TestGetTShinseiMeisaiList3pra.json");
	}
	
	@Test
	@DisplayName("引数の条件に合致する取消されていない本予約のT_申請明細を返却します.（使用実績入力で使用）")
	@TestInitDataFile("TestGetTShinseiMeisaiList10praInit.xlsx")
	public void TestGetTShinseiMeisaiList10pra_1() throws Exception {
		int shinseiBangoFrom = 10;

		int shinseiBangoTo = 10;

		short kanriCode = 10;

		short bashoCode = 90;

		short shisetsuCode = 10;

		boolean shiyojissekiUmuFlg = true;

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/M/d");
		Date shiyoDateFrom = new Date();
		shiyoDateFrom = formatter.parse("2017/5/15");
		
		Date shiyoDateTo = new Date();
		shiyoDateTo = formatter.parse("2017/5/17");
		
		Date uketukebiFrom = new Date();
		uketukebiFrom = formatter.parse("2016/9/12");
		
		Date uketukebiTo = new Date();
		uketukebiTo = formatter.parse("2016/9/14");

		List<ShinseiMeisaiDtoForMadoguchi> ret = tShinseiMeisaiLogic.getTShinseiMeisaiList(
				shinseiBangoFrom,
				shinseiBangoTo,
				kanriCode,
				bashoCode,
				shisetsuCode,
				shiyoDateFrom,
				shiyoDateTo,
				uketukebiFrom,
				uketukebiTo,
				shiyojissekiUmuFlg
				);
		exportJsonData(ret, "TestGetTShinseiMeisaiList10pra_1.json");
	}
	
	@Test
	@DisplayName("引数の条件に合致する取消されていない本予約のT_申請明細を返却します.（使用実績入力で使用）")
	@TestInitDataFile("TestGetTShinseiMeisaiList10praInit.xlsx")
	public void TestGetTShinseiMeisaiList10pra_2() throws Exception {
		int shinseiBangoFrom = 9;

		Integer shinseiBangoTo = null;

		short kanriCode = 10;

		short bashoCode = 90;

		short shisetsuCode = 10;

		Boolean shiyojissekiUmuFlg = null;

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/M/d");
		Date shiyoDateFrom = new Date();
		shiyoDateFrom = formatter.parse("2017/5/15");
		
		Date shiyoDateTo = null;
		
		Date uketukebiFrom = new Date();
		uketukebiFrom = formatter.parse("2016/9/12");
		
		Date uketukebiTo = null;
		
		List<ShinseiMeisaiDtoForMadoguchi> ret = tShinseiMeisaiLogic.getTShinseiMeisaiList(
				shinseiBangoFrom,
				shinseiBangoTo,
				kanriCode,
				bashoCode,
				shisetsuCode,
				shiyoDateFrom,
				shiyoDateTo,
				uketukebiFrom,
				uketukebiTo,
				shiyojissekiUmuFlg
				);
		exportJsonData(ret, "TestGetTShinseiMeisaiList10pra_2.json");
	}
	
	@Test
	@DisplayName("引数の条件に合致する取消されていない本予約のT_申請明細を返却します.（使用実績入力で使用）")
	@TestInitDataFile("TestGetTShinseiMeisaiList10praInit.xlsx")
	public void TestGetTShinseiMeisaiList10pra_3() throws Exception {
		Integer shinseiBangoFrom = null;

		Integer shinseiBangoTo = 11;

		short kanriCode = 10;

		short bashoCode = 90;

		short shisetsuCode = 10;

		Boolean shiyojissekiUmuFlg = null;

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/M/d");
		Date shiyoDateFrom = null;
		
		Date shiyoDateTo = new Date();
		shiyoDateTo = formatter.parse("2017/5/17");
		
		Date uketukebiFrom = null;
		
		Date uketukebiTo = new Date();
		uketukebiTo = formatter.parse("2016/9/14");
		
		List<ShinseiMeisaiDtoForMadoguchi> ret = tShinseiMeisaiLogic.getTShinseiMeisaiList(
				shinseiBangoFrom,
				shinseiBangoTo,
				kanriCode,
				bashoCode,
				shisetsuCode,
				shiyoDateFrom,
				shiyoDateTo,
				uketukebiFrom,
				uketukebiTo,
				shiyojissekiUmuFlg
				);
		exportJsonData(ret, "TestGetTShinseiMeisaiList10pra_3.json");
	}
	
	@Test
	@DisplayName("引数の条件に合致する取消されていない本予約のT_申請明細を返却します.（使用実績入力で使用）")
	@TestInitDataFile("TestGetTShinseiMeisaiList10praInit.xlsx")
	public void TestGetTShinseiMeisaiList10pra_4() throws Exception {
		Integer shinseiBangoFrom = null;

		Integer shinseiBangoTo = null;

		Short kanriCode = null;

		Short bashoCode = null;

		Short shisetsuCode = null;

		Boolean shiyojissekiUmuFlg = null;

		Date shiyoDateFrom = null;
		
		Date shiyoDateTo = null;
		
		Date uketukebiFrom = null;
		
		Date uketukebiTo = null;
		
		List<ShinseiMeisaiDtoForMadoguchi> ret = tShinseiMeisaiLogic.getTShinseiMeisaiList(
				shinseiBangoFrom,
				shinseiBangoTo,
				kanriCode,
				bashoCode,
				shisetsuCode,
				shiyoDateFrom,
				shiyoDateTo,
				uketukebiFrom,
				uketukebiTo,
				shiyojissekiUmuFlg
				);
		exportJsonData(ret, "TestGetTShinseiMeisaiList10pra_4.json");
	}

	@Test
	@DisplayName("引数の条件に合致する取消されていない本予約のT_申請明細を返却します.（審査入力で使用）")
	@TestInitDataFile("TestGetTShinseiMeisaiList11praInit.xlsx")
	public void TestGetTShinseiMeisaiList11pra_1() throws Exception {
		Integer shinseiBangoFrom = 10;

		Integer shinseiBangoTo = 10;

		Short kanriCode = 10;

		Short bashoCode = 90;

		Short shisetsuCode = 10;

		List<String> shinsaKubunCode = new ArrayList<>();
		shinsaKubunCode.add("1");

		List<Short> riyoshaGroupCodeList = new ArrayList<>();
		riyoshaGroupCodeList.add((short)1);

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/M/d");
		Date shiyoDateFrom = new Date();
		shiyoDateFrom = formatter.parse("2017/5/15");
		
		Date shiyoDateTo = new Date();
		shiyoDateTo = formatter.parse("2017/5/17");
		
		Date uketukebiFrom = new Date();
		uketukebiFrom = formatter.parse("2016/9/12");
		
		Date uketukebiTo = new Date();
		uketukebiTo = formatter.parse("2016/9/14");

		List<ShinseiMeisaiDtoForMadoguchi> ret = tShinseiMeisaiLogic.getTShinseiMeisaiList(
				shinseiBangoFrom,
				shinseiBangoTo,
				kanriCode,
				bashoCode,
				shisetsuCode,
				shiyoDateFrom,
				shiyoDateTo,
				uketukebiFrom,
				uketukebiTo,
				shinsaKubunCode,
				riyoshaGroupCodeList
				);
		exportJsonData(ret, "TestGetTShinseiMeisaiList11pra_1.json");
	}
	
	@Test
	@DisplayName("引数の条件に合致する取消されていない本予約のT_申請明細を返却します.（審査入力で使用）")
	@TestInitDataFile("TestGetTShinseiMeisaiList11praInit.xlsx")
	public void TestGetTShinseiMeisaiList11pra_2() throws Exception {
		Integer shinseiBangoFrom = 10;

		Integer shinseiBangoTo = null;

		Short kanriCode = 10;

		Short bashoCode = 90;

		Short shisetsuCode = 10;

		List<String> shinsaKubunCode = new ArrayList<>();

		List<Short> riyoshaGroupCodeList = new ArrayList<>();
		
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/M/d");
		Date shiyoDateFrom = null;
		
		Date shiyoDateTo = new Date();
		shiyoDateTo = formatter.parse("2017/5/17");
		
		Date uketukebiFrom = null;
		
		Date uketukebiTo = new Date();
		uketukebiTo = formatter.parse("2016/9/14");

		List<ShinseiMeisaiDtoForMadoguchi> ret = tShinseiMeisaiLogic.getTShinseiMeisaiList(
				shinseiBangoFrom,
				shinseiBangoTo,
				kanriCode,
				bashoCode,
				shisetsuCode,
				shiyoDateFrom,
				shiyoDateTo,
				uketukebiFrom,
				uketukebiTo,
				shinsaKubunCode,
				riyoshaGroupCodeList
				);
		exportJsonData(ret, "TestGetTShinseiMeisaiList11pra_2.json");
	}
	
	@Test
	@DisplayName("引数の条件に合致する取消されていない本予約のT_申請明細を返却します.（審査入力で使用）")
	@TestInitDataFile("TestGetTShinseiMeisaiList11praInit.xlsx")
	public void TestGetTShinseiMeisaiList11pra_3() throws Exception {
		Integer shinseiBangoFrom = null;

		Integer shinseiBangoTo = 11;

		Short kanriCode = 10;

		Short bashoCode = 90;

		Short shisetsuCode = 10;

		List<String> shinsaKubunCode = new ArrayList<>();

		List<Short> riyoshaGroupCodeList = new ArrayList<>();
		
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/M/d");
		Date shiyoDateFrom = new Date();
		shiyoDateFrom = formatter.parse("2017/5/15");
		
		Date shiyoDateTo = null;
		
		Date uketukebiFrom = new Date();
		uketukebiFrom = formatter.parse("2016/9/12");
		
		Date uketukebiTo = null;

		List<ShinseiMeisaiDtoForMadoguchi> ret = tShinseiMeisaiLogic.getTShinseiMeisaiList(
				shinseiBangoFrom,
				shinseiBangoTo,
				kanriCode,
				bashoCode,
				shisetsuCode,
				shiyoDateFrom,
				shiyoDateTo,
				uketukebiFrom,
				uketukebiTo,
				shinsaKubunCode,
				riyoshaGroupCodeList
				);
		exportJsonData(ret, "TestGetTShinseiMeisaiList11pra_3.json");
	}
	
	@Test
	@DisplayName("引数の条件に合致する取消されていない本予約のT_申請明細を返却します.（審査入力で使用）")
	@TestInitDataFile("TestGetTShinseiMeisaiList11praInit.xlsx")
	public void TestGetTShinseiMeisaiList11pra_4() throws Exception {
		Integer shinseiBangoFrom = null;

		Integer shinseiBangoTo = null;

		Short kanriCode = null;

		Short bashoCode = null;

		Short shisetsuCode = null;

		List<String> shinsaKubunCode = new ArrayList<>();

		List<Short> riyoshaGroupCodeList = new ArrayList<>();
		
		Date shiyoDateFrom = null;
		
		Date shiyoDateTo = null;
		
		Date uketukebiFrom = null;
		
		Date uketukebiTo = null;

		List<ShinseiMeisaiDtoForMadoguchi> ret = tShinseiMeisaiLogic.getTShinseiMeisaiList(
				shinseiBangoFrom,
				shinseiBangoTo,
				kanriCode,
				bashoCode,
				shisetsuCode,
				shiyoDateFrom,
				shiyoDateTo,
				uketukebiFrom,
				uketukebiTo,
				shinsaKubunCode,
				riyoshaGroupCodeList
				);
		exportJsonData(ret, "TestGetTShinseiMeisaiList11pra_4.json");
	}

	@Test
	@DisplayName("引数の条件に合致する取消されていない仮予約のT_申請明細を返却します.")
	@TestInitDataFile("TestGetTShinseiMeisaiList4praInit.xlsx")
	public void TestGetTShinseiMeisaiList4pra() throws Exception {
		String loginId = "1";

		Short kanriCode = 10;

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/M/d");
		Date shiyoDateFrom = new Date();
		shiyoDateFrom = formatter.parse("2017/5/16");
		
		Date shiyoDateTo = new Date();
		shiyoDateTo = formatter.parse("2017/5/17");

		List<TShinseiMeisai> ret = tShinseiMeisaiLogic.getTShinseiMeisaiList(
				loginId,
				kanriCode,
				shiyoDateFrom,
				shiyoDateTo
				);
		exportJsonData(ret, "TestGetTShinseiMeisaiList4pra.json");
	}
	
	@Test
	@DisplayName("引数の条件に合致する取消されていない仮予約のT_申請明細を返却します.")
	@TestInitDataFile("TestGetTosenMeisaiListInit.xlsx")
	public void TestGetTosenMeisaiList() throws Exception {
		String loginId = "1";
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/M/d");
		Date shiyoDateFrom = new Date();
		shiyoDateFrom = formatter.parse("2017/5/16");
		
		Date shiyoDateTo = new Date();
		shiyoDateTo = formatter.parse("2017/5/17");

		List<TShinseiMeisai> ret = tShinseiMeisaiLogic.getTosenMeisaiList(
				loginId,
				shiyoDateFrom,
				shiyoDateTo
				);
		exportJsonData(ret, "TestGetTosenMeisaiList.json");
	}
	
	@Test
	@DisplayName("引数の条件に合致する取消されていない仮予約のT_申請明細を返却します.")
	@TestInitDataFile("TestGetDateToDeleteInit.xlsx")
	public void TestGetDateToDelete() throws Exception {
		List<TShinsei> expiredlist = new ArrayList<>();
		TShinsei tShinsei = new TShinsei();
		tShinsei.setKanriCode((short)10);
		tShinsei.setShinseiNumber(444);
		expiredlist.add(tShinsei);

		List<TShinseiMeisai> ret = tShinseiMeisaiLogic.getDateToDelete(expiredlist);
		exportJsonData(ret, "TestGetDateToDelete.json");
	}
	
	@Test
	@DisplayName("引数の条件に合致する取消されていない仮予約のT_申請明細を返却します.")
	@TestInitDataFile("TestGetMudanCancelMeisaiInit.xlsx")
	public void TestGetMudanCancelMeisai() throws Exception {
		List<TShinseiMeisai> ret = tShinseiMeisaiLogic.getMudanCancelMeisai();
		exportJsonData(ret, "TestGetMudanCancelMeisai.json");
	}
	
	@Test
	@DisplayName("引数の条件に合致する取消されていない仮予約のT_申請明細を返却します.")
	@TestInitDataFile("TestGetYoyakuDateListInit.xlsx")
	public void TestGetYoyakuDateList() throws Exception {
		
		short bashoCode = 90;
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/M/d");
		Date shiyoDateFrom = new Date();
		shiyoDateFrom = formatter.parse("2017/5/16");
		
		Date shiyoDateTo = new Date();
		shiyoDateTo = formatter.parse("2017/5/17");
		
		List<LocalDate> ret = tShinseiMeisaiLogic.getYoyakuDateList(bashoCode, shiyoDateFrom, shiyoDateTo);
		exportJsonData(ret, "TestGetYoyakuDateList.json");
	}
	
	@Test
	@DisplayName("引数の条件に合致する取消されていない仮予約のT_申請明細を返却します.")
	@TestInitDataFile("TestGetBatchKidoViewDataInit.xlsx")
	public void TestGetBatchKidoViewData1() throws Exception 
	{
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/M/d");
		Date baseDate = new Date();
		baseDate = formatter.parse("2017/12/29");
		
		List<BatchKidoViewDto> ret = tShinseiMeisaiLogic.getBatchKidoViewData(BatchShurui.TOSEN_SAKUJO, baseDate);
		exportJsonData(ret, "TestGetBatchKidoViewData1.json");
	}
	
	@Test
	@DisplayName("引数の条件に合致する取消されていない仮予約のT_申請明細を返却します.")
	@TestInitDataFile("TestGetBatchKidoViewDataInit.xlsx")
	public void TestGetBatchKidoViewData2() throws Exception 
	{
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/M/d");
		Date baseDate = new Date();
		baseDate = formatter.parse("2017/12/29");
		
		List<BatchKidoViewDto> ret = tShinseiMeisaiLogic.getBatchKidoViewData(BatchShurui.KARIYOYAKU_SAKUJO, baseDate);
		exportJsonData(ret, "TestGetBatchKidoViewData2.json");
	}
	
	@Test
	@DisplayName("引数の条件に合致する取消されていない仮予約のT_申請明細を返却します.")
	@TestInitDataFile("TestGetBatchKidoViewDataInit.xlsx")
	public void TestGetBatchKidoViewData3() throws Exception 
	{
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/M/d");
		Date baseDate = new Date();
		baseDate = formatter.parse("2018/4/20");
		
		List<BatchKidoViewDto> ret = tShinseiMeisaiLogic.getBatchKidoViewData(BatchShurui.MUDAN_CANCEL_KOSHIN, baseDate);
		exportJsonData(ret, "TestGetBatchKidoViewData3.json");
	}
	
	@Test
	@DisplayName("引数の条件に合致する取消されていない仮予約のT_申請明細を返却します.")
	@TestInitDataFile("TestGetBatchKidoViewDataInit.xlsx")
	public void TestGetBatchKidoViewData4() throws Exception 
	{
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/M/d");
		Date baseDate = new Date();
		baseDate = formatter.parse("2018/4/20");
		
		List<BatchKidoViewDto> ret = tShinseiMeisaiLogic.getBatchKidoViewData(BatchShurui.CHUSEN_JIKKO, baseDate);
		exportJsonData(ret, "TestGetBatchKidoViewData4.json");
	}
	
	@Test
	@DisplayName("引数の条件に合致する取消されていない仮予約のT_申請明細を返却します.")
	@TestInitDataFile("TestGetDoubleBookingChkInfoInit.xlsx")
	public void TestGetDoubleBookingChkInfo1() throws Exception 
	{
		ShinseiMeisaiDto meisaiDto = new ShinseiMeisaiDto();
		meisaiDto.setKanriCode((short)10);
		//meisaiDto.setShinseiNumber(10);
		meisaiDto.setBashoCode((short)10);
		meisaiDto.setStartKoma((short)2);
		meisaiDto.setEndKoma((short)6);
		meisaiDto.setShisetsuCode((short)10);
		meisaiDto.setKashidashiTaniCode((short)0);
		
		List<MHaitaKashidashiTani> meisaiHaitaTaniList = new ArrayList<>();
		MHaitaKashidashiTani mHaitaKashidashiTani = new MHaitaKashidashiTani();
		mHaitaKashidashiTani.setShisetsuCode((short)10);
		mHaitaKashidashiTani.setKashidashiTaniCode((short)0);
		meisaiHaitaTaniList.add(mHaitaKashidashiTani);
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/M/d");
		Date shiyoDate = new Date();
		shiyoDate = formatter.parse("2018/4/19");
		meisaiDto.setShiyoDate(shiyoDate);
		
		List<TShinseiMeisai> ret = tShinseiMeisaiLogic.getDoubleBookingChkInfo(meisaiDto, meisaiHaitaTaniList);
		exportJsonData(ret, "TestGetDoubleBookingChkInfo1.json");
	}
	
	@Test
	@DisplayName("引数の条件に合致する取消されていない仮予約のT_申請明細を返却します.")
	@TestInitDataFile("TestGetDoubleBookingChkInfoInit.xlsx")
	public void TestGetDoubleBookingChkInfo2() throws Exception 
	{
		ShinseiMeisaiDto meisaiDto = new ShinseiMeisaiDto();
		meisaiDto.setKanriCode((short)10);
		meisaiDto.setShinseiNumber(0);
		meisaiDto.setBashoCode((short)10);
		meisaiDto.setStartKoma((short)2);
		meisaiDto.setEndKoma((short)6);
		meisaiDto.setShisetsuCode((short)10);
		meisaiDto.setKashidashiTaniCode((short)0);
		
		List<MHaitaKashidashiTani> meisaiHaitaTaniList = new ArrayList<>();
		MHaitaKashidashiTani mHaitaKashidashiTani = new MHaitaKashidashiTani();
		mHaitaKashidashiTani.setShisetsuCode((short)10);
		mHaitaKashidashiTani.setKashidashiTaniCode((short)0);
		meisaiHaitaTaniList.add(mHaitaKashidashiTani);
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/M/d");
		Date shiyoDate = new Date();
		shiyoDate = formatter.parse("2018/4/19");
		meisaiDto.setShiyoDate(shiyoDate);
		
		List<TShinseiMeisai> ret = tShinseiMeisaiLogic.getDoubleBookingChkInfo(meisaiDto, meisaiHaitaTaniList);
		exportJsonData(ret, "TestGetDoubleBookingChkInfo2.json");
	}
	
	@Test
	@DisplayName("引数の条件に合致する取消されていない仮予約のT_申請明細を返却します.")
	@TestInitDataFile("TestGetTosenSakujoListInit.xlsx")
	public void TestGetTosenSakujoList() throws Exception 
	{
		List<TShinsei> tosenlist = new ArrayList<>();
		TShinsei tShinsei = new TShinsei();
		tShinsei.setKanriCode((short)10);
		List<TShinseiMeisai> ret = tShinseiMeisaiLogic.getTosenSakujoList(tosenlist);
		exportJsonData(ret, "TestGetTosenSakujoList.json");
	}
	
	@Test
	@DisplayName("引数の条件に合致する取消されていない仮予約のT_申請明細を返却します.")
	@TestInitDataFile("TestGetDoubleBookingChkInfoForKyukanBashoInit.xlsx")
	public void TestGetDoubleBookingChkInfoForKyukanBasho() throws Exception 
	{
		TShisetsuHeisa tShisetsuHeisa = new TShisetsuHeisa();
		tShisetsuHeisa.setKanriCode((short)10);
		tShisetsuHeisa.setShisetsuCode((short)10);
		Date heisaDate = new Date();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/M/d");
		heisaDate = formatter.parse("2018/4/19");
		tShisetsuHeisa.setHeisaDate(heisaDate);
		tShisetsuHeisa.setStartKoma((short)2);
		tShisetsuHeisa.setEndKoma((short)6);	
		
		List<TShinseiMeisai> ret = tShinseiMeisaiLogic.getDoubleBookingChkInfoForKyukanIkkatsuSettei(tShisetsuHeisa);
		exportJsonData(ret, "TestGetDoubleBookingChkInfoForKyukanBasho.json");
	}
	
	@Test
	@DisplayName("引数の条件に合致する取消されていない仮予約のT_申請明細を返却します.")
	@TestInitDataFile("TestGetYoyakuByLoginIdKanriShisetsuShiyoDateInit.xlsx")
	public void TestGetYoyakuByLoginIdKanriShisetsuShiyoDate() throws Exception 
	{
		String loginId = "0";
		Map<Short, List<Short>> kanriShisetsuMap = new HashMap<Short, List<Short>>(); 
		Short kanriCode = 10;
		List<Short> shisetsuCodes = new ArrayList<>();
		shisetsuCodes.add((short)10);
		kanriShisetsuMap.put(kanriCode, shisetsuCodes);
		
		Date from = new Date();
		Date to = new Date();
	
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/M/d");
		
		from = formatter.parse("2018/4/18");
		to = formatter.parse("2018/4/20");
		
		List<TShinseiMeisai> ret = tShinseiMeisaiLogic.getYoyakuByLoginIdKanriShisetsuShiyoDate(loginId, kanriShisetsuMap, from, to);
		exportJsonData(ret, "TestGetYoyakuByLoginIdKanriShisetsuShiyoDate.json");
	}
	
	@Test
	@DisplayName("引数の条件に合致する取消されていない仮予約のT_申請明細を返却します.")
	@TestInitDataFile("TestGetTShinseiMeisaisInit.xlsx")
	public void TestGetTShinseiMeisais() throws Exception 
	{
		String loginId = "0";
		Map<Short, List<Short>> kanriShisetsuMap = new HashMap<Short, List<Short>>(); 
		Short kanriCode = 10;
		List<Short> shisetsuCodes = new ArrayList<>();
		shisetsuCodes.add((short)10);
		kanriShisetsuMap.put(kanriCode, shisetsuCodes);
		
		Date from = new Date();
		Date to = new Date();
	
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/M/d");
		
		from = formatter.parse("2018/4/18");
		to = formatter.parse("2018/4/20");
		
		List<ShinseiShurui> shinseiShuruis = new ArrayList<>();
		shinseiShuruis.add(ShinseiShurui.KARIYOYAKU);
		shinseiShuruis.add(ShinseiShurui.MITSUMORI);
		
		List<TShinseiMeisai> ret = tShinseiMeisaiLogic.getTShinseiMeisais(loginId, shinseiShuruis, kanriShisetsuMap, from, to);
		exportJsonData(ret, "TestGetTShinseiMeisais.json");
	}
	
	@Test
	@DisplayName("引数の条件に合致する取消されていない仮予約のT_申請明細を返却します.")
	@TestInitDataFile("TestGetRyoshuAriShinseiIchiranDtoByLoginIdInit.xlsx")
	public void TestGetRyoshuAriShinseiIchiranDtoByLoginId() throws Exception 
	{
		String loginId = "0";
		List<ShinseiIchiranDto> ret = tShinseiMeisaiLogic.getRyoshuAriShinseiIchiranDtoByLoginId(loginId);
		exportJsonData(ret, "TestGetRyoshuAriShinseiIchiranDtoByLoginId.json");
	}
	
	@Test
	@DisplayName("引数の条件に合致するT_申請を返却します")
	public void TestgetDao() throws Exception {
		GenericDao<TShinseiMeisai, ?> ret =  tShinseiMeisaiLogic.getDao();
	}
}
