package jp.ne.yec.seagullLC.stagia.test.junit.logic.transaction.TShinseiLogic;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.beans.criteria.MitsumoriSearchDto;
import jp.ne.yec.seagullLC.stagia.beans.enums.JokenHukumu;
import jp.ne.yec.seagullLC.stagia.entity.MChusenGroup;
import jp.ne.yec.seagullLC.stagia.entity.MKanri;
import jp.ne.yec.seagullLC.stagia.entity.TShinsei;
import jp.ne.yec.seagullLC.stagia.logic.transaction.TShinseiLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = { "classpath:TestApplicationContext.xml" })
@WebAppConfiguration
public class TestTShinseiLogic extends JunitBase {

	@Autowired
	TShinseiLogic tShinseiLogic;

	@Test
	@DisplayName("引数の条件に合致するT_申請を返却します")
	@TestInitDataFile("TestGetTShinseiInit.xlsx")
	public void TestGetTShinsei() throws Exception {
		List<TShinsei> tList = new ArrayList<>();
		short kanriCode = 10;
		int shinseiNumber = 1;

		TShinsei tShinsei = tShinseiLogic.getTShinsei(kanriCode, shinseiNumber);
		tList.add(tShinsei);
		exportJsonData(tList, "TestGetTShinsei.json");
	}

	@Test
	@TestInitDataFile("TestGetExpiredDateInit.xlsx")
	public void TestGetExpiredDate() throws Exception {
		List<List<TShinsei>> tList = new ArrayList<>();
		List<TShinsei> list = tShinseiLogic.getExpiredDate();
		tList.add(list);
		exportJsonData(tList, "TestGetExpiredDate.json");
	}

	@Test
	@DisplayName("引数の条件に合致するT_申請を返却します")
	@TestInitDataFile("TestgetTShinsei_ListInit.xlsx")
	public void TestgetTShinsei_List1() throws Exception {
		List<List<TShinsei>> tList = new ArrayList<>();
		List<MitsumoriSearchDto> searchDto = new ArrayList<>();
		MitsumoriSearchDto mitsumoriSearchDto = new MitsumoriSearchDto();
		mitsumoriSearchDto.setLoginId("1");
		MKanri mKanri = new MKanri();
		mKanri.setKanriCode((short)10);
		mitsumoriSearchDto.setJoken(JokenHukumu.ICCHI);
		mitsumoriSearchDto.setMKanri(mKanri);
		mitsumoriSearchDto.setShinseiNumber(2);
		mitsumoriSearchDto.setShinseishaKanaName("ジュウミンテストリヨウシャ");
		mitsumoriSearchDto.setShinseishaName("住民テスト利用者");
		searchDto.add(mitsumoriSearchDto);

		List<TShinsei> ret = tShinseiLogic.getTShinsei(searchDto.get(0));
		tList.add(ret);
		exportJsonData(tList, "TestgetTShinsei_List1.json");
	}

	@Test
	@DisplayName("引数の条件に合致するT_申請を返却します")
	@TestInitDataFile("TestgetTShinsei_ListInit.xlsx")
	public void TestgetTShinsei_List2() throws Exception {
		List<List<TShinsei>> tList = new ArrayList<>();
		List<MitsumoriSearchDto> searchDto = new ArrayList<>();
		MitsumoriSearchDto mitsumoriSearchDto = new MitsumoriSearchDto();
		mitsumoriSearchDto.setLoginId("1");
		mitsumoriSearchDto.setJoken(JokenHukumu.HUKUMU);
		MKanri mKanri = new MKanri();
		mKanri.setKanriCode((short)10);
		mitsumoriSearchDto.setMKanri(mKanri);
		mitsumoriSearchDto.setShinseiNumber(2);
		mitsumoriSearchDto.setShinseishaKanaName("ジュウミンテストリヨウシャ");
		mitsumoriSearchDto.setShinseishaName("住民テスト利用者");
		searchDto.add(mitsumoriSearchDto);

		List<TShinsei> ret = tShinseiLogic.getTShinsei(searchDto.get(0));
		tList.add(ret);
		exportJsonData(tList, "TestgetTShinsei_List2.json");
	}

	@Test
	@DisplayName("引数の条件に合致するT_申請を返却します")
	@TestInitDataFile("TestGetTosenSakujoInit.xlsx")
	public void TestGetTosenSakujo() throws Exception {
		List<List<TShinsei>> tList = new ArrayList<>();
		List <MChusenGroup> setdatelist = new ArrayList<>();
		MChusenGroup mChusenGroup = new MChusenGroup();
		mChusenGroup.setChusenGroupCode((short)1);
		setdatelist.add(mChusenGroup);

		List<TShinsei> ret = tShinseiLogic.getTosenSakujo(setdatelist);
		tList.add(ret);
		exportJsonData(tList, "TestGetTosenSakujo.json");
	}

	@Test
	@DisplayName("引数の条件に合致するT_申請を返却します")
	public void TestgetDao() throws Exception {
		GenericDao<TShinsei, ?>ret =  tShinseiLogic.getDao();
	}
}
