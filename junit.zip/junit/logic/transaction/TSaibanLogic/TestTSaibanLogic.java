package jp.ne.yec.seagullLC.stagia.test.junit.logic.transaction.TSaibanLogic;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.beans.enums.domain.SaibanShurui;
import jp.ne.yec.seagullLC.stagia.entity.TSaiban;
import jp.ne.yec.seagullLC.stagia.logic.transaction.TSaibanLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestTSaibanLogic extends JunitBase {

	@Autowired
	TSaibanLogic tSaibanLogic;
	
	@Test
	public void TestgetDao() throws Exception {
		GenericDao<TSaiban, ?> ret = tSaibanLogic.getDao() ;
	}
	
	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestGetSaibanInit.xlsx")
	public void TestGetSaiban() throws Exception
	{
		Short kanriCode = 10;
		String updatedBy = "3718";

		int ret = tSaibanLogic.getSaiban(kanriCode, SaibanShurui.SHINSEI, updatedBy);
		assertEquals(720, ret);
	}

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestGetSaibanInit.xlsx")
	public void TestGetRyokinSeisanDto() throws Exception
	{
		short kanriCode = 10;
		int count = 1;
		String updatedBy = "3718";

		int[] ret = tSaibanLogic.getSaiban(kanriCode, SaibanShurui.SHINSEI, count, updatedBy);
		exportJsonData(ret, "TestGetRyokinSeisanDto.json");
	}
	
	
}