package jp.ne.yec.seagullLC.stagia.test.junit.logic.transaction.TKampuMeisaiLogic;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.seagullLC.stagia.entity.TKampu;
import jp.ne.yec.seagullLC.stagia.entity.TKampuMeisai;
import jp.ne.yec.seagullLC.stagia.logic.transaction.TKampuLogic;
import jp.ne.yec.seagullLC.stagia.logic.transaction.TKampuMeisaiLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestTKampuMeisaiLogic extends JunitBase {

	@Autowired
	TKampuMeisaiLogic tKampuMeisaiLogic;
	@Autowired
	TKampuLogic tKampuLogic;
	
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetTKampuMeisaiByIdInit.xlsx")
	public void TestgetTKampuMeisaiById() throws Exception
	{
		
		List<Integer> ids = new ArrayList<>();
		ids.add(37986);
		ids.add(37987);
		ids.add(37984);
		List<TKampuMeisai> ret =  tKampuMeisaiLogic.getTKampuMeisaiById(ids);
		exportJsonData(ret, "TestgetTKampuMeisaiById.json");
	}

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetTKampuMeisaiInit.xlsx")
	public void TestgetDao() throws Exception
	{
		tKampuMeisaiLogic.getDao();
	}
	
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetTKampuMeisaiInit.xlsx")
	public void TestgetTKampuMeisai() throws Exception
	{
		TKampu t = new TKampu();
		t.setKanriCode((short)10);
		t.setKampuNumber(314);
		List<TKampu> listTKampuu = new ArrayList<>();
		listTKampuu.add(t);
		
		List<? extends TKampu> tKampus = listTKampuu;
		
		List<TKampuMeisai> ret =  tKampuMeisaiLogic.getTKampuMeisai(tKampus);
		exportJsonData(ret, "TestgetTKampuMeisai.json");
	}
}