package jp.ne.yec.seagullLC.stagia.test.junit.logic.transaction.TShisetsuHeisaLogic;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.beans.unei.KyukanSetteiDataDto;
import jp.ne.yec.seagullLC.stagia.entity.MHaitaKashidashiTani;
import jp.ne.yec.seagullLC.stagia.entity.MShisetsu;
import jp.ne.yec.seagullLC.stagia.entity.TShinseiMeisai;
import jp.ne.yec.seagullLC.stagia.entity.TShisetsuHeisa;
import jp.ne.yec.seagullLC.stagia.logic.transaction.TShisetsuHeisaLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestTShisetsuHeisaLogic extends JunitBase {

	@Autowired
	TShisetsuHeisaLogic tShisetsuHeisaLogic;
	
	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestGetTShisetsuHeisaListInit.xlsx")
	public void TestGetTShisetsuHeisaList() throws Exception
	{
		
		List<MShisetsu> mShisetsus = new ArrayList<MShisetsu>();
		MShisetsu mShisetsu = new MShisetsu();
		mShisetsu.setKanriCode((short)10);
		mShisetsu.setShisetsuCode((short)10);
		
		mShisetsus.add(mShisetsu);

	
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/M/d");
		Date fDate = new Date();
		fDate = formatter.parse("2017/4/3");
	
		Date tDate = new Date();
		tDate = formatter.parse("2017/4/14");

		List<TShisetsuHeisa> ret = tShisetsuHeisaLogic.getTShisetsuHeisaList(mShisetsus, fDate, tDate);
		exportJsonData(ret, "TestGetTShisetsuHeisaList.json");
	}

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestGetHeisaByHaitaKanrenInit.xlsx")
	public void TestGetHeisaByHaitaKanren() throws Exception
	{
		List<MHaitaKashidashiTani> mHaitaKashidashiTanis = new ArrayList<>();
		MHaitaKashidashiTani mHaitaKashidashiTani = new MHaitaKashidashiTani();
		mHaitaKashidashiTani.setKashidashiTaniCode((short)0);
		mHaitaKashidashiTani.setKanriCode((short)10);
		mHaitaKashidashiTani.setShisetsuCode((short)10);
		mHaitaKashidashiTanis.add(mHaitaKashidashiTani);

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/M/dd");
		Date fDate = new Date();
		fDate = formatter.parse("2017/4/2");

		Date tDate = new Date();
		tDate = formatter.parse("2017/4/5");

		List<TShisetsuHeisa> ret = tShisetsuHeisaLogic.getHeisaByHaitaKanren(mHaitaKashidashiTanis, fDate, tDate);
		exportJsonData(ret, "TestGetHeisaByHaitaKanren.json");
	}
	
	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestGetTShisetsuHeisaByTShinseiMeisaiInit.xlsx")
	public void TestGetTShisetsuHeisaByTShinseiMeisai() throws Exception
	{
		TShinseiMeisai tShinseiMeisai = new TShinseiMeisai();
		tShinseiMeisai.setKanriCode((short)10);
		tShinseiMeisai.setShisetsuCode((short)10);
		SimpleDateFormat sd = new SimpleDateFormat("yyyy/M/d");
		Date shiyoDate = new Date();
		shiyoDate = sd.parse("2017/4/3");
		tShinseiMeisai.setShiyoDate(shiyoDate);
		
		List<TShinseiMeisai> listTShinseiMeisai = new ArrayList<>();
		listTShinseiMeisai.add(tShinseiMeisai);
		
		List<? extends TShinseiMeisai> tShinseiMeisais = listTShinseiMeisai;
	
		List<TShisetsuHeisa> ret = tShisetsuHeisaLogic.getTShisetsuHeisaByTShinseiMeisai(tShinseiMeisais);
		exportJsonData(ret, "TestGetTShisetsuHeisaByTShinseiMeisai.json");
		
	}
	
	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestGetTShisetsuHeisaForBookingCheckInit.xlsx")
	public void TestGetTShisetsuHeisaForBookingCheck() throws Exception
	{
		TShinseiMeisai tShinseiMeisai = new TShinseiMeisai();
		tShinseiMeisai.setKanriCode((short)10);
		tShinseiMeisai.setShisetsuCode((short)10);
		tShinseiMeisai.setKashidashiTaniCode((short)0);
		SimpleDateFormat sd = new SimpleDateFormat("yyyy/M/d");
		Date shiyoDate = new Date();
		shiyoDate = sd.parse("2017/4/3");
		tShinseiMeisai.setShiyoDate(shiyoDate);
		tShinseiMeisai.setEndKoma((short)13);
		tShinseiMeisai.setStartKoma((short)1);
		
		List<TShisetsuHeisa> ret = tShisetsuHeisaLogic.getTShisetsuHeisaForBookingCheck(tShinseiMeisai);
		exportJsonData(ret, "TestGetTShisetsuHeisaForBookingCheck.json");
	
	}
	
	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestGetTShisetsuHeisaForKakuninInit.xlsx")
	public void TestGetTShisetsuHeisaForKakunin1() throws Exception
	{
		KyukanSetteiDataDto kyukanSetteiDataDto = new KyukanSetteiDataDto();
		kyukanSetteiDataDto.setKanriCode((short)10);
		kyukanSetteiDataDto.setShisetsuCode((short)10);
		kyukanSetteiDataDto.setKashidashiTaniCode((short)0);
		kyukanSetteiDataDto .setHeisaShurui("0");
		kyukanSetteiDataDto.setBashoCode((short)10);
		
		DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("yyyy/M/d");
		LocalDate startDate = LocalDate.parse("2017/4/2", formatter2);
		LocalDate endDate = LocalDate.parse("2017/4/5", formatter2);
		kyukanSetteiDataDto.setStartDate(startDate);
		kyukanSetteiDataDto.setEndDate(endDate);
		
		List<String> heisaShuruiCodes = new ArrayList<>();
		heisaShuruiCodes.add("0");
		kyukanSetteiDataDto.setHeisaShuruiCodes(heisaShuruiCodes);
		
		List<KyukanSetteiDataDto> ret = tShisetsuHeisaLogic.getTShisetsuHeisaForKakunin(kyukanSetteiDataDto);
		exportJsonData(ret, "TestGetTShisetsuHeisaForKakunin1.json");
	}
	
	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestGetTShisetsuHeisaForKakuninInit.xlsx")
	public void TestGetTShisetsuHeisaForKakunin2() throws Exception
	{
		KyukanSetteiDataDto kyukanSetteiDataDto = new KyukanSetteiDataDto();
		kyukanSetteiDataDto.setKanriCode((short)10);
		kyukanSetteiDataDto.setShisetsuCode(null);
		kyukanSetteiDataDto.setKashidashiTaniCode(null);
		kyukanSetteiDataDto .setHeisaShurui("0");
		kyukanSetteiDataDto.setBashoCode((short)10);
		
		DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("yyyy/M/d");
		LocalDate startDate = LocalDate.parse("2017/4/2", formatter2);
		LocalDate endDate = LocalDate.parse("2017/4/5", formatter2);
		kyukanSetteiDataDto.setStartDate(startDate);
		kyukanSetteiDataDto.setEndDate(endDate);
		
		List<String> heisaShuruiCodes = new ArrayList<>();
		kyukanSetteiDataDto.setHeisaShuruiCodes(heisaShuruiCodes);
		
		List<KyukanSetteiDataDto> ret = tShisetsuHeisaLogic.getTShisetsuHeisaForKakunin(kyukanSetteiDataDto);
		exportJsonData(ret, "TestGetTShisetsuHeisaForKakunin2.json");
	}
	
	@Test
	public void TestgetDao() throws Exception {
		GenericDao<TShisetsuHeisa, ?> ret =  tShisetsuHeisaLogic.getDao();
	}
}