package jp.ne.yec.seagullLC.stagia.test.junit.logic.shinsei.ShinseiLogic;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.google.gson.reflect.TypeToken;

import jp.ne.yec.seagullLC.stagia.beans.enums.domain.ShinseiShurui;
import jp.ne.yec.seagullLC.stagia.beans.shinsei.ShinseiDto;
import jp.ne.yec.seagullLC.stagia.beans.shinsei.ShinseiIchiranDto;
import jp.ne.yec.seagullLC.stagia.beans.shinsei.ShinseiMeisaiDto;
import jp.ne.yec.seagullLC.stagia.beans.shinsei.ShukeiDataDto;
import jp.ne.yec.seagullLC.stagia.entity.MBasho;
import jp.ne.yec.seagullLC.stagia.entity.MShisetsu;
import jp.ne.yec.seagullLC.stagia.entity.MShukei;
import jp.ne.yec.seagullLC.stagia.entity.MShukeiKomoku;
import jp.ne.yec.seagullLC.stagia.entity.TRiyosha;
import jp.ne.yec.seagullLC.stagia.logic.shinsei.ShinseiLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestShinseiLogic extends JunitBase {

	@Autowired
	ShinseiLogic shinseiLogic;

	@Test
	 /* chưa đủ 80%*/
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestSetNewMeisaiDtoInfo_Step1_Init.xlsx")
	public void TestSetNewMeisaiDtoInfo_Step1() throws Exception
	{
		List<ShinseiMeisaiDto> meisaiDtos = readJson("TestSetNewMeisaiDtoInfo_Step1_meisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>(){}.getType());
		Map<Short, MBasho> mBashoMap = readJson("TestSetNewMeisaiDtoInfo_Step1_mBashoMap.pra", new TypeToken<Map<Short, MBasho>>(){}.getType());;
		Map<String, MShisetsu> mShisetsuMap = readJson("TestSetNewMeisaiDtoInfo_Step1_mShisetsuMap.pra", new TypeToken<Map<String, MShisetsu>>(){}.getType());;
		shinseiLogic.setNewMeisaiDtoInfo(meisaiDtos, mBashoMap, mShisetsuMap, false);
	}

	@Test
	/* chưa đủ 70%*/
	@TestInitDataFile("TestSetConflictingReservations_Init.xlsx")
	@DisplayName("データ更新に使用するDaoを取得します")
	public void TestSetConflictingReservations() throws Exception
	{
		List<? extends ShinseiMeisaiDto> meisaiDtos = readJson("TestSetConflictingReservations_meisaiDtos.pra", new TypeToken<List<? extends ShinseiMeisaiDto>>() {}.getType());
		shinseiLogic.setConflictingReservations(meisaiDtos);
	}

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestSetUserInformation_TRiyosha_Step1_Init.xlsx")
	public void TestSetUserInformation_TRiyosha_Step1() throws Exception
	{
		ShinseiDto shinseiDto = readJson("TestSetUserInformation_TRiyosha_Step1_shinseiDto.pra", new TypeToken<ShinseiDto>(){}.getType());
		TRiyosha tRiyosha = readJson("TestSetUserInformation_TRiyosha_Step1_tRiyosha.pra", new TypeToken<TRiyosha>(){}.getType());
		shinseiLogic.setUserInformation(shinseiDto, tRiyosha);
	}

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestSetUserInformation_TRiyosha_Step2_Init.xlsx")
	public void TestSetUserInformation_TRiyosha_Step2() throws Exception
	{
		ShinseiDto shinseiDto = readJson("TestSetUserInformation_TRiyosha_Step2_shinseiDto.pra", new TypeToken<ShinseiDto>(){}.getType());
		TRiyosha tRiyosha = readJson("TestSetUserInformation_TRiyosha_Step2_tRiyosha.pra", new TypeToken<TRiyosha>(){}.getType());
		shinseiLogic.setUserInformation(shinseiDto, tRiyosha);
	}

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestSetUserInformation_TRiyosha_Step3_Init.xlsx")
	public void TestSetUserInformation_TRiyosha_Step3() throws Exception
	{
		ShinseiDto shinseiDto = readJson("TestSetUserInformation_TRiyosha_Step3_shinseiDto.pra", new TypeToken<ShinseiDto>(){}.getType());
		TRiyosha tRiyosha = readJson("TestSetUserInformation_TRiyosha_Step3_tRiyosha.pra", new TypeToken<TRiyosha>(){}.getType());
		shinseiLogic.setUserInformation(shinseiDto, tRiyosha);
	}

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestSetUserInformation_TRiyosha_Step4_Init.xlsx")
	public void TestSetUserInformation_TRiyosha_Step4() throws Exception
	{
		ShinseiDto shinseiDto = readJson("TestSetUserInformation_TRiyosha_Step4_shinseiDto.pra", new TypeToken<ShinseiDto>(){}.getType());
		TRiyosha tRiyosha = readJson("TestSetUserInformation_TRiyosha_Step4_tRiyosha.pra", new TypeToken<TRiyosha>(){}.getType());
		shinseiLogic.setUserInformation(shinseiDto, tRiyosha);
	}

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestSetUserInformation_TRiyosha_Step5_Init.xlsx")
	public void TestSetUserInformation_TRiyosha_Step5() throws Exception
	{
		ShinseiDto shinseiDto = readJson("TestSetUserInformation_TRiyosha_Step5_shinseiDto.pra", new TypeToken<ShinseiDto>(){}.getType());
		TRiyosha tRiyosha = readJson("TestSetUserInformation_TRiyosha_Step5_tRiyosha.pra", new TypeToken<TRiyosha>(){}.getType());
		shinseiLogic.setUserInformation(shinseiDto, tRiyosha);
	}

	@Test
	/* chưa đủ 70%*/
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestSetTKanribetsuRiyoshaJohoInfo_Init.xlsx")
	public void TestSetTKanribetsuRiyoshaJohoInfo() throws Exception
	{
		List<ShinseiMeisaiDto> shinseiMeisaiDtos = readJson("TestSetTKanribetsuRiyoshaJohoInfo_shinseiMeisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>() {}.getType());
		SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd HH:MM:ss");
		Date toshoUketsukeDate = format.parse("2018/07/04 15:03:53");
		shinseiLogic.setTKanribetsuRiyoshaJohoInfo("tnt", shinseiMeisaiDtos, toshoUketsukeDate);
	}

	@Test
	 /* Chưa đủ 60%*/
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestSetRyokinInformation_Step1_Init.xlsx")
	public void TestSetRyokinInformation_Step1() throws Exception
	{
		SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd HH:MM:ss");
		List<ShinseiMeisaiDto> shinseiMeisaiDtos = readJson("TestSetRyokinInformation_shinseiMeisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>() {}.getType());
		Date toshoUketsukeDates = format.parse("2018/07/04 12:00:00");
		shinseiLogic.setRyokinInformation(shinseiMeisaiDtos, toshoUketsukeDates);
	}

	@Test
	@TestInitDataFile("TestSetSetsubiUmu_Step1_Init.xlsx")
	@DisplayName("データ更新に使用するDaoを取得します")
	public void TestSetSetsubiUmu_Step1() throws Exception
	{
		List<ShinseiIchiranDto> shiseniQueryDtoList = readJson("TestSetSetsubiUmu_Step1_ichiranDtos.pra", new TypeToken<List<ShinseiIchiranDto>>(){}.getType());
		shinseiLogic.setSetsubiUmu(shiseniQueryDtoList);;
	}

	@Test
	@TestInitDataFile("TestSetSetsubiUmu_Step2_Init.xlsx")
	@DisplayName("データ更新に使用するDaoを取得します")
	public void TestSetSetsubiUmu_Step2() throws Exception
	{
		List<ShinseiIchiranDto> shiseniQueryDtoList = new ArrayList<ShinseiIchiranDto>();;
		shinseiLogic.setSetsubiUmu(shiseniQueryDtoList);;
	}

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	public void TestSetSetsubiUmu_Step3() throws Exception
	{
		List<ShinseiIchiranDto> shiseniQueryDtoList = readJson("TestSetSetsubiUmu_Step3_ichiranDtos.pra", new TypeToken<List<ShinseiIchiranDto>>(){}.getType());
		shinseiLogic.setSetsubiUmu(shiseniQueryDtoList);;
	}

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestSetMeisaiSubTables_Step1_Init.xlsx")
	public void TestSetMeisaiSubTables_Step1() throws Exception
	{
		List<ShinseiMeisaiDto> meisaiDtos = readJson("TestSetMeisaiSubTables_Step1_meisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>(){}.getType());
		shinseiLogic.setMeisaiSubTables((short)10, ShinseiShurui.HONYOYAKU, meisaiDtos);
	}


	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	public void TestMakeShukeiDataDto() throws Exception
	{
		List<MShukei> mShukeis = readJson("TestMakeShukeiDataDto_mShukeis.pra", new TypeToken<List<MShukei>>(){}.getType());
		Map<Short, List<MShukeiKomoku>> mShukeiKomokuMap = readJson("TestMakeShukeiDataDto_mShukeiKomokuMap.pra", new TypeToken<Map<Short, List<MShukeiKomoku>>>(){}.getType());;
		List<ShukeiDataDto> ret = shinseiLogic.makeShukeiDataDto(mShukeis, mShukeiKomokuMap);
		exportJsonData(ret, "TestMakeShukeiDataDto.json");
	}

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	public void TestGetRyokinKeisanKijunDate_Step1() throws Exception
	{
		SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd HH:MM:ss");
		Date shiyoDates = format.parse("2018/07/06 12:00:00");
		Date uketsukeDates = format.parse("2018/07/06 12:00:00");
		Date toshoUketsukeDates = format.parse("2018/07/06 12:00:00");
		Date ret = shinseiLogic.getRyokinKeisanKijunDate(shiyoDates,uketsukeDates,toshoUketsukeDates,"0");
		exportJsonData(ret, "TestGetRyokinKeisanKijunDate_Step1.json");
	}

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	public void TestGetRyokinKeisanKijunDate_Step2() throws Exception
	{
		SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd HH:MM:ss");
		Date shiyoDates = format.parse("2018/07/06 12:00:00");
		Date uketsukeDates = format.parse("2018/07/06 12:00:00");
		Date toshoUketsukeDates = format.parse("2018/07/06 12:00:00");
		Date ret = shinseiLogic.getRyokinKeisanKijunDate(shiyoDates,uketsukeDates,toshoUketsukeDates,"1");
		exportJsonData(ret, "TestGetRyokinKeisanKijunDate_Step2.json");
	}

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	public void TestGetRyokinKeisanKijunDate_Step3() throws Exception
	{
		SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd HH:MM:ss");
		Date shiyoDates = format.parse("2018/07/06 12:00:00");
		Date uketsukeDates = format.parse("2018/07/06 12:00:00");
		Date toshoUketsukeDates = format.parse("2018/07/06 12:00:00");
		Date ret = shinseiLogic.getRyokinKeisanKijunDate(shiyoDates,uketsukeDates,toshoUketsukeDates,"2");
		exportJsonData(ret, "TestGetRyokinKeisanKijunDate_Step3.json");
	}

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestGetShinseiDto_Init.xlsx")
	public void TestGetShinseiDto() throws Exception
	{
		ShinseiDto ret = shinseiLogic.getShinseiDto((short)10, 772, false);
		exportJsonData(ret, "TestgetShinseiDto.json");
	}

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestGetShinseiDtoWithUketsukeBashoCode_Init.xlsx")
	public void TestGetShinseiDtoWithUketsukeBashoCode() throws Exception
	{
		ShinseiDto ret = shinseiLogic.getShinseiDto((short)10, 772, (short)10, false);
		exportJsonData(ret, "TestGetShinseiDtoWithUketsukeBashoCode.json");
	}

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestGetShinseiDtoForShokai_Init.xlsx")
	public void TestGetShinseiDtoForShokai() throws Exception
	{
		ShinseiDto ret = shinseiLogic.getShinseiDtoForShokai((short)10, 772, false);
		exportJsonData(ret, "TestGetShinseiDtoForShokai.json");
	}

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestSetMasterToMeisaiDto_Step2_Init.xlsx")
	public void TestSetMasterToMeisaiDto_Step2() throws Exception
	{
		List<? extends ShinseiMeisaiDto> meisaiDtos = readJson("TestSetMasterToMeisaiDto_Step2_meisaiDtos.pra",  new TypeToken<List<? extends ShinseiMeisaiDto>>(){}.getType());
		boolean isShokuinLogin = false;
		shinseiLogic.setMasterToMeisaiDto(meisaiDtos,isShokuinLogin);
	}

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestSetMasterToMeisaiDto_Step1_Init.xlsx")
	public void TestSetMasterToMeisaiDto_Step1() throws Exception
	{
		List<? extends ShinseiMeisaiDto> meisaiDtos = readJson("TestSetMasterToMeisaiDto_Step1_meisaiDtos.pra",  new TypeToken<List<? extends ShinseiMeisaiDto>>(){}.getType());
		boolean isShokuinLogin = true;
		shinseiLogic.setMasterToMeisaiDto(meisaiDtos,isShokuinLogin);
	}
}

