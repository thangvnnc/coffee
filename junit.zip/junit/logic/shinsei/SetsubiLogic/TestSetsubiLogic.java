package jp.ne.yec.seagullLC.stagia.test.junit.logic.shinsei.SetsubiLogic;

import static org.junit.Assert.*;

import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.google.common.reflect.TypeToken;

import jp.ne.yec.seagullLC.stagia.beans.shinsei.SetsubiInfoDto;
import jp.ne.yec.seagullLC.stagia.beans.shinsei.SetsubiShinseiDto;
import jp.ne.yec.seagullLC.stagia.beans.shinsei.SetsubiShinseiKomaDto;
import jp.ne.yec.seagullLC.stagia.beans.shinsei.ShinseiDto;
import jp.ne.yec.seagullLC.stagia.beans.shinsei.ShinseiMeisaiDto;
import jp.ne.yec.seagullLC.stagia.beans.shinsei.ShisetsuKomaDto;
import jp.ne.yec.seagullLC.stagia.entity.MWebZaiko;
import jp.ne.yec.seagullLC.stagia.logic.shinsei.SetsubiLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestSetsubiLogic extends JunitBase {

	@Autowired
	SetsubiLogic setsubiLogic;

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	public void TestMakeShinseiSetsubiListForDisplay_Step1() throws Exception
	{
		SetsubiShinseiDto setsubiShinseiDto = readJson("TestMakeShinseiSetsubiListForDisplay_Step1_setsubiShinseiDto.pra", new TypeToken<SetsubiShinseiDto>() {}.getType());
		List<SetsubiShinseiDto> ret = setsubiLogic.makeShinseiSetsubiListForDisplay(setsubiShinseiDto);
		exportJsonData(ret, "TestMakeShinseiSetsubiListForDisplay_Step1.json");
	}

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	public void TestMakeShinseiSetsubiListForDisplay_Step2() throws Exception
	{
		SetsubiShinseiDto setsubiShinseiDto = readJson("TestMakeShinseiSetsubiListForDisplay_Step2_setsubiShinseiDto.pra", new TypeToken<SetsubiShinseiDto>() {}.getType());
		List<SetsubiShinseiDto> ret = setsubiLogic.makeShinseiSetsubiListForDisplay(setsubiShinseiDto);
		assertEquals(0, ret.size());
	}

	@Test
	public void TestGetRenzokuAndSameSuryoSetsubiMap_Step1() throws Exception
	{
		List<SetsubiShinseiKomaDto> setsubiKomas = readJson("TestGetRenzokuAndSameSuryoSetsubiMap_Step1_setsubiKomas.pra", new TypeToken<List<SetsubiShinseiKomaDto>>() {}.getType());
		Map<Integer, List<SetsubiShinseiKomaDto>> ret = setsubiLogic.getRenzokuAndSameSuryoSetsubiMap(setsubiKomas);
		exportJsonData(ret, "TestGetRenzokuAndSameSuryoSetsubiMap_Step1.json");
	}

	@Test
	public void TestGetRenzokuAndSameSuryoSetsubiMap_Step2() throws Exception
	{
		List<SetsubiShinseiKomaDto> setsubiKomas = readJson("TestGetRenzokuAndSameSuryoSetsubiMap_Step2_setsubiKomas.pra", new TypeToken<List<SetsubiShinseiKomaDto>>() {}.getType());
		Map<Integer, List<SetsubiShinseiKomaDto>> ret = setsubiLogic.getRenzokuAndSameSuryoSetsubiMap(setsubiKomas);
		exportJsonData(ret, "TestGetRenzokuAndSameSuryoSetsubiMap_Step2.json");
	}

	@Test
	public void TestGetRenzokuAndSameSuryoSetsubiMap_Step3() throws Exception
	{
		List<SetsubiShinseiKomaDto> setsubiKomas = readJson("TestGetRenzokuAndSameSuryoSetsubiMap_Step3_setsubiKomas.pra", new TypeToken<List<SetsubiShinseiKomaDto>>() {}.getType());
		Map<Integer, List<SetsubiShinseiKomaDto>> ret = setsubiLogic.getRenzokuAndSameSuryoSetsubiMap(setsubiKomas);
		exportJsonData(ret, "TestGetRenzokuAndSameSuryoSetsubiMap_Step3.json");
	}

	@Test
	public void TestGetRenzokuAndSameSuryoSetsubiMap_Step4() throws Exception
	{
		List<SetsubiShinseiKomaDto> setsubiKomas = readJson("TestGetRenzokuAndSameSuryoSetsubiMap_Step4_setsubiKomas.pra", new TypeToken<List<SetsubiShinseiKomaDto>>() {}.getType());
		Map<Integer, List<SetsubiShinseiKomaDto>> ret = setsubiLogic.getRenzokuAndSameSuryoSetsubiMap(setsubiKomas);
		exportJsonData(ret, "TestGetRenzokuAndSameSuryoSetsubiMap_Step4.json");
	}

	@Test
	@TestInitDataFile("TestGetJidoSetsubi_Step1_Init.xlsx")
	public void TestGetJidoSetsubi_Step1() throws Exception
	{
		ShinseiMeisaiDto meisaiDto = readJson("TestGetJidoSetsubi_Step1_meisaiDto.pra", new TypeToken<ShinseiMeisaiDto>() {}.getType());
		List<SetsubiShinseiDto> ret = setsubiLogic.getJidoSetsubi(meisaiDto);
		assertEquals(0, ret.size());
	}

	@Test
	@TestInitDataFile("TestGetJidoSetsubi_Step2_Init.xlsx")
	public void TestGetJidoSetsubi_Step2() throws Exception
	{
		ShinseiMeisaiDto meisaiDto = readJson("TestGetJidoSetsubi_Step2_meisaiDto.pra", new TypeToken<ShinseiMeisaiDto>() {}.getType());
		List<SetsubiShinseiDto> ret = setsubiLogic.getJidoSetsubi(meisaiDto);
		assertEquals(0, ret.size());
	}

	@Test
	@TestInitDataFile("TestGetJidoSetsubi_Step3_Init.xlsx")
	public void TestGetJidoSetsubi_Step3() throws Exception
	{
		ShinseiMeisaiDto meisaiDto = readJson("TestGetJidoSetsubi_Step3_meisaiDto.pra", new TypeToken<ShinseiMeisaiDto>() {}.getType());
		List<SetsubiShinseiDto> ret = setsubiLogic.getJidoSetsubi(meisaiDto);
		exportJsonData(ret, "TestGetJidoSetsubi_Step3.json");
	}

	@Test
	// chua du 70%
	@DisplayName("データ更新に使用するDaoを取得します")
	public void TestGetAvailableSetsubi_Step1() throws Exception
	{
		List<SetsubiInfoDto> setsubiInfoDtos = readJson("TestGetAvailableSetsubi_Step1_setsubiInfoDtos.pra", new TypeToken<List<SetsubiInfoDto>>() {}.getType());
		List<ShisetsuKomaDto> selectedKomas = readJson("TestGetAvailableSetsubi_Step1_selectedKomas.pra", new TypeToken<List<ShisetsuKomaDto>>() {}.getType());;
		List<SetsubiInfoDto>  ret = setsubiLogic.getAvailableSetsubi(setsubiInfoDtos, selectedKomas, false);
		exportJsonData(ret, "TestGetAvailableSetsubi_Step1.json");
	}

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestUpdateSetsubiZaiko_Step1_Init.xlsx")
	public void TestUpdateSetsubiZaiko_Step1() throws Exception
	{
		List<SetsubiInfoDto> availableSetsubi = readJson("TestUpdateSetsubiZaiko_Step1_availableSetsubi.pra", new TypeToken<List<SetsubiInfoDto>>() {}.getType());
		ShinseiDto shinseiDto = readJson("TestUpdateSetsubiZaiko_Step1_shinseiDto.pra", new TypeToken<ShinseiDto>() {}.getType());
		ShinseiMeisaiDto meisaiDto = readJson("TestUpdateSetsubiZaiko_Step1_meisaiDto.pra", new TypeToken<ShinseiMeisaiDto>() {}.getType());
		List<ShinseiMeisaiDto> meisaiDtos = readJson("TestUpdateSetsubiZaiko_Step1_meisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>() {}.getType());
		List<MWebZaiko> mWebZaikoList = readJson("TestUpdateSetsubiZaiko_Step1_mWebZaikoList.pra", new TypeToken<List<MWebZaiko>>() {}.getType());

		setsubiLogic.updateSetsubiZaiko(availableSetsubi, shinseiDto, meisaiDto, meisaiDtos, (short)900, (short)1000, mWebZaikoList);
	}

	@Test
	@TestInitDataFile("TestCheckSetsubiZaikoOver_Step1_Init.xlsx")
	public void TestCheckSetsubiZaikoOver_Step1() throws Exception
	{
		ShinseiDto shinseiDto = readJson("TestCheckSetsubiZaikoOver_Step1_shinseiDto.pra", new TypeToken<ShinseiDto>() {}.getType());
		List<ShinseiMeisaiDto> meisaiDtos = readJson("TestCheckSetsubiZaikoOver_Step1_meisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>(){}.getType());
		setsubiLogic.checkSetsubiZaikoOver(shinseiDto, meisaiDtos, false);
	}

	@Test
	@TestInitDataFile("TestCheckSetsubiZaikoOver_Step2_Init.xlsx")
	public void TestCheckSetsubiZaikoOver_Step2() throws Exception
	{
		try
		{
			ShinseiDto shinseiDto = readJson("TestCheckSetsubiZaikoOver_Step2_shinseiDto.pra", new TypeToken<ShinseiDto>() {}.getType());
			List<ShinseiMeisaiDto> meisaiDtos = readJson("TestCheckSetsubiZaikoOver_Step2_meisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>(){}.getType());
			setsubiLogic.checkSetsubiZaikoOver(shinseiDto, meisaiDtos, false);
		}
		catch (Exception e) {
			String message = "申請[ 生涯学習センター 会議室 １：2018/7/13 09：00～10：00 ]の設備[ ポインター ]の使用数量が在庫数を超えています。再度設備設定画面にて数量を確認してください。~申請[ 生涯学習センター 会議室 ２：2018/7/13 09：00～10：00 ]の設備[ ポインター ]の使用数量が在庫数を超えています。再度設備設定画面にて数量を確認してください。~申請[ 生涯学習センター 会議室 ３：2018/7/13 09：00～10：00 ]の設備[ ポインター ]の使用数量が在庫数を超えています。再度設備設定画面にて数量を確認してください。";
			assertEquals(message, e.getMessage());
		}
	}

	@Test
	@TestInitDataFile("TestCheckSetsubiZaikoOver_Step3_Init.xlsx")
	public void TestCheckSetsubiZaikoOver_Step3() throws Exception
	{
		ShinseiDto shinseiDto = readJson("TestCheckSetsubiZaikoOver_Step3_shinseiDto.pra", new TypeToken<ShinseiDto>() {}.getType());
		List<ShinseiMeisaiDto> meisaiDtos = readJson("TestCheckSetsubiZaikoOver_Step3_meisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>(){}.getType());
		setsubiLogic.checkSetsubiZaikoOver(shinseiDto, meisaiDtos, true);
	}

	@Test
	@TestInitDataFile("TestCheckSetsubiZaikoOver_Step4_Init.xlsx")
	public void TestCheckSetsubiZaikoOver_Step4() throws Exception
	{
		ShinseiDto shinseiDto = readJson("TestCheckSetsubiZaikoOver_Step4_shinseiDto.pra", new TypeToken<ShinseiDto>() {}.getType());
		List<ShinseiMeisaiDto> meisaiDtos = readJson("TestCheckSetsubiZaikoOver_Step4_meisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>(){}.getType());
		setsubiLogic.checkSetsubiZaikoOver(shinseiDto, meisaiDtos, false);
	}

	@Test
	@TestInitDataFile("TestCheckSetsubiZaikoOver_Step5_Init.xlsx")
	public void TestCheckSetsubiZaikoOver_Step5() throws Exception
	{
			ShinseiDto shinseiDto = readJson("TestCheckSetsubiZaikoOver_Step5_shinseiDto.pra", new TypeToken<ShinseiDto>() {}.getType());
			List<ShinseiMeisaiDto> meisaiDtos = readJson("TestCheckSetsubiZaikoOver_Step5_meisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>(){}.getType());
			setsubiLogic.checkSetsubiZaikoOver(shinseiDto, meisaiDtos, false);
	}
}

