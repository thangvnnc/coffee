package jp.ne.yec.seagullLC.stagia.common;

/**
 * 運営機能内で使用する共通定数を定義したクラスです
 *
 * @author sic-hanaoka
 *
 */
public final class UneiConstants {

	/**
	 * ドロップタウン変更：管理
	 */
	public static final int CHANGE_DD_KANRI = 1;
	/**
	 * ドロップタウン変更：場所
	 */
	public static final int CHANGE_DD_BASHO = 2;
	/**
	 * ドロップタウン変更：施設
	 */
	public static final int CHANGE_DD_SHISETSU = 3;

	/**
	 * LocalTimeを文字列変換した際のフォーマット
	 */
	public static final String LOCAL_TIME_FORMAT = "HHmm";

	/**
	 * 週選択ラジオのコード(毎週)
	 */
	public static final String CODE_WEEKRADIO_ALLWEEK = "0";

	/**
	 * 週選択ラジオのコード(週選択)
	 */
	public static final String CODE_WEEKRADIO_SELECTWEEK = "1";

	/**
	 * メッセージタイプ：お知らせ
	 */
	public static final int MESSEAGE_TYPE_OSHIRASE = 1;

	/**
	 * お知らせ表示時のhtmlで指定している未読件数のclass
	 */
	public static final String HTML_CLASS_MSG_COUNT = "oshirase-count";

	/**
	 * お知らせ検索時に使用している独自のカラム名
	 *
	 * 「KIDOKU_ID」=t_oshirase_kidokuとm_oshiraseのoshirase_idが重複するため定義
	 * 「user_name」=sane_userのカラム名を定義
	 */
	public static final String KIDOKU_ID = "kidoku_id";
	public static final String USER_NAME = "user_name";
}
