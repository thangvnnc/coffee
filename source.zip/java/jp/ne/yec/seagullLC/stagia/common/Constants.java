package jp.ne.yec.seagullLC.stagia.common;

/**
 * Stagia2内で使用する共通定数を定義したクラスです
 *
 * @author sic-hanaoka
 *
 */
public final class Constants {
	public static final String ATTRIBUTE_NAME_MAXLENGTH = "maxlength";
	public static final String ATTRIBUTE_NAME_PLACEHOLDER = "placeholder";

	/**
	 * ハイフン
	 */
	public static final String HYPHEN = "-";

	/**
	 * パーセント
	 */
	public static final String PERCENT = "%";

	/**
	 * 半角スペース
	 */
	public static final String SPACE = " ";

	/**
	 * 全角スペース
	 */
	public static final String DOUBLE_BYTE_SPACE = "　";

	public static final String ERROR_DELIMITER  = "~";

	/**
	 * 画面表示時の年月日フォーマット
	 */
	public static final String DISP_DATE_FORMAT = "yyyy/M/d";

	/**
	 * 画面表示時の年月フォーマット
	 */
	public static final String DISP_YEARMONTH_FORMAT = "yyyy/M";

	/**
	 * 画面表示時の時刻フォーマット
	 */
	public static final String DISP_TIME_FORMAT = "HH:mm";

	/**
	 * 「カタカナ」のみかを表す正規表現
	 */
	public static final String REG_KATAKANA_ONLY = "^[\\u30A0-\\u30FF]+$";

	/**
	 * 「半角カタカナ」のみかを表す正規表現
	 */
	public static final String REG_HALF_KATAKANA_ONLY = "^[\\uFF65-\\uFF9F]+$";

	/**
	 * 「半角文字」のみかを表す正規表現
	 */
	public static final String REG_HALF_ONLY = "[ -~｡-ﾟ]+";

	/**
	 * 「半角数字」のみかを表す正規表現
	 */
	public static final String REG_HALF_NUM_ONLY = "^[0-9]+$";

	/**
	 * 「半角英数字記号」のみかを表す正規表現
	 */
	public static final String REG_HALF_EISUJIKIGO = "^[a-zA-Z0-9 -/:-@\\[-\\`\\{-\\~]+$";

	/**
	 * 口座名義人カナの使用可能文字を表す正規表現</BR>
	 * 全国銀行協会で定められた下記半角文字のみを許容します.
	 * <ul>
	 * 	<li>ｱｲｳｴｵｶｷｸｹｺｻｼｽｾｿﾀﾁﾂﾃﾄﾅﾆﾇﾈﾉﾊﾋﾌﾍﾎﾏﾐﾑﾒﾓﾔﾕﾖﾗﾘﾙﾚﾛﾜﾝﾞﾟ
	 * 	<li>0123456789
	 * 	<li>ABCDEFGHIJKLMNOPQRSTUVWXYZ
	 * 	<li>( ) . - /　※【前カッコ　後カッコ　ピリオド　マイナス記号　スラッシュ】
	 * </ul>
	 */
	public static final String REG_KOZA_MEIGININ_KANA = "^[A-Z0-9ｱ-ﾟ().-/]+$";

}
