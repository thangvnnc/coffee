package jp.ne.yec.seagullLC.stagia.beans.enums.domain;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import org.apache.commons.lang.StringUtils;

import jp.ne.yec.seagullLC.stagia.beans.enums.domain.base.StagiaEnum;

/**
 * Generated on Mon Feb 05 19:18:17 JST 2018 based on <br>
 * ドメイン定義票（基準日算出単位）.xlsx.
 * <p>
 * 	各種基準日を算出する際に使用する単位を保持する列挙型です。<br>
 * </p>
 */
public enum KijunDateTani implements StagiaEnum  {
	UKETSUKEBIGO("0", "受付日後"),
	SHIYOBIMAE("1", "使用日前"),
	SHIYOBIGO("2", "使用日後"),
;
	private String code;
	private String name;

	private KijunDateTani(String code, String name) {
		this.code = code;
		this.name = name;
	}

	public String getCode() {
		return this.code;
	}

	public String getName() {
		return this.name;
	}

	/**
	 * 引数のコードを保持する列挙子を返却します.
	 * 存在しない場合、{@code null}を返却します.
	 *
	 * @param code
	 * @return - codeを保持するKijunDateTani
	 */
	public static KijunDateTani getEnumClass(String code) {
		return Stream.of(values()).filter(e -> e.getCode().equals(code)).findFirst().orElse(null);
	}

	/**
	 * 引数のコードを保持する列挙子の名称を返却します.
	 * 存在しない場合、{@code StringUtils.EMPTY}を返却します.
	 *
	 * @param code
	 * @return - codeを保持するKijunDateTaniのname
	 */
	public static String getName(String code) {
		KijunDateTani enumClass = getEnumClass(code);
		if (null == enumClass) {
			return StringUtils.EMPTY;
		}
		return enumClass.getName();
	}

	/**
	 * KijunDateTaniの列挙子全てをList型で返却します.
	 *
	 * @return - KijunDateTaniのList
	 */
	public static List<KijunDateTani> getList() {
		return Arrays.asList(values());
	}
}
