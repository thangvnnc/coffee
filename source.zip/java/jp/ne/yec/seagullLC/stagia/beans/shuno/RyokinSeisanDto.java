package jp.ne.yec.seagullLC.stagia.beans.shuno;

import jp.ne.yec.seagullLC.stagia.common.Constants;
import jp.ne.yec.seagullLC.stagia.entity.TRyokin;
import lombok.Getter;
import lombok.Setter;

@SuppressWarnings("serial")
public class RyokinSeisanDto extends TRyokin {

	@Setter
	@Getter
	private Short meisaiKoshinKaisu;

	@Setter
	@Getter
	private boolean isCancelSeisan;

	@Setter
	@Getter
	private int yojoGaku;

	@Override
	public String getRyokinGokeiCurrencyFormat() {
		if (isCancelSeisan) {
			return Constants.HYPHEN;
		}
		return super.getRyokinGokeiCurrencyFormat();
	}

	@Override
	public Integer getRyoshuGokei() {
		if (isCancelSeisan) {
			return yojoGaku;
		}
		return super.getRyoshuGokei();
	}

	public int getSeisanGaku() {
		if (isCancelSeisan) {
			return getMiseisanCancelRyokinGokei();
		}
		return getRyokinGokei() - getRyoshuGokei() + getYojoGaku() + getKampuGokei();
	}

	public String getZenkaiShiyoRyokinCurrencyFormat() {
		if (isCancelSeisan) {
			return Constants.HYPHEN;
		}
		if (0 == meisaiKoshinKaisu) {
			return Constants.HYPHEN;
		}
		return currencyFormater(getZenkaiShiyoRyokin());
	}

	public String getRyoshuGokeiCurrencyFormat() {
		return currencyFormater(getRyoshuGokei());
	}

	public String getKampuGokeiCurrencyFormat() {
		if (isCancelSeisan) {
			return Constants.HYPHEN;
		}
		return currencyFormater(getKampuGokei());
	}

	public String getSeisanGakuCurrencyFormat() {
		return currencyFormater(getSeisanGaku());
	}
}
