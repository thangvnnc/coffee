package jp.ne.yec.seagullLC.stagia.beans.unei;

import java.io.Serializable;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.List;

import jp.ne.yec.sane.beans.StringCodeNamePair;
import jp.ne.yec.seagullLC.stagia.beans.enums.OshiraseBunruiKubun;
import jp.ne.yec.seagullLC.stagia.beans.enums.UpdateKubun;
import jp.ne.yec.seagullLC.stagia.beans.enums.domain.HyojisakiShurui;
import lombok.Getter;
import lombok.Setter;

/**
 * お知らせ設定の表示情報・更新情報を保持するDTOです
 *
 * @author sic-hanaoka
 *
 */
@Setter
@Getter
@SuppressWarnings("serial")
public class OshiraseSetteiDto  implements Serializable {

	/**
	 * 管理リスト(画面表示用リスト)
	 */
	private List<StringCodeNamePair> kanriList;

	/**
	 * 申請グループリスト(画面表示用リスト)
	 */
	private List<StringCodeNamePair> shinseiGroupList;

	/**
	 * お知らせ分類リスト(画面表示用リスト)
	 */
	private List<StringCodeNamePair> bunruiList;

	/**
	 * お知らせID
	 */
	private Integer oshiraseID;

	/**
	 * 更新区分(入力情報取得用)
	 */
	private UpdateKubun selectedUpdateKbn;

	/**
	 * 更新区分(処理用)
	 */
	private String updateKbn;

	/**
	 * 表示先種類(入力情報取得用)
	 */
	private HyojisakiShurui selectedHyojisaki;

	/**
	 * 表示先種類(処理用)
	 */
	private String hyojisakiShurui;

	/**
	 * お知らせ表示期間開始日(入力情報取得用)
	 */
	private String fromDate;

	/**
	 * お知らせ表示期間開始日(処理用)
	 */
	private LocalDate startDate;

	/**
	 * お知らせ表示期間終了日(入力情報取得用)
	 */
	private String toDate;

	/**
	 * お知らせ表示期間終了日(処理用)
	 */
	private LocalDate endDate;

	/**
	 * 管理コード(入力情報取得用)
	 */
	private StringCodeNamePair selectedKanri;

	/**
	 * 管理コード(処理用)
	 */
	private Short kanriCode;

	/**
	 * 申請グループコード(入力情報取得用)
	 */
	private StringCodeNamePair selectedShinseiGroup;

	/**
	 * 申請グループコード(処理用)
	 */
	private Short shinseiGroupCode;

	/**
	 * お知らせ分類区分(入力情報取得用)
	 */
	private OshiraseBunruiKubun selectedBunruiKbn;

	/**
	 * お知らせ分類コード(入力情報取得用)
	 */
	private StringCodeNamePair selectedBunrui;

	/**
	 * お知らせ分類コード(処理用)
	 */
	private Short bunruiCode;

	/**
	 * 任意分類名称
	 */
	private String optBunruiName;

	/**
	 * 任意分類背景色
	 */
	private String optBunruiBgColor;

	/**
	 * 任意分類文字色
	 */
	private String optBunruiColor;

	/**
	 * ログインID
	 */
	private String loginId;

	/**
	 * お知らせタイトル
	 */
	private String title;

	/**
	 * お知らせ本文
	 */
	private String honbun;

	/**
	 * 登録日時
	 */
	private Timestamp createdAt;

	/**
	 * 登録者ID
	 */
	private String createdBy;

	/**
	 * バージョン
	 */
	private Integer version;

	/**
	 * DatePick用(表示期間開始日)
	 */
	private Object fromDatepick;

	/**
	 * DatePick用(表示期間終了日)
	 */
	private Object toDatepick;
}

