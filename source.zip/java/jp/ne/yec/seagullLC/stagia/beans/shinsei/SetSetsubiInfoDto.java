package jp.ne.yec.seagullLC.stagia.beans.shinsei;

import jp.ne.yec.seagullLC.stagia.entity.MSetSetsubi;
import lombok.Getter;
import lombok.Setter;


/**
 * セット設備の情報を保持するDTOクラスです.
 *
 * @author sic-hanaoka
 *
 */
@Getter
@Setter
@SuppressWarnings("serial")
public class SetSetsubiInfoDto extends MSetSetsubi {

	/**
	 * セット設備の設備名称
	 */
	private String setSetsubiName;

	/**
	 * セット設備の在庫数
	 */
	private Short setZaikosu;

	/**
	 * セット設備の単位
	 */
	private String setTani;

	/**
	 * 構成設備の設備名称
	 */
	private String koseiSetsubiBunruiName;

	/**
	 * 構成設備の設備名称
	 */
	private String koseiSetsubiName;

	/**
	 * 構成設備の在庫数
	 */
	private Short koseiZaikosu;

	/**
	 * 構成設備の単位
	 */
	private String koseiTani;

	/**
	 * セット設備を一意としたキー値を返却します.
	 *
	 * @return setsubiBunruiCode * 10000 + setsubiCode;
	 */
	public int getSetSetsubiKey() {
		return getSetsubiBunruiCode() * 10000 + getSetsubiCode();
	}

	/**
	 * 構成設備を一意としたキー値を返却します.
	 *
	 * @return koseiSetsubiBunruiCode * 10000 + koseiSetsubiCode;
	 */
	public int getKoseiSetsubiKey() {
		return getKoseiSetsubiBunruiCode() * 10000 + getKoseiSetsubiCode();
	}

	/**
	 * 画面表示用の構成設備の数量を返却します.
	 *
	 * @return
	 */
	public String getDisplayKoseiSuryo() {
		return String.valueOf(getSuryo()).concat(koseiTani);
	}
}
