package jp.ne.yec.seagullLC.stagia.beans.shinsei;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import jp.ne.yec.seagullLC.stagia.beans.enums.domain.KeisanKomokuCode;
import jp.ne.yec.seagullLC.stagia.entity.TRyokin;
import jp.ne.yec.seagullLC.stagia.entity.TRyokinSanshutsuKomoku;
import lombok.Getter;
import lombok.Setter;

/**
 * @author nao-hirata
 *
 */
@SuppressWarnings("serial")
public class RyokinDto extends TRyokin {

	@Setter
	@Getter
	private List<RyokinSanshutsuKomokuDto> ryokinSanshutsuKomokuDtos = new ArrayList<>();

	public Integer getTax() {
		return ryokinSanshutsuKomokuDtos.stream()
				.filter(e -> e.getKeisanKomokuCode().equals(KeisanKomokuCode.TAX.getCode()))
				.map(TRyokinSanshutsuKomoku::getSanshutsuRyokin)
				.findFirst()
				.orElse(null);
	}

	public String getKihonRyokinCurrencyFormat() {
		return currencyFormater(getKihonRyokin());
	}
	public String getKasangakuGokeiCurrencyFormat() {
		return currencyFormater(getKasangakuGokei());
	}
	public String getGemmengakuGokeiCurrencyFormat() {
		return currencyFormater(getGemmengakuGokei());
	}
	public String getWaribikigakuGokeiCurrencyFormat() {
		return currencyFormater(getWaribikigakuGokei());
	}
	public String getHasuChoseigakuCurrencyFormat() {
		return currencyFormater(getHasuChoseigaku());
	}
	public void setTenyuryokuChoseigakuCurrencyFormat(String tenyuryokuChoseigaku) {
		if (StringUtils.isEmpty(tenyuryokuChoseigaku)) {
			return;
		}
		try {
			setTenyuryokuChoseigaku(Integer.parseInt(tenyuryokuChoseigaku));
		} catch (NumberFormatException e) {
			return;
		}
	}
	public String getTenyuryokuChoseigakuCurrencyFormat() {
		return currencyFormater(getTenyuryokuChoseigaku());
	}
	public String getTaxCurrencyFormat() {
		return currencyFormater(getTax());
	}
}
