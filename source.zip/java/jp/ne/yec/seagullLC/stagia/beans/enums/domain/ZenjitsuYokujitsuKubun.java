package jp.ne.yec.seagullLC.stagia.beans.enums.domain;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import org.apache.commons.lang.StringUtils;

import jp.ne.yec.seagullLC.stagia.beans.enums.domain.base.StagiaEnum;

/**
 * Generated on Mon Feb 05 19:18:17 JST 2018 based on <br>
 * ドメイン定義票（前日翌日区分）.xlsx.
 * <p>
 * 	領収予定日や申請受付日初日の振替先を保持する列挙型です。<br>
 * </p>
 */
public enum ZenjitsuYokujitsuKubun implements StagiaEnum  {
	ZENJITSU("0", "前日"),
	YOKUJITSU("1", "翌日"),
;
	private String code;
	private String name;

	private ZenjitsuYokujitsuKubun(String code, String name) {
		this.code = code;
		this.name = name;
	}

	public String getCode() {
		return this.code;
	}

	public String getName() {
		return this.name;
	}

	/**
	 * 引数のコードを保持する列挙子を返却します.
	 * 存在しない場合、{@code null}を返却します.
	 *
	 * @param code
	 * @return - codeを保持するZenjitsuYokujitsuKubun
	 */
	public static ZenjitsuYokujitsuKubun getEnumClass(String code) {
		return Stream.of(values()).filter(e -> e.getCode().equals(code)).findFirst().orElse(null);
	}

	/**
	 * 引数のコードを保持する列挙子の名称を返却します.
	 * 存在しない場合、{@code StringUtils.EMPTY}を返却します.
	 *
	 * @param code
	 * @return - codeを保持するZenjitsuYokujitsuKubunのname
	 */
	public static String getName(String code) {
		ZenjitsuYokujitsuKubun enumClass = getEnumClass(code);
		if (null == enumClass) {
			return StringUtils.EMPTY;
		}
		return enumClass.getName();
	}

	/**
	 * ZenjitsuYokujitsuKubunの列挙子全てをList型で返却します.
	 *
	 * @return - ZenjitsuYokujitsuKubunのList
	 */
	public static List<ZenjitsuYokujitsuKubun> getList() {
		return Arrays.asList(values());
	}
}
