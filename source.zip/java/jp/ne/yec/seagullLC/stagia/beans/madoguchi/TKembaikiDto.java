package jp.ne.yec.seagullLC.stagia.beans.madoguchi;

import java.io.Serializable;

import jp.ne.yec.seagullLC.stagia.entity.TKembaiki;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@SuppressWarnings("serial")
public class TKembaikiDto extends TKembaiki implements Serializable {

	private String buttonName;
	private Integer tanka;
}
