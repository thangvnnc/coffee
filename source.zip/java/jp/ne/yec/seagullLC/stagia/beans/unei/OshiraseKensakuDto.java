package jp.ne.yec.seagullLC.stagia.beans.unei;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import jp.ne.yec.sane.beans.StringCodeNamePair;
import jp.ne.yec.seagullLC.stagia.beans.enums.domain.HyojisakiShurui;
import lombok.Getter;
import lombok.Setter;

/**
 * お知らせ設定の表示情報を保持するDTOです
 *
 * @author sic-higuchi
 *
 */
@Setter
@Getter
@SuppressWarnings("serial")
public class OshiraseKensakuDto implements Serializable {

	/**
	 * 全管理名リスト</BR>
	 * プルダウン表示用リスト
	 *
	 */
	private List<StringCodeNamePair> allKanriList;

	/**
	 * 全申請グループリスト</BR>
	 * プルダウン表示用リスト
	 */
	private List<StringCodeNamePair> allShinseiGroupList;

	/**
	 * 選択表示先</BR>
	 * 画面選択項目取得用
	 */
	private HyojisakiShurui hyojisaki;

	/**
	 * 選択管理名リスト</BR>
	 * 画面選択項目取得用
	 */
	private List<StringCodeNamePair> selectedKanriList = new ArrayList<>();

	/**
	 * 選択申請グループリスト</BR>
	 * 画面選択項目取得用
	 */
	private List<StringCodeNamePair> selectedShinseiGroupList = new ArrayList<>();

	/**
	 * ログインID</BR>
	 * 画面選択項目取得用
	 */
	private String loginId;

	/**
	 * 表示開始年月日</BR>
	 * 画面選択項目取得用
	 */
	private String fromDateTxt;

	/**
	 * 表示終了年月日</BR>
	 * 画面選択項目取得用
	 */
	private String toDateTxt;

}
