package jp.ne.yec.seagullLC.stagia.beans.enums;

/**
 * 台帳に表示するマークを保持する列挙型です。
 *
 * @author nao-hirata
 *
 */
public enum DaichoMark {
	AKI("○"),
	MOUSIKOMI_ARI("△"),
	AKI_NASHI("×"),
	UKETSUKE_KIKAN_GAI("―"),
	SELECTED("選択"),
;
	String mark;

	private DaichoMark(String mark) {
		this.mark = mark;
	}

	public String getMark() {
		return this.mark;
	}

}
