package jp.ne.yec.seagullLC.stagia.beans.riyosha;

import java.io.Serializable;

import org.apache.commons.lang.StringUtils;

import jp.ne.yec.sane.beans.StringCodeNamePair;
import jp.ne.yec.seagullLC.stagia.entity.TRyokinJidoSettei;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@SuppressWarnings("serial")
public class RyokinSetteiDto extends TRyokinJidoSettei implements Serializable {
	private String updateKbn = StringUtils.EMPTY;
	private String ryokinKeisanKomokuName;
	private String ryokinKeisanNaiyoName;
	private StringCodeNamePair ryokinKeisanKomokuCodeSelect;
	private StringCodeNamePair ryokinKeisanNaiyoCodeSelect;

}
