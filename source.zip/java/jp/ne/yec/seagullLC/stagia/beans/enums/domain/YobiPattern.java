package jp.ne.yec.seagullLC.stagia.beans.enums.domain;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import org.apache.commons.lang.StringUtils;

import jp.ne.yec.seagullLC.stagia.beans.enums.domain.base.StagiaEnum;

/**
 * Generated on Mon Feb 05 19:18:17 JST 2018 based on <br>
 * ドメイン定義票（曜日パターン）.xlsx.
 * <p>
 * 	M_施設料金やM_自動設備で使用する曜日のパターンを保持する列挙型です。<br>
 * </p>
 */
public enum YobiPattern implements StagiaEnum  {
	HEIJITSU("0", "平日"),
	DOYO("1", "土曜"),
	NICHIYO("2", "日曜"),
	SHUKUJITSU("3", "祝日"),
;
	private String code;
	private String name;

	private YobiPattern(String code, String name) {
		this.code = code;
		this.name = name;
	}

	public String getCode() {
		return this.code;
	}

	public String getName() {
		return this.name;
	}

	/**
	 * 引数のコードを保持する列挙子を返却します.
	 * 存在しない場合、{@code null}を返却します.
	 *
	 * @param code
	 * @return - codeを保持するYobiPattern
	 */
	public static YobiPattern getEnumClass(String code) {
		return Stream.of(values()).filter(e -> e.getCode().equals(code)).findFirst().orElse(null);
	}

	/**
	 * 引数のコードを保持する列挙子の名称を返却します.
	 * 存在しない場合、{@code StringUtils.EMPTY}を返却します.
	 *
	 * @param code
	 * @return - codeを保持するYobiPatternのname
	 */
	public static String getName(String code) {
		YobiPattern enumClass = getEnumClass(code);
		if (null == enumClass) {
			return StringUtils.EMPTY;
		}
		return enumClass.getName();
	}

	/**
	 * YobiPatternの列挙子全てをList型で返却します.
	 *
	 * @return - YobiPatternのList
	 */
	public static List<YobiPattern> getList() {
		return Arrays.asList(values());
	}
}
