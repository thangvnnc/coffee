package jp.ne.yec.seagullLC.stagia.beans.shinsei;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import jp.ne.yec.seagullLC.stagia.entity.MBasho;
import jp.ne.yec.seagullLC.stagia.entity.MKanri;
import jp.ne.yec.seagullLC.stagia.entity.TShinsei;
import lombok.Getter;
import lombok.Setter;

/**
 * @author nao-hirata
 *
 */
@Getter
@Setter
@SuppressWarnings("serial")
public class ShinseiDto extends TShinsei {
	private Map<Short, MKanri> mKanriMap = new HashMap<>();
	private List<ShinseiMeisaiDto> shinseiMeisaiDtos = new ArrayList<>();
	private Map<Short, List<ShukeiDataDto>> shukeiDataMap = new HashMap<>();
	private MBasho uketsukeBasho;
	private Date uketsukeDate = new Date();
}
