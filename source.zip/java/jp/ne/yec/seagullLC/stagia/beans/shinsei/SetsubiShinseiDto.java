package jp.ne.yec.seagullLC.stagia.beans.shinsei;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;

import jp.ne.yec.seagullLC.stagia.entity.TSetsubiShinsei;
import jp.ne.yec.seagullLC.stagia.util.TimeUtils;
import lombok.Getter;
import lombok.Setter;


/**
 * 設備の申請情報を保持するDTOクラスです.
 *
 * @author sic-hanaoka
 *
 */
@Getter
@Setter
@SuppressWarnings("serial")
public class SetsubiShinseiDto extends TSetsubiShinsei {

	/**
	 * 設備コマ情報リスト
	 */
	private List<SetsubiShinseiKomaDto> setsubiKomas = new ArrayList<>();

	/**
	 * 設備分類名称
	 */
	private String setsubiBunruiName;

	/**
	 * 設備名称
	 */
	private String setsubiName;

	/**
	 * 単位
	 */
	private String tani;

	/**
	 * 料金を手入力するかを判断
	 */
	private boolean isRyokinTenyuryoku;

	/**
	 * 抽選で利用可能かを判断
	 */
	private boolean isEnabledChusen;

	/**
	 * セット設備かを判断
	 */
	private boolean isSetSetsubi;

	/**
	 * 利用者機能で表示するか判断
	 */
	private boolean isDisplayedWeb;

	/**
	 * 画面表示用にフォーマットした使用時間(開始時間～終了時間)を返却します.</BR>
	 * 保持しているコマ情報リスト全体の開始時間～終了時間を返却します.</BR>
	 * ※一覧表示用に纏めてある場合はコマ情報リストは連続コマのみ.
	 *
	 * @return
	 */
	public String getDisplayShiyoTime() {
		if (CollectionUtils.isEmpty(getSetsubiKomas())) {
			return StringUtils.EMPTY;
		}

		return TimeUtils.toTimeRangeFormat(
				getSetsubiKomas().get(0).getStartTime(),
				getSetsubiKomas().get(getSetsubiKomas().size() - 1).getEndTime());
	}

	/**
	 * 画面表示用にフォーマットした使用数量を返却します.</BR>
	 * 一覧表示用に纏めた設備申請情報の場合に使用します(コマ情報リストの一つ目の数量を使用).</BR>
	 * ※一覧表示用に纏めてある場合はコマ情報リスト内の数量は全て同じ.
	 *
	 * @return
	 */
	public String getDisplayUseNum() {
		return String.valueOf(getSetsubiKomas().get(0).getSuryo()).concat(getTani());
	}

	/**
	 * 設備を一意としたキー値を返却します.
	 *
	 * @return setsubiBunruiCode * 10000 + setsubiCode()
	 */
	public int getSetsubiKey() {
		return getSetsubiBunruiCode() * 10000 + getSetsubiCode();
	}
}
