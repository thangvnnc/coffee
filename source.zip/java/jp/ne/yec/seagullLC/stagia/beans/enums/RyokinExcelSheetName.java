package jp.ne.yec.seagullLC.stagia.beans.enums;

import lombok.Getter;

/**
 * 料金計算で使用するExcelのシート名を保持する列挙型です.
 *
 * @author nao-hirata
 *
 */
public enum RyokinExcelSheetName {
	KOMA("コマ単位"),
	MEISAI("明細単位"),
;
	@Getter
	private String name;

	private RyokinExcelSheetName(String name) {
		this.name = name;
	}

}
