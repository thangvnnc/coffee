package jp.ne.yec.seagullLC.stagia.beans.unei;

import java.io.Serializable;
import java.time.LocalDate;

import lombok.Getter;
import lombok.Setter;

/**
 * 休館日設定のカレンダー表示用DTOです</BR>
 * ・休館日カレンダーのセル表示用
 *
 * @author sic-hanaoka
 *
 */
@Setter
@Getter
@SuppressWarnings("serial")
public class KyukanCalendarColDto implements Serializable {

	/**
	 * 休館カレンダー表示リストのrow index
	 */
	private int rowIdx;

	/**
	 * 休館カレンダー表示リストのcol index
	 */
	private int colIdx;

	/**
	 * 日付番号
	 */
	private int dayNum;

	/**
	 *  対象日付
	 */
	private LocalDate date;

	/**
	 * 対象月有無
	 */
	private boolean isOtherMonth = false;

	/**
	 * 予約有無
	 */
	private boolean isYoyakuUmu = false;

	/**
	 * 休館設定有無
	 */
	private boolean isKyukan = false;

}
