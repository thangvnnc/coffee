package jp.ne.yec.seagullLC.stagia.beans.enums;

import java.time.DayOfWeek;
import java.time.format.TextStyle;
import java.util.Locale;

/**
 * 曜日を保持する列挙型.
 *
 * 月～日までは{@link java.time.DayOfWeek}と同様の定義。祝日を数値{@code 8}で追加。
 *
 * @author nao-hirata
 *
 */
public enum StagiaDayOfWeek {

	MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY, HOLIDAY;

	public int getValue() {
		return ordinal() + 1;
	}

	public String getName(){
		if (8 == this.getValue()) {
			return "祝";
		}
		return DayOfWeek.of(this.getValue()).getDisplayName(TextStyle.SHORT, Locale.JAPAN);
	}

	public String getFullName(){
		if (8 == this.getValue()) {
			return "祝日";
		}
		return DayOfWeek.of(this.getValue()).getDisplayName(TextStyle.FULL, Locale.JAPAN);
	}
}
