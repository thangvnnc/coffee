package jp.ne.yec.seagullLC.stagia.beans.criteria;

import java.io.Serializable;

import jp.ne.yec.seagullLC.stagia.beans.enums.JokenHukumu;
import jp.ne.yec.seagullLC.stagia.beans.enums.domain.ShinseiShurui;
import jp.ne.yec.seagullLC.stagia.entity.MKanri;
import lombok.Getter;
import lombok.Setter;

/**
 * 見積履歴検索画面で使用する検索条件格納用Dto
 *
 * @author nao-hirata
 *
 */
@Setter
@Getter
@SuppressWarnings("serial")
public class MitsumoriSearchDto implements Serializable {

	private final ShinseiShurui shinseiShurui = ShinseiShurui.MITSUMORI;

	private MKanri mKanri;
	private Integer shinseiNumber;
	private String loginId;
	private JokenHukumu joken = JokenHukumu.HUKUMU;
	private String shinseishaKanaName;
	private String shinseishaName;
}
