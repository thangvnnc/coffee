package jp.ne.yec.seagullLC.stagia.beans.unei;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.List;

import lombok.Getter;
import lombok.Setter;

/**
 * 休館日設定のカレンダー表示用DTOです</BR>

 *
 * @author sic-hanaoka
 *
 */
@Setter
@Getter
@SuppressWarnings("serial")
public class KyukanCalendarDto implements Serializable {

	/**
	 * 登録済み休館日リスト
	 */
	private List<LocalDate> kyukanbiOrgList;

	/**
	 * 休館日セルリスト(1week)
	 */
	private List<KyukanCalendarRowDto> kyukanCalendarList;

}
