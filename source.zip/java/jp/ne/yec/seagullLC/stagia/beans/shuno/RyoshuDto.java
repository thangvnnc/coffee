package jp.ne.yec.seagullLC.stagia.beans.shuno;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.apache.commons.lang.StringUtils;

import jp.ne.yec.seagullLC.stagia.beans.enums.domain.RyoshuHoho;
import jp.ne.yec.seagullLC.stagia.beans.enums.domain.RyoshuJotai;
import jp.ne.yec.seagullLC.stagia.common.Constants;
import jp.ne.yec.seagullLC.stagia.entity.TRyoshu;
import jp.ne.yec.seagullLC.stagia.entity.TRyoshuMeisai;
import lombok.Getter;
import lombok.Setter;

/**
 * @author nao-hirata
 *
 */
@Getter
@Setter
@SuppressWarnings("serial")
public class RyoshuDto extends TRyoshu {

	RyoshuHoho ryoshuHohoEnum;
	List<TRyoshuMeisai> tRyoshuMeisais = new ArrayList<>();

	public void setRyoshuHohoEnum(RyoshuHoho ryoshuHohoEnum) {
		this.ryoshuHohoEnum = ryoshuHohoEnum;
		if (Objects.nonNull(ryoshuHohoEnum)) {
			setRyoshuHoho(ryoshuHohoEnum.getCode());
			return;
		}
		setRyoshuHoho(null);
	}

	public String getDisplayRyoshuNumber() {
		if (Objects.isNull(getRyoshuNumber())) {
			return StringUtils.EMPTY;
		}
		return StringUtils.leftPad(String.valueOf(getKanriCode()), 2, "0")
				+ Constants.HYPHEN
				+ String.valueOf(getRyoshuNumber());
	}

	public String getStatus() {
		return RyoshuJotai.getName(getRyoshuJotai());
	}

	public String getRyoshuGakuCurrencyFormat() {
		int ryokin = null == getRyoshuGaku() ? 0 : getRyoshuGaku();
		return NumberFormat.getCurrencyInstance().format(ryokin);
	}
}
