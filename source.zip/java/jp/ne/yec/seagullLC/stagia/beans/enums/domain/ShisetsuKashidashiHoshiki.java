package jp.ne.yec.seagullLC.stagia.beans.enums.domain;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import org.apache.commons.lang.StringUtils;

import jp.ne.yec.seagullLC.stagia.beans.enums.domain.base.StagiaEnum;

/**
 * Generated on Mon Feb 05 19:18:17 JST 2018 based on <br>
 * ドメイン定義票（施設貸出方式）.xlsx.
 * <p>
 * 	利用者機能で施設の貸し方を保持する列挙型です。<br>
 * 	貸出単位指定：複数面の貸出単位がある施設の申請を行う場合でも１つの貸出単位を指定して申請を行う方式です。<br>
 * 	面数指定    ：複数面の貸出単位がある施設の申請を行う場合、面数を指定して申請を行う方式です。<br>
 * </p>
 */
public enum ShisetsuKashidashiHoshiki implements StagiaEnum  {
	KASHIDASHITANI_SHITEI("0", "貸出単位指定"),
	MENSU_SHITEI("1", "面数指定"),
;
	private String code;
	private String name;

	private ShisetsuKashidashiHoshiki(String code, String name) {
		this.code = code;
		this.name = name;
	}

	public String getCode() {
		return this.code;
	}

	public String getName() {
		return this.name;
	}

	/**
	 * 引数のコードを保持する列挙子を返却します.
	 * 存在しない場合、{@code null}を返却します.
	 *
	 * @param code
	 * @return - codeを保持するShisetsuKashidashiHoshiki
	 */
	public static ShisetsuKashidashiHoshiki getEnumClass(String code) {
		return Stream.of(values()).filter(e -> e.getCode().equals(code)).findFirst().orElse(null);
	}

	/**
	 * 引数のコードを保持する列挙子の名称を返却します.
	 * 存在しない場合、{@code StringUtils.EMPTY}を返却します.
	 *
	 * @param code
	 * @return - codeを保持するShisetsuKashidashiHoshikiのname
	 */
	public static String getName(String code) {
		ShisetsuKashidashiHoshiki enumClass = getEnumClass(code);
		if (null == enumClass) {
			return StringUtils.EMPTY;
		}
		return enumClass.getName();
	}

	/**
	 * ShisetsuKashidashiHoshikiの列挙子全てをList型で返却します.
	 *
	 * @return - ShisetsuKashidashiHoshikiのList
	 */
	public static List<ShisetsuKashidashiHoshiki> getList() {
		return Arrays.asList(values());
	}
}
