package jp.ne.yec.seagullLC.stagia.beans.master;

import jp.ne.yec.sane.beans.StringCodeNamePair;
import jp.ne.yec.seagullLC.stagia.entity.MJorei;
import lombok.Getter;
import lombok.Setter;

/**
 * 「m_jorei」の情報を保持するDTOクラスです.
 *
 * @author sic-yu
 *
 */
@Getter
@Setter
@SuppressWarnings("serial")
public class MJoreiDto extends MJorei {
	/**
	 * 選択管理
	 */
	private StringCodeNamePair selectedKanriCode;

}
