package jp.ne.yec.seagullLC.stagia.beans.enums.domain;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import org.apache.commons.lang.StringUtils;
import jp.ne.yec.seagullLC.stagia.beans.enums.domain.base.StagiaEnum;

/**
 * Generated on Wed Jun 27 09:30:41 JST 2018 based on <br>
 * ドメイン定義票（バッチ実行状態）.xlsx.
 * <p>
 * 	バッチの種類を保持する列挙型です。<br>
 * </p>
 */
public enum BatchStatus implements StagiaEnum  {
	RUNNING("0", "実行中"),
	SUCCESS("1", "正常終了"),
	ABORT("2", "異常終了"),
	STOP("3", "実行中止"),
;
	private String code;
	private String name;

	private BatchStatus(String code, String name) {
		this.code = code;
		this.name = name;
	}

	public String getCode() {
		return this.code;
	}

	public String getName() {
		return this.name;
	}

	/**
	 * 引数のコードを保持する列挙子を返却します.
	 * 存在しない場合、{@code null}を返却します.
	 *
	 * @param code
	 * @return - codeを保持するBatchStatus
	 */
	public static BatchStatus getEnumClass(String code) {
		return Stream.of(values()).filter(e -> e.getCode().equals(code)).findFirst().orElse(null);
	}

	/**
	 * 引数のコードを保持する列挙子の名称を返却します.
	 * 存在しない場合、{@code StringUtils.EMPTY}を返却します.
	 *
	 * @param code
	 * @return - codeを保持するBatchStatusのname
	 */
	public static String getName(String code) {
		BatchStatus enumClass = getEnumClass(code);
		if (null == enumClass) {
			return StringUtils.EMPTY;
		}
		return enumClass.getName();
	}

	/**
	 * BatchStatusの列挙子全てをList型で返却します.
	 *
	 * @return - BatchStatusのList
	 */
	public static List<BatchStatus> getList() {
		return Arrays.asList(values());
	}
}
