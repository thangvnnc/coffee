package jp.ne.yec.seagullLC.stagia.beans.enums;

import java.util.Arrays;
import java.util.List;

import jp.ne.yec.seagullLC.stagia.beans.enums.domain.base.StagiaEnum;
import lombok.Getter;

/**
 * 台帳表示期間を保持する列挙型です.
 *
 * @author nao-hirata
 *
 */
public enum DaichoHyojiKikan implements StagiaEnum {
	DAY("1", "1日"),
	WEEK("7", "1週間"),
	MONTH("31", "1ヵ月"),
;
	@Getter
	private String code;
	@Getter
	private String name;

	private DaichoHyojiKikan(String code, String name) {
		this.code = code;
		this.name = name;
	}

	/**
	 * 列挙子を返却します.
	 *
	 * @return - {@code List<DaichoHyojiKikan>}
	 */
	public static List<DaichoHyojiKikan> getList() {
		return Arrays.asList(values());
	}

}
