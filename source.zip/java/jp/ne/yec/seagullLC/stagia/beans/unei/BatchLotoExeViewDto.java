package jp.ne.yec.seagullLC.stagia.beans.unei;

import java.io.Serializable;

import org.apache.commons.lang.StringUtils;

import lombok.Getter;
import lombok.Setter;

/**
 * バッチ起動の一覧表示用のDTO</BR>
 * ・一行分の情報を保持します.</BR>
 * 抽選実行で使用します.
 *
 * @author sic-hanaoka
 *
 */
@Setter
@Getter
@SuppressWarnings("serial")
public class BatchLotoExeViewDto implements Serializable {

	/**
	 * 処理対象有無
	 */
	private boolean isTarget = false;

	/**
	 * 抽選グループコード
	 */
	private Short chusenGroupCode = 0;

	/**
	 * 抽選グループ名
	 */
	private String chusenGroupName = StringUtils.EMPTY;

	/**
	 * 抽選対象期間
	 */
	private String chusenTaishoKikan = StringUtils.EMPTY;

	/**
	 * 抽選申込期間
	 */
	private String chusenMoshikomiKikan = StringUtils.EMPTY;

	/**
	 * 抽選期間
	 */
	private String chusenKikan = StringUtils.EMPTY;

	/**
	 * 抽選日
	 */
	private String chusenDate = StringUtils.EMPTY;

	/**
	 * 当選申請期間
	 */
	private String tosenShinseiKikan = StringUtils.EMPTY;

}
