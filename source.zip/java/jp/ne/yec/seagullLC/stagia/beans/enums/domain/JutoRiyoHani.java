package jp.ne.yec.seagullLC.stagia.beans.enums.domain;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import org.apache.commons.lang.StringUtils;

import jp.ne.yec.seagullLC.stagia.beans.enums.domain.base.StagiaEnum;

/**
 * Generated on Mon Feb 05 19:18:16 JST 2018 based on <br>
 * ドメイン定義票（充当利用範囲）.xlsx.
 * <p>
 * 	充当利用可能な範囲を保持する列挙型です。<br>
 * </p>
 */
public enum JutoRiyoHani implements StagiaEnum  {
	NONE("0", "利用しない"),
	SHINSEI("1", "申請単位"),
	RIYOSHA("2", "利用者単位"),
;
	private String code;
	private String name;

	private JutoRiyoHani(String code, String name) {
		this.code = code;
		this.name = name;
	}

	public String getCode() {
		return this.code;
	}

	public String getName() {
		return this.name;
	}

	/**
	 * 引数のコードを保持する列挙子を返却します.
	 * 存在しない場合、{@code null}を返却します.
	 *
	 * @param code
	 * @return - codeを保持するJutoRiyoHani
	 */
	public static JutoRiyoHani getEnumClass(String code) {
		return Stream.of(values()).filter(e -> e.getCode().equals(code)).findFirst().orElse(null);
	}

	/**
	 * 引数のコードを保持する列挙子の名称を返却します.
	 * 存在しない場合、{@code StringUtils.EMPTY}を返却します.
	 *
	 * @param code
	 * @return - codeを保持するJutoRiyoHaniのname
	 */
	public static String getName(String code) {
		JutoRiyoHani enumClass = getEnumClass(code);
		if (null == enumClass) {
			return StringUtils.EMPTY;
		}
		return enumClass.getName();
	}

	/**
	 * JutoRiyoHaniの列挙子全てをList型で返却します.
	 *
	 * @return - JutoRiyoHaniのList
	 */
	public static List<JutoRiyoHani> getList() {
		return Arrays.asList(values());
	}
}
