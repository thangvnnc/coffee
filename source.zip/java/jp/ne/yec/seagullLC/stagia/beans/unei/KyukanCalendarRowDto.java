package jp.ne.yec.seagullLC.stagia.beans.unei;

import java.io.Serializable;
import java.util.List;

import lombok.Getter;
import lombok.Setter;

/**
 * 休館日設定のカレンダー表示用DTOです</BR>
 * ・一週間分の行情報を保持
 *
 * @author sic-hanaoka
 *
 */
@Setter
@Getter
@SuppressWarnings("serial")
public class KyukanCalendarRowDto implements Serializable {

	/**
	 * 休館日セルリスト(1week)
	 */
	private List<KyukanCalendarColDto> kyukanCalList;

}
