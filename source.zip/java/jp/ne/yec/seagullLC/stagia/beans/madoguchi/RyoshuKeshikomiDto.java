package jp.ne.yec.seagullLC.stagia.beans.madoguchi;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import jp.ne.yec.seagullLC.stagia.beans.enums.domain.RyoshuHoho;
import jp.ne.yec.seagullLC.stagia.beans.enums.domain.base.StagiaEnum;
import jp.ne.yec.seagullLC.stagia.beans.madoguchi.base.IKeshikomiDto;
import jp.ne.yec.seagullLC.stagia.entity.TRyokin;
import jp.ne.yec.seagullLC.stagia.entity.TRyoshu;
import jp.ne.yec.seagullLC.stagia.entity.TRyoshuMeisai;
import lombok.Getter;
import lombok.Setter;

/**
 * @author nao-hirata
 *
 */
@Setter
@Getter
@SuppressWarnings("serial")
public class RyoshuKeshikomiDto extends TRyoshu implements IKeshikomiDto {

	// 領収精算で使用するプロパティ
	private Integer id;
	private Integer shinseiNumber;
	private Short meisaiNumber;
	private Short bashoCode;
	private Short shisetsuCode;
	private Short kashidashiTaniCode;
	private Date shiyoDate;
	private Short startTime;
	private Short endTime;
	private String shinseishaName;
	private String ryokinKubun;

	private Short meisaiKoshinKaisu;
	private String loginId;
	private Short henkoShinseiKaisu;

	private List<ShinseiMeisaiDtoForMadoguchi> meisaiDtos = new ArrayList<>();
	private List<TRyoshuMeisai> tRyoshuMeisais = new ArrayList<>();
	private List<TRyokin> tRyokins = new ArrayList<>();

	// 領収精算で設定するプロパティ
	private boolean isUpdating = false;
	private RyoshuHoho updateRyoshuHoho;
	private Date updateYoteiDate;
	private Date updateSeisanDate;
	private Date updateChoteiDate;
	private Date updateUketsukeDate;
	private Short updateUketsukeBashoCode;

	// 名寄せで使用するプロパティ
	private boolean isSummary = false;
	private boolean isDeleting = false;
	private List<RyoshuKeshikomiDto> summarizedDtos = new ArrayList<>();

	@Override
	public Integer getSeisanNumber() {
		return getRyoshuNumber();
	}

	@Override
	public Date getSeisanDate() {
		return getRyoshuDate();
	}

	@Override
	public Integer getSeisanGaku() {
		return getRyoshuGaku();
	}

	@Override
	public void setUpdateSeisanDate(Date updateSeisanDate) {
		this.updateSeisanDate = updateSeisanDate;
	}

	@Override
	public void setUpdateSeisanHoho(StagiaEnum seisanHoho) {
		this.updateRyoshuHoho = (RyoshuHoho) seisanHoho;
	}

	@Override
	public Date getUpdateSeisanDate() {
		return updateSeisanDate;
	}

	@Override
	public String getSeisanHohoName() {
		return RyoshuHoho.getName(getRyoshuHoho());
	}

	@Override
	public StagiaEnum getUpdateSeisanHoho() {
		return updateRyoshuHoho;
	}
}
