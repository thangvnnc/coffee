package jp.ne.yec.seagullLC.stagia.beans.enums.domain;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import org.apache.commons.lang.StringUtils;

import jp.ne.yec.seagullLC.stagia.beans.enums.domain.base.StagiaEnum;

/**
 * Generated on Mon Feb 05 19:18:16 JST 2018 based on <br>
 * ドメイン定義票（予約種類）.xlsx.
 * <p>
 * 	予約の種類を保持する列挙型です。<br>
 * </p>
 */
public enum YoyakuShurui implements StagiaEnum  {
	KARIYOYAKU("0", "仮予約"),
	HONYOYAKU("1", "本予約"),
;
	private String code;
	private String name;

	private YoyakuShurui(String code, String name) {
		this.code = code;
		this.name = name;
	}

	public String getCode() {
		return this.code;
	}

	public String getName() {
		return this.name;
	}

	/**
	 * 引数のコードを保持する列挙子を返却します.
	 * 存在しない場合、{@code null}を返却します.
	 *
	 * @param code
	 * @return - codeを保持するYoyakuShurui
	 */
	public static YoyakuShurui getEnumClass(String code) {
		return Stream.of(values()).filter(e -> e.getCode().equals(code)).findFirst().orElse(null);
	}

	/**
	 * 引数のコードを保持する列挙子の名称を返却します.
	 * 存在しない場合、{@code StringUtils.EMPTY}を返却します.
	 *
	 * @param code
	 * @return - codeを保持するYoyakuShuruiのname
	 */
	public static String getName(String code) {
		YoyakuShurui enumClass = getEnumClass(code);
		if (null == enumClass) {
			return StringUtils.EMPTY;
		}
		return enumClass.getName();
	}

	/**
	 * YoyakuShuruiの列挙子全てをList型で返却します.
	 *
	 * @return - YoyakuShuruiのList
	 */
	public static List<YoyakuShurui> getList() {
		return Arrays.asList(values());
	}
}
