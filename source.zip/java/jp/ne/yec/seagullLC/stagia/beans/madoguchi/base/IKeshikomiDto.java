package jp.ne.yec.seagullLC.stagia.beans.madoguchi.base;

import java.text.NumberFormat;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.apache.commons.lang.StringUtils;

import jp.ne.yec.seagullLC.stagia.beans.enums.domain.base.StagiaEnum;
import jp.ne.yec.seagullLC.stagia.beans.madoguchi.ShinseiMeisaiDtoForMadoguchi;
import jp.ne.yec.seagullLC.stagia.common.Constants;
import jp.ne.yec.seagullLC.stagia.util.CalendarUtils;

/**
 * 領収／還付消込を透過的に行うinterfaceです.
 *
 * @author nao-hirata
 *
 */
public interface IKeshikomiDto extends Comparable<IKeshikomiDto> {

	public Integer getId();
	public Short getKanriCode();
	public Integer getShinseiNumber();
	public Short getMeisaiNumber();
	public Short getBashoCode();
	public Short getShisetsuCode();
	public Short getKashidashiTaniCode();
	public Date getShiyoDate();
	public Short getStartTime();
	public Short getEndTime();
	public String getShinseishaName();
	public String getRyokinKubun();
	public Integer getSeisanNumber();
	public List<ShinseiMeisaiDtoForMadoguchi> getMeisaiDtos();
	public boolean isUpdating();
	public boolean isDeleting();
	public Date getYoteiDate();
	public Date getSeisanDate();
	public Date getChoteiDate();
	public Integer getSeisanGaku();
	public String getSeisanHohoName();
	public void setUpdating(boolean isUpdating);
	public Date getUpdateYoteiDate();
	public void setUpdateYoteiDate(Date yoteiDate);
	public Date getUpdateSeisanDate();
	public void setUpdateSeisanDate(Date seisanDate);
	public void setUpdateChoteiDate(Date choteiDate);
	public void setUpdateUketsukeDate(Date uketsukeDate);
	public void setUpdateUketsukeBashoCode(Short bashoCode);
	public StagiaEnum getUpdateSeisanHoho();
	public void setUpdateSeisanHoho(StagiaEnum seisanHoho);
	public boolean isSummary();
	public String getLoginId();

	/**
	 * 0埋め二桁の管理コードと領収/還付番号を-で連結した文字列を返却します.
	 * 名寄せを行った場合や未精算データの場合は{@code Constants.HYPHEN}を返却します.
	 *
	 * @return
	 */
	public default String getDisplaySeisanNumber() {
		if (Objects.isNull(getSeisanNumber())) {
			return Constants.HYPHEN;
		}
		return StringUtils.leftPad(String.valueOf(getKanriCode()), 2, "0") + Constants.HYPHEN
				+ String.valueOf(getSeisanNumber());
	}

	/**
	 * 画面に表示する領収状態を返却します.
	 *
	 * @return
	 */
	public default String getDisplaySeisanJotai() {
		Date date = isUpdating() ? getUpdateSeisanDate() : getSeisanDate();
		return Objects.nonNull(date) ? "済み" : "予定";
	}

	/**
	 * 画面に表示する精算方法を返却します.
	 *
	 * @return
	 */
	public default String getDisplaySeisanHoho() {
		if (isUpdating()) {
			return getUpdateSeisanHoho().getName();
		}
		return getSeisanHohoName();
	}

	/**
	 * 画面に表示する予定日を返却します.
	 *
	 * @return
	 */
	public default String getDisplayYoteiDate() {
		if (isUpdating()) {
			return CalendarUtils.toFormatyyyyMdSeparatedBySlashes(getUpdateYoteiDate());
		}
		return CalendarUtils.toFormatyyyyMdSeparatedBySlashes(getYoteiDate());
	}

	/**
	 * 画面に表示する精算金額を返却します.
	 *
	 * @return
	 */
	public default String getDisplayKingaku() {
		return NumberFormat.getCurrencyInstance().format(getSeisanGaku());
	}

	@Override
	public default int compareTo(IKeshikomiDto o) {
		int updateing = Boolean.compare(o.isUpdating(), isUpdating());
		if (0 != updateing) {
			return updateing;
		}
		int loginId = getLoginId().compareTo(o.getLoginId());
		if (0 != loginId) {
			return loginId;
		}
		Date seisanDate1 = Optional.ofNullable(getSeisanDate()).orElse(new Date(0));
		Date seisanDate2 = Optional.ofNullable(o.getSeisanDate()).orElse(new Date(0));

		if (seisanDate1.before(seisanDate2)) {
			return -1;
		}
		if (seisanDate1.after(seisanDate2)) {
			return 1;
		}
		short kanri1 = Optional.ofNullable(getKanriCode()).orElse((short)0);
		short kanri2 = Optional.ofNullable(o.getKanriCode()).orElse((short)0);
		if (kanri1 < kanri2) {
			return -1;
		}
		if (kanri1 > kanri2) {
			return 1;
		}
		Date yoteiDate1 = Optional.ofNullable(getYoteiDate()).orElse(new Date(0));
		Date yoteiDate2 = Optional.ofNullable(o.getYoteiDate()).orElse(new Date(0));
		if (yoteiDate1.before(yoteiDate2)) {
			return -1;
		}
		if (yoteiDate1.after(yoteiDate2)) {
			return 1;
		}
		Integer number1 = Optional.ofNullable(getSeisanNumber()).orElse(0);
		Integer number2 = Optional.ofNullable(o.getSeisanNumber()).orElse(0);
		if (number1 > number2) {
			return 1;
		}
		if (number1 < number2) {
			return -1;
		}
		return 0;
	}
}
