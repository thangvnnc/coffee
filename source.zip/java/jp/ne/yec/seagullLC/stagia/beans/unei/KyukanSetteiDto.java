package jp.ne.yec.seagullLC.stagia.beans.unei;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import jp.ne.yec.sane.beans.StringCodeNamePair;
import jp.ne.yec.seagullLC.stagia.beans.enums.domain.HeisaShurui;
import lombok.Getter;
import lombok.Setter;

/**
 * 休館設定画面・基本設定画面の表示情報を保持するDTOです
 *
 * @author sic-hanaoka
 *
 */
@Setter
@Getter
@SuppressWarnings("serial")
public class KyukanSetteiDto  implements Serializable {

	/**
	 * 全管理リスト
	 */
	private List<StringCodeNamePair> allKanriList;

	/**
	 * 全場所リスト
	 */
	private List<StringCodeNamePair> allBashoList;

	/**
	 * 全施設リスト
	 */
	private List<StringCodeNamePair> allShisetsuList = new ArrayList<StringCodeNamePair>();

	/**
	 * 全貸出単位リスト
	 */
	private List<StringCodeNamePair> allKashidashiTaniList = new ArrayList<StringCodeNamePair>();

	/**
	 * 休館指定年月
	 */
	private String selectedYM;

	/**
	 * 休館指定開始年月日
	 */
	private String kyukanFromDateTxt;

	/**
	 * 休館指定終了年月日
	 */
	private String kyukanToDateTxt;

	/**
	 * 基本設定画面で変更されたドロップダウンの区分
	 *
	 */
	private int changeDDKubun = 0;

	/**
	 * 選択管理
	 */
	private StringCodeNamePair selectedKanri;

	/**
	 * 選択場所
	 */
	private StringCodeNamePair selectedBasho;

	/**
	 * 選択施設
	 */
	private StringCodeNamePair selectedShisetsu;

	/**
	 * 選択貸出単位
	 */
	private StringCodeNamePair selectedKashidashiTani;

	/**
	 * 選択閉鎖種類
	 */
	private HeisaShurui selectedHeisaShurui;

	/**
	 * 休館指定開始時間
	 */
	private String kyukanFromTime;

	/**
	 * 休館指定終了時間
	 */
	private String kyukanToTime;

	/**
	 * 毎週/週指定
	 */
	private StringCodeNamePair selectedWeekKbn;

	/**
	 * 毎週/週指定(週指定)
	 */
	private List<StringCodeNamePair> selectedWeek = new ArrayList<>();

	/**
	 * 曜日
	 */
	private List<StringCodeNamePair> selectedDayOfWeek = new ArrayList<>();

	/**
	 * 日付指定1
	 */
	private String setDay1 = StringUtils.EMPTY;

	/**
	 * 日付指定2
	 */
	private String setDay2 = StringUtils.EMPTY;

	/**
	 * 日付指定3
	 */
	private String setDay3 = StringUtils.EMPTY;

	/**
	 * 日付指定4
	 */
	private String setDay4 = StringUtils.EMPTY;

	/**
	 * 日付指定5
	 */
	private String setDay5 = StringUtils.EMPTY;

	/**
	 * 日付指定6
	 */
	private String setDay6 = StringUtils.EMPTY;

	/**
	 * メモ
	 */
	private String memo = StringUtils.EMPTY;

	/**
	 * 複数選択閉鎖種類(確認画面で使用)
	 */
	private List<HeisaShurui> heisaShuruis;
}
