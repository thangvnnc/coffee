package jp.ne.yec.seagullLC.stagia.beans.enums.domain;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import org.apache.commons.lang.StringUtils;

import jp.ne.yec.seagullLC.stagia.beans.enums.domain.base.StagiaEnum;

/**
 * Generated on Tue Feb 13 10:21:07 JST 2018 based on <br>
 * ドメイン定義票（計算単位）.xlsx.
 * <p>
 * 	加算／減免／割引／リハーサルを適用する単位を保持する列挙型です。<br>
 * 	コマ  ：設定したコマに対して各種計算内容が適用され、料金計算されます。<br>
 * 	明細  ：明細に対して各種計算内容が適用され、料金計算されます。<br>
 * </p>
 */
public enum KeisanTani implements StagiaEnum  {
	KOMA("0", "コマ"),
	MEISAI("1", "明細"),
;
	private String code;
	private String name;

	private KeisanTani(String code, String name) {
		this.code = code;
		this.name = name;
	}

	public String getCode() {
		return this.code;
	}

	public String getName() {
		return this.name;
	}

	/**
	 * 引数のコードを保持する列挙子を返却します.
	 * 存在しない場合、{@code null}を返却します.
	 *
	 * @param code
	 * @return - codeを保持するKeisanTani
	 */
	public static KeisanTani getEnumClass(String code) {
		return Stream.of(values()).filter(e -> e.getCode().equals(code)).findFirst().orElse(null);
	}

	/**
	 * 引数のコードを保持する列挙子の名称を返却します.
	 * 存在しない場合、{@code StringUtils.EMPTY}を返却します.
	 *
	 * @param code
	 * @return - codeを保持するKeisanTaniのname
	 */
	public static String getName(String code) {
		KeisanTani enumClass = getEnumClass(code);
		if (null == enumClass) {
			return StringUtils.EMPTY;
		}
		return enumClass.getName();
	}

	/**
	 * KeisanTaniの列挙子全てをList型で返却します.
	 *
	 * @return - KeisanTaniのList
	 */
	public static List<KeisanTani> getList() {
		return Arrays.asList(values());
	}
}
