package jp.ne.yec.seagullLC.stagia.beans.madoguchi;

import java.io.Serializable;

import jp.ne.yec.seagullLC.stagia.entity.MKembaiki;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@SuppressWarnings("serial")
public class MKembaikiDto extends MKembaiki implements Serializable {

	private String bashoName;
}
