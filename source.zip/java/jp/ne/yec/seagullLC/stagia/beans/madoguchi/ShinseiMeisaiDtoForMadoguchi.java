/**
 *
 */
package jp.ne.yec.seagullLC.stagia.beans.madoguchi;

import org.apache.commons.lang.StringUtils;

import jp.ne.yec.seagullLC.stagia.beans.enums.domain.RyokinKubun;
import jp.ne.yec.seagullLC.stagia.beans.shinsei.ShinseiMeisaiDto;
import jp.ne.yec.seagullLC.stagia.common.Constants;
import lombok.Getter;
import lombok.Setter;

/**
 * @author min-amemiya
 *
 */

@Getter
@Setter
@SuppressWarnings("serial")
public class ShinseiMeisaiDtoForMadoguchi extends ShinseiMeisaiDto {

	private String koshinUmu;
	private String kanriName;
	private String shisetsuName;

	// sane基盤のユーザ名
	private String userName;
	//T_申請の申請者名
	private String shinseishaName;

	private String shinsaKubunName;
	private String shinsaRiyuName;
	private String shiyoJissekiUmu;


	private RyokinKubun ryokinKubun;

	@Override
	public String getBashoShisetsuName() {
		if (StringUtils.isEmpty(getBashoName())) {
			return StringUtils.EMPTY;
		}
		return getBashoName() + Constants.SPACE + getShisetsuName();
	}

}
