package jp.ne.yec.seagullLC.stagia.beans.riyosha;

import java.io.Serializable;

import jp.ne.yec.seagullLC.stagia.entity.MNijutoroku;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@SuppressWarnings("serial")
public class OverLapCheckInfoDto extends MNijutoroku implements Serializable {

	// M_システムの二重登録範囲
	private String nijutorokuHanteiHani;

}
