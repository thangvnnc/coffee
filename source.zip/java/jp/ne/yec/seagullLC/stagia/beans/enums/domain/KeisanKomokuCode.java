package jp.ne.yec.seagullLC.stagia.beans.enums.domain;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import org.apache.commons.lang.StringUtils;


/**
 * Generated on Thu Mar 08 18:40:54 JST 2018 based on <br>
 * ドメイン定義票（計算項目コード）.xlsx.
 * <p>
 * 	料金計算項目を保持する列挙型です。<br>
 * 	1～9まではM_料金計算項目.料金計算項目コードが対応します。20～24はT_料金の各カラムと対応しています。<br>
 * 	カスタマイズで料金名称を増やす場合、単一項目については16～19を使用してください。<br>
 * 	合計金額を増やす場合は25以降を使用してください。<br>
 * </p>
 */
public enum KeisanKomokuCode  {
	KURIAGE(new Integer(10).shortValue(), "繰上"),
	ENCHO(new Integer(11).shortValue(), "延長"),
	REIDAMBO(new Integer(12).shortValue(), "冷暖房"),
	NYUJORYOKIN(new Integer(13).shortValue(), "入場料金"),
	REHEARSAL(new Integer(14).shortValue(), "リハーサル"),
	TAX(new Integer(15).shortValue(), "消費税"),
	KASAN_TOTAL(new Integer(20).shortValue(), "加算額合計"),
	GEMMEN_TOTAL(new Integer(21).shortValue(), "減免額合計"),
	WARIBIKI_TOTAL(new Integer(22).shortValue(), "割引額合計"),
	HASU_KINGAKU(new Integer(23).shortValue(), "端数金額"),
	RYOKIN_TOTAL(new Integer(24).shortValue(), "使用料金合計"),
;
	private Short code;
	private String name;

	private KeisanKomokuCode(Short code, String name) {
		this.code = code;
		this.name = name;
	}

	public Short getCode() {
		return this.code;
	}

	public String getName() {
		return this.name;
	}

	/**
	 * 引数のコードを保持する列挙子を返却します.
	 * 存在しない場合、{@code null}を返却します.
	 *
	 * @param code
	 * @return - codeを保持するKeisanKomokuCode
	 */
	public static KeisanKomokuCode getEnumClass(Short code) {
		return Stream.of(values()).filter(e -> e.getCode().equals(code)).findFirst().orElse(null);
	}

	/**
	 * 引数のコードを保持する列挙子の名称を返却します.
	 * 存在しない場合、{@code StringUtils.EMPTY}を返却します.
	 *
	 * @param code
	 * @return - codeを保持するKeisanKomokuCodeのname
	 */
	public static String getName(Short code) {
		KeisanKomokuCode enumClass = getEnumClass(code);
		if (null == enumClass) {
			return StringUtils.EMPTY;
		}
		return enumClass.getName();
	}

	/**
	 * KeisanKomokuCodeの列挙子全てをList型で返却します.
	 *
	 * @return - KeisanKomokuCodeのList
	 */
	public static List<KeisanKomokuCode> getList() {
		return Arrays.asList(values());
	}
}
