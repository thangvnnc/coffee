/**
 *
 */
package jp.ne.yec.seagullLC.stagia.beans.shinsei;

import jp.ne.yec.seagullLC.stagia.entity.TNyujoRyokinKoma;
import lombok.Getter;
import lombok.Setter;

/**
 * @author nao-hirata
 *
 */
@Setter
@Getter
@SuppressWarnings("serial")
public class NyujoRyokinKomaDto extends TNyujoRyokinKoma {

	private String nyujoRyokinKomaLabel;
	private boolean isSelected = false;
}
