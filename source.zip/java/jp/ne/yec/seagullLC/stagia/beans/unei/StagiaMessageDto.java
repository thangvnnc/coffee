package jp.ne.yec.seagullLC.stagia.beans.unei;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

/**
 * 施設予約のメッセージ表示用DTO</BR>
 *
 * @author sic-hanaoka
 *
 */
@Setter
@Getter
@SuppressWarnings("serial")
public class StagiaMessageDto implements Serializable {

	/**
	 * メッセージID
	 */
	private Integer messageID;

	/**
	 * 分類
	 */
	private String bunrui;

	/**
	 * 分類背景色
	 */
	private String bunruiBgColor;

	/**
	 * 分類文字色
	 */
	private String bunruiColor;

	/**
	 * 掲載日
	 */
	private String postDate;

	/**
	 * タイトル
	 */
	private String title;

	/**
	 * 本文
	 */
	private String message;

	/**
	 * 既読/未読フラグ
	 */
	private Boolean isRead;

}
