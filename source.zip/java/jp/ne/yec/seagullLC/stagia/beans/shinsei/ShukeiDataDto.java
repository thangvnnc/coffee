package jp.ne.yec.seagullLC.stagia.beans.shinsei;

import java.util.List;
import java.util.Objects;

import jp.ne.yec.seagullLC.stagia.entity.MShukeiKomoku;
import jp.ne.yec.seagullLC.stagia.entity.TShukeiData;
import lombok.Getter;
import lombok.Setter;

/**
 * @author nao-hirata
 *
 */
@Setter
@Getter
@SuppressWarnings("serial")
public class ShukeiDataDto extends TShukeiData {

	private String shukeiName;
	private List<MShukeiKomoku> shukeiKomokus;

	private MShukeiKomoku selectedShukeiKomoku;

	/**
	 * 画面で設定された集計項目から集計項目コードをセットします.
	 *
	 * @param selectedShukeiKomoku
	 */
	public void setSelectedShukeiKomoku(MShukeiKomoku selectedShukeiKomoku) {
		this.selectedShukeiKomoku = selectedShukeiKomoku;
		if (Objects.isNull(selectedShukeiKomoku)) {
			setShukeiKomokuCode(null);
			return;
		}
		setShukeiKomokuCode(selectedShukeiKomoku.getShukeiKomokuCode());
	}

}
