package jp.ne.yec.seagullLC.stagia.beans.enums;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import org.apache.commons.lang.StringUtils;

import jp.ne.yec.seagullLC.stagia.beans.enums.domain.KeisanHoho;
import jp.ne.yec.seagullLC.stagia.beans.enums.domain.base.StagiaEnum;

/**
 * {@code KeisanHoho}を画面表示する際に使用するenumクラスです.
 *
 * @author nao-hirata
 *
 */
public enum PercentYen implements StagiaEnum {

	PERCENT(KeisanHoho.RITSU.getCode(), "%"),
	YEN(KeisanHoho.GAKU.getCode(), "円")
;
	private String code;
	private String name;

	private PercentYen(String code, String name) {
		this.code = code;
		this.name = name;
	}

	public String getCode() {
		return this.code;
	}

	public String getName() {
		return this.name;
	}

	/**
	 * 引数のコードを保持する列挙子を返却します.
	 * 存在しない場合、{@code null}を返却します.
	 *
	 * @param code
	 * @return - codeを保持するPercentYen
	 */
	public static PercentYen getEnumClass(String code) {
		return Stream.of(values()).filter(e -> e.getCode().equals(code)).findFirst().orElse(null);
	}

	/**
	 * 引数のコードを保持する列挙子の名称を返却します.
	 * 存在しない場合、{@code StringUtils.EMPTY}を返却します.
	 *
	 * @param code
	 * @return - codeを保持するPercentYenのname
	 */
	public static String getName(String code) {
		PercentYen enumClass = getEnumClass(code);
		if (null == enumClass) {
			return StringUtils.EMPTY;
		}
		return enumClass.getName();
	}

	/**
	 * PercentYenの列挙子全てをList型で返却します.
	 *
	 * @return - PercentYenのList
	 */
	public static List<PercentYen> getList() {
		return Arrays.asList(values());
	}
}