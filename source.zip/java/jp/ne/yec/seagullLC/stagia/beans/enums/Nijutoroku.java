package jp.ne.yec.seagullLC.stagia.beans.enums;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import org.apache.commons.lang.StringUtils;

import jp.ne.yec.seagullLC.stagia.beans.enums.domain.base.StagiaEnum;

/**
 * 二重登録の判定項目を保持する列挙型.</BR>
 * 「m_二重登録」のカラム項目を保持します.
 *
 * @author sic-hanaoka
 *
 */
public enum Nijutoroku implements StagiaEnum {
	NAMEKANA("0", "ユーザ名カナ"),
	NAME("1", "ユーザ名称"),
	BIRTH("2", "生年月日"),
	TEL1("3", "電話番号１"),
	TEL2("4", "電話番号２"),
	ZIP("5", "郵便番号"),
	ADDRESS1("6", "住所１"),
	ADDRESS2("7", "住所２"),
	MAIL("8", "メールアドレス"),
;
	private String code;
	private String name;

	private Nijutoroku(String code, String name) {
		this.code = code;
		this.name = name;
	}

	public String getCode() {
		return this.code;
	}

	public String getName() {
		return this.name;
	}

	/**
	 * 引数のコードを保持する列挙子を返却します.
	 * 存在しない場合、{@code null}を返却します.
	 *
	 * @param code
	 * @return - codeを保持するNijutoroku
	 */
	public static Nijutoroku getEnumClass(String code) {
		return Stream.of(values()).filter(e -> e.getCode().equals(code)).findFirst().orElse(null);
	}

	/**
	 * 引数のコードを保持する列挙子の名称を返却します.
	 * 存在しない場合、{@code StringUtils.EMPTY}を返却します.
	 *
	 * @param code
	 * @return - codeを保持するNijutorokuのname
	 */
	public static String getName(String code) {
		Nijutoroku enumClass = getEnumClass(code);
		if (null == enumClass) {
			return StringUtils.EMPTY;
		}
		return enumClass.getName();
	}

	/**
	 * Nijutorokuの列挙子全てをList型で返却します.
	 *
	 * @return - NijutorokuのList
	 */
	public static List<Nijutoroku> getList() {
		return Arrays.asList(values());
	}
}