package jp.ne.yec.seagullLC.stagia.beans.criteria;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.stream.Stream;

import org.apache.commons.lang.StringUtils;

import jp.ne.yec.seagullLC.stagia.beans.enums.JokenHukumu;
import jp.ne.yec.seagullLC.stagia.beans.enums.domain.RyokinKubun;
import jp.ne.yec.seagullLC.stagia.beans.enums.domain.base.StagiaEnum;
import jp.ne.yec.seagullLC.stagia.entity.MBasho;
import jp.ne.yec.seagullLC.stagia.entity.MKanri;
import jp.ne.yec.seagullLC.stagia.entity.MShisetsu;
import lombok.Getter;
import lombok.Setter;

/**
 * @author nao-hirata
 *
 */
@Setter
@Getter
@SuppressWarnings("serial")
public class SearchIKeshikomiDto implements Serializable {

	private SeisanShurui seisanShurui = SeisanShurui.RYOSHU;

	private String loginId;
	private JokenHukumu joken = JokenHukumu.HUKUMU;

	private Integer shinseiNoFrom;
	private Integer shinseiNoTo;
	private Integer seisanNoFrom;
	private Integer seisanNoTo;

	private MKanri mKanri;
	private MBasho mBasho;
	private List<MShisetsu> mShisetsuList;
	private List<RyokinKubun> ryokinKubunList;
	private List<StagiaEnum> seisanJotaiList;
	private List<StagiaEnum> seisanHohoList;

	private Date shiyoDateFrom;
	private Date shiyoDateTo;
	private Date yoteiDateFrom;
	private Date yoteiDateTo;
	private Date seisanDateFrom;
	private Date seisanDateTo;
	private Date choteiDateFrom;
	private Date choteiDateTo;
	private Date uketsukeDateFrom;
	private Date uketsukeDateTo;
	private MBasho uketsukeBasho;

	/**
	 * 精算種類を保持する列挙型です.
	 *
	 * @author nao-hirata
	 *
	 */
	public enum SeisanShurui implements StagiaEnum  {
		RYOSHU("0", "領収"),
		KAMPU("1", "還付"),
	;
		private String code;
		private String name;

		private SeisanShurui(String code, String name) {
			this.code = code;
			this.name = name;
		}

		public String getCode() {
			return this.code;
		}

		public String getName() {
			return this.name;
		}

		/**
		 * 引数のコードを保持する列挙子を返却します.
		 * 存在しない場合、{@code null}を返却します.
		 *
		 * @param code
		 * @return - codeを保持するSeisanShurui
		 */
		public static SeisanShurui getEnumClass(String code) {
			return Stream.of(values()).filter(e -> e.getCode().equals(code)).findFirst().orElse(null);
		}

		/**
		 * 引数のコードを保持する列挙子の名称を返却します.
		 * 存在しない場合、{@code StringUtils.EMPTY}を返却します.
		 *
		 * @param code
		 * @return - codeを保持するSeisanShuruiのname
		 */
		public static String getName(String code) {
			SeisanShurui enumClass = getEnumClass(code);
			if (null == enumClass) {
				return StringUtils.EMPTY;
			}
			return enumClass.getName();
		}

		/**
		 * SeisanShuruiの列挙子全てをList型で返却します.
		 *
		 * @return - SeisanShuruiのList
		 */
		public static List<SeisanShurui> getList() {
			return Arrays.asList(values());
		}

	}
}
