package jp.ne.yec.seagullLC.stagia.beans.search;

import java.util.List;

/**
 * 施設絞込検索情報を保持するクラス
 *
 * @author nao-hirata
 * @since 1.0
 * @version 1.0
 */
public class SearchAkijyokyoInfoDto {

	private String displayStartDay;

	private List<String> mokutekiCdList;

	private List<String> basyoCdList;

	private List<String> hutaiSetubiCdList;

	private String sisetuCd;

	private String sisetuGroupCd;

	/**
	 * displayStartDayを取得します.
	 *
	 * @return displayStartDay
	 */
	public String getDisplayStartDay() {
		return displayStartDay;
	}

	/**
	 * displayStartDayを設定します.
	 * @param displayStartDay セットする displayStartDay
	 */
	public void setDisplayStartDay(String displayStartDay) {
		this.displayStartDay = displayStartDay;
	}

	/**
	 * mokutekiCdListを取得します.
	 *
	 * @return mokutekiCdList
	 */
	public List<String> getMokutekiCdList() {
		return mokutekiCdList;
	}

	/**
	 * mokutekiCdListを設定します.
	 * @param mokutekiCdList セットする mokutekiCdList
	 */
	public void setMokutekiCdList(List<String> mokutekiCdList) {
		this.mokutekiCdList = mokutekiCdList;
	}

	/**
	 * basyoCdListを取得します.
	 *
	 * @return basyoCdList
	 */
	public List<String> getBasyoCdList() {
		return basyoCdList;
	}

	/**
	 * basyoCdListを設定します.
	 * @param basyoCdList セットする basyoCdList
	 */
	public void setBasyoCdList(List<String> basyoCdList) {
		this.basyoCdList = basyoCdList;
	}

	/**
	 * hutaiSetubiCdListを取得します.
	 *
	 * @return hutaiSetubiCdList
	 */
	public List<String> getHutaiSetubiCdList() {
		return hutaiSetubiCdList;
	}

	/**
	 * hutaiSetubiCdListを設定します.
	 * @param hutaiSetubiCdList セットする hutaiSetubiCdList
	 */
	public void setHutaiSetubiCdList(List<String> hutaiSetubiCdList) {
		this.hutaiSetubiCdList = hutaiSetubiCdList;
	}

	/**
	 * sisetuCdを取得します.
	 *
	 * @return sisetuCd
	 */
	public String getSisetuCd() {
		return sisetuCd;
	}

	/**
	 * sisetuCdを設定します.
	 * @param sisetuCd セットする sisetuCd
	 */
	public void setSisetuCd(String sisetuCd) {
		this.sisetuCd = sisetuCd;
	}

	/**
	 * sisetuGroupCdを取得します.
	 *
	 * @return sisetuGroupCd
	 */
	public String getSisetuGroupCd() {
		return sisetuGroupCd;
	}

	/**
	 * sisetuGroupCdを設定します.
	 * @param sisetuGroupCd セットする sisetuGroupCd
	 */
	public void setSisetuGroupCd(String sisetuGroupCd) {
		this.sisetuGroupCd = sisetuGroupCd;
	}
}
