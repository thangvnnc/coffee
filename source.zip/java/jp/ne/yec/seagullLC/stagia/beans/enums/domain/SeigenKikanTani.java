package jp.ne.yec.seagullLC.stagia.beans.enums.domain;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import org.apache.commons.lang.StringUtils;

import jp.ne.yec.seagullLC.stagia.beans.enums.domain.base.StagiaEnum;

/**
 * Generated on Mon Feb 05 19:18:17 JST 2018 based on <br>
 * ドメイン定義票（制限期間算出単位）.xlsx.
 * <p>
 * 	使用日からみて件数制限の対象となる受付期間を算出する際に使用する単位を保持する列挙型です。<br>
 * </p>
 */
public enum SeigenKikanTani implements StagiaEnum  {
	DAY("0", "日前"),
	WEEK("1", "週間前"),
	MONTH("2", "ヵ月前"),
	YEAR("3", "年前"),
;
	private String code;
	private String name;

	private SeigenKikanTani(String code, String name) {
		this.code = code;
		this.name = name;
	}

	public String getCode() {
		return this.code;
	}

	public String getName() {
		return this.name;
	}

	/**
	 * 引数のコードを保持する列挙子を返却します.
	 * 存在しない場合、{@code null}を返却します.
	 *
	 * @param code
	 * @return - codeを保持するSeigenKikanTani
	 */
	public static SeigenKikanTani getEnumClass(String code) {
		return Stream.of(values()).filter(e -> e.getCode().equals(code)).findFirst().orElse(null);
	}

	/**
	 * 引数のコードを保持する列挙子の名称を返却します.
	 * 存在しない場合、{@code StringUtils.EMPTY}を返却します.
	 *
	 * @param code
	 * @return - codeを保持するSeigenKikanTaniのname
	 */
	public static String getName(String code) {
		SeigenKikanTani enumClass = getEnumClass(code);
		if (null == enumClass) {
			return StringUtils.EMPTY;
		}
		return enumClass.getName();
	}

	/**
	 * SeigenKikanTaniの列挙子全てをList型で返却します.
	 *
	 * @return - SeigenKikanTaniのList
	 */
	public static List<SeigenKikanTani> getList() {
		return Arrays.asList(values());
	}
}
