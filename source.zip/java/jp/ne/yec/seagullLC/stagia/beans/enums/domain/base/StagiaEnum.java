package jp.ne.yec.seagullLC.stagia.beans.enums.domain.base;

import jp.ne.yec.sane.beans.ICodeNamePair;

/**
 * @author nao-hirata
 *
 */
public interface StagiaEnum extends ICodeNamePair {
	String getCode();
	String getName();
}
