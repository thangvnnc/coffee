package jp.ne.yec.seagullLC.stagia.beans.shinsei;

import jp.ne.yec.seagullLC.stagia.entity.TRyokinSanshutsuKomoku;
import lombok.Getter;
import lombok.Setter;

/**
 * @author nao-hirata
 *
 */
@Setter
@Getter
@SuppressWarnings("serial")
public class RyokinSanshutsuKomokuDto extends TRyokinSanshutsuKomoku {
	private String komokuName;
	private String naiyoName;
}
