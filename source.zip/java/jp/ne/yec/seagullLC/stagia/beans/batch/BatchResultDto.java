package jp.ne.yec.seagullLC.stagia.beans.batch;

import java.util.HashMap;
import java.util.Map;

import lombok.Getter;
import lombok.Setter;

/**
 * バッチ実行結果
 *
 * バッチ実行結果を格納するMAPを保持します.
 * このオブジェクトはjson形式でTバッチ管理.logに格納されます.
 *
 * 以下の4項目はデフォルトで用意します.
 * 対象件数
 * 正常処理件数
 * 異常処理件数
 * 例外メッセージ
 *
 * MAPキーは格納するオブジェクトを類推できる名前でサービス側で定義してください.
 * 値はjsonに変換されることを想定して任意のObjectを格納してください.
 *
 * @author 佐藤武
 *
 */
@Getter
@Setter
@SuppressWarnings("serial")
public class BatchResultDto {

	public static final String ALL_CNT = "all.cnt";
	public static final String NORMAL_CNT = "normal.cnt";
	public static final String ABORT_CNT = "abort.cnt";
	public static final String STACK_TRACE_MESSAGE = "stack.trace.message";

	/**
	 * バッチ実行結果
	 *
	 * バッチにより内容がかわることを想定して値はObjectとします.
	 * キーはそのオブジェクトの内容がわかる名前でサービス側で定義して格納してください.
	 *
	 */
	private Map<String, Object> resultMap;

	public BatchResultDto() {
		resultMap = new HashMap<>();
		setAllCnt(0);
		setNormalCnt(0);
		setAbortCnt(0);
	}

	/**
	 * 対象件数を設定します.
	 *
	 * @param allCnt
	 */
	public void setAllCnt(int allCnt) {
		resultMap.put(ALL_CNT, allCnt);
	}

	/**
	 * 正常処理件数を設定します.
	 *
	 * @param normalCnt
	 */
	public void setNormalCnt(int normalCnt) {
		resultMap.put(NORMAL_CNT, normalCnt);
	}

	/**
	 * 異常処理件数を設定します.
	 *
	 * @param normalCnt
	 */
	public void setAbortCnt(int abortCnt) {
		resultMap.put(ABORT_CNT, abortCnt);
	}

}
