package jp.ne.yec.seagullLC.stagia.beans.enums.domain;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import org.apache.commons.lang.StringUtils;

import jp.ne.yec.seagullLC.stagia.beans.enums.domain.base.StagiaEnum;

/**
 * Generated on Mon Feb 05 19:18:18 JST 2018 based on <br>
 * ドメイン定義票（申請内制限種類）.xlsx.
 * <p>
 * 	申請内制限の対象とする申請の種類を保持する列挙型です。<br>
 * </p>
 */
public enum ShinseinaiSeigenShurui implements StagiaEnum  {
	CHUSEN("0", "抽選"),
	KARIYOYAKU("1", "仮予約"),
	HONYOYAKU("2", "本予約"),
;
	private String code;
	private String name;

	private ShinseinaiSeigenShurui(String code, String name) {
		this.code = code;
		this.name = name;
	}

	public String getCode() {
		return this.code;
	}

	public String getName() {
		return this.name;
	}

	/**
	 * 引数のコードを保持する列挙子を返却します.
	 * 存在しない場合、{@code null}を返却します.
	 *
	 * @param code
	 * @return - codeを保持するShinseinaiSeigenShurui
	 */
	public static ShinseinaiSeigenShurui getEnumClass(String code) {
		return Stream.of(values()).filter(e -> e.getCode().equals(code)).findFirst().orElse(null);
	}

	/**
	 * 引数のコードを保持する列挙子の名称を返却します.
	 * 存在しない場合、{@code StringUtils.EMPTY}を返却します.
	 *
	 * @param code
	 * @return - codeを保持するShinseinaiSeigenShuruiのname
	 */
	public static String getName(String code) {
		ShinseinaiSeigenShurui enumClass = getEnumClass(code);
		if (null == enumClass) {
			return StringUtils.EMPTY;
		}
		return enumClass.getName();
	}

	/**
	 * ShinseinaiSeigenShuruiの列挙子全てをList型で返却します.
	 *
	 * @return - ShinseinaiSeigenShuruiのList
	 */
	public static List<ShinseinaiSeigenShurui> getList() {
		return Arrays.asList(values());
	}
}
