package jp.ne.yec.seagullLC.stagia.beans.riyosha;

import org.apache.commons.lang.StringUtils;

import jp.ne.yec.sane.beans.StringCodeNamePair;
import jp.ne.yec.seagullLC.stagia.entity.TKanribetsuRiyoshaJoho;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@SuppressWarnings("serial")
public class KanribetsuRiyoshaJohoDto extends TKanribetsuRiyoshaJoho {
	private String updateKbn = StringUtils.EMPTY;
	private StringCodeNamePair selectedRyokinTaikeiCode;
	private StringCodeNamePair selectedShiyoMokutekiCode;
	private StringCodeNamePair selectedTeishiRiyuCode;

}
