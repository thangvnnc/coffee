package jp.ne.yec.seagullLC.stagia.beans.shuno;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import org.apache.commons.lang.StringUtils;

import jp.ne.yec.seagullLC.stagia.beans.enums.domain.KampuHoho;
import jp.ne.yec.seagullLC.stagia.common.Constants;
import jp.ne.yec.seagullLC.stagia.entity.TKampu;
import jp.ne.yec.seagullLC.stagia.entity.TKampuMeisai;
import lombok.Getter;
import lombok.Setter;

/**
 * @author nao-hirata
 *
 */
@Getter
@Setter
@SuppressWarnings("serial")
public class KampuDto extends TKampu {

	KampuHoho kampuHohoEnum;
	List<TKampuMeisai> tKampuMeisais = new ArrayList<>();


	public void setKampuHohoEnum(KampuHoho kampuHohoEnum) {
		this.kampuHohoEnum = kampuHohoEnum;
		if (Objects.nonNull(kampuHohoEnum)) {
			setKampuHoho(kampuHohoEnum.getCode());
			return;
		}
		setKampuHoho(null);
	}

	public String getDisplayKampuNumber() {
		if (Objects.isNull(getKampuNumber())) {
			return StringUtils.EMPTY;
		}
		return StringUtils.leftPad(String.valueOf(getKanriCode()), 2, "0")
				+ Constants.HYPHEN
				+ String.valueOf(getKampuNumber());
	}

	public String getStatus() {
		if (isPaid()) {
			return "済み";
		}
		return "予定";
	}

	public String getKampuGakuCurrencyFormat() {
		int ryokin = null == getKampuGaku() ? 0 : getKampuGaku();
		return NumberFormat.getCurrencyInstance().format(ryokin);
	}

}
