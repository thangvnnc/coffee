package jp.ne.yec.seagullLC.stagia.beans.shokai;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import jp.ne.yec.sane.beans.StringCodeNamePair;
import jp.ne.yec.seagullLC.stagia.entity.MKanri;
import jp.ne.yec.seagullLC.stagia.entity.MShokuin;
import jp.ne.yec.seagullLC.stagia.entity.MShokuinKengen;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@SuppressWarnings("serial")
public class ShokuinDto extends MShokuin implements Serializable {
	// 職員氏名
	private String userName;
	private String password;

	/**
	 * 更新権限有りの管理リスト</BR>
	 * ※マスターメンテナンスにて使用</BR>
	 * ※画面にてチェックした管理のリスト
	 *
	 */
	private List<MKanri> kanriCodeCK = new ArrayList<>();

	/**
	 * 職員権限リスト</BR>
	 * ※マスターメンテナンスにて使用
	 */
	private List<MShokuinKengen> mShokuinKengenList;

	/**
	 * 選択受付場所</BR>
	 * ※マスターメンテナンスにて使用
	 */
	private StringCodeNamePair selectedUketsukeBasho;

}
