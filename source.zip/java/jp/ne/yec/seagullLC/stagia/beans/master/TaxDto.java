package jp.ne.yec.seagullLC.stagia.beans.master;

import jp.ne.yec.seagullLC.stagia.entity.MTax;
import jp.ne.yec.seagullLC.stagia.util.CalendarUtils;

public class TaxDto extends MTax {

	public String getDisplayYukoStartDate() {
		return CalendarUtils.toFormatyyyyMdSeparatedBySlashes(getYukokikanStartDate());
	}

	public String getDisplayYukoEndDate() {
		return CalendarUtils.toFormatyyyyMdSeparatedBySlashes(getYukokikanEndDate());
	}

	public String getDisplayTaxRate() {
		return String.valueOf(getTaxRate());
	}
}
