package jp.ne.yec.seagullLC.stagia.beans.shinsei;

import jp.ne.yec.seagullLC.stagia.entity.TSetsubiShinseiKoma;
import lombok.Getter;
import lombok.Setter;


/**
 * 設備の申請コマ情報を保持するDTOクラスです.
 *
 * @author sic-hanaoka
 *
 */
@Getter
@Setter
@SuppressWarnings("serial")
public class SetsubiShinseiKomaDto extends TSetsubiShinseiKoma {

	/**
	 * 設備コマを一意としたキー値を返却します.
	 *
	 * @return setsubiBunruiCode * 1000000 + setsubiCode * 100 + komaCode
	 */
	public int getSetsubiKomaKey() {
		return getSetsubiBunruiCode() * 1000000 + getSetsubiCode() * 100 + getKomaCode();
	}

	/**
	 * 設備を一意としたキー値を返却します.
	 *
	 * @return setsubiBunruiCode * 10000 + getSetsubiCode
	 */
	public int getSetsubiKey() {
		return getSetsubiBunruiCode() * 10000 + getSetsubiCode();
	}
}
