package jp.ne.yec.seagullLC.stagia.beans.enums.domain;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import org.apache.commons.lang.StringUtils;

import jp.ne.yec.seagullLC.stagia.beans.enums.domain.base.StagiaEnum;

/**
 * Generated on Mon Feb 05 19:18:17 JST 2018 based on <br>
 * ドメイン定義票（延長料金算出方式）.xlsx.
 * <p>
 * 	繰上延長料金の算出方法を保持する列挙型です。<br>
 * 	時間：繰上／延長で使用した時間を元に繰上／延長料金を算出する方法です。<br>
 * 	コマ：繰上／延長で使用したコマに設定されている基本料金を繰上／延長料金とする方法です。<br>
 * 	安価：「時間」「コマ」両方で料金を算出し、金額が低い方を採用する方法です。<br>
 * </p>
 */
public enum KuriageEnchoSanshutsuHoshiki implements StagiaEnum  {
	JIKAN("0", "時間"),
	KOMA("1", "コマ"),
	ANKA("2", "安価"),
;
	private String code;
	private String name;

	private KuriageEnchoSanshutsuHoshiki(String code, String name) {
		this.code = code;
		this.name = name;
	}

	public String getCode() {
		return this.code;
	}

	public String getName() {
		return this.name;
	}

	/**
	 * 引数のコードを保持する列挙子を返却します.
	 * 存在しない場合、{@code null}を返却します.
	 *
	 * @param code
	 * @return - codeを保持するKuriageEnchoSanshutsuHoshiki
	 */
	public static KuriageEnchoSanshutsuHoshiki getEnumClass(String code) {
		return Stream.of(values()).filter(e -> e.getCode().equals(code)).findFirst().orElse(null);
	}

	/**
	 * 引数のコードを保持する列挙子の名称を返却します.
	 * 存在しない場合、{@code StringUtils.EMPTY}を返却します.
	 *
	 * @param code
	 * @return - codeを保持するKuriageEnchoSanshutsuHoshikiのname
	 */
	public static String getName(String code) {
		KuriageEnchoSanshutsuHoshiki enumClass = getEnumClass(code);
		if (null == enumClass) {
			return StringUtils.EMPTY;
		}
		return enumClass.getName();
	}

	/**
	 * KuriageEnchoSanshutsuHoshikiの列挙子全てをList型で返却します.
	 *
	 * @return - KuriageEnchoSanshutsuHoshikiのList
	 */
	public static List<KuriageEnchoSanshutsuHoshiki> getList() {
		return Arrays.asList(values());
	}
}
