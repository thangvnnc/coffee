package jp.ne.yec.seagullLC.stagia.beans.shinsei;

import static java.util.stream.Collectors.*;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

import org.apache.commons.lang.StringUtils;

import jp.ne.yec.seagullLC.stagia.beans.enums.PercentYen;
import jp.ne.yec.seagullLC.stagia.beans.enums.domain.KeisanHoho;
import jp.ne.yec.seagullLC.stagia.beans.enums.domain.MeisaiJotai;
import jp.ne.yec.seagullLC.stagia.beans.enums.domain.RyokinKubun;
import jp.ne.yec.seagullLC.stagia.beans.enums.domain.ShinsaKubun;
import jp.ne.yec.seagullLC.stagia.beans.enums.domain.ShinseiShurui;
import jp.ne.yec.seagullLC.stagia.beans.enums.domain.ShisetsuKashidashiHoshiki;
import jp.ne.yec.seagullLC.stagia.common.Constants;
import jp.ne.yec.seagullLC.stagia.entity.MChusenGroup;
import jp.ne.yec.seagullLC.stagia.entity.MKashidashiTani;
import jp.ne.yec.seagullLC.stagia.entity.MKoma;
import jp.ne.yec.seagullLC.stagia.entity.MRyokinTaikei;
import jp.ne.yec.seagullLC.stagia.entity.MShinsaRiyu;
import jp.ne.yec.seagullLC.stagia.entity.MShisetsu;
import jp.ne.yec.seagullLC.stagia.entity.MShiyoMokuteki;
import jp.ne.yec.seagullLC.stagia.entity.TNyujoRyokinKoma;
import jp.ne.yec.seagullLC.stagia.entity.TRehearsal;
import jp.ne.yec.seagullLC.stagia.entity.TShinseiMeisai;
import jp.ne.yec.seagullLC.stagia.util.CalendarUtils;
import jp.ne.yec.seagullLC.stagia.util.TimeUtils;
import lombok.Getter;
import lombok.Setter;

/**
 * @author nao-hirata
 *
 */
@Getter
@Setter
@SuppressWarnings("serial")
public class ShinseiMeisaiDto extends TShinseiMeisai implements Comparable<ShinseiMeisaiDto> {

	private MShisetsu mShisetsu;
	/**
	 * この明細に適用されるMKomaのマップ.
	 * {@code Map<MKoma.komaCode, Mkoma>}を保持
	 */
	private Map<Short, MKoma> mKomaMap;

	private String bashoName;
	private String kashidashiTaniName;

	// 明細一覧
	private ShinseiShurui shinseiShurui;
	private List<MKashidashiTani> reservableMKashidashiTanis = new ArrayList<>();
	private List<MShiyoMokuteki> mShiyoMokutekiList = new ArrayList<>();
	private MKashidashiTani selectedMKashidashiTani;
	private MShiyoMokuteki mShiyoMokuteki;
	private Integer mensu;
	private Short yusenJuni;

	// 変更時プロパティ
	private MKoma changedStartKoma;
	private MKoma changedEndKoma;
	private boolean isDeleted = false;
	private boolean isAdded = false;

	// 明細詳細設定
	private MRyokinTaikei mRyokinTaikei;
	private ShinsaKubun selectedShinsaKubun;
	private MShinsaRiyu selectedShinsaRiyu;
	private Integer reidamboKasan;
	private PercentYen reidamboRitsuGaku;
	private List<NyujoRyokinDto> nyujoRyokinDtos = new ArrayList<>();
	private List<NyujoRyokinKomaDto> nyujoRyokinKomaDtos = new ArrayList<>();
	private List<RehearsalDto> rehearsalDtos = new ArrayList<>();
	private List<KoenTimeDto> koenTimeDtos = new ArrayList<>();

	private MChusenGroup mChusenGroup;
	private Set<String> komaCode = new HashSet<>();

	private Map<RyokinKubun, RyokinDto> ryokinDtoMap = new HashMap<>();
	{
		RyokinDto shisetsuRyokin = new RyokinDto();
		shisetsuRyokin.setRyokinKubun(RyokinKubun.SHISETSU.getCode());
		ryokinDtoMap.put(RyokinKubun.SHISETSU, shisetsuRyokin);
		RyokinDto setsubiRyokin = new RyokinDto();
		setsubiRyokin.setRyokinKubun(RyokinKubun.SETSUBI.getCode());
		ryokinDtoMap.put(RyokinKubun.SETSUBI, setsubiRyokin);
	}

	// 設備情報
	private List<SetsubiShinseiDto> setsubiShinseiDtos = new ArrayList<>();

	public RyokinDto getShisetsuRyokinDto() {
		return ryokinDtoMap.get(RyokinKubun.SHISETSU);
	}

	public RyokinDto getSetsubiRyokinDto() {
		return ryokinDtoMap.get(RyokinKubun.SETSUBI);
	}

	/**
	 * 画面で選択された使用目的から使用目的コードをセットします.
	 *
	 * @param mShiyoMokuteki
	 */
	public void setMShiyoMokuteki(MShiyoMokuteki mShiyoMokuteki) {
		this.mShiyoMokuteki = mShiyoMokuteki;
		Short shiyoMokutekiCode = Objects.nonNull(mShiyoMokuteki) ? mShiyoMokuteki.getShiyoMokutekiCode() : null;
		setShiyoMokutekiCode(shiyoMokutekiCode);
	}

	/**
	 * 画面で選択された貸出単位から貸出単位コード、貸出単位名称をセットします.
	 *
	 * @param mKashidashiTani
	 */
	public void setSelectedMKashidashiTani(MKashidashiTani mKashidashiTani) {
		this.selectedMKashidashiTani = mKashidashiTani;
		if (Objects.isNull(mKashidashiTani)) {
			kashidashiTaniName = null;
			setKashidashiTaniCode(null);
			return;
		}
		kashidashiTaniName = mKashidashiTani.getKashidashiTaniName();
		setKashidashiTaniCode(mKashidashiTani.getKashidashiTaniCode());
	}

	/**
	 * 画面で選択された料金体系を元に料金体系コードをセットします.
	 *
	 * @param mShiyoMokuteki
	 */
	public void setMRyokinTaikei(MRyokinTaikei mRyokinTaikei) {
		this.mRyokinTaikei = mRyokinTaikei;
		Short ryokinTaikeiCode = Objects.nonNull(mRyokinTaikei) ? mRyokinTaikei.getRyokinTaikeiCode() : null;
		setRyokinTaikeiCode(ryokinTaikeiCode);
	}

	/**
	 * 画面で入力された開始時間をセットします.
	 *
	 * @param startTime
	 */
	public void setDisplayStartTime(String startTime) {
		super.setStartTime(TimeUtils.stringWithColonToShort(startTime));
	}

	/**
	 * 画面で入力された終了時間をセットします.
	 *
	 * @param endTime
	 */
	public void setDisplayEndTime(String endTime) {
		super.setEndTime(TimeUtils.stringWithColonToShort(endTime));
	}

	/**
	 * 面数入力を行う明細であるかを判定します.
	 *
	 * @return
	 */
	public boolean isMensuNyuryoku() {
		return ShisetsuKashidashiHoshiki.MENSU_SHITEI.getCode().equals(getMShisetsu().getShisetsuKashidashiHoshiki());
	}

	/**
	 * 管理コード、施設コード、使用日を結合した文字列を返却します.
	 *
	 * @return
	 */
	public String getUsePlaceDate() {
		return StringUtils.leftPad(String.valueOf(getKanriCode()), 2, "0")
				+ StringUtils.leftPad(String.valueOf(getShisetsuCode()), 3, "0")
				+ CalendarUtils.toFormatyyyyMMdd(getShiyoDate());
	}

	/**
	 * 画面に表示する使用日を返却します.
	 *
	 * @return
	 */
	public String getDisplayShiyoDate() {
		return CalendarUtils.toFormatyyyyMdSeparatedBySlashes(getShiyoDate());
	}

	/**
	 * 場所施設名称を返却します.
	 *
	 * @return
	 */
	public String getBashoShisetsuName() {
		if (StringUtils.isEmpty(getBashoName())) {
			return StringUtils.EMPTY;
		}
		return getBashoName() + Constants.SPACE + getMShisetsu().getShisetsuName();
	}

	/**
	 * 場所施設貸出単位名称を返却します.
	 *
	 * @return
	 */
	public String getBashoShisetsuKashidashiName() {
		return getBashoShisetsuName() + Constants.SPACE + kashidashiTaniName;
	}

	/**
	 * 使用施設名称を返却します.</BR>
	 * 貸出単位が確定していない場合は場所施設名称のみを返却します.
	 *
	 * @return 使用施設名称
	 */
	public String getShiyoShisetsuName() {
		if (StringUtils.isBlank(kashidashiTaniName)) {
			return getBashoShisetsuName();
		}
		return getBashoShisetsuKashidashiName();
	}

	/**
	 * 画面に表示する申請番号を返却します.
	 *
	 * @return
	 */
	public String getDisplayShinseiNumber() {
		return StringUtils.leftPad(String.valueOf(getKanriCode()), 2, "0")
				+ Constants.HYPHEN
				+ String.valueOf(getShinseiNumber())
				+ Constants.HYPHEN
				+ StringUtils.leftPad(String.valueOf(getMeisaiNumber()), 2, "0");
	}

	/**
	 * 画面に表示する施設・使用日・時間を返却します.
	 *
	 * @return
	 */
	public String getDisplayShinseiShisetsuShiyoDate() {
		return getShiyoShisetsuName()
				+ TimeUtils.EM_COLON
				+ getDisplayShiyoDateTime();
	}


	/**
	 * 画面に表示する明細状態を返却します.
	 *
	 * @return
	 */
	public String getDisplayMeisaiJotai() {
		return MeisaiJotai.getName(getMeisaiJotai());
	}

	/**
	 * 画面に表示する開始、終了時間を返却します.
	 *
	 * @return
	 */
	public String getDisplayUseTime() {
		return TimeUtils.toTimeRangeFormat(getStartTime(), getEndTime());
	}

	/**
	 * 画面に表示する開始時間を返却します.
	 *
	 * @return
	 */
	public String getDisplayStartTime() {
		return TimeUtils.toTimeFormatFourDigits(getStartTime());
	}

	/**
	 * 画面に表示する終了時間を返却します.
	 *
	 * @return
	 */
	public String getDisplayEndTime() {
		return TimeUtils.toTimeFormatFourDigits(getEndTime());
	}

	/**
	 * 画面に表示する使用日、時間を返却します.
	 *
	 * @return
	 */
	public String getDisplayShiyoDateTime() {
		return CalendarUtils.toFormatyyyyMdSeparatedBySlashes(getShiyoDate())
				+ Constants.SPACE
				+ getDisplayUseTime();
	}

	/**
	 * 料金計算で使用するリハーサルリストを返却します.
	 *
	 * @return
	 */
	public List<? extends TRehearsal> getRehearsalDtosForCalc() {
		return getRehearsalDtos().stream().filter(e -> Objects.nonNull(e.getRehearsalCode())).collect(toList());
	}

	/**
	 * 料金計算で使用する入場料金コマリストを返却します.
	 *
	 * @return
	 */
	public List<? extends TNyujoRyokinKoma> getNyujoRyokinKomaDtosForCalc() {
		return getNyujoRyokinKomaDtos().stream().filter(NyujoRyokinKomaDto::isSelected).collect(toList());
	}

	/**
	 * 料金計算で使用する冷暖房の計算方法を返却します.
	 *
	 * @return
	 */
	public KeisanHoho getReidamboKeisanHoho() {
		return Objects.isNull(getReidamboRitsuGaku()) ? null : KeisanHoho.getEnumClass(getReidamboRitsuGaku().getCode());
	}

	@Override
	public int compareTo(ShinseiMeisaiDto o) {
		int shinseiShurui1 = Integer.parseInt(shinseiShurui.getCode());
		int shinseiShurui2 = Integer.parseInt(o.getShinseiShurui().getCode());
		if (shinseiShurui1 < shinseiShurui2) {
			return -1;
		} else if (shinseiShurui1 > shinseiShurui2) {
			return 1;
		}
		if (getKanriCode() < o.getKanriCode()) {
			return -1;
		} else if (getKanriCode() > o.getKanriCode()) {
			return 1;
		}

		int shinseiNumber1 = Optional.ofNullable(getShinseiNumber()).orElse(Integer.MAX_VALUE);
		int shinseiNumber2 = Optional.ofNullable(o.getShinseiNumber()).orElse(Integer.MAX_VALUE);
		if (shinseiNumber1 < shinseiNumber2) {
			return -1;
		} else if (shinseiNumber1 > shinseiNumber2) {
			return 1;
		}

		short meisaiNumber1 = Optional.ofNullable(getMeisaiNumber()).orElse((short) 1000);
		short meisaiNumber2 = Optional.ofNullable(o.getMeisaiNumber()).orElse((short) 1000);
		if (meisaiNumber1 < meisaiNumber2) {
			return -1;
		} else if (meisaiNumber1 > meisaiNumber2) {
			return 1;
		}
		int shiyoDate1 = Integer.parseInt(new SimpleDateFormat("yyyyMMdd").format(getShiyoDate()));
		int shiyoDate2 = Integer.parseInt(new SimpleDateFormat("yyyyMMdd").format(o.getShiyoDate()));

		if (shiyoDate1 < shiyoDate2) {
			return -1;
		} else if (shiyoDate1 > shiyoDate2) {
			return 1;
		}
		if (getStartKoma() < o.getStartKoma()) {
			return -1;
		} else if (getStartKoma() > o.getStartKoma()) {
			return 1;
		}
		if (getEndKoma() < o.getEndKoma()) {
			return -1;
		} else if (getEndKoma() > o.getEndKoma()) {
			return 1;
		}
		if (getShisetsuCode() < o.getShisetsuCode()) {
			return -1;
		} else if (getShisetsuCode() > o.getShisetsuCode()) {
			return 1;
		}
		if (Objects.isNull(getKashidashiTaniCode()) || Objects.isNull(o.getKashidashiTaniCode())) {
			return 0;
		}
		if (getKashidashiTaniCode() < o.getKashidashiTaniCode()) {
			return -1;
		} else if (getKashidashiTaniCode() > o.getKashidashiTaniCode()) {
			return 1;
		}
		return 0;
	}
}
