package jp.ne.yec.seagullLC.stagia.beans.search;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import lombok.Getter;
import lombok.Setter;

/**
 * 空き状況表示の１行を表現するクラス.<br>
 * {@code field}に「管理コード」,「施設コード」, 「表示する行数」,「表示するコマリスト」を保持します.
 *
 * @author nao-hirata
 *
 */
@Getter
@Setter
@SuppressWarnings("serial")
public class AkijokyoRowDto implements Serializable {

	private int rowNo;
	private List<AkijokyoKomaDto> komaDtoList = new ArrayList<>();

}
