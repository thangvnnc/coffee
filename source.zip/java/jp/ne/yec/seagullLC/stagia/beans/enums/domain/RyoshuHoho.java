package jp.ne.yec.seagullLC.stagia.beans.enums.domain;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import org.apache.commons.lang.StringUtils;

import jp.ne.yec.seagullLC.stagia.beans.enums.domain.base.StagiaEnum;

/**
 * Generated on Mon Feb 05 19:18:18 JST 2018 based on <br>
 * ドメイン定義票（領収方法）.xlsx.
 * <p>
 * 	領収方法を保持する列挙型です。<br>
 * </p>
 */
public enum RyoshuHoho implements StagiaEnum  {
	GENKIN("0", "現金"),
	FURIKOMIIRAISHO("1", "振込依頼書"),
	NOFUSHO("2", "納付書"),
	KOZAHIKIOTOSHI("3", "口座引落"),
	MULTIPAYMENT("4", "マルチペイメント"),
;
	private String code;
	private String name;

	private RyoshuHoho(String code, String name) {
		this.code = code;
		this.name = name;
	}

	public String getCode() {
		return this.code;
	}

	public String getName() {
		return this.name;
	}

	/**
	 * 引数のコードを保持する列挙子を返却します.
	 * 存在しない場合、{@code null}を返却します.
	 *
	 * @param code
	 * @return - codeを保持するRyoshuHoho
	 */
	public static RyoshuHoho getEnumClass(String code) {
		return Stream.of(values()).filter(e -> e.getCode().equals(code)).findFirst().orElse(null);
	}

	/**
	 * 引数のコードを保持する列挙子の名称を返却します.
	 * 存在しない場合、{@code StringUtils.EMPTY}を返却します.
	 *
	 * @param code
	 * @return - codeを保持するRyoshuHohoのname
	 */
	public static String getName(String code) {
		RyoshuHoho enumClass = getEnumClass(code);
		if (null == enumClass) {
			return StringUtils.EMPTY;
		}
		return enumClass.getName();
	}

	/**
	 * RyoshuHohoの列挙子全てをList型で返却します.
	 *
	 * @return - RyoshuHohoのList
	 */
	public static List<RyoshuHoho> getList() {
		return Arrays.asList(values());
	}
}
