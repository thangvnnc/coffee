package jp.ne.yec.seagullLC.stagia.beans.unei;

import java.time.LocalDate;
import java.util.List;

import jp.ne.yec.seagullLC.stagia.beans.enums.domain.HeisaShurui;
import jp.ne.yec.seagullLC.stagia.common.Constants;
import jp.ne.yec.seagullLC.stagia.entity.TShisetsuHeisa;
import jp.ne.yec.seagullLC.stagia.util.CalendarUtils;
import jp.ne.yec.seagullLC.stagia.util.TimeUtils;
import lombok.Getter;
import lombok.Setter;

/**
 * 休館日、閉鎖日等の更新情報を保持するDTOです
 *
 * @author sic-hanaoka
 *
 */
@Setter
@Getter
@SuppressWarnings("serial")
public class KyukanSetteiDataDto extends TShisetsuHeisa {

	/**
	 * 場所コード
	 */
	private short bashoCode;

	/**
	 * 登録休館日リスト</BR>
	 * ※休館場所設定で使用
	 */
	private List<LocalDate> insKyukanbi;

	/**
	 * 削除休館日リスト</BR>
	 * ※休館場所設定で使用
	 */
	private List<LocalDate> delKyukanbi;

	/**
	 * 閉鎖種類設定日リスト</BR>
	 * ※休館一括設定で使用
	 */
	private List<LocalDate> heisaDateList;

	/**
	 * 閉鎖種類設定開始時間</BR>
	 * ※休館一括設定で使用
	 */
	private String heisaStartTime;

	/**
	 * 閉鎖種類設定終了時間</BR>
	 * ※休館一括設定で使用
	 */
	private String heisaEndTime;


	private String bashoName;
	private String shisetsuName;
	private String kashidashiTaniName;
	private LocalDate startDate;
	private LocalDate endDate;
	private List<String> heisaShuruiCodes;

	/**
	 * 画面に表示する閉鎖日を返却します.
	 *
	 * @return
	 */
	public String getDisplayHeisaDate() {
		return CalendarUtils.toFormatyyyyMdSeparatedBySlashes(getHeisaDate());
	}

	/**
	 * 画面に表示する開始、終了時間を返却します.
	 *
	 * @return
	 */
	public String getDisplayHeisaTime() {
		return TimeUtils.toTimeRangeFormat(getStartTime(), getEndTime());
	}

	/**
	 * 閉鎖施設名称を返却します.</BR>
	 *
	 * @return 閉鎖施設名称
	 */
	public String getHeisaShisetsuName() {
		StringBuilder buff = new StringBuilder(bashoName);
		buff.append(Constants.SPACE);
		buff.append(shisetsuName);
		buff.append(Constants.SPACE);
		buff.append(kashidashiTaniName);
		return buff.toString();
	}

	public String getHeisaShuruiName() {
		return HeisaShurui.getName(getHeisaShurui());
	}
}
