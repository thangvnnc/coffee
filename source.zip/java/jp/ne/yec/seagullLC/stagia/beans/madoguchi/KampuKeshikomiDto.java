package jp.ne.yec.seagullLC.stagia.beans.madoguchi;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import jp.ne.yec.seagullLC.stagia.beans.enums.domain.KampuHoho;
import jp.ne.yec.seagullLC.stagia.beans.enums.domain.base.StagiaEnum;
import jp.ne.yec.seagullLC.stagia.beans.madoguchi.base.IKeshikomiDto;
import jp.ne.yec.seagullLC.stagia.entity.TKampu;
import jp.ne.yec.seagullLC.stagia.entity.TKampuMeisai;
import jp.ne.yec.seagullLC.stagia.entity.TRyokin;
import lombok.Getter;
import lombok.Setter;

/**
 * @author nao-hirata
 *
 */
@Setter
@Getter
@SuppressWarnings("serial")
public class KampuKeshikomiDto extends TKampu implements IKeshikomiDto {

	private Integer id;
	private Integer shinseiNumber;
	private Short meisaiNumber;
	private Short bashoCode;
	private Short shisetsuCode;
	private Short kashidashiTaniCode;
	private Date shiyoDate;
	private Short startTime;
	private Short endTime;
	private String shinseishaName;
	private String ryokinKubun;
	private String loginId;

	private List<ShinseiMeisaiDtoForMadoguchi> meisaiDtos = new ArrayList<>();
	private List<TKampuMeisai> tKampuMeisais = new ArrayList<>();
	private List<TRyokin> tRyokins = new ArrayList<>();

	private boolean isUpdating = false;
	private boolean isDeleting = false;

	private KampuHoho updateKampuHoho;
	private Date updateYoteiDate;
	private Date updateSeisanDate;
	private Date updateChoteiDate;
	private Date updateUketsukeDate;
	private Short updateUketsukeBashoCode;


	@Override
	public Integer getSeisanNumber() {
		return getKampuNumber();
	}

	@Override
	public Date getSeisanDate() {
		return getKampuDate();
	}

	@Override
	public Integer getSeisanGaku() {
		return getKampuGaku();
	}

	@Override
	public void setUpdateSeisanDate(Date updateSeisanDate) {
		this.updateSeisanDate = updateSeisanDate;
	}

	@Override
	public void setUpdateSeisanHoho(StagiaEnum seisanHoho) {
		this.updateKampuHoho = (KampuHoho) seisanHoho;
	}

	@Override
	public Date getUpdateSeisanDate() {
		return updateSeisanDate;
	}

	@Override
	public String getSeisanHohoName() {
		return KampuHoho.getName(getKampuHoho());
	}

	@Override
	public StagiaEnum getUpdateSeisanHoho() {
		return updateKampuHoho;
	}

	@Override
	public boolean isSummary() {
		return false;
	}
}
