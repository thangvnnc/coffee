package jp.ne.yec.seagullLC.stagia.beans.master;

import jp.ne.yec.seagullLC.stagia.entity.MRyokinTaikei;

public class RyokinTaikeiDto extends MRyokinTaikei {

	public String getDisplayRyokinTaikeiCode() {
		return String.valueOf(getRyokinTaikeiCode());
	}
	public String getDisplayRyokinTaikeiName() {
		return getRyokinTaikeiName();
	}

}
