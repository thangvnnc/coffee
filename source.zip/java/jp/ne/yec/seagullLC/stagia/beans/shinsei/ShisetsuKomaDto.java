package jp.ne.yec.seagullLC.stagia.beans.shinsei;

import jp.ne.yec.seagullLC.stagia.entity.MKoma;
import jp.ne.yec.seagullLC.stagia.util.TimeUtils;
import lombok.Getter;
import lombok.Setter;


/**
 * 施設のコマ情報を保持するDTOクラスです.
 *
 * @author sic-hanaoka
 *
 */
@Getter
@Setter
@SuppressWarnings("serial")
public class ShisetsuKomaDto extends MKoma {

	/**
	 * 画面表示用にフォーマットした使用時間(開始時間～終了時間)を返却します.
	 *
	 * @return
	 */
	public String getDisplayKomaTime() {
		return TimeUtils.toTimeRangeFormat(getStartTime(), getEndTime());
	}

}
