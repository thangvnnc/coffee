package jp.ne.yec.seagullLC.stagia.beans.enums.domain;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import org.apache.commons.lang.StringUtils;

import jp.ne.yec.seagullLC.stagia.beans.enums.domain.base.StagiaEnum;

/**
 * Generated on Mon Feb 05 19:18:18 JST 2018 based on <br>
 * ドメイン定義票（表示先種類）.xlsx.
 * <p>
 * 	お知らせの表示先を保持する列挙型です。<br>
 * </p>
 */
public enum HyojisakiShurui implements StagiaEnum  {
	SHOKUIN_ALL("1", "職員全体"),
	SHOKUIN_SHOZOKU("2", "職員所属"),
	SHOKUIN_KOJIN("3", "職員個人"),
	MEDIA_ALL("4", "メディア全体"),
	MEDIA_SHINSEI_GROUP("5", "メディア申請グループ"),
	MEDIA_RIYOSHA("6", "メディア利用者"),
;
	private String code;
	private String name;

	private HyojisakiShurui(String code, String name) {
		this.code = code;
		this.name = name;
	}

	public String getCode() {
		return this.code;
	}

	public String getName() {
		return this.name;
	}

	/**
	 * 引数のコードを保持する列挙子を返却します.
	 * 存在しない場合、{@code null}を返却します.
	 *
	 * @param code
	 * @return - codeを保持するHyojisakiShurui
	 */
	public static HyojisakiShurui getEnumClass(String code) {
		return Stream.of(values()).filter(e -> e.getCode().equals(code)).findFirst().orElse(null);
	}

	/**
	 * 引数のコードを保持する列挙子の名称を返却します.
	 * 存在しない場合、{@code StringUtils.EMPTY}を返却します.
	 *
	 * @param code
	 * @return - codeを保持するHyojisakiShuruiのname
	 */
	public static String getName(String code) {
		HyojisakiShurui enumClass = getEnumClass(code);
		if (null == enumClass) {
			return StringUtils.EMPTY;
		}
		return enumClass.getName();
	}

	/**
	 * HyojisakiShuruiの列挙子全てをList型で返却します.
	 *
	 * @return - HyojisakiShuruiのList
	 */
	public static List<HyojisakiShurui> getList() {
		return Arrays.asList(values());
	}
}
