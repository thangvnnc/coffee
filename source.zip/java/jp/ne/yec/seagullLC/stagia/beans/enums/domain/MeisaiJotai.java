package jp.ne.yec.seagullLC.stagia.beans.enums.domain;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import org.apache.commons.lang.StringUtils;

import jp.ne.yec.seagullLC.stagia.beans.enums.domain.base.StagiaEnum;

/**
 * Generated on Mon Feb 05 19:18:17 JST 2018 based on <br>
 * ドメイン定義票（明細状態）.xlsx.
 * <p>
 * 	明細が取りうる状態を保持する列挙型です。<br>
 * </p>
 */
public enum MeisaiJotai implements StagiaEnum  {
	SHINKI("0", "新規"),
	HENKO("1", "変更"),
	TORIKESHI("2", "取消"),
	TEISEI_TORIKESHI("3", "訂正取消"),
	TOSEN_KIKAN_CHOKA("4", "当選期間超過"),
	RAIHO_DATE_CHOKA("5", "来訪日超過"),
	MUDAN_CANCEL("6", "無断キャンセル"),
;
	private String code;
	private String name;

	private MeisaiJotai(String code, String name) {
		this.code = code;
		this.name = name;
	}

	public String getCode() {
		return this.code;
	}

	public String getName() {
		return this.name;
	}

	/**
	 * 引数のコードを保持する列挙子を返却します.
	 * 存在しない場合、{@code null}を返却します.
	 *
	 * @param code
	 * @return - codeを保持するMeisaiJotai
	 */
	public static MeisaiJotai getEnumClass(String code) {
		return Stream.of(values()).filter(e -> e.getCode().equals(code)).findFirst().orElse(null);
	}

	/**
	 * 引数のコードを保持する列挙子の名称を返却します.
	 * 存在しない場合、{@code StringUtils.EMPTY}を返却します.
	 *
	 * @param code
	 * @return - codeを保持するMeisaiJotaiのname
	 */
	public static String getName(String code) {
		MeisaiJotai enumClass = getEnumClass(code);
		if (null == enumClass) {
			return StringUtils.EMPTY;
		}
		return enumClass.getName();
	}

	/**
	 * MeisaiJotaiの列挙子全てをList型で返却します.
	 *
	 * @return - MeisaiJotaiのList
	 */
	public static List<MeisaiJotai> getList() {
		return Arrays.asList(values());
	}
}
