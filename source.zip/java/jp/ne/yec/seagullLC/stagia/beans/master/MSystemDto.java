package jp.ne.yec.seagullLC.stagia.beans.master;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import jp.ne.yec.sane.beans.StringCodeNamePair;
import jp.ne.yec.seagullLC.stagia.beans.enums.Nijutoroku;
import jp.ne.yec.seagullLC.stagia.beans.enums.domain.NijutorokuHanteiHani;
import jp.ne.yec.seagullLC.stagia.entity.MMailServer;
import jp.ne.yec.seagullLC.stagia.entity.MNijutoroku;
import jp.ne.yec.seagullLC.stagia.entity.MSystem;
import lombok.Getter;
import lombok.Setter;

/**
 * 「m_system」の情報を保持するDTOクラスです.
 *
 * @author sic-hanaoka
 *
 */
@Getter
@Setter
@SuppressWarnings("serial")
public class MSystemDto extends MSystem {

	// 二重登録判定範囲
	private NijutorokuHanteiHani selectedNijutorokuHanteiHani;

	// WEB利用者グループ記定値
	private StringCodeNamePair selectedRiyoshaGroupName;

	// 二重登録判定項目チェックリスト
	List<Nijutoroku> nijutorokuCK = new ArrayList<>();

	private MNijutoroku mNijutoroku;
	private String inputServiceStartTime;
	private String inputServiceEndTime;
	private String inputUketsukeStartTime;
	private String inputUketsukeEndTime;

	//休止日追加変数
	private Date kyushiDate;

	// 休止日一覧リスト
	List<Date> kyushibiList;
	List<Date> orgKyushibiList;

	// M_メールサーバ
	private MMailServer mMailServer;

	// M_消費税
	List<TaxDto> taxList;
	List<TaxDto> orgTaxList;
}
