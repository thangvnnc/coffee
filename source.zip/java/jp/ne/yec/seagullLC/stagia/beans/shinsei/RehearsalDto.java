/**
 *
 */
package jp.ne.yec.seagullLC.stagia.beans.shinsei;

import java.util.Objects;

import jp.ne.yec.seagullLC.stagia.entity.MRehearsal;
import jp.ne.yec.seagullLC.stagia.entity.TRehearsal;
import lombok.Getter;
import lombok.Setter;

/**
 * @author nao-hirata
 *
 */
@SuppressWarnings("serial")
public class RehearsalDto extends TRehearsal {

	@Getter
	@Setter
	private String rehearsalKomaLabel;

	@Getter
	private MRehearsal selectedRehearsal;

	/**
	 * selectedRehearsalを設定します.
	 *
	 * @param selectedRehearsal セットする selectedRehearsal
	 */
	public void setSelectedRehearsal(MRehearsal selectedRehearsal) {
		this.selectedRehearsal = selectedRehearsal;
		Short rehearsalCode = Objects.nonNull(selectedRehearsal) ? selectedRehearsal.getRehearsalCode() : null;
		setRehearsalCode(rehearsalCode);
	}

}
