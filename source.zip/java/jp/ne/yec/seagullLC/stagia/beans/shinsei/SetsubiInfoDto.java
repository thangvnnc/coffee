package jp.ne.yec.seagullLC.stagia.beans.shinsei;

import java.util.List;
import java.util.Objects;

import jp.ne.yec.seagullLC.stagia.common.Constants;
import jp.ne.yec.seagullLC.stagia.entity.MSetsubi;
import lombok.Getter;
import lombok.Setter;


/**
 * 設備情報を保持するDTOクラスです.
 *
 * @author sic-hanaoka
 *
 */
@Getter
@Setter
@SuppressWarnings("serial")
public class SetsubiInfoDto extends MSetsubi {

	/**
	 * 設備分類名称
	 */
	private String setsubiBunruiName;

	/**
	 * 設備使用数(画面入力項目)
	 */
	private String useNum = "0";

	/**
	 * 開始コマ</BR>
	 * ※自動設備取得時(自動設備開始コマ)、利用可能設備取得(設備料金の開始コマ)に使用
	 *
	 */
	private Short startKoma;

	/**
	 * 終了コマ</BR>
	 * ※自動設備取得時(自動設備終了コマ)、利用可能設備取得(設備料金の終了コマ)に使用
	 */
	private Short endKoma;

	/**
	 * 自動設備設定数量</BR>
	 * ※自動設備設定時に使用
	 */
	private Short jidoSetsubiSuryo;

	/**
	 * 在庫チェック用数量</BR>
	 * ※在庫チェック時に使用
	 */
	private Integer zaikoCheckNum;

	/**
	 * セット設備を構成している設備リスト</BR>
	 * 設備追加画面表示時の在庫更新時に格納されます.</BR>
	 * ※セット設備の場合のみ格納
	 */
	private List<SetSetsubiInfoDto> koseiList;

	/**
	 * 画面表示用の在庫数を返却します.
	 *
	 * @return
	 */
	public String getDisplayZaikoNum() {
		if (Objects.isNull(getZaikosu())) {
			return Constants.HYPHEN;
		}
		return String.valueOf(getZaikosu()).concat(getTani());
	}

	/**
	 * 設備を一意としたキー値を返却します.
	 *
	 * @return setsubiBunruiCode * 10000 + getSetsubiCode
	 */
	public int getSetsubiKey() {
		return getSetsubiBunruiCode() * 10000 + getSetsubiCode();
	}
}
