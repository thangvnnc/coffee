package jp.ne.yec.seagullLC.stagia.beans.unei;

import java.io.Serializable;

import org.apache.commons.lang.StringUtils;

import lombok.Getter;
import lombok.Setter;

/**
 * バッチ起動の一覧表示用のDTO</BR>
 * ・一行分の情報を保持します.</BR>
 * 当選削除、仮予約削除、無断キャンセル更新で使用します.
 *
 * @author sic-hanaoka
 *
 */
@Setter
@Getter
@SuppressWarnings("serial")
public class BatchKidoViewDto implements Serializable {
	/**
	 * 処理対象有無
	 */
	private boolean isTarget = false;

	/**
	 * 管理コード
	 */
	private Short kanriCode = 0;

	/**
	 * 管理名
	 */
	private String kanriName = StringUtils.EMPTY;

	/**
	 * 処理対象件数
	 */
	private Integer targetNum = 0;

}
