/**
 *
 */
package jp.ne.yec.seagullLC.stagia.beans.shinsei;

import org.apache.commons.lang.StringUtils;

import jp.ne.yec.seagullLC.stagia.entity.TKoenTime;
import jp.ne.yec.seagullLC.stagia.util.TimeUtils;

/**
 * @author nao-hirata
 *
 */
@SuppressWarnings("serial")
public class KoenTimeDto extends TKoenTime {

	public String getDisplayTime1() {
		if (null == getKoenTime1()) {
			return StringUtils.EMPTY;
		}
		return TimeUtils.toTimeFormatWithColon(getKoenTime1());
	}

	public String getDisplayTime2() {
		if (null == getKoenTime2()) {
			return StringUtils.EMPTY;
		}
		return TimeUtils.toTimeFormatWithColon(getKoenTime2());
	}

	public String getDisplayTime3() {
		if (null == getKoenTime3()) {
			return StringUtils.EMPTY;
		}
		return TimeUtils.toTimeFormatWithColon(getKoenTime3());
	}

	public String getDisplayTime4() {
		if (null == getKoenTime4()) {
			return StringUtils.EMPTY;
		}
		return TimeUtils.toTimeFormatWithColon(getKoenTime4());
	}
}
