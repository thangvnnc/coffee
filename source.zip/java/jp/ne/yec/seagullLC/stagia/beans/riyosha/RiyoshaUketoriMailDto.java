package jp.ne.yec.seagullLC.stagia.beans.riyosha;

import java.io.Serializable;

import jp.ne.yec.seagullLC.stagia.entity.TRiyoshaUketoriMail;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@SuppressWarnings("serial")
public class RiyoshaUketoriMailDto extends TRiyoshaUketoriMail implements Serializable {

}
