package jp.ne.yec.seagullLC.stagia.beans.enums.domain;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import org.apache.commons.lang.StringUtils;

import jp.ne.yec.seagullLC.stagia.beans.enums.domain.base.StagiaEnum;

/**
 * Generated on Mon Feb 05 19:18:17 JST 2018 based on <br>
 * ドメイン定義票（期間終了日算出単位）.xlsx.
 * <p>
 * 	各種期間終了日を算出する際に使用する単位を保持する列挙型です。<br>
 * 	「ヵ月後（同日）」と「ヵ月後（同日月末補正）」の違いについて<br>
 * 	9/30を起点にした場合、<br>
 * 	「1ヵ月後（同日）」は「10/30」となります。<br>
 * 	「1ヵ月後（同日月末補正）」は「10/31」となります。<br>
 * </p>
 */
public enum KikanEndTani implements StagiaEnum  {
	NICHIGO("0", "日後"),
	KAGETSUGO_DOJITSU("1", "ヵ月後（同日）"),
	KAGETSUGO_DOJITSU_GETSUMATSUHOSEI("2", "ヵ月後（同日月末補正）"),
	KAGETSUGO_GETSUMATSU("3", "ヵ月後（月末）"),
;
	private String code;
	private String name;

	private KikanEndTani(String code, String name) {
		this.code = code;
		this.name = name;
	}

	public String getCode() {
		return this.code;
	}

	public String getName() {
		return this.name;
	}

	/**
	 * 引数のコードを保持する列挙子を返却します.
	 * 存在しない場合、{@code null}を返却します.
	 *
	 * @param code
	 * @return - codeを保持するKikanEndTani
	 */
	public static KikanEndTani getEnumClass(String code) {
		return Stream.of(values()).filter(e -> e.getCode().equals(code)).findFirst().orElse(null);
	}

	/**
	 * 引数のコードを保持する列挙子の名称を返却します.
	 * 存在しない場合、{@code StringUtils.EMPTY}を返却します.
	 *
	 * @param code
	 * @return - codeを保持するKikanEndTaniのname
	 */
	public static String getName(String code) {
		KikanEndTani enumClass = getEnumClass(code);
		if (null == enumClass) {
			return StringUtils.EMPTY;
		}
		return enumClass.getName();
	}

	/**
	 * KikanEndTaniの列挙子全てをList型で返却します.
	 *
	 * @return - KikanEndTaniのList
	 */
	public static List<KikanEndTani> getList() {
		return Arrays.asList(values());
	}
}
