package jp.ne.yec.seagullLC.stagia.beans.master;

import java.util.List;

import jp.ne.yec.sane.beans.StringCodeNamePair;
import jp.ne.yec.seagullLC.stagia.beans.enums.domain.HasushoriHoho;
import jp.ne.yec.seagullLC.stagia.beans.enums.domain.HasushoriKetasu;
import jp.ne.yec.seagullLC.stagia.beans.enums.domain.JutoRiyoHani;
import jp.ne.yec.seagullLC.stagia.beans.enums.domain.KampuChoteiKijunDate;
import jp.ne.yec.seagullLC.stagia.beans.enums.domain.KampuHoho;
import jp.ne.yec.seagullLC.stagia.beans.enums.domain.KuriageEnchoSanshutsuHoshiki;
import jp.ne.yec.seagullLC.stagia.beans.enums.domain.NyujoryokinSanshutsuKijun;
import jp.ne.yec.seagullLC.stagia.beans.enums.domain.RyokinTaikeiTekiyoHani;
import jp.ne.yec.seagullLC.stagia.beans.enums.domain.RyoshuChoteiKijunDate;
import jp.ne.yec.seagullLC.stagia.beans.enums.domain.RyoshuHoho;
import jp.ne.yec.seagullLC.stagia.beans.enums.domain.TojitsuShinseiKigenKijun;
import jp.ne.yec.seagullLC.stagia.beans.enums.domain.ZenjitsuYokujitsuKubun;
import jp.ne.yec.seagullLC.stagia.entity.MJorei;
import jp.ne.yec.seagullLC.stagia.entity.MKanri;
import jp.ne.yec.seagullLC.stagia.entity.MRyokinTaikei;
import jp.ne.yec.seagullLC.stagia.entity.MWebSettei;
import lombok.Getter;
import lombok.Setter;

/**
 * 「m_kanri」の情報を保持するDTOクラスです.
 *
 * @author sic-hanaoka
 *
 */
@Getter
@Setter
@SuppressWarnings("serial")
public class MKanriDto extends MKanri {

	// M_WEB設定
	private MWebSettei mWebSettei;

	// M_条例
	private MJorei mJorei;

	// M_料金体系
	private MRyokinTaikei mRyokinTaikei;

	// M_料金体系
	List<RyokinTaikeiDto> ryokinTaikeiList;
	List<RyokinTaikeiDto> orgRyokinTaikeiList;

	// 管理コード
	private StringCodeNamePair selectedKanriCode;

	// 料金体系
	private String selectedRyokinTaikei;

	// 受付場所既定値
	private StringCodeNamePair selectedUketsukeBasho;

	// 利用者グループ
	private StringCodeNamePair selectedRiyoshaGroupName;

	// 還付方法既定値
	private KampuHoho selectedKampuHohoKiteichi;

	// 領収方法既定値
	private RyoshuHoho selectedRyoshuHohoKiteichi;

	// 領収調定基準日
	private RyoshuChoteiKijunDate selectedRyoshuChoteiKijunDate;

	// 還付調定基準日
	private KampuChoteiKijunDate selectedKampuChoteiKijunDate;

	// 充当利用範囲
	private JutoRiyoHani selectedJutoRiyoHani;

	// 料金体系適用範囲
	private RyokinTaikeiTekiyoHani selectedRyokinTaikeiTekiyoHani;

	// 繰上延長算出方式
	private KuriageEnchoSanshutsuHoshiki selectedKuriageEnchoSanshutsuHoshiki;

	// 入場料金算出基準
	private NyujoryokinSanshutsuKijun selectedNyujoryokinSanshutsuKijun;

	// 領収還付端数処理桁数
	private HasushoriKetasu selectedRyoshuKampuHasushoriKetasu;

	// 領収還付端数処理方法
	private HasushoriHoho selectedRyoshuKampuHasushoriHoho;

	//領収予定日振替方式
	private ZenjitsuYokujitsuKubun selectedRyoshuFurikaeHoshiki;

	//受付開始日振替方式
	private ZenjitsuYokujitsuKubun selectedUketsukeFurikaeHoshiki;

	//当日申請期限算出基準
	private TojitsuShinseiKigenKijun selectedTojitsuShinseiKigenKijun;
}
