package jp.ne.yec.seagullLC.stagia.beans.excel;

import java.util.HashMap;
import java.util.Map;

import org.apache.poi.ss.util.CellReference;

import jp.ne.yec.seagullLC.stagia.beans.enums.RyokinExcelSheetName;
import jp.ne.yec.seagullLC.stagia.beans.enums.domain.KeisanHoho;
import jp.ne.yec.seagullLC.stagia.entity.MRyokinKeisanShiki;
import jp.ne.yec.seagullLC.stagia.entity.TRyokinSanshutsuKomoku;
import lombok.Getter;
import lombok.Setter;

/**
 * 料金計算Excelを表現するBean.
 *
 * @author nao-hirata
 *
 */
public abstract class RyokinKeisanExcelSheet {

	public static final Integer PERCENT_COLUMN = 4;
	public static final Integer COUNT_COLUMN = 5;

	public abstract RyokinExcelSheetName getSheetName();

	@Setter
	@Getter
	private CellReference kihonRyokinCell = new CellReference("G5");

	@Setter
	@Getter
	private int kihonRyokin;

	@Getter
	private Map<Short, ExcelRow> rows = new HashMap<>();


	/**
	 * 料金計算Excelの１行を保持するBean.
	 *
	 * @author nao-hirata
	 *
	 */
	@Setter
	@Getter
	public class ExcelRow {
		KeisanHoho keisanHoho;
		private Short ritsu;
		private Double kingaku;
		private int kuriageEnchoCount = 0;
		private CellReference calculateCell;
		private String formula;
		private double calculationResult = 0;
	}

	/**
	 * @param calcItem
	 * @param keisanShiki
	 * @param mRyokinKeisanTekiyo
	 */
	public void makeCalculationRow(TRyokinSanshutsuKomoku calcItem, MRyokinKeisanShiki keisanShiki) {
		ExcelRow row = new ExcelRow();
		row.setKeisanHoho(calcItem.getKeisanHoho());
		row.setRitsu(calcItem.getSanshutsuRitsu());
		row.setKingaku(calcItem.getSanshutsuRyokin().doubleValue());
		row.setCalculateCell(new CellReference(keisanShiki.getCell()));
		row.setFormula(keisanShiki.getKeisanShiki());
		rows.put(keisanShiki.getKeisanKomokuCode(), row);
	}

	/**
	 * @param calcItem
	 * @param keisanShiki
	 */
	public void makeCalculationResultRow(MRyokinKeisanShiki keisanShiki) {
		ExcelRow row = new ExcelRow();
		row.setKeisanHoho(KeisanHoho.RITSU);
		row.setCalculateCell(new CellReference(keisanShiki.getCell()));
		row.setFormula(keisanShiki.getKeisanShiki());
		rows.put(keisanShiki.getKeisanKomokuCode(), row);
	}

	/**
	 * @param calcItem
	 * @param komaKeisanShiki
	 * @param overTimeCount
	 */
	public void makeCalculationRow(TRyokinSanshutsuKomoku calcItem, MRyokinKeisanShiki meisaiKeisanShiki,
			int overTimeCount) {
		makeCalculationRow(calcItem, meisaiKeisanShiki);
		if (0 == overTimeCount) {
			return;
		}
		if (KeisanHoho.GAKU.equals(calcItem.getKeisanHoho())) {
			return;

		}
		ExcelRow row = rows.get(meisaiKeisanShiki.getKeisanKomokuCode());
		row.setKuriageEnchoCount(overTimeCount);
	}

}
