/**
 *
 */
package jp.ne.yec.seagullLC.stagia.beans.search;

import java.io.Serializable;
import java.time.LocalDate;

import org.apache.commons.lang.StringUtils;

import jp.ne.yec.seagullLC.stagia.beans.enums.domain.ShinseiShurui;
import jp.ne.yec.seagullLC.stagia.util.TimeUtils;
import lombok.Getter;
import lombok.Setter;

/**
 * 空き状況の１コマを表現するクラス.
 *
 * @author nao-hirata
 *
 */
@Getter
@Setter
@SuppressWarnings("serial")
public class AkijokyoKomaDto implements Serializable {

	private String id;
	private int rowNo;

	private LocalDate date;
	private String dayOfWeek;
	private Short startKoma;
	private Short endKoma;
	private Short startTime;
	private Short endTime;
	private boolean isReservable;
	private String komaName;
	private String status;
	private ShinseiShurui shinseiShurui;

	private String kanriCode;
	private String shisetsuCode;

	/**
	 * 台帳表示用の時間を返却します.
	 *
	 * @return 台帳に表示するコマ時間
	 */
	public String getDisplayTime() {
		if (null == startTime) {
			return StringUtils.EMPTY;
		}
		return TimeUtils.toTimeRangeFormat(startTime, endTime);
	}

	/**
	 * 台帳に表示する時間または名称を返却します.
	 *
	 * @return
	 */
	public String getDisplayTimeOrName() {
		if (StringUtils.isNotEmpty(komaName)) {
			return komaName;
		}
		return getDisplayTime();
	}
}
