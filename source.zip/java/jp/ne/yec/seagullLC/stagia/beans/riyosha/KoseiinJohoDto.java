package jp.ne.yec.seagullLC.stagia.beans.riyosha;

import java.io.Serializable;

import org.apache.commons.lang.StringUtils;

import jp.ne.yec.seagullLC.stagia.beans.enums.domain.KoseiinYakuwari;
import jp.ne.yec.seagullLC.stagia.entity.TKoseiin;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@SuppressWarnings("serial")
public class KoseiinJohoDto extends TKoseiin implements Serializable {

	private String updateKbn = StringUtils.EMPTY;
	private String koseiinCodeColumn;
	private String koseinYakuwariName;
	private KoseiinYakuwari koseiinYakuwariSelect;

	/**
	 * 構成員情報を一意判別するKey文字列を返却します.
	 * @return
	 */
	public String getKoseiinKey() {
		return getLoginId().concat(String.valueOf(getKoseiinCode()));
	}
}
