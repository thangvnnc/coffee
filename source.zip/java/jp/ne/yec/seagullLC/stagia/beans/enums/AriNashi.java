package jp.ne.yec.seagullLC.stagia.beans.enums;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import org.apache.commons.lang.StringUtils;

public enum AriNashi {
	ARI(true, "有"),
	NASHI(false, "無"),
;
	private boolean bool;
	private String name;

	private AriNashi(boolean bool, String name) {
		this.bool = bool;
		this.name = name;
	}

	public boolean isBool() {
		return this.bool;
	}

	public String getName() {
		return this.name;
	}

	/**
	 * 引数のコードを保持する列挙子を返却します.
	 * 存在しない場合、{@bool null}を返却します.
	 *
	 * @param bool
	 * @return - boolを保持するAriNashi
	 */
	public static AriNashi getEnumClass(boolean bool) {
		return Stream.of(values()).filter(e -> e.isBool() == bool).findFirst().orElse(null);
	}

	/**
	 * 引数のコードを保持する列挙子の名称を返却します.
	 * 存在しない場合、{@bool StringUtils.EMPTY}を返却します.
	 *
	 * @param bool
	 * @return - boolを保持するAriNashiのname
	 */
	public static String getName(boolean bool) {
		AriNashi enumClass = getEnumClass(bool);
		if (null == enumClass) {
			return StringUtils.EMPTY;
		}
		return enumClass.getName();
	}

	/**
	 * AriNashiの列挙子全てをList型で返却します.
	 *
	 * @return - AriNashiのList
	 */
	public static List<AriNashi> getList() {
		return Arrays.asList(values());
	}

}