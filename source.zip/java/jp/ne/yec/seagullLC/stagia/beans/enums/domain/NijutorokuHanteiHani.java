package jp.ne.yec.seagullLC.stagia.beans.enums.domain;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import org.apache.commons.lang.StringUtils;

import jp.ne.yec.seagullLC.stagia.beans.enums.domain.base.StagiaEnum;

/**
 * Generated on Mon Feb 05 19:18:16 JST 2018 based on <br>
 * ドメイン定義票（二重登録判定範囲）.xlsx.
 * <p>
 * 	二重登録チェックのチェック範囲を保持する列挙型です。<br>
 * </p>
 */
public enum NijutorokuHanteiHani implements StagiaEnum  {
	NONE("0", "二重登録判定しない"),
	DOITSU("1", "利用者／構成員同士で判定"),
	KONZAI("2", "利用者／構成員混在で判定"),
;
	private String code;
	private String name;

	private NijutorokuHanteiHani(String code, String name) {
		this.code = code;
		this.name = name;
	}

	public String getCode() {
		return this.code;
	}

	public String getName() {
		return this.name;
	}

	/**
	 * 引数のコードを保持する列挙子を返却します.
	 * 存在しない場合、{@code null}を返却します.
	 *
	 * @param code
	 * @return - codeを保持するNijutorokuHanteiHani
	 */
	public static NijutorokuHanteiHani getEnumClass(String code) {
		return Stream.of(values()).filter(e -> e.getCode().equals(code)).findFirst().orElse(null);
	}

	/**
	 * 引数のコードを保持する列挙子の名称を返却します.
	 * 存在しない場合、{@code StringUtils.EMPTY}を返却します.
	 *
	 * @param code
	 * @return - codeを保持するNijutorokuHanteiHaniのname
	 */
	public static String getName(String code) {
		NijutorokuHanteiHani enumClass = getEnumClass(code);
		if (null == enumClass) {
			return StringUtils.EMPTY;
		}
		return enumClass.getName();
	}

	/**
	 * NijutorokuHanteiHaniの列挙子全てをList型で返却します.
	 *
	 * @return - NijutorokuHanteiHaniのList
	 */
	public static List<NijutorokuHanteiHani> getList() {
		return Arrays.asList(values());
	}
}
