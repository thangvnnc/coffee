package jp.ne.yec.seagullLC.stagia.beans.shokai;

import java.io.Serializable;
import java.time.LocalDate;

import jp.ne.yec.sane.beans.StringCodeNamePair;
import jp.ne.yec.seagullLC.stagia.beans.enums.JokenHukumu;
import jp.ne.yec.seagullLC.stagia.beans.enums.domain.KoseiinYakuwari;
import jp.ne.yec.seagullLC.stagia.beans.enums.domain.KozaShubetsu;
import lombok.Getter;
import lombok.Setter;

/**
 * 窓口業務-照会で指定された条件を保持するクラスです.</BR>
 * 照会条件：利用者
 *
 * @author sic-hanaoka
 *
 */
@Setter
@Getter
@SuppressWarnings("serial")
public class SearchRiyoshaConditionsDto implements Serializable {

	// --- 利用者条件項目 ---
	/**
	 * ログインID
	 */
	private String rLoginId;
	/**
	 * ログインID検索条件(入力条件)
	 */
	private JokenHukumu rLoginIdMuchSelect;
	/**
	 * ログインID検索条件(検索用)
	 */
	private String loginIdMuchSelect;
	/**
	 * 使用目的(入力条件)
	 */
	private StringCodeNamePair rShiyoMokutekiSelect;
	/**
	 * 使用目的(検索用)
	 */
	private Short shiyoMokutekiCd;
	/**
	 * 登録期間開始(入力条件)
	 */
	private String rCreatedStartDate;
	/**
	 * 登録期間開始(検索用)
	 */
	private LocalDate createdStartDate;
	/**
	 * 登録期間終了(入力条件)
	 */
	private String rCreatedEndDate;
	/**
	 * 登録期間終了(検索用)
	 */
	private LocalDate createdEndDate;
	/**
	 * 有効期間開始(入力条件)
	 */
	private String rYukokikanStartDate;
	/**
	 * 有効期間開始(検索用)
	 */
	private LocalDate yukokikanStartDate;
	/**
	 * 有効期間終了(入力条件)
	 */
	private String rYukokikanEndDate;
	/**
	 * 有効期間終了(検索用)
	 */
	private LocalDate yukokikanEndDate;
	/**
	 * 停止期間開始(入力条件)
	 */
	private String rShinseiTeishiStartDate;
	/**
	 * 停止期間開始(検索用)
	 */
	private LocalDate shinseiTeishiStartDate;
	/**
	 * 停止期間終了(入力条件)
	 */
	private String rShinseiTeishiEndDate;
	/**
	 * 停止期間終了(検索用)
	 */
	private LocalDate shinseiTeishiEndDate;
	/**
	 * 使用人数
	 */
	private Integer rShiyoNinzu;
	/**
	 * ペナルティ有無(入力条件)
	 */
	private StringCodeNamePair rPenaltySelect;
	/**
	 * ペナルティ有無(検索用)
	 */
	private String penaltySelect;
	/**
	 * カナ氏名
	 */
	private String rKanaName;
	/**
	 * 電話番号
	 */
	private String rDenwaBango;
	/**
	 * 郵便番号
	 */
	private String rYubinBango;
	/**
	 * 住所
	 */
	private String rJusho;
	/**
	 * 口座情報-銀行(入力条件)
	 */
	private StringCodeNamePair rGinkoNameSelect;
	/**
	 * 口座情報-銀行(検索用)
	 */
	private Short ginkoCode;
	/**
	 * 口座情報-支店(入力条件)
	 */
	private StringCodeNamePair rShitenNameSelect;
	/**
	 * 口座情報-支店(検索用)
	 */
	private Short shitenCode;
	/**
	 * 口座情報-カナ名義人
	 */
	private String kozaMeigininKanaName;
	/**
	 * 口座情報-口座種別(入力条件)
	 */
	private KozaShubetsu rKozaShubetsuSelect;
	/**
	 * 口座情報-口座種別(検索用)
	 */
	private String kozaShubetsu;
	/**
	 * 口座情報-口座番号
	 */
	private String kozaNumber;
	/**
	 * 構成員情報-役割(入力条件)
	 */
	private KoseiinYakuwari rKoseiinYakuwariSelect;
	/**
	 * 構成員情報-役割(検索用)
	 */
	private String koseiinYakuwari;
	/**
	 * 構成員情報-カナ氏名
	 */
	private String rKoseiinKanaName;
	/**
	 * 構成員情報-郵便番号
	 */
	private String rKoseiinYubinBango;
	/**
	 * 構成員情報-住所
	 */
	private String rKoseiinJusho;
	/**
	 * 構成員情報-電話番号
	 */
	private String rKoseiinDenwaBango;

}
