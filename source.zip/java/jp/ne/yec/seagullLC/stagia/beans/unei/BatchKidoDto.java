package jp.ne.yec.seagullLC.stagia.beans.unei;

import java.io.Serializable;
import java.util.List;

import jp.ne.yec.seagullLC.stagia.beans.enums.domain.BatchShurui;
import lombok.Getter;
import lombok.Setter;

/**
 * バッチ起動用のDTO</BR>
 * 画面で選択された起動情報を保持します。
 *
 * @author sic-hanaoka
 *
 */
@Setter
@Getter
@SuppressWarnings("serial")
public class BatchKidoDto implements Serializable {
	/**
	 * 選択バッチ種類
	 */
	private BatchShurui selectedBatchType;

	/**
	 * 処理対象年月日</BR>
	 * 仮予約削除、無断キャンセル更新で使用
	 */
	private String targetDate;

	/**
	 * 抽選実行リスト
	 */
	private List<BatchLotoExeViewDto> batchLotoExeList;;

	/**
	 * バッチ起動リスト</BR>
	 * 当選削除、仮予約削除、無断キャンセル更新で使用します。
	 */
	private List<BatchKidoViewDto> batchExeList;

}
