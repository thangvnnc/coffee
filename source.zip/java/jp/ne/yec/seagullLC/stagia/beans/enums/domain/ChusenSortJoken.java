package jp.ne.yec.seagullLC.stagia.beans.enums.domain;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import org.apache.commons.lang.StringUtils;

import jp.ne.yec.seagullLC.stagia.beans.enums.domain.base.StagiaEnum;

/**
 * Generated on Mon Feb 05 19:18:17 JST 2018 based on <br>
 * ドメイン定義票（抽選ソート条件）.xlsx.
 * <p>
 * 	抽選実行方式(ソート条件)を管理する列挙型です。<br>
 * 	乱数          ：乱数を使用して抽選リストをソートします。<br>
 * 	優先順位      ：優先順位昇順で抽選リストをソートします。<br>
 * 	当選回数      ：当選回数降順で抽選リストをソートします。<br>
 * 	申込回数      ：申込回数昇順で抽選リストをソートします。<br>
 * 	登録日        ：利用者の登録日昇順で抽選リストをソートします。<br>
 * 	ペナルティ回数：ペナルティ回数昇順で抽選リストをソートします。<br>
 * 	申込日        ：申込日昇順で抽選リストをソートします。<br>
 * </p>
 */
public enum ChusenSortJoken implements StagiaEnum  {
	RANSU("0", "乱数"),
	YUSENJUNI("1", "優先順位"),
	TOSEN_KAISU("2", "当選回数"),
	MOSHIKOMI_KAISU("3", "申込回数"),
	TOROKU_DATE("4", "登録日付"),
	PENALTY_KAISU("5", "ペナルティ回数"),
	MOSHIKOMI_DATE("6", "申込日付"),
;
	private String code;
	private String name;

	private ChusenSortJoken(String code, String name) {
		this.code = code;
		this.name = name;
	}

	public String getCode() {
		return this.code;
	}

	public String getName() {
		return this.name;
	}

	/**
	 * 引数のコードを保持する列挙子を返却します.
	 * 存在しない場合、{@code null}を返却します.
	 *
	 * @param code
	 * @return - codeを保持するChusenSortJoken
	 */
	public static ChusenSortJoken getEnumClass(String code) {
		return Stream.of(values()).filter(e -> e.getCode().equals(code)).findFirst().orElse(null);
	}

	/**
	 * 引数のコードを保持する列挙子の名称を返却します.
	 * 存在しない場合、{@code StringUtils.EMPTY}を返却します.
	 *
	 * @param code
	 * @return - codeを保持するChusenSortJokenのname
	 */
	public static String getName(String code) {
		ChusenSortJoken enumClass = getEnumClass(code);
		if (null == enumClass) {
			return StringUtils.EMPTY;
		}
		return enumClass.getName();
	}

	/**
	 * ChusenSortJokenの列挙子全てをList型で返却します.
	 *
	 * @return - ChusenSortJokenのList
	 */
	public static List<ChusenSortJoken> getList() {
		return Arrays.asList(values());
	}
}
