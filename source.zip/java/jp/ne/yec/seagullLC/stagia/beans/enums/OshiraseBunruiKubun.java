package jp.ne.yec.seagullLC.stagia.beans.enums;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import org.apache.commons.lang.StringUtils;

import jp.ne.yec.seagullLC.stagia.beans.enums.domain.base.StagiaEnum;

public enum OshiraseBunruiKubun implements StagiaEnum {
	KITEI("1", "既定"),
	OPTION("2", "任意"),
;
	private String code;
	private String name;

	private OshiraseBunruiKubun(String code, String name) {
		this.code = code;
		this.name = name;
	}

	public String getCode() {
		return this.code;
	}

	public String getName() {
		return this.name;
	}

	/**
	 * 引数のコードを保持する列挙子を返却します.
	 * 存在しない場合、{@code null}を返却します.
	 *
	 * @param code
	 * @return - codeを保持するOshiraseBunruiKubun
	 */
	public static OshiraseBunruiKubun getEnumClass(String code) {
		return Stream.of(values()).filter(e -> e.getCode().equals(code)).findFirst().orElse(null);
	}

	/**
	 * 引数のコードを保持する列挙子の名称を返却します.
	 * 存在しない場合、{@code StringUtils.EMPTY}を返却します.
	 *
	 * @param code
	 * @return - codeを保持するOshiraseBunruiKubunのname
	 */
	public static String getName(String code) {
		OshiraseBunruiKubun enumClass = getEnumClass(code);
		if (null == enumClass) {
			return StringUtils.EMPTY;
		}
		return enumClass.getName();
	}

	/**
	 * OshiraseBunruiKubunの列挙子全てをList型で返却します.
	 *
	 * @return - OshiraseBunruiKubunのList
	 */
	public static List<OshiraseBunruiKubun> getList() {
		return Arrays.asList(values());
	}
}