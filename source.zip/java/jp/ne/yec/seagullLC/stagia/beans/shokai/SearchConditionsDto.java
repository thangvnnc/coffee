package jp.ne.yec.seagullLC.stagia.beans.shokai;

import java.io.Serializable;
import java.util.List;

import jp.ne.yec.sane.beans.StringCodeNamePair;
import jp.ne.yec.seagullLC.stagia.beans.enums.AriNashi;
import jp.ne.yec.seagullLC.stagia.beans.enums.JokenHukumu;
import jp.ne.yec.seagullLC.stagia.beans.enums.domain.ChusenKekka;
import jp.ne.yec.seagullLC.stagia.beans.enums.domain.KoseiinYakuwari;
import jp.ne.yec.seagullLC.stagia.beans.enums.domain.MeisaiJotai;
import jp.ne.yec.seagullLC.stagia.beans.enums.domain.ShinseiShurui;
import jp.ne.yec.seagullLC.stagia.beans.enums.domain.TosenShinseiJotai;
import jp.ne.yec.seagullLC.stagia.entity.MKanri;
import lombok.Getter;
import lombok.Setter;

/**
 * 窓口業務-照会で指定された条件を保持するクラスです.</BR>
 * 照会条件：申請、構成員
 *
 * @author sic-hanaoka
 *
 */
@Setter
@Getter
@SuppressWarnings("serial")
public class SearchConditionsDto implements Serializable {

	// --- 申請条件項目 ---
	private ShinseiShurui sShinseiShuruiSelect;			// 申請種類
	private List<StringCodeNamePair> sShiyoMokutekiList;	// 使用目的
	private String sLoginId;								// ログインID
	private JokenHukumu sLoginIdMuchSelect;			// ログインID検索条件
	private Integer sShinseiBango;							// 申請番号
	private String sShinseishaShimeiKana;					// 申請者カナ氏名
	private String sShinseishaShimei;						// 申請者氏名
	private String sDaihyoshaShimeiKana;					// 代表者カナ氏名
	private String sDaihyoshaShimei;						// 代表者氏名
	private String sRenrakushaShimeiKana;					// 連絡者カナ氏名
	private String sRenrakushaShimei;						// 連絡者氏名
	private String sRenrakushaDenwaBango;					// 連絡者電話番号
	private String sRenrakushaYubinBango;					// 連絡者郵便番号
	private MKanri sKanrimeiSelect;						// 管理
	private StringCodeNamePair sBashomeiSelect;			// 場所
	private StringCodeNamePair sShisetsumeiSelect;			// 施設
	private StringCodeNamePair sKashidashiTaniSelect;		// 貸出単位
	private List<StringCodeNamePair> sUketsukeBashoList;	// 受付場所リスト
	private List<MeisaiJotai> sMeisaiJotaiList;			// 明細状態リスト
	private String sUketsukeStartDate;						// 受付日-開始
	private String sUketsukeEndDate;						// 受付日-終了
	private String sToshoUketsukeStartDate;				// 当初受付日-開始
	private String sToshoUketsukeEndDate;					// 当初受付日-終了
	private String sShiyoStartDate;						// 使用日-開始
	private String sShiyoEndDate;							// 使用日-終了
	private String sSakujoKijitsuStart;					// 削除期日-開始
	private String sSakujoKijitsuEnd;						// 削除期日-終了
	private AriNashi sGenmenSelect;						// 減免
	private AriNashi sKasanSelect;							// 加算
	private AriNashi sWaribikiSelect;						// 割引
	private String sGyoji;									// 行事
	private String sMemo;									// メモ
	private List<StringCodeNamePair> sChusenGroupList;		// 抽選グループリスト
	private List<ChusenKekka> sTorakuList;					// 当落リスト
	private List<TosenShinseiJotai> sTosenShinseiJotaiList;// 当落状況リスト

	// --- 構成員条件項目 ---
	private String kLoginId;								// ログインID
	private JokenHukumu kLoginIdMuchSelect;			// ログインID検索条件
	private KoseiinYakuwari kYakuwariSelect;				// 役割
	private String kKanaName;								// 構成員カナ氏名
	private String kYubinBango;							// 構成員郵便番号
	private String kJusho;									// 構成員住所
	private String kDenwaBango;							// 構成員電話番号
}
