/**
 *
 */
package jp.ne.yec.seagullLC.stagia.beans.shinsei;

import java.text.NumberFormat;

import jp.ne.yec.seagullLC.stagia.entity.TNyujoRyokin;

/**
 * @author nao-hirata
 *
 */
@SuppressWarnings("serial")
public class NyujoRyokinDto extends TNyujoRyokin {

	public String getDisplayNyujoRyokin() {
		NumberFormat format = NumberFormat.getNumberInstance();
		return format.format(getNyujoRyokin());
	}
}
