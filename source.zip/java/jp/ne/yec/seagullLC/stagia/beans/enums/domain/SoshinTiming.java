package jp.ne.yec.seagullLC.stagia.beans.enums.domain;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import org.apache.commons.lang.StringUtils;

import jp.ne.yec.seagullLC.stagia.beans.enums.domain.base.StagiaEnum;

/**
 * Generated on Mon Feb 05 19:18:18 JST 2018 based on <br>
 * ドメイン定義票（送信タイミング）.xlsx.
 * <p>
 * 	メール送信するタイミングを保持する列挙型です。<br>
 * </p>
 */
public enum SoshinTiming implements StagiaEnum  {
	YOYAKU_KANRYO("0", "予約完了"),
	YOYAKU_TORIKESHI("1", "予約取消"),
	YOYAKU_HENKO("2", "予約変更"),
	CHUSEN_KANRYO("3", "抽選完了"),
	CHUSEN_TORIKESHI("4", "抽選取消"),
	CHUSEN_JIKKO("5", "抽選実行"),
	TOSEN_KANRYO("6", "当選完了"),
	TOSEN_JITAI("7", "当選辞退"),
;
	private String code;
	private String name;

	private SoshinTiming(String code, String name) {
		this.code = code;
		this.name = name;
	}

	public String getCode() {
		return this.code;
	}

	public String getName() {
		return this.name;
	}

	/**
	 * 引数のコードを保持する列挙子を返却します.
	 * 存在しない場合、{@code null}を返却します.
	 *
	 * @param code
	 * @return - codeを保持するSoshinTiming
	 */
	public static SoshinTiming getEnumClass(String code) {
		return Stream.of(values()).filter(e -> e.getCode().equals(code)).findFirst().orElse(null);
	}

	/**
	 * 引数のコードを保持する列挙子の名称を返却します.
	 * 存在しない場合、{@code StringUtils.EMPTY}を返却します.
	 *
	 * @param code
	 * @return - codeを保持するSoshinTimingのname
	 */
	public static String getName(String code) {
		SoshinTiming enumClass = getEnumClass(code);
		if (null == enumClass) {
			return StringUtils.EMPTY;
		}
		return enumClass.getName();
	}

	/**
	 * SoshinTimingの列挙子全てをList型で返却します.
	 *
	 * @return - SoshinTimingのList
	 */
	public static List<SoshinTiming> getList() {
		return Arrays.asList(values());
	}
}
