package jp.ne.yec.seagullLC.stagia.beans.enums.domain;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Stream;

import org.apache.commons.lang.StringUtils;

import jp.ne.yec.seagullLC.stagia.beans.enums.domain.base.StagiaEnum;

/**
 * Generated on Mon Feb 05 19:18:17 JST 2018 based on <br>
 * ドメイン定義票（当日申請期限算出基準）.xlsx.
 * <p>
 * 	当日申請受付を許可する時間を算出する際に基準とする時間を保持する列挙型です。<br>
 * 	例：「開始時間／終了時間」から○分前までのコマは当日申請可能。<br>
 * </p>
 */
public enum TojitsuShinseiKigenKijun implements StagiaEnum  {
	START_TIME("0", "開始時間"),
	END_TIME("1", "終了時間"),
;
	private String code;
	private String name;

	private TojitsuShinseiKigenKijun(String code, String name) {
		this.code = code;
		this.name = name;
	}

	public String getCode() {
		return this.code;
	}

	public String getName() {
		return this.name;
	}

	/**
	 * 引数のコードを保持する列挙子を返却します.
	 * 存在しない場合、{@code null}を返却します.
	 *
	 * @param code
	 * @return - codeを保持するTojitsuShinseiKigenKijun
	 */
	public static TojitsuShinseiKigenKijun getEnumClass(String code) {
		return Stream.of(values()).filter(e -> e.getCode().equals(code)).findFirst().orElse(null);
	}

	/**
	 * 引数のコードを保持する列挙子の名称を返却します.
	 * 存在しない場合、{@code StringUtils.EMPTY}を返却します.
	 *
	 * @param code
	 * @return - codeを保持するTojitsuShinseiKigenKijunのname
	 */
	public static String getName(String code) {
		TojitsuShinseiKigenKijun enumClass = getEnumClass(code);
		if (null == enumClass) {
			return StringUtils.EMPTY;
		}
		return enumClass.getName();
	}

	/**
	 * TojitsuShinseiKigenKijunの列挙子全てをList型で返却します.
	 *
	 * @return - TojitsuShinseiKigenKijunのList
	 */
	public static List<TojitsuShinseiKigenKijun> getList() {
		return Arrays.asList(values());
	}
}
