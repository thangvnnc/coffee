package jp.ne.yec.seagullLC.stagia.beans.riyosha;

import java.io.Serializable;

import jp.ne.yec.sane.beans.StringCodeNamePair;
import jp.ne.yec.seagullLC.stagia.entity.TRiyokanoShinseiGroup;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@SuppressWarnings("serial")
public class RiyoKanoShinseiGroupDto extends TRiyokanoShinseiGroup implements Serializable {
	StringCodeNamePair selectedShinseiGroupCode;

}
