package jp.ne.yec.seagullLC.stagia.beans.shinsei;

import org.apache.commons.lang.StringUtils;

import jp.ne.yec.seagullLC.stagia.beans.enums.AriNashi;
import jp.ne.yec.seagullLC.stagia.beans.enums.domain.ChusenKekka;
import jp.ne.yec.seagullLC.stagia.beans.enums.domain.MeisaiJotai;
import jp.ne.yec.seagullLC.stagia.beans.enums.domain.ShinseiShurui;
import jp.ne.yec.seagullLC.stagia.beans.enums.domain.TosenShinseiJotai;
import jp.ne.yec.seagullLC.stagia.entity.TShinseiMeisai;
import jp.ne.yec.seagullLC.stagia.util.CalendarUtils;
import jp.ne.yec.seagullLC.stagia.util.TimeUtils;
import lombok.Getter;
import lombok.Setter;


/**
 * 申請照会時に使用するDTOクラスです.
 *
 * @author sic-hanaoka
 *
 */
@Getter
@Setter
@SuppressWarnings("serial")
public class ShinseiIchiranDto extends TShinseiMeisai {

	// 申請種類
	private String shinseiShurui;

	// ログインID
	private String loginId;

	// 申請者名
	private String shinseishaName;

	// 利用者グループコード
	private Short riyoshaGroupCode;

	// 抽選グループコード
	private Short chusenGroupCode;

	// 優先順位
	private Short yusenJuni;

	// 抽選結果
	private String chusenKekka;

	// 当選申請状態
	private String tosenShinseiJotai;

	// 場所名称
	private String bashoName;

	// 施設名称
	private String shisetsuName;

	// 施設貸出方式
	private String shisetsuKashidashiHoshiki;

	// 面数表示単位
	private String mensuHyojiTani;

	// 貸出単位名称
	private String kashidashiTaniName;

	// 使用目的名称
	private String shiyoMokutekiName = StringUtils.EMPTY;

	// 設備有無
	private String setsubiUmu = AriNashi.NASHI.getName();

	// 加算有無
	private Boolean kasanUmu;

	// 減免有無
	private Boolean gemmenUmu;

	// 割引有無
	private Boolean waribikiUmu;

	/**
	 * 画面表示用にフォーマットした申請番号を返却します.
	 *
	 * @return
	 */
	public String getDisplayShinseiNumber() {
		StringBuilder shinseiNum = new StringBuilder(StringUtils.leftPad(String.valueOf(getKanriCode()), 2, "0"));
		shinseiNum.append("-");
		shinseiNum.append(getShinseiNumber());
		shinseiNum.append("-");
		shinseiNum.append(StringUtils.leftPad(String.valueOf(getMeisaiNumber()), 2, "0"));
		return shinseiNum.toString();
	}

	/**
	 * 画面表示用にフォーマットした使用日を返却します.
	 *
	 * @return
	 */
	public String getDisplayShiyoDate() {

		return CalendarUtils.toFormatyyyyMdSeparatedBySlashes(getShiyoDate());
	}

	/**
	 * 画面表示用にフォーマットした使用時間(開始時間～終了時間)を返却します.
	 *
	 * @return
	 */
	public String getDisplayShiyoTime() {
		return TimeUtils.toTimeRangeFormat(getStartTime(), getEndTime());
	}

	/**
	 * 画面表示用にフォーマットした使用施設名称を返却します.
	 *
	 * @return
	 */
	public String getDisplayShisetsuName() {
		StringBuilder shisetsu = new StringBuilder(getBashoName());
		shisetsu.append("　");
		shisetsu.append(getShisetsuName());
		if (StringUtils.isNotBlank(getKashidashiTaniName())) {
			shisetsu.append("　");
			shisetsu.append(getKashidashiTaniName());
		}
		return shisetsu.toString();
	}

	/**
	 * 画面表示用の明細状態を返却します.
	 *
	 * @return
	 */
	public String getDisplayMeisaiJotai() {
		if (ShinseiShurui.CHUSEN.getCode().equals(getShinseiShurui())) {
			return getDisplayChusenJotai();
		}
		return MeisaiJotai.getName(getMeisaiJotai());
	}

	/**
	 * 画面表示用の抽選状態を返却します.
	 *
	 * @return
	 */
	public String getDisplayChusenJotai() {
		if (ChusenKekka.MOSHIKOMI.getCode().equals(getChusenKekka())) {
			if (MeisaiJotai.SHINKI.getCode().equals(getMeisaiJotai())
					|| MeisaiJotai.HENKO.getCode().equals(getMeisaiJotai())) {
				return ChusenKekka.MOSHIKOMI.getName();
			}
			return ChusenKekka.MOSHIKOMI.getName().concat(MeisaiJotai.TORIKESHI.getName());
		}
		if (ChusenKekka.RAKUSEN.getCode().equals(getChusenKekka())) {
			return ChusenKekka.RAKUSEN.getName();
		}
		if (TosenShinseiJotai.JITAI.getCode().equals(getTosenShinseiJotai())) {
			return ChusenKekka.TOSEN.getName().concat(TosenShinseiJotai.JITAI.getName());
		}
		if (TosenShinseiJotai.BATCHI_SAKUJO.getCode().equals(getTosenShinseiJotai())) {
			return MeisaiJotai.TOSEN_KIKAN_CHOKA.getName();
		}
		return ChusenKekka.TOSEN.getName().concat(TosenShinseiJotai.MISHINSEI.getName());
	}
}
