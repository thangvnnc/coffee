package jp.ne.yec.seagullLC.stagia.beans.unei;

import java.util.Objects;

import org.apache.commons.lang.StringUtils;

import jp.ne.yec.seagullLC.stagia.beans.enums.domain.HyojisakiShurui;
import jp.ne.yec.seagullLC.stagia.entity.MOshirase;
import jp.ne.yec.seagullLC.stagia.util.CalendarUtils;
import lombok.Getter;
import lombok.Setter;

/**
 * お知らせ機能の一覧情報を保持するDTO</BR>
 * 一行分の情報を保持します</BR>
 *
 * @author sic-higuchi
 *
 */
@Setter
@Getter
@SuppressWarnings("serial")
public class OshiraseViewDto extends MOshirase {

	/**
	 * お知らせ分類名
	 */
	private String bunruiName = StringUtils.EMPTY;

	/**
	 * 管理名
	 */
	private String kanriName = StringUtils.EMPTY;

	/**
	 * 申請グループ名
	 */
	private String shinseiGroupName = StringUtils.EMPTY;

	/**
	 * 個人名
	 */
	private String userName = StringUtils.EMPTY;

	/**
	 * お知らせ既読ID　([T_お知らせ既読]のお知らせID)
	 */
	private Integer kidokuId;

	/**
	 * お知らせ既読</BR>
	 * ※ヘッダーへの表示時に使用
	 *
	 */
	private Boolean isRead;

	/**
	 * 画面に表示するための表示期間を返却します.
	 *
	 * @return 表示期間
	 */
	public String getHyojikikan() {
		StringBuilder buff = new StringBuilder(CalendarUtils.toFormatyyyyMdSeparatedBySlashes(getHyojiStartDate()));
		buff.append(" ～ ");
		buff.append(CalendarUtils.toFormatyyyyMdSeparatedBySlashes(getHyojiEndDate()));
		return buff.toString();
	}

	/**
	 * 画面に表示する削除文字列を返却します.
	 *
	 * @return 削除文字列
	 */
	public String getIsDeleted() {
		if (isDeleted()) {
			return "削除";
		}
		return StringUtils.EMPTY;
	}

	/**
	 * 画面に表示する既読状態を返却します.
	 *
	 * @return 既読状態
	 */
	public String getKidokuJotai() {
		if (Objects.isNull(kidokuId)) {
			return "未読";
		}
		return "既読";
	}

	/**
	 * お知らせ既読を返却します.
	 *
	 * @return
	 */
	public Boolean isRead() {
		return isRead;
	}

	/**
	 * 画面に表示する表示先種類名称を返却します.
	 *
	 * @return
	 */
	public String getHyojisakiShuruiName() {
		return HyojisakiShurui.getName(getHyojisakiShurui());
	}
}
