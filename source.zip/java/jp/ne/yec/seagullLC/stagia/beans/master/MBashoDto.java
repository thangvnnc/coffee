package jp.ne.yec.seagullLC.stagia.beans.master;

import jp.ne.yec.seagullLC.stagia.entity.MBasho;
import lombok.Getter;
import lombok.Setter;

/**
 * 「m_basho」の情報を保持するDTOクラスです.
 *
 * @author sic-yu
 *
 */
@Getter
@Setter
@SuppressWarnings("serial")
public class MBashoDto extends MBasho {

}
