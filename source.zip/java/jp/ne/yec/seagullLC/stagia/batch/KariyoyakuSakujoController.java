/**
 *
 */
package jp.ne.yec.seagullLC.stagia.batch;

import org.quartz.DisallowConcurrentExecution;

import jp.ne.yec.sane.util.SpringBeans;
import jp.ne.yec.seagullLC.stagia.batch.base.BatchJobControllerBase;
import jp.ne.yec.seagullLC.stagia.service.batch.BatchService;

/**
 * 仮予約自動削除バッチ
 *
 * @author 佐藤武
 *
 */
@DisallowConcurrentExecution
public class KariyoyakuSakujoController extends BatchJobControllerBase {

	/* (非 Javadoc)
	 * @see jp.ne.yec.seagullLC.stagia.batch.base.BatchJobControllerBase#getService()
	 */
	@Override
	protected BatchService getService() {
		return (BatchService)SpringBeans.get("kariyoyakuSakujoService");
	}

}
