package jp.ne.yec.seagullLC.stagia.batch.base;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;

import org.quartz.Job;
import org.quartz.JobDataMap;
import org.quartz.JobExecutionContext;

import com.google.gson.Gson;

import jp.ne.yec.seagullLC.stagia.beans.batch.BatchResultDto;
import jp.ne.yec.seagullLC.stagia.beans.enums.domain.BatchStatus;
import jp.ne.yec.seagullLC.stagia.entity.MBatchSchedule;
import jp.ne.yec.seagullLC.stagia.entity.TBatchKanri;
import jp.ne.yec.seagullLC.stagia.service.batch.BatchService;

/**
 * 業務バッチコントローラ基底クラス
 *
 * @author 佐藤武
 *
 */
public abstract class BatchJobControllerBase implements Job {

	public static final String BATCH_SCHEDULE = "batchSchdule";

	public static final short ALL_EXECUTE = 0;

	/* (非 Javadoc)
	 * @see org.quartz.Job#execute(org.quartz.JobExecutionContext)
	 */
	@Override
	public void execute(JobExecutionContext context) {
		MBatchSchedule mBatchSchedule = getBatchSchdule(context);
		TBatchKanri tBatchKanri = createTBatchKanri(mBatchSchedule);
		Map<Short, JobDataMap> executeMap = getExecuteMap(mBatchSchedule);
		for(Map.Entry<Short, JobDataMap> entrySet : executeMap.entrySet()) {
			try {
				tBatchKanri.setStartTimestamp(new Timestamp(System.currentTimeMillis()));
				if (!isTargetHost(mBatchSchedule.getHostName())) {
					return;
				}
				tBatchKanri.setBatchTaishoCode(entrySet.getKey());
				if (isRunning(tBatchKanri)) {
					tBatchKanri.setRunningStatus(BatchStatus.STOP.getCode());
					getService().insertBatchKanri(tBatchKanri);
					return;
				}
				getService().insertBatchKanri(tBatchKanri);
				BatchResultDto resultDto = getService().execute((JobDataMap)entrySet.getValue());
				tBatchKanri.setLog(toJson(resultDto));
				tBatchKanri.setRunningStatus(BatchStatus.SUCCESS.getCode());
			} catch (Exception e) {
				tBatchKanri.setLog(cnvStackTrace2String(e));
				tBatchKanri.setRunningStatus(BatchStatus.ABORT.getCode());
			} finally {
				tBatchKanri.setEndTimestamp(new Timestamp(System.currentTimeMillis()));
				getService().updateBatchKanri(tBatchKanri);
			}
		}
		return;
	}

	/**
	 * サービス実装クラスを返します.
	 *
	 * @return
	 */
	protected abstract BatchService getService();

	/**
	 * バッチ種類及び対象コードが同一のバッチが実行中か返します.
	 *
	 * @param tBatchKanri
	 * @return
	 */
	protected boolean isRunning(TBatchKanri tBatchKanri) {
		return getService().isRunning(tBatchKanri);
	}

	/**
	 * 対象コードを返します.
	 *
	 * @param context
	 * @return
	 */
	protected MBatchSchedule getBatchSchdule(JobExecutionContext context) {
		JobDataMap dataMap = context.getJobDetail().getJobDataMap();
		return (MBatchSchedule)dataMap.get(BATCH_SCHEDULE);
	}

	/**
	 * Tバッチ管理を作成します.
	 *
	 * @param batchTaishoCode
	 * @param batchShurui
	 * @return
	 */
	protected TBatchKanri createTBatchKanri(MBatchSchedule mBatchSchedule) {
		TBatchKanri ret = new TBatchKanri();
		ret.setBatchShurui(mBatchSchedule.getBatchShurui());
		ret.setBatchTaishoCode(mBatchSchedule.getBatchTaishoCode());
		ret.setRunningStatus(BatchStatus.RUNNING.getCode());
		ret.setScheduleId(mBatchSchedule.getId());
		ret.setCreatedBy(mBatchSchedule.getBatchExecId());
		ret.setUpdatedBy(mBatchSchedule.getBatchExecId());
		return ret;
	}

	/**
	 * バッチ実行する条件を返します.
	 *
	 * @param mBatchSchedule
	 * @return
	 */
	protected Map<Short, JobDataMap> getExecuteMap(MBatchSchedule mBatchSchedule) {
		if (!isAllExecuteCode(mBatchSchedule)) {
			Map<Short, JobDataMap> ret = new HashMap<>();
			ret.put(mBatchSchedule.getBatchTaishoCode(), new JobDataMap());
			return ret;
		}
		return getService().getExecuteCondtion();
	}

	/**
	 * 全対象コード実行か返します.
	 *
	 * @param mBatchSchedule
	 * @return
	 */
	protected boolean isAllExecuteCode(MBatchSchedule mBatchSchedule) {
		if (ALL_EXECUTE == mBatchSchedule.getBatchTaishoCode()) {
			return true;
		}
		return false;
	}

	/**
	 * 例外情報を文字列に変換します.
	 *
	 * @param e
	 * @return
	 */
	protected String cnvStackTrace2String(Exception e) {
		StringWriter sw = new StringWriter();
		PrintWriter pw = new PrintWriter(sw);
		e.printStackTrace(pw);
		pw.flush();
		return sw.toString();
	}

	/**
	 * @param targetHostName
	 * @return
	 * @throws UnknownHostException
	 */
	protected boolean isTargetHost(String targetHostName) {
		try {
			if (targetHostName.equals(InetAddress.getLocalHost().getHostName())) {
				return true;
			}
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		return false;
	}

//	TODO 共通UTILにするか検討
	/**
	 *
	 *
	 * @param resultDto
	 * @return
	 */
	protected String toJson(BatchResultDto resultDto) {
		return new Gson().toJson(resultDto);
	}


}
