/**
 *
 */
package jp.ne.yec.seagullLC.stagia.batch;

import jp.ne.yec.sane.util.SpringBeans;
import jp.ne.yec.seagullLC.stagia.batch.base.BatchJobControllerBase;
import jp.ne.yec.seagullLC.stagia.service.batch.BatchService;

/**
 * 当選未申請削除バッチ
 *
 * @author 佐藤武
 *
 */
public class TosenSakujoController extends BatchJobControllerBase {

	/* (非 Javadoc)
	 * @see jp.ne.yec.seagullLC.stagia.batch.base.BatchJobControllerBase#getService()
	 */
	@Override
	protected BatchService getService() {
		return (BatchService)SpringBeans.get("tosenSakujoService");
	}

}
