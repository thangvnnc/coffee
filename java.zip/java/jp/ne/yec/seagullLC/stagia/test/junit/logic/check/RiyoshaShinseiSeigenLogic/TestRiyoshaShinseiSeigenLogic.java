package jp.ne.yec.seagullLC.stagia.test.junit.logic.check.RiyoshaShinseiSeigenLogic;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.google.gson.reflect.TypeToken;

import jp.ne.yec.seagullLC.stagia.beans.enums.domain.ShinseiShurui;
import jp.ne.yec.seagullLC.stagia.beans.riyosha.KoseiinJohoDto;
import jp.ne.yec.seagullLC.stagia.beans.shinsei.ShinseiMeisaiDto;
import jp.ne.yec.seagullLC.stagia.entity.MChusenGroup;
import jp.ne.yec.seagullLC.stagia.logic.check.RenzokuShiyoSeigenLogic;
import jp.ne.yec.seagullLC.stagia.logic.check.RiyoshaShinseiSeigenLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestRiyoshaShinseiSeigenLogic extends JunitBase {


	@Autowired
	RiyoshaShinseiSeigenLogic riyoshaShinseiSeigenLogic;

//	@Test
//	@DisplayName("データ更新に使用するDaoを取得します")
//	@TestInitDataFile("TestKoseiinJohoEntityToKoseiinJohoDtoInit.xlsx")
//	public void TestKoseiinJohoEntityToKoseiinJohoDto() throws Exception
//	{
//		List<List<KoseiinJohoDto>> jsonData = new ArrayList<List<KoseiinJohoDto>>();
//
//		String loginId = "tnt";
//		 List<ShinseiMeisaiDto> shinseiMeisaiDtos = readJson("shinseiMeisaiDtos_in.json", new TypeToken<List<ShinseiMeisaiDto> >(){}.getType());
//		riyoshaShinseiSeigenLogic.check(loginId, shinseiMeisaiDtos);
//	}
//
//	@Test
//	@DisplayName("データ更新に使用するDaoを取得します")
//	@TestInitDataFile("TestKoseiinJohoEntityToKoseiinJohoDto_step5Init.xlsx")
//	public void TestKoseiinJohoEntityToKoseiinJohoDto_step5() throws Exception
//	{
//		List<List<KoseiinJohoDto>> jsonData = new ArrayList<List<KoseiinJohoDto>>();
//
//		String loginId = "tnt";
//		 List<ShinseiMeisaiDto> shinseiMeisaiDtos = readJson("shinseiMeisaiDtos_in.json", new TypeToken<List<ShinseiMeisaiDto> >(){}.getType());
//		riyoshaShinseiSeigenLogic.check(loginId, shinseiMeisaiDtos);
//	}
//
//
//	@Test
//	@DisplayName("データ更新に使用するDaoを取得します")
//	@TestInitDataFile("TestKoseiinJohoEntityToKoseiinJohoDto_step2Init.xlsx")
//	public void TestKoseiinJohoEntityToKoseiinJohoDto_step2() throws Exception
//	{
//		List<List<KoseiinJohoDto>> jsonData = new ArrayList<List<KoseiinJohoDto>>();
//
//		String loginId = "tnt";
//		 List<ShinseiMeisaiDto> shinseiMeisaiDtos = readJson("shinseiMeisaiDtos_in.json", new TypeToken<List<ShinseiMeisaiDto> >(){}.getType());
//		riyoshaShinseiSeigenLogic.check(loginId, shinseiMeisaiDtos);
//	}
//
//	@Test
//	@DisplayName("データ更新に使用するDaoを取得します")
//	@TestInitDataFile("TestKoseiinJohoEntityToKoseiinJohoDto_step3Init.xlsx")
//	public void TestKoseiinJohoEntityToKoseiinJohoDto_step3() throws Exception
//	{
//		List<List<KoseiinJohoDto>> jsonData = new ArrayList<List<KoseiinJohoDto>>();
//
//		String loginId = "tnt";
//		 List<ShinseiMeisaiDto> shinseiMeisaiDtos = readJson("shinseiMeisaiDtos_in.json", new TypeToken<List<ShinseiMeisaiDto> >(){}.getType());
//		 try
//		 {
//			 riyoshaShinseiSeigenLogic.check(loginId, shinseiMeisaiDtos);
//		 }
//		 catch(Exception ex)
//		 {
//			 assertEquals("[青少年館 実習室：2018/7/10 09：00～21：30]は利用申請停止期間(2018/7/10～)であるため申請できません。~[青少年館 実習室：2018/7/11 09：00～21：30]は利用申請停止期間(2018/7/10～)であるため申請できません。~[青少年館 実習室：2018/7/12 09：00～21：30]は利用申請停止期間(2018/7/10～)であるため申請できません。",ex.getMessage());
//		 }
//
//	}
//
//	@Test
//	@DisplayName("データ更新に使用するDaoを取得します")
//	@TestInitDataFile("TestKoseiinJohoEntityToKoseiinJohoDto_step4Init.xlsx")
//	public void TestKoseiinJohoEntityToKoseiinJohoDto_step4() throws Exception
//	{
//		List<List<KoseiinJohoDto>> jsonData = new ArrayList<List<KoseiinJohoDto>>();
//
//		String loginId = "tnt";
//		 List<ShinseiMeisaiDto> shinseiMeisaiDtos = readJson("shinseiMeisaiDtos_in.json", new TypeToken<List<ShinseiMeisaiDto> >(){}.getType());
//		 try
//		 {
//			 riyoshaShinseiSeigenLogic.check(loginId, shinseiMeisaiDtos);
//		 }
//		 catch(Exception ex)
//		 {
//			 assertEquals("[青少年館 実習室：2018/7/10 09：00～21：30]は利用申請停止期間(～2018/7/10)であるため申請できません。~[青少年館 実習室：2018/7/11 09：00～21：30]は利用申請停止期間(～2018/7/10)であるため申請できません。~[青少年館 実習室：2018/7/12 09：00～21：30]は利用申請停止期間(～2018/7/10)であるため申請できません。",ex.getMessage());
//		 }
//	}
//
//	@Test
//	@DisplayName("データ更新に使用するDaoを取得します")
//	@TestInitDataFile("TestKoseiinJohoEntityToKoseiinJohoDto_step6Init.xlsx")
//	public void TestKoseiinJohoEntityToKoseiinJohoDto_step6() throws Exception
//	{
//		List<List<KoseiinJohoDto>> jsonData = new ArrayList<List<KoseiinJohoDto>>();
//
//		String loginId = "tnt";
//		 List<ShinseiMeisaiDto> shinseiMeisaiDtos = readJson("shinseiMeisaiDtos_in.json", new TypeToken<List<ShinseiMeisaiDto> >(){}.getType());
//		 try
//		 {
//			 riyoshaShinseiSeigenLogic.check(loginId, shinseiMeisaiDtos);
//		 }
//		 catch(Exception ex)
//		 {
//			 assertEquals("[青少年館 実習室：2018/7/10 09：00～21：30]は利用申請停止期間(2018/7/1～)であるため申請できません。~[青少年館 実習室：2018/7/11 09：00～21：30]は利用申請停止期間(2018/7/1～)であるため申請できません。~[青少年館 実習室：2018/7/12 09：00～21：30]は利用申請停止期間(2018/7/1～)であるため申請できません。",ex.getMessage());
//		 }
//	}
//
//	@Test
//	@DisplayName("データ更新に使用するDaoを取得します")
//	@TestInitDataFile("TestKoseiinJohoEntityToKoseiinJohoDto_step7Init.xlsx")
//	public void TestKoseiinJohoEntityToKoseiinJohoDto_step7() throws Exception
//	{
//		List<List<KoseiinJohoDto>> jsonData = new ArrayList<List<KoseiinJohoDto>>();
//
//		String loginId = "tnt";
//		 List<ShinseiMeisaiDto> shinseiMeisaiDtos = readJson("shinseiMeisaiDtos_in.json", new TypeToken<List<ShinseiMeisaiDto> >(){}.getType());
//		riyoshaShinseiSeigenLogic.check(loginId, shinseiMeisaiDtos);
//	}
//
//	@Test
//	@DisplayName("データ更新に使用するDaoを取得します")
//	@TestInitDataFile("TestKoseiinJohoEntityToKoseiinJohoDto_step8Init.xlsx")
//	public void TestKoseiinJohoEntityToKoseiinJohoDto_step8() throws Exception
//	{
//		List<List<KoseiinJohoDto>> jsonData = new ArrayList<List<KoseiinJohoDto>>();
//
//		String loginId = "tnt";
//		 List<ShinseiMeisaiDto> shinseiMeisaiDtos = readJson("shinseiMeisaiDtos_in.json", new TypeToken<List<ShinseiMeisaiDto> >(){}.getType());
//		riyoshaShinseiSeigenLogic.check(loginId, shinseiMeisaiDtos);
//	}
//
//	@Test
//	@DisplayName("データ更新に使用するDaoを取得します")
//	@TestInitDataFile("TestKoseiinJohoEntityToKoseiinJohoDto_step8Init.xlsx")
//	public void TestKoseiinJohoEntityToKoseiinJohoDto_step9() throws Exception
//	{
//		List<List<KoseiinJohoDto>> jsonData = new ArrayList<List<KoseiinJohoDto>>();
//
//		String loginId = "tnt";
//		 List<ShinseiMeisaiDto> shinseiMeisaiDtos = readJson("shinseiMeisaiDtos_in.json", new TypeToken<List<ShinseiMeisaiDto> >(){}.getType());
//		 shinseiMeisaiDtos.get(0).setShinseiShurui(ShinseiShurui.CHUSEN);
//		 MChusenGroup mChusenGroup = new MChusenGroup();
//		 mChusenGroup.setAllowedPenaltyRiyosha(true);
//		 shinseiMeisaiDtos.get(0).setMChusenGroup(mChusenGroup);
//		riyoshaShinseiSeigenLogic.check(loginId, shinseiMeisaiDtos);
//	}

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestKoseiinJohoEntityToKoseiinJohoDto_step8Init.xlsx")
	public void TestshinseiKanoKomaCheck() throws Exception
	{
		 List<ShinseiMeisaiDto> shinseiMeisaiDtos = readJson("shinseiMeisaiDtos_in.json", new TypeToken<List<ShinseiMeisaiDto> >(){}.getType());
		 shinseiMeisaiDtos.get(0).setShinseiShurui(ShinseiShurui.CHUSEN);
		 MChusenGroup mChusenGroup = new MChusenGroup();
		 mChusenGroup.setAllowedPenaltyRiyosha(true);
		 shinseiMeisaiDtos.get(0).setMChusenGroup(mChusenGroup);
		riyoshaShinseiSeigenLogic.shinseiKanoKomaCheck(shinseiMeisaiDtos);
	}
}

