package jp.ne.yec.seagullLC.stagia.test.junit.logic.master.MNijutorokuLogic;

import static org.junit.Assert.*;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.entity.MNijutoroku;
import jp.ne.yec.seagullLC.stagia.logic.master.MNijutorokuLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestMNijutorokuLogic extends JunitBase {

	@Autowired
	MNijutorokuLogic mNijutorokuLogic;

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetMNijutorokuN.xlsx")
	public void TestgetMNijutoroku() throws Exception
	{
		 MNijutoroku ret =  mNijutorokuLogic.getMNijutoroku();
		 exportJsonData(ret, "TestgetMNijutoroku.json");
	}
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetMNijutorokuN.xlsx")
	public void TestupdateMNijutoroku() throws Exception
	{

		MNijutoroku mNijutoroku = new MNijutoroku();
		mNijutoroku.setVersion(140);
		mNijutoroku.setUpdatedBy("0-3718");
		mNijutoroku.setUsedJusho1(true);
		mNijutoroku.setUsedJusho2(false);
		mNijutoroku.setUsedMailAddress(true);
		mNijutoroku.setUsedDenwaBango1(true);
		mNijutoroku.setUsedDenwaBango2(true);
		mNijutoroku.setCreatedBy("3718");
		mNijutoroku.setUsedBirthDay(true);
		mNijutoroku.setUsedNameKana(true);
		mNijutoroku.setUsedName(false);
		mNijutoroku.setUsedYubinBango(true);

		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/M/d HH:mm");
		Date dateCreate = new Date();
		dateCreate = dateFormat.parse("2018/3/29 14:14");
		long timeCreate = dateCreate.getTime();
		Timestamp tCreate = new Timestamp(timeCreate);
		mNijutoroku.setCreatedAt(tCreate);

		Date dateUpdate = new Date();
		dateUpdate = dateFormat.parse("2018/6/15 15:38");
		long timeUpdate= dateUpdate.getTime();
		Timestamp tUpdate = new Timestamp(timeUpdate);
		mNijutoroku.setUpdatedAt(tUpdate);

		String updatedBy = "0-3718";
		mNijutorokuLogic.updateMNijutoroku(mNijutoroku, updatedBy);
	}
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetMNijutorokuN2.xlsx")
	public void TestupdateMNijutoroku2() throws Exception
	{

		MNijutoroku mNijutoroku = new MNijutoroku();
		mNijutoroku.setVersion(3);
		mNijutoroku.setUpdatedBy("0-3718");
		mNijutoroku.setUsedJusho1(true);
		mNijutoroku.setUsedJusho2(false);
		mNijutoroku.setUsedMailAddress(true);
		mNijutoroku.setUsedDenwaBango1(true);
		mNijutoroku.setUsedDenwaBango2(true);
		mNijutoroku.setCreatedBy("3718");
		mNijutoroku.setUsedBirthDay(true);
		mNijutoroku.setUsedNameKana(true);
		mNijutoroku.setUsedName(false);
		mNijutoroku.setUsedYubinBango(true);

		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/M/d HH:mm");
		Date dateCreate = new Date();
		dateCreate = dateFormat.parse("2018/3/29 14:14");
		long timeCreate = dateCreate.getTime();
		Timestamp tCreate = new Timestamp(timeCreate);
		mNijutoroku.setCreatedAt(tCreate);

		Date dateUpdate = new Date();
		dateUpdate = dateFormat.parse("2018/6/15 15:38");
		long timeUpdate= dateUpdate.getTime();
		Timestamp tUpdate = new Timestamp(timeUpdate);
		mNijutoroku.setUpdatedAt(tUpdate);

		String updatedBy = "0-3718";
		try
		{
			mNijutorokuLogic.updateMNijutoroku(mNijutoroku, updatedBy);
		}
		catch (Exception e) {
			String messageExp = "m_nijutoroku Optimistic lock error";
			assertEquals(messageExp, e.getMessage());
		}
	}
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	//@TestInitDataFile("TestgetMBashoList.xlsx")
	public void TestgetDao() throws Exception
	{
			GenericDao<MNijutoroku, ?> ret = mNijutorokuLogic.getDao();
	}
}