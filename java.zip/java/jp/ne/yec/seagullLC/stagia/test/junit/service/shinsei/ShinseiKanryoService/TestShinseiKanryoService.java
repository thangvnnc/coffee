package jp.ne.yec.seagullLC.stagia.test.junit.service.shinsei.ShinseiKanryoService;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.seagullLC.stagia.service.shinsei.ShinseiKanryoService;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestShinseiKanryoService extends JunitBase{

	@Autowired
	ShinseiKanryoService shinseiKanryoService;

	@Test
	@DisplayName("引数のMapから本予約のみを再抽出します.")
	public void TestGetHonyoyakuShinseiMapr() throws Exception{
//		shinseiKanryoService.getHonyoyakuShinseiMap(shinseiMap)
	}
}
