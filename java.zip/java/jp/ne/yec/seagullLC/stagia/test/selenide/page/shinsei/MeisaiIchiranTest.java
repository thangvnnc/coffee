package jp.ne.yec.seagullLC.stagia.test.selenide.page.shinsei;

import static com.codeborne.selenide.Selenide.*;

import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.codeborne.selenide.SelenideElement;

import jp.ne.yec.seagullLC.stagia.test.selenide.page.base.SelenidePageBase;

/**
 * 明細一覧画面のテストクラス.
 *
 * @author nao-hirata
 *
 */
public class MeisaiIchiranTest extends SelenidePageBase {

	@FindBy(how = How.CSS, using = "button[wicketpath=form_shinseishaJoho]")
	protected SelenideElement shinseishaJohoButton;

	@FindBy(how = How.CSS, using = "button[wicketpath=form_nextPage]")
	protected SelenideElement shinseiKakuninButton;

	/**
	 * 申請者情報画面に遷移します.
	 *
	 * @return - ShinseishaJohoTestのインスタンス
	 */
	public ShinseishaJohoTest shinseishaJohoButtonClick () {
		return takeScreenShotAndMovePage(shinseishaJohoButton, ShinseishaJohoTest.class);
	}

	/**
	 * 引数に該当する明細行を返却します.
	 *
	 * @param row - 取得対象の明細行数。1行目は0。
	 * @return - 明細行に対応するtrタグのSelenideElement
	 */
	public SelenideElement meisaiRow(int row) {
		return $("tr[wicketpath=form_velocityTablePanel_table_tbodyTr_" + String.valueOf(row) + "]");
	}

	/**
	 * 名称からを指定して、貸出単位を設定します.
	 *
	 * @param row - 貸出単位を設定する明細行。1行目は0。
	 * @param name - 貸出単位の名称。
	 */
	public void setKashidashiTaniByName(int row, String name) {
		$("select[wicketpath=form_velocityTablePanel_table_tbodyTr_" + String.valueOf(row) + "_menSelect_selectedMKashidashiTani]").selectOption(name);
	}

	/**
	 * 申請確認ページへ遷移します.
	 *
	 * @return - ShinseiKakuninTestのインスタンス
	 */
	public ShinseiKakuninTest nextPage() {
		return takeScreenShotAndMovePage(shinseiKakuninButton, ShinseiKakuninTest.class);
	}

}
