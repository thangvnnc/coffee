package jp.ne.yec.seagullLC.stagia.test.junit.service.akijokyo.MultipleFacilitiesAkijokyoPanelService;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.seagullLC.stagia.beans.search.AkijokyoRowDto;
import jp.ne.yec.seagullLC.stagia.entity.MShisetsu;
import jp.ne.yec.seagullLC.stagia.service.akijokyo.MultipleFacilitiesAkijokyoPanelService;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestMultipleFacilitiesAkijokyoPanelService extends JunitBase {

	@Autowired
	MultipleFacilitiesAkijokyoPanelService multipleFacilitiesAkijokyoPanelService;

//	@Test
//	@DisplayName("データ更新に使用するDaoを取得します")
//	public void TestCreateAkijokyo() throws Exception
//	{
//		List<List<MShisetsu>> mShisetsuLists = new ArrayList<>();
//		List<MShisetsu> mShisetsus = new ArrayList<>();
//		mShisetsus.add(new MShisetsu());
//		mShisetsuLists.add(mShisetsus);
//
//		List<LocalDate> displaytDates = new ArrayList<>();
//		displaytDates.add(LocalDate.now());
//
//		List<Map<String, MKomaPattern>> shisetsuToMKomaPatterns = new ArrayList<>();
//		Map<String, MKomaPattern> shisetsuToMKomaPattern = new HashMap<>();
//		shisetsuToMKomaPattern.put("test", new MKomaPattern());
//		shisetsuToMKomaPatterns.add(shisetsuToMKomaPattern);
//
//		List<Map<Short, List<MKoma>>> mKomaListToKomaPatterns = new ArrayList<>();
//		Map<Short, List<MKoma>> mKomaListToKomaPattern = new HashMap<>();
//		List<MKoma> komas = new ArrayList<>();
//		komas.add(new MKoma());
//		mKomaListToKomaPattern.put((short) 10, komas);
//
//		List<Map<Short, Map<Short, MKomaGroup>>> mKomaGroupMaps = new ArrayList<>();
//		Map<Short, Map<Short, MKomaGroup>> mKomaGroupMap = new HashMap<>();
//		Map<Short, MKomaGroup> mapKomaGroup = new HashMap<>();
//		mapKomaGroup.put((short) 10, new MKomaGroup());
//		mKomaGroupMap.put((short) 10, mapKomaGroup);
//		mKomaGroupMaps.add(mKomaGroupMap);
//
//		List<List<AkijokyoRowDto>> exports = new ArrayList<>();
//		for (int item = 0; item < mShisetsuLists.size(); item++)
//		{
//			List<AkijokyoRowDto> ret = multipleFacilitiesAkijokyoPanelService.createAkijokyo(
//					mShisetsuLists.get(item),
//					displaytDates.get(item),
//					shisetsuToMKomaPatterns.get(item),
//					mKomaListToKomaPatterns.get(item),
//					mKomaGroupMaps.get(item));
//			exports.add(ret);
//		}
//
//		exportJsonData(exports, "TestCreateAkijokyo.json");
//	}

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	public void TestKomaToMeisaiDtoAndSetName() throws Exception
	{
		//
		List<List<MShisetsu>> mShisetsuLists = new ArrayList<List<MShisetsu>>();
		List<MShisetsu> mShisetsuss = new ArrayList<MShisetsu>();
		MShisetsu mShisetsus = new MShisetsu();
		mShisetsuss.add(mShisetsus);
		mShisetsuLists.add(mShisetsuss);

		List<List<AkijokyoRowDto>> rowList = new ArrayList<List<AkijokyoRowDto>>();
		List<AkijokyoRowDto> AkijokyoRowDtos = new ArrayList<AkijokyoRowDto>();
		AkijokyoRowDto akijokyoRowDto = new AkijokyoRowDto();
		AkijokyoRowDtos.add(akijokyoRowDto);
		rowList.add(AkijokyoRowDtos);

		List<List<String[]>> exports = new ArrayList<>();
		for (int item = 0; item < mShisetsuLists.size(); item++)
		{
			List<String[]> ret = multipleFacilitiesAkijokyoPanelService.shisetsuNameList(mShisetsuLists.get(item), rowList.get(item));
			exports.add(ret);
		}
		exportJsonData(exports, "TestKomaToMeisaiDtoAndSetName.json");
	}
}