package jp.ne.yec.seagullLC.stagia.test.junit.logic.master.MChusenShikakuLogic;

import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.entity.MChusenShikaku;
import jp.ne.yec.seagullLC.stagia.logic.master.MChusenShikakuLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestMChusenShikakuLogic extends JunitBase {

	@Autowired
	MChusenShikakuLogic mChusenShikakuLogic;

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestgetMChusenShikakuByRiyoshaGroupCode.xlsx")
	public void TestgetMChusenShikakuByRiyoshaGroupCode() throws Exception
	{
		Short riyoshaGroupCode = 1;
		List<MChusenShikaku>  ret = mChusenShikakuLogic.getMChusenShikakuByRiyoshaGroupCode(riyoshaGroupCode);
		exportJsonData(ret, "TestgetMChusenShikakuByRiyoshaGroupCode.json");
	}
	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	//@TestInitDataFile("TestgetMBashoList.xlsx")
	public void TestgetDao() throws Exception
	{
		GenericDao<MChusenShikaku, ?>  ret = mChusenShikakuLogic.getDao();
	}
}