package jp.ne.yec.seagullLC.stagia.test.junit.service.app.KensakuKekkaService;

import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.seagullLC.stagia.service.app.KensakuKekkaService;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = { "classpath:TestApplicationContext.xml" })
@WebAppConfiguration
public class TestKensakuKekkaService extends JunitBase {

	@Autowired
	KensakuKekkaService kensakuKekkaService;

//	@Test
//	public void TestAppGetItemIndex() throws Exception {
//		List<Integer> jsonData = new ArrayList<Integer>();
//		Map<String, String> mapTest = new HashMap<String, String>();
//		int result = kensakuKekkaService.appGetItemIndex(mapTest);
//		jsonData.add(result);
//		exportJsonData(jsonData, "TestAppGetItemIndex.json");
//	}

//	@Test
//	public void TestAppSearchResult() throws Exception {
//		Map<String, String> mapTest = new HashMap<String, String>();
//		List<Map<String, String>[]> jsonData = new ArrayList<Map<String, String>[]>();
//		Map<String, String>[] map = kensakuKekkaService.appSearchResult(mapTest);
//		jsonData.add(map);
//		exportJsonData(jsonData, "TestAppSearchResult.json");
//	}
}
