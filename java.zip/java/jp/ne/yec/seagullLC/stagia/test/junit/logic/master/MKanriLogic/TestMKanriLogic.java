package jp.ne.yec.seagullLC.stagia.test.junit.logic.master.MKanriLogic;


import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.beans.StringCodeNamePair;
import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.entity.MKanri;
import jp.ne.yec.seagullLC.stagia.logic.master.MKanriLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestMKanriLogic extends JunitBase {

	@Autowired
	MKanriLogic mKanriLogic;

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetKanriByUserAuthority.xlsx")
	public void TestgetAllMKanriList() throws Exception
	{
		List<MKanri>  ret = mKanriLogic.getAllMKanriList();
		exportJsonData(ret, "TestgetAllMKanriList.json");
	}

	@Test
	@DisplayName("検索条件なしでM_管理名を取得しStringCodeNamePairの形式で返却します")
	@TestInitDataFile("TestgetKanriByUserAuthority.xlsx")
	public void TestgetStringCodeNamePairList() throws Exception
	{
		List<StringCodeNamePair>  ret = mKanriLogic.getStringCodeNamePairList();
		exportJsonData(ret, "TestgetStringCodeNamePairList.json");
	}

	@Test
	@DisplayName("検索条件なしでM_管理名を取得しStringCodeNamePairの形式で返却します")
	@TestInitDataFile("TestgetKanriByUserAuthority.xlsx")
	public void TestgetMKanri() throws Exception
	{
		List<Short> liShorts = new ArrayList<Short>();
		Short KanriCode = 10;
		liShorts.add(KanriCode);
		List<MKanri> mList = new ArrayList<>();
		for(int item = 0; item < liShorts.size();item ++)
		{
			MKanri  ret = mKanriLogic.getMKanri(liShorts.get(item));
			mList.add(ret);
		}
		exportJsonData(mList, "TestgetMKanri.json");
	}

	@Test
	@DisplayName("検索条件なしでM_管理名を取得しStringCodeNamePairの形式で返却します")
	@TestInitDataFile("TestgetKanriByUserAuthority.xlsx")
	public void TestgetMKanriList() throws Exception
	{
		List<Short> liShorts = new ArrayList<Short>();
		Short KanriCode = 10;
		liShorts.add(KanriCode);
		List<MKanri>  ret = mKanriLogic.getMKanriList(liShorts);
		exportJsonData(ret, "TestgetMKanriList.json");
	}
	
	@Test
	@DisplayName("検索条件なしでM_管理名を取得しStringCodeNamePairの形式で返却します")
	@TestInitDataFile("TestgetKanriByUserAuthority.xlsx")
	public void TestGetJissekiMKanriList() throws Exception
	{
		List<Short> liShorts = new ArrayList<Short>();
		Short KanriCode = 10;
		liShorts.add(KanriCode);
		List<MKanri> ret =  mKanriLogic.getJissekiMKanriList(liShorts);
		exportJsonData(ret, "TestGetJissekiMKanriList.json");
	}
	@Test
	@DisplayName("検索条件なしでM_管理名を取得しStringCodeNamePairの形式で返却します")
	@TestInitDataFile("TestgetKanriByUserAuthority.xlsx")
	public void TestGetKariyoyakuSakujoKanriCodeList() throws Exception
	{
		List<Short> ret = mKanriLogic.getKariyoyakuSakujoKanriCodeList();
		exportJsonData(ret, "TestGetKariyoyakuSakujoKanriCodeList.json");
	}
	@Test
	@DisplayName("  データ更新に使用するDaoを取得します")
	public void TestgetDao() throws Exception
	{
		GenericDao<MKanri, ?>  ret = mKanriLogic.getDao();
	}
}