package jp.ne.yec.seagullLC.stagia.test.selenide.page.shinsei;

import static com.codeborne.selenide.Selenide.*;

/**
 * 明細一覧変更画面のテストクラス.
 *
 * @author nao-hirata
 *
 */
public class MeisaiIchiranHenkoTest extends MeisaiIchiranTest {

	public void clickTrashIcon(int row) {
		click($("i[wicketpath=form_velocityTablePanel_table_tbodyTr_" + String.valueOf(row) +  "_meisaiDeleteButton_trash]"));
	}

	@Override
	public ShinseiKakuninHenkoTest nextPage() {
		return takeScreenShotAndMovePage(shinseiKakuninButton, ShinseiKakuninHenkoTest.class);
	}

}
