package jp.ne.yec.seagullLC.stagia.test.junit.logic.transaction.TKampuLogic;

import static org.junit.Assert.*;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.beans.criteria.SearchIKeshikomiDto;
import jp.ne.yec.seagullLC.stagia.beans.enums.JokenHukumu;
import jp.ne.yec.seagullLC.stagia.beans.enums.domain.RyokinKubun;
import jp.ne.yec.seagullLC.stagia.beans.enums.domain.base.StagiaEnum;
import jp.ne.yec.seagullLC.stagia.beans.madoguchi.KampuKeshikomiDto;
import jp.ne.yec.seagullLC.stagia.entity.MBasho;
import jp.ne.yec.seagullLC.stagia.entity.MKanri;
import jp.ne.yec.seagullLC.stagia.entity.MShisetsu;
import jp.ne.yec.seagullLC.stagia.entity.TKampu;
import jp.ne.yec.seagullLC.stagia.logic.transaction.TKampuLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestTKampuLogic extends JunitBase {

	@Autowired
	TKampuLogic tKampuLogic;


	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestgetTKampuInit.xlsx")
	public void TestgetTKampu1() throws Exception
	{
		// Tạo Map<>
		Map<Short, List<Integer>> tKampuMap = new HashMap<Short, List<Integer>>();
		List<TKampu> ret = tKampuLogic.getTKampu(tKampuMap);
		assertEquals(0, ret.size());
	}

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestgetTKampuInit.xlsx")
	public void TestgetTKampu2() throws Exception
	{
		Map<Short, List<Integer>> tKampuMap = new HashMap<Short, List<Integer>>();
		List<Integer> tKampuValue = new ArrayList<>();
		tKampuValue.add(314);
		tKampuMap.put((short)10, tKampuValue);
		List<TKampu> ret = tKampuLogic.getTKampu(tKampuMap);
		exportJsonData(ret, "TestgetTKampu2.json");
	}

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestgetKampuKeshikomiDtoInit.xlsx")
	public void TestgetKampuKeshikomiDto() throws Exception
	{
		SearchIKeshikomiDto searchIKeshikomiDto = new SearchIKeshikomiDto();
		searchIKeshikomiDto.setLoginId("37986");

		MKanri mKanri = new MKanri();
		mKanri.setKanriCode((short)10);

		searchIKeshikomiDto.setMKanri(mKanri);
		searchIKeshikomiDto.setJoken(JokenHukumu.HUKUMU);

		List<KampuKeshikomiDto> ret = tKampuLogic.getKampuKeshikomiDto(searchIKeshikomiDto);
		exportJsonData(ret, "TestgetKampuKeshikomiDto.json");
	}


	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestgetKampuKeshikomiDtoInit.xlsx")
	public void TestgetKampuKeshikomiDto2() throws Exception
	{
		SimpleDateFormat sd = new SimpleDateFormat("yyyy/M/d");

		SearchIKeshikomiDto searchIKeshikomiDto = new SearchIKeshikomiDto();
		searchIKeshikomiDto.setLoginId("37986");

		MKanri mKanri = new MKanri();
		mKanri.setKanriCode((short)10);

		searchIKeshikomiDto.setMKanri(mKanri);
		searchIKeshikomiDto.setJoken(JokenHukumu.ICCHI);

		List<MShisetsu> mShisetsuList = new ArrayList<>();
		MShisetsu mShisetsu = new MShisetsu();
		mShisetsu.setKanriCode((short)10);
		mShisetsu.setBashoCode((short)10);
		mShisetsu.setShisetsuCode((short)10);
		mShisetsuList.add(mShisetsu);

		List<RyokinKubun> ryokinKubunList = new ArrayList<>();
		ryokinKubunList.add(RyokinKubun.SHISETSU);

		searchIKeshikomiDto.setMShisetsuList(mShisetsuList);
		searchIKeshikomiDto.setRyokinKubunList(ryokinKubunList);

		List<StagiaEnum> kampuJotaiList = new ArrayList<>();
		StagiaEnum stagiaEnum = RyokinKubun.SETSUBI;
		kampuJotaiList.add(stagiaEnum);

		StagiaEnum stagiaEnum2 = RyokinKubun.SHISETSU;

		List<StagiaEnum> kampuHohoList = new ArrayList<>();
		kampuHohoList.add(stagiaEnum2);

		searchIKeshikomiDto.setSeisanHohoList(kampuHohoList);
		searchIKeshikomiDto.setSeisanJotaiList(kampuJotaiList);

		searchIKeshikomiDto.setShinseiNoFrom(444);
		searchIKeshikomiDto.setShinseiNoTo(444);

		MBasho mBasho = new MBasho();
		mBasho.setBashoCode((short)10);
		searchIKeshikomiDto.setMBasho(mBasho);

		Date yoteiDateFrom = new Date();
		yoteiDateFrom = sd.parse("2018/5/25");
		Date yoteiDateTo = new Date();
		yoteiDateTo = sd.parse("2018/5/27");
		searchIKeshikomiDto.setYoteiDateFrom(yoteiDateFrom);
		searchIKeshikomiDto.setYoteiDateTo(yoteiDateTo);

		Date shiyoDateFrom = new Date();
		shiyoDateFrom = sd.parse("2018/4/18");
		Date shiyoDateTo = new Date();
		shiyoDateTo = sd.parse("2018/4/20");
		searchIKeshikomiDto.setShiyoDateFrom(shiyoDateFrom);
		searchIKeshikomiDto.setShiyoDateTo(shiyoDateTo);

		Date choteiDateFrom = new Date();
		choteiDateFrom = sd.parse("2018/5/26");
		Date choteiDateTo = new Date();
		choteiDateTo = sd.parse("2018/5/27");
		searchIKeshikomiDto.setChoteiDateFrom(choteiDateFrom);
		searchIKeshikomiDto.setChoteiDateTo(choteiDateTo);

		Date uketsukeDateFrom = new Date();
		uketsukeDateFrom = sd.parse("2018/5/24");
		Date uketsukeDateTo = new Date();
		uketsukeDateTo = sd.parse("2018/5/26");
		searchIKeshikomiDto.setUketsukeDateFrom(uketsukeDateFrom);
		searchIKeshikomiDto.setUketsukeDateTo(uketsukeDateTo);

		MBasho uketsukeBasho = new MBasho();
		uketsukeBasho.setBashoCode((short)1);
		searchIKeshikomiDto.setUketsukeBasho(uketsukeBasho);


		Date seisanDateFrom = new Date();
		seisanDateFrom = sd.parse("2018/5/25");
		Date seisanDateTo = new Date();
		seisanDateTo = sd.parse("2018/5/27");
		searchIKeshikomiDto.setSeisanDateFrom(seisanDateFrom);
		searchIKeshikomiDto.setSeisanDateTo(seisanDateTo);

		searchIKeshikomiDto.setSeisanNoFrom(313);
		searchIKeshikomiDto.setSeisanNoTo(315);

		List<KampuKeshikomiDto> ret = tKampuLogic.getKampuKeshikomiDto(searchIKeshikomiDto);
		exportJsonData(ret, "TestgetKampuKeshikomiDto2.json");
	}

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	//@TestInitDataFile("TestgetMBashoList.xlsx")
	public void TestgetDao() throws Exception
	{
		GenericDao<TKampu, ?> ret = tKampuLogic.getDao() ;
	}
}