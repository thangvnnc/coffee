package jp.ne.yec.seagullLC.stagia.test.junit.service.shinsei.MeisaiJohoSetteiService;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.seagullLC.stagia.entity.MKanri;
import jp.ne.yec.seagullLC.stagia.entity.MRyokinTaikei;
import jp.ne.yec.seagullLC.stagia.entity.MShinsaRiyu;
import jp.ne.yec.seagullLC.stagia.entity.MWebSettei;
import jp.ne.yec.seagullLC.stagia.service.shinsei.MeisaiJohoSetteiService;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestMeisaiJohoSetteiService extends JunitBase{

	@Autowired
	MeisaiJohoSetteiService meisaiJohoSetteiService;

	@Test
	@DisplayName("M_管理を取得します.")
	@TestInitDataFile("TestGetMKanri_Init.xlsx")
	public void TestGetMKanri() throws Exception{
		short kanriCode = 10;
		MKanri mKanri = meisaiJohoSetteiService.getMKanri(kanriCode);
		exportJsonData(mKanri, "TestGetMKanri.json");
	}

	@Test
	@DisplayName("M_WEB設定を取得します.")
	@TestInitDataFile("TestGetMWebSettei_Init.xlsx")
	public void TestGetMWebSettei() throws Exception{
		short kanriCode = 10;
		MWebSettei mWebSettei = meisaiJohoSetteiService.getMWebSettei(kanriCode);
		exportJsonData(mWebSettei, "TestGetMWebSettei.json");
	}

	@Test
	@DisplayName("M_審査理由のリストを返却します. 審査が不要な施設の場合、空のリストを返却します。")
	@TestInitDataFile("TestGetMShinsaRiyu_Step1_Init.xlsx")
	public void TestGetMShinsaRiyu_Step1() throws Exception{
		short kanriCode = 10;
		List<MShinsaRiyu> list = meisaiJohoSetteiService.getMShinsaRiyu(true, kanriCode);
		exportJsonData(list, "TestGetMShinsaRiyu_Step1.json");
	}

	@Test
	@DisplayName("M_審査理由のリストを返却します. 審査が不要な施設の場合、空のリストを返却します。")
	@TestInitDataFile("TestGetMShinsaRiyu_Step2_Init.xlsx")
	public void TestGetMShinsaRiyu_Step2() throws Exception{
		short kanriCode = 10;
		List<MShinsaRiyu> list = meisaiJohoSetteiService.getMShinsaRiyu(false, kanriCode);
		assertEquals(0, list.size());
	}


	@Test
	@TestInitDataFile("TestGetMRyokinKeisanKomoku_Init.xlsx")
	public void TestGetMRyokinKeisanKomoku() throws Exception{
		short kanriCode = 10;
		List<MRyokinTaikei> list = meisaiJohoSetteiService.getMRyokinTaikei(kanriCode);
		exportJsonData(list, "TestGetMRyokinKeisanKomoku.json");
	}

//	@Test
//	@DisplayName("管理コードを条件にM_料金計算項目を取得し返却します.")
//	public void TestGetMRyokinKeisanKomoku() throws Exception{
//		List<Short> listKanriCode = readArrShort("TestGetMRyokinKeisanKomoku_kanriCode.txt");
//		for (Short kanriCode : listKanriCode) {
//			List<MRyokinKeisanKomoku> list = meisaiJohoSetteiService.getMRyokinKeisanKomoku(kanriCode);
//			assertNotNull(list);
//		}
//	}
//
//	@Test
//	@DisplayName("管理コードを条件にM_料金計算内容を取得し返却します.")
//	public void TestGetMRyokinKeisanNaiyo() throws Exception{
//		List<Short> listKanriCode = readArrShort("TestGetMRyokinKeisanNaiyo_kanriCode.txt");
//		for (Short kanriCode : listKanriCode) {
//			List<MRyokinKeisanNaiyo> list = meisaiJohoSetteiService.getMRyokinKeisanNaiyo(kanriCode);
//			assertNotNull(list);
//		}
//	}
//
//	@Test
//	@DisplayName("管理コードを条件にkeyがリハーサルコード、valueがM_リハーサルのMapを取得し返却します.")
//	public void TestGetMRehearsalMap() throws Exception{
//		List<Short> listKanriCode = readArrShort("TestGetMRehearsalMap_kanriCode.txt");
//		for (Short kanriCode : listKanriCode) {
//			Map<Short, MRehearsal> map = meisaiJohoSetteiService.getMRehearsalMap(kanriCode);
//			assertNotNull(map);
//		}
//	}
//
//	@Test
//	@DisplayName("M_料金計算式を取得します.")
//	public void TestGetMRyokinKeisanShiki() throws Exception{
//		List<Short> listKanriCode = readArrShort("TestGetMRyokinKeisanShiki_kanriCode.txt");
//		for (Short kanriCode : listKanriCode) {
//			List<MRyokinKeisanShiki> list = meisaiJohoSetteiService.getMRyokinKeisanShiki(kanriCode);
//			assertNotNull(list);
//		}
//	}
//
//	@Test
//	@DisplayName("M_施設受付を取得します.")
//	public void TestGetMShisetsuUketsuke() throws Exception{
//		List<Short> listKanriCode = readArrShort("TestGetMShisetsuUketsuke_kanriCode.txt");
//		List<Short> listShisetsuCode = readArrShort("TestGetMShisetsuUketsuke_shisetsuCode.txt");
//		List<Short> listRiyoshaGroupCode = readArrShort("TestGetMShisetsuUketsuke_riyoshaGroupCode.txt");
//
//		for (int idx = 0; idx < listKanriCode.size(); idx++) {
//			MShisetsuUketsuke mShisetsuUketsuke = meisaiJohoSetteiService.getMShisetsuUketsuke(
//					listKanriCode.get(idx),
//					listShisetsuCode.get(idx),
//					listRiyoshaGroupCode.get(idx)
//					);
//			assertNotNull(mShisetsuUketsuke);
//		}
//	}
}
