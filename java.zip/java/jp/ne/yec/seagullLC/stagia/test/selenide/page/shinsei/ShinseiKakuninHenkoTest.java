package jp.ne.yec.seagullLC.stagia.test.selenide.page.shinsei;

/**
 * 申請確認変更画面のテストクラス.
 *
 * @author nao-hirata
 *
 */
public class ShinseiKakuninHenkoTest extends ShinseiKakuninTest {

	@Override
	public void kakuteiButtonClick() {
		click(shinseiKakuteiButton);
	}
}
