package jp.ne.yec.seagullLC.stagia.test.junit.logic.transaction.TKanribetsuRiyoshaJohoLogic;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.entity.TKanribetsuRiyoshaJoho;
import jp.ne.yec.seagullLC.stagia.logic.transaction.TKanribetsuRiyoshaJohoLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestTKanribetsuRiyoshaJohoLogic extends JunitBase {

	@Autowired
	TKanribetsuRiyoshaJohoLogic tKanribetsuRiyoshaJohoLogic;

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetTKanribetsuRiyoshaJohoInit.xlsx")
	public void TestgetTKanribetsuRiyoshaJoho() throws Exception
	{
		String loginId= "1";
		List<TKanribetsuRiyoshaJoho> ret =  tKanribetsuRiyoshaJohoLogic.getTKanribetsuRiyoshaJoho(loginId);
		exportJsonData(ret, "TestgetTKanribetsuRiyoshaJoho.json");
	}
	
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetTKanribetsuRiyoshaJohoByPKInit.xlsx")
	public void TestgetTKanribetsuRiyoshaJohoByPK() throws Exception
	{
		List<TKanribetsuRiyoshaJoho> tList = new ArrayList<>();
		String loginId = "1";
		Short kanriCode = 10;
		
		TKanribetsuRiyoshaJoho ret =  tKanribetsuRiyoshaJohoLogic.getTKanribetsuRiyoshaJohoByPK(loginId,kanriCode);
		tList.add(ret);
		exportJsonData(tList, "TestgetTKanribetsuRiyoshaJohoByPK.json");	
	}
	
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetTKanribetsuRiyoshaJoho_LisInit.xlsx")
	public void TestgetTKanribetsuRiyoshaJoho_List() throws Exception
	{
		String loginId = "1";
		List<Short> listKanriCode = new ArrayList<>();
		listKanriCode.add((short)10);
		List<TKanribetsuRiyoshaJoho> ret =  tKanribetsuRiyoshaJohoLogic.getTKanribetsuRiyoshaJoho(loginId, listKanriCode);
		exportJsonData(ret, "TestgetTKanribetsuRiyoshaJoho_List.json");	
	}
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	//@TestInitDataFile("TestgetMBashoList.xlsx")
	public void TestgetDao() throws Exception
	{
		GenericDao<TKanribetsuRiyoshaJoho, ?> ret = tKanribetsuRiyoshaJohoLogic.getDao() ;
	}
}