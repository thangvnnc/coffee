package jp.ne.yec.seagullLC.stagia.test.junit.logic.master.MBashoLogic;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.beans.StringCodeNamePair;
import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.entity.MBasho;
import jp.ne.yec.seagullLC.stagia.logic.master.MBashoLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestMBashoLogic extends JunitBase {


	@Autowired
	MBashoLogic mBashoLogic;

	@Test
	@DisplayName("検索条件なしで場所マスタを取得し、返却します")
	@TestInitDataFile("TestgetMBashoList.xlsx")
	public void TestgetMBashoList() throws Exception
	{
		List<MBasho> ret = mBashoLogic.getMBashoList();
		exportJsonData(ret, "TestgetMBashoList.json");
	}

	@Test
	@DisplayName("検索条件なしで申請受付場所(場所マスタ.受付有無が有のレコード）を取得し、返却します")
	@TestInitDataFile("TestgetMBashoList.xlsx")
	public void TestgetUketsukeBashoList() throws Exception
	{
		List<MBasho> ret = mBashoLogic.getUketsukeBashoList();
		exportJsonData(ret, "TestgetUketsukeBashoList.json");
	}

	@Test
	@DisplayName("検索条件なしでM_場所を取得しStringCodeNamePairの形式で返却します")
	@TestInitDataFile("TestgetMBashoList.xlsx")
	public void TestgetStringCodeNamePairList() throws Exception
	{
		List<StringCodeNamePair> ret =  mBashoLogic.getStringCodeNamePairList();
		exportJsonData(ret, "TestgetStringCodeNamePairList.json");
	}

	@Test
	@DisplayName("検索条件なしでM_場所を取得しStringCodeNamePairの形式で返却します")
	@TestInitDataFile("TestgetMBashoList.xlsx")
	public void TestgetMBashoListByBashoCode() throws Exception
	{
		List<Short> bashoCodeList = new ArrayList<Short>();
		bashoCodeList.add((short)10);
		List<MBasho> ret = mBashoLogic.getMBashoListByBashoCode(bashoCodeList);
		exportJsonData(ret, "TestgetMBashoListByBashoCode.json");
	}

	@Test
	@DisplayName("検索条件なしでM_場所を取得しStringCodeNamePairの形式で返却します")
	@TestInitDataFile("TestgetMBashoList.xlsx")
	public void TestgetMBasho() throws Exception
	{
		List<MBasho> List = new ArrayList<MBasho>();
		Short bashoCode = 10;
		MBasho ret = mBashoLogic.getMBasho(bashoCode);
		List.add(ret);
		exportJsonData(List, "TestgetMBasho.json");
	}
	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	// @TestInitDataFile("TestRiyoshaServiceInit.xlsx")
	public void TestgetDao() throws Exception
	{
		GenericDao<MBasho, ?> ret = mBashoLogic.getDao();
	}
}

