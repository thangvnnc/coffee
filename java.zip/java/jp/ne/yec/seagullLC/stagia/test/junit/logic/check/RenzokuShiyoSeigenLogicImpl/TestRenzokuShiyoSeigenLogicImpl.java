package jp.ne.yec.seagullLC.stagia.test.junit.logic.check.RenzokuShiyoSeigenLogicImpl;

import static org.junit.Assert.*;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.google.gson.reflect.TypeToken;

import jp.ne.yec.seagullLC.stagia.beans.enums.domain.ShinseiShurui;
import jp.ne.yec.seagullLC.stagia.beans.riyosha.KoseiinJohoDto;
import jp.ne.yec.seagullLC.stagia.beans.shinsei.ShinseiMeisaiDto;
import jp.ne.yec.seagullLC.stagia.logic.check.RenzokuShiyoSeigenLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestRenzokuShiyoSeigenLogicImpl extends JunitBase {


	@Autowired
	RenzokuShiyoSeigenLogic renzokuShiyoSeigenLogic;

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	//@TestInitDataFile("TestgetMBashoList.xlsx")
	public void TestKoseiinJohoEntityToKoseiinJohoDto() throws Exception
	{
		List<List<KoseiinJohoDto>> jsonData = new ArrayList<List<KoseiinJohoDto>>();

		String loginId = "1";
		Map<ShinseiShurui, List<ShinseiMeisaiDto>> meisaiMap = new HashMap<>();
		//String loginId, Map<ShinseiShurui, List<T>> meisaiMap, Date uketsukeDate
		List<ShinseiMeisaiDto> shinseiMeisaiDtos = readJson("shinseiMeisaiDtos_in.json", new TypeToken<List<ShinseiMeisaiDto> >(){}.getType());
		meisaiMap.put(ShinseiShurui.CHUSEN, shinseiMeisaiDtos);
		Date uketsukeDate = new Date();
		renzokuShiyoSeigenLogic.check(loginId,meisaiMap, uketsukeDate );

	}

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	//@TestInitDataFile("TestgetMBashoList.xlsx")
	public void TestKoseiinJohoEntityToKoseiinJohoDto_Step2() throws Exception
	{
		List<List<KoseiinJohoDto>> jsonData = new ArrayList<List<KoseiinJohoDto>>();

		String loginId = "1";
		Map<ShinseiShurui, List<ShinseiMeisaiDto>> meisaiMap = new HashMap<>();
		//String loginId, Map<ShinseiShurui, List<T>> meisaiMap, Date uketsukeDate
		List<ShinseiMeisaiDto> shinseiMeisaiDtos = readJson("shinseiMeisaiDtos_in.json", new TypeToken<List<ShinseiMeisaiDto> >(){}.getType());
		meisaiMap.put(ShinseiShurui.KARIYOYAKU, shinseiMeisaiDtos);
		Date uketsukeDate = new Date();
		renzokuShiyoSeigenLogic.check(loginId,meisaiMap, uketsukeDate );

	}

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestKoseiinJohoEntityToKoseiinJohoDto_Step3Init.xlsx")
	public void TestKoseiinJohoEntityToKoseiinJohoDto_Step3() throws Exception
	{
		List<List<KoseiinJohoDto>> jsonData = new ArrayList<List<KoseiinJohoDto>>();

		String loginId = "1";
		Map<ShinseiShurui, List<ShinseiMeisaiDto>> meisaiMap = new HashMap<>();
		//String loginId, Map<ShinseiShurui, List<T>> meisaiMap, Date uketsukeDate
		List<ShinseiMeisaiDto> shinseiMeisaiDtos = readJson("shinseiMeisaiDtos_in.json", new TypeToken<List<ShinseiMeisaiDto> >(){}.getType());
		meisaiMap.put(ShinseiShurui.KARIYOYAKU, shinseiMeisaiDtos);
		Date uketsukeDate = new Date();
		renzokuShiyoSeigenLogic.check(loginId,meisaiMap, uketsukeDate );

	}

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestKoseiinJohoEntityToKoseiinJohoDto_Step3Init.xlsx")
	public void TestKoseiinJohoEntityToKoseiinJohoDto_Step4() throws Exception
	{
		List<List<KoseiinJohoDto>> jsonData = new ArrayList<List<KoseiinJohoDto>>();

		String loginId = "1";
		Map<ShinseiShurui, List<ShinseiMeisaiDto>> meisaiMap = new HashMap<>();
		//String loginId, Map<ShinseiShurui, List<T>> meisaiMap, Date uketsukeDate
		List<ShinseiMeisaiDto> shinseiMeisaiDtos = readJson("shinseiMeisaiDtos_in.json", new TypeToken<List<ShinseiMeisaiDto> >(){}.getType());
		shinseiMeisaiDtos.get(1).setId(null);
		meisaiMap.put(ShinseiShurui.KARIYOYAKU, shinseiMeisaiDtos);
		Date uketsukeDate = new Date();
		renzokuShiyoSeigenLogic.check(loginId,meisaiMap, uketsukeDate );

	}

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestKoseiinJohoEntityToKoseiinJohoDto_Step3Init.xlsx")
	public void TestKoseiinJohoEntityToKoseiinJohoDto_Step5() throws Exception
	{
		List<List<KoseiinJohoDto>> jsonData = new ArrayList<List<KoseiinJohoDto>>();

		String loginId = "1";
		Map<ShinseiShurui, List<ShinseiMeisaiDto>> meisaiMap = new HashMap<>();
		//String loginId, Map<ShinseiShurui, List<T>> meisaiMap, Date uketsukeDate
		List<ShinseiMeisaiDto> shinseiMeisaiDtos = readJson("shinseiMeisaiDtos_in.json", new TypeToken<List<ShinseiMeisaiDto> >(){}.getType());
		shinseiMeisaiDtos.get(1).setId(100);
		meisaiMap.put(ShinseiShurui.KARIYOYAKU, shinseiMeisaiDtos);
		Date uketsukeDate = new Date();
		renzokuShiyoSeigenLogic.check(loginId,meisaiMap, uketsukeDate );

	}

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestKoseiinJohoEntityToKoseiinJohoDto_Step3Init.xlsx")
	public void TestKoseiinJohoEntityToKoseiinJohoDto_Step6() throws Exception
	{
		List<List<KoseiinJohoDto>> jsonData = new ArrayList<List<KoseiinJohoDto>>();

		String loginId = "1";
		Map<ShinseiShurui, List<ShinseiMeisaiDto>> meisaiMap = new HashMap<>();
		//String loginId, Map<ShinseiShurui, List<T>> meisaiMap, Date uketsukeDate
		List<ShinseiMeisaiDto> shinseiMeisaiDtos = readJson("shinseiMeisaiDtos_in.json", new TypeToken<List<ShinseiMeisaiDto> >(){}.getType());
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
		Date shunoDate = formatter.parse("2018/08/30");
		shinseiMeisaiDtos.get(1).setShiyoDate(shunoDate);
		meisaiMap.put(ShinseiShurui.KARIYOYAKU, shinseiMeisaiDtos);
		Date uketsukeDate = new Date();
		renzokuShiyoSeigenLogic.check(loginId,meisaiMap, uketsukeDate );

	}

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestKoseiinJohoEntityToKoseiinJohoDto_Step3Init.xlsx")
	public void TestKoseiinJohoEntityToKoseiinJohoDto_Step7() throws Exception
	{
		List<List<KoseiinJohoDto>> jsonData = new ArrayList<List<KoseiinJohoDto>>();

		String loginId = "1";
		Map<ShinseiShurui, List<ShinseiMeisaiDto>> meisaiMap = new HashMap<>();
		//String loginId, Map<ShinseiShurui, List<T>> meisaiMap, Date uketsukeDate
		List<ShinseiMeisaiDto> shinseiMeisaiDtos = readJson("shinseiMeisaiDtos_in.json", new TypeToken<List<ShinseiMeisaiDto> >(){}.getType());
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
		Date shunoDate = formatter.parse("2019/10/10");
		shinseiMeisaiDtos.get(1).setShiyoDate(shunoDate);
		meisaiMap.put(ShinseiShurui.KARIYOYAKU, shinseiMeisaiDtos);
		Date uketsukeDate = formatter.parse("2017/10/10");
		renzokuShiyoSeigenLogic.check(loginId,meisaiMap, uketsukeDate );

	}

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestKoseiinJohoEntityToKoseiinJohoDto_Step4Init.xlsx")
	public void TestKoseiinJohoEntityToKoseiinJohoDto_Step8() throws Exception
	{
		List<List<KoseiinJohoDto>> jsonData = new ArrayList<List<KoseiinJohoDto>>();

		String loginId = "1";
		Map<ShinseiShurui, List<ShinseiMeisaiDto>> meisaiMap = new HashMap<>();
		//String loginId, Map<ShinseiShurui, List<T>> meisaiMap, Date uketsukeDate
		List<ShinseiMeisaiDto> shinseiMeisaiDtos = readJson("shinseiMeisaiDtos_in.json", new TypeToken<List<ShinseiMeisaiDto> >(){}.getType());
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
		Date shunoDate = formatter.parse("2019/10/10");
		shinseiMeisaiDtos.get(1).setShiyoDate(shunoDate);
		meisaiMap.put(ShinseiShurui.KARIYOYAKU, shinseiMeisaiDtos);
		Date uketsukeDate = formatter.parse("2017/10/10");
		renzokuShiyoSeigenLogic.check(loginId,meisaiMap, uketsukeDate );

	}

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestKoseiinJohoEntityToKoseiinJohoDto_Step9Init.xlsx")
	public void TestKoseiinJohoEntityToKoseiinJohoDto_Step9() throws Exception
	{
		List<List<KoseiinJohoDto>> jsonData = new ArrayList<List<KoseiinJohoDto>>();

		String loginId = "1";
		Map<ShinseiShurui, List<ShinseiMeisaiDto>> meisaiMap = new HashMap<>();
		//String loginId, Map<ShinseiShurui, List<T>> meisaiMap, Date uketsukeDate
		List<ShinseiMeisaiDto> shinseiMeisaiDtos = readJson("shinseiMeisaiDtos_in.json", new TypeToken<List<ShinseiMeisaiDto> >(){}.getType());
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
		Date shunoDate = formatter.parse("2019/10/10");
		shinseiMeisaiDtos.get(1).setShiyoDate(shunoDate);
		meisaiMap.put(ShinseiShurui.KARIYOYAKU, shinseiMeisaiDtos);
		Date uketsukeDate = formatter.parse("2017/10/10");
		renzokuShiyoSeigenLogic.check(loginId,meisaiMap, uketsukeDate );

	}

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestKoseiinJohoEntityToKoseiinJohoDto_Step10Init.xlsx")
	public void TestKoseiinJohoEntityToKoseiinJohoDto_Step10() throws Exception
	{
		List<List<KoseiinJohoDto>> jsonData = new ArrayList<List<KoseiinJohoDto>>();

		String loginId = "1";
		Map<ShinseiShurui, List<ShinseiMeisaiDto>> meisaiMap = new HashMap<>();
		//String loginId, Map<ShinseiShurui, List<T>> meisaiMap, Date uketsukeDate
		List<ShinseiMeisaiDto> shinseiMeisaiDtos = readJson("shinseiMeisaiDtos_in.json", new TypeToken<List<ShinseiMeisaiDto> >(){}.getType());
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
		Date shunoDate = formatter.parse("2019/10/10");
		shinseiMeisaiDtos.get(1).setShiyoDate(shunoDate);
		meisaiMap.put(ShinseiShurui.KARIYOYAKU, shinseiMeisaiDtos);
		Date uketsukeDate = formatter.parse("2017/10/10");
		try
		{
		renzokuShiyoSeigenLogic.check(loginId,meisaiMap, uketsukeDate );
		}
		catch(Exception ex)
		{
			String a = ex.getMessage();
			assertEquals("", ex.getMessage());
		}
	}

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestKoseiinJohoEntityToKoseiinJohoDto_Step11Init.xlsx")
	public void TestKoseiinJohoEntityToKoseiinJohoDto_Step11() throws Exception
	{
		List<List<KoseiinJohoDto>> jsonData = new ArrayList<List<KoseiinJohoDto>>();

		String loginId = "1";
		Map<ShinseiShurui, List<ShinseiMeisaiDto>> meisaiMap = new HashMap<>();
		//String loginId, Map<ShinseiShurui, List<T>> meisaiMap, Date uketsukeDate
		List<ShinseiMeisaiDto> shinseiMeisaiDtos = readJson("shinseiMeisaiDtos_in.json", new TypeToken<List<ShinseiMeisaiDto> >(){}.getType());
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
		Date shunoDate = formatter.parse("2019/10/10");
		shinseiMeisaiDtos.get(1).setShiyoDate(shunoDate);
		meisaiMap.put(ShinseiShurui.KARIYOYAKU, shinseiMeisaiDtos);
		Date uketsukeDate = formatter.parse("2017/10/10");
		try
		{
		renzokuShiyoSeigenLogic.check(loginId,meisaiMap, uketsukeDate );
		}
		catch(Exception ex)
		{
			String a = ex.getMessage();
			assertEquals("", ex.getMessage());
		}
	}
}

