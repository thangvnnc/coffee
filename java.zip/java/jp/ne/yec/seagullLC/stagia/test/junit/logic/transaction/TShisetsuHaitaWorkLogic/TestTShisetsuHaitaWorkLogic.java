package jp.ne.yec.seagullLC.stagia.test.junit.logic.transaction.TShisetsuHaitaWorkLogic;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.seagullLC.stagia.beans.shinsei.ShinseiMeisaiDto;
import jp.ne.yec.seagullLC.stagia.entity.MHaitaKashidashiTani;
import jp.ne.yec.seagullLC.stagia.logic.transaction.TShisetsuHaitaWorkLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration

public class TestTShisetsuHaitaWorkLogic extends JunitBase {

	@Autowired
	TShisetsuHaitaWorkLogic tShisetsuHaitaWorkLogic;

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestInsertShisetsuKomaInit.xlsx")
	public void TestInsertShisetsuKoma() throws Exception
	{
		List<ShinseiMeisaiDto> meisaiDtos = new ArrayList<>();
		List<MHaitaKashidashiTani> haitaTaniList = new ArrayList<>();
		
		MHaitaKashidashiTani mHai = new MHaitaKashidashiTani();
		mHai.setKanriCode((short)10);
		mHai.setShisetsuCode((short)10);
		mHai.setKashidashiTaniCode((short)0);
		
		haitaTaniList.add(mHai);
		Date date = new Date();
		SimpleDateFormat sd = new SimpleDateFormat("yyyy/M/d");
		date = sd.parse("2018/7/3");
		
		ShinseiMeisaiDto shinsei = new ShinseiMeisaiDto();
		shinsei.setKanriCode((short)10);
		shinsei.setBashoCode((short)10);
		shinsei.setShisetsuCode((short)10);
		//shinsei.setKashidashiTaniCode((short)10);
		shinsei.setShiyoDate(date);
		shinsei.setStartKoma((short)10);
		shinsei.setEndKoma((short)10);
		meisaiDtos.add(shinsei);
		
		String sessionId = "asd";
		String updatedBy = "asd";
		tShisetsuHaitaWorkLogic.insertShisetsuKoma(meisaiDtos, haitaTaniList, sessionId, updatedBy);
	}
	
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestInsertShisetsuKomaInit.xlsx")
	public void TestInsertShisetsuKoma2() throws Exception
	{
		List<ShinseiMeisaiDto> meisaiDtos = new ArrayList<>();
		List<MHaitaKashidashiTani> haitaTaniList = new ArrayList<>();
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/M/d HH:mm");
		Date dateCreate = new Date();
		dateCreate = dateFormat.parse("2018/7/5 15:05");
		long timeCreate = dateCreate.getTime();
		Timestamp tCreate = new Timestamp(timeCreate);

		Date dateUpdate = new Date();
		dateUpdate = dateFormat.parse("2018/7/6 15:05");
		long timeUpdate= dateUpdate.getTime();
		Timestamp tUpdate = new Timestamp(timeUpdate);
		
		MHaitaKashidashiTani mHai = new MHaitaKashidashiTani();
		mHai.setKanriCode((short)20);
		mHai.setShisetsuCode((short)20);
		mHai.setKashidashiTaniCode((short)1);
		mHai.setCreatedAt(tCreate);
		mHai.setCreatedBy("123");
		mHai.setUpdatedAt(tUpdate);
		mHai.setUpdatedBy("123");
		mHai.setVersion(1);
		mHai.setHaitaKashidashiTaniCode((short)0);
		mHai.setHaitaShisetsuCode((short)10);
		
		haitaTaniList.add(mHai);
		Date date = new Date();
		SimpleDateFormat sd = new SimpleDateFormat("yyyy/M/d");
		date = sd.parse("2018/7/5");
		
		ShinseiMeisaiDto shinsei = new ShinseiMeisaiDto();
		shinsei.setKanriCode((short)20);
		shinsei.setBashoCode((short)20);
		shinsei.setShisetsuCode((short)20);
		shinsei.setKashidashiTaniCode((short)1);
		shinsei.setShiyoDate(date);
		shinsei.setStartKoma((short)20);
		shinsei.setEndKoma((short)20);
		meisaiDtos.add(shinsei);
		
		String sessionId = "asd";
		String updatedBy = "asd";
		tShisetsuHaitaWorkLogic.insertShisetsuKoma(meisaiDtos, haitaTaniList, sessionId, updatedBy);
	}
	
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestInsertShisetsuKomaInit.xlsx")
	public void TestInsertShisetsuKoma3() throws Exception
	{
		List<ShinseiMeisaiDto> meisaiDtos = new ArrayList<>();
		List<MHaitaKashidashiTani> haitaTaniList = new ArrayList<>();
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/M/d HH:mm");
		Date dateCreate = new Date();
		dateCreate = dateFormat.parse("2018/7/5 15:05");
		long timeCreate = dateCreate.getTime();
		Timestamp tCreate = new Timestamp(timeCreate);

		Date dateUpdate = new Date();
		dateUpdate = dateFormat.parse("2018/7/6 15:05");
		long timeUpdate= dateUpdate.getTime();
		Timestamp tUpdate = new Timestamp(timeUpdate);
		
		MHaitaKashidashiTani mHai = new MHaitaKashidashiTani();
		mHai.setKanriCode((short)20);
		mHai.setShisetsuCode((short)20);
		mHai.setKashidashiTaniCode((short)1);
		mHai.setCreatedAt(tCreate);
		mHai.setCreatedBy("123");
		mHai.setUpdatedAt(tUpdate);
		mHai.setUpdatedBy("123");
		mHai.setVersion(1);
		mHai.setHaitaKashidashiTaniCode((short)0);
		mHai.setHaitaShisetsuCode((short)10);
		
		haitaTaniList.add(mHai);
		Date date = new Date();
		SimpleDateFormat sd = new SimpleDateFormat("yyyy/M/d");
		date = sd.parse("2018/7/5");
		
		ShinseiMeisaiDto shinsei = new ShinseiMeisaiDto();
		shinsei.setKanriCode((short)30);
		shinsei.setBashoCode((short)30);
		shinsei.setShisetsuCode((short)30);
		shinsei.setKashidashiTaniCode((short)2);
		shinsei.setShiyoDate(date);
		shinsei.setStartKoma((short)20);
		shinsei.setEndKoma((short)20);
		meisaiDtos.add(shinsei);
		
		String sessionId = "asd";
		String updatedBy = "asd";
		tShisetsuHaitaWorkLogic.insertShisetsuKoma(meisaiDtos, haitaTaniList, sessionId, updatedBy);
	}
	
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestInsertShisetsuKomaInit.xlsx")
	public void TestDeleteBySessionId() throws Exception
	{
		String sessionId = "asd";
		tShisetsuHaitaWorkLogic.deleteBySessionId(sessionId);
	}
	
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestInsKyukanBashoHaitaInit.xlsx")
	public void TestInsKyukanBashoHaita() throws Exception
	{
		Short bashoCode = 10;
		List<LocalDate> kyukanbiList = new ArrayList<>();
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/M/yyyy");
        
		String date = "7/7/2018";

        LocalDate localDate = LocalDate.parse(date, formatter);
	
		kyukanbiList.add(localDate);
		String updatedBy = "asd";
		String sessionId = "asd";
		tShisetsuHaitaWorkLogic.insKyukanBashoHaita(bashoCode, kyukanbiList, sessionId,updatedBy);
	}
	
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestInsKyukanBashoHaitaInit.xlsx")
	public void TestInsKyukanBashoHaita2() throws Exception
	{
		Short bashoCode = 10;
		List<LocalDate> kyukanbiList = new ArrayList<>();
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/M/yyyy");
        
		String date = "8/7/2018";

        LocalDate localDate = LocalDate.parse(date, formatter);
	
		kyukanbiList.add(localDate);
		String updatedBy = "asd";
		String sessionId = "asd";
		tShisetsuHaitaWorkLogic.insKyukanBashoHaita(bashoCode, kyukanbiList, sessionId,updatedBy);
	}
	
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestInsKyukanBashoHaitaInit.xlsx")
	public void TestInsKyukanBashoHaita3() throws Exception
	{
		Short bashoCode = 10;
		List<LocalDate> kyukanbiList = new ArrayList<>();
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/M/yyyy");
        
		String date = "1/1/2018";

        LocalDate localDate = LocalDate.parse(date, formatter);
	
		kyukanbiList.add(localDate);
		String updatedBy = "asd";
		String sessionId = "asd";
		tShisetsuHaitaWorkLogic.insKyukanBashoHaita(bashoCode, kyukanbiList, sessionId,updatedBy);
	}
	
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestInsKyukanBashoHaitaInit.xlsx")
	public void TestInsKyukanBashoHaita4() throws Exception
	{
		Short bashoCode = 10;
		List<LocalDate> kyukanbiList = new ArrayList<>();
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("d/M/yyyy");
        
		String date = "5/7/2018";

        LocalDate localDate = LocalDate.parse(date, formatter);
	
		kyukanbiList.add(localDate);
		String updatedBy = "asd";
		String sessionId = "asd";
		tShisetsuHaitaWorkLogic.insKyukanBashoHaita(bashoCode, kyukanbiList, sessionId,updatedBy);
	}
	
}
