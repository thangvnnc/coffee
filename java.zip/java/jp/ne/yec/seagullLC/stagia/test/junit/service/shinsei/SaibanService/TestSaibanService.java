package jp.ne.yec.seagullLC.stagia.test.junit.service.shinsei.SaibanService;

import static org.junit.Assert.*;

import java.util.Queue;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.seagullLC.stagia.beans.enums.domain.SaibanShurui;
import jp.ne.yec.seagullLC.stagia.service.shinsei.SaibanService;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestSaibanService extends JunitBase{

	@Autowired
	SaibanService saibanService;

	@Test
	@TestInitDataFile("TestGetSaibanInit.xlsx")
	@DisplayName("指定された管理コード、採番種類より番号を採番し返却します. 採番が完了した時点で、T採番該当行の番号をインクリメントします.")
	public void TestGetSaiban() throws Exception{
		Short kanriCode = 10;
		String updatedBy = "3718";
		int result = saibanService.getSaiban(kanriCode, SaibanShurui.SHINSEI, updatedBy);
		assertEquals(720, result);
	}

	@Test
	@TestInitDataFile("TestGetSaibanInit.xlsx")
	@DisplayName("指定された管理コード、採番種類、取得する採番数より番号を採番し返却します.")
	public void TestGetSaibanCount() throws Exception{
		Short kanriCode = 10;
		String updatedBy = "3718";
		Queue<Integer>  result = saibanService.getSaiban(kanriCode, SaibanShurui.SHINSEI, 1, updatedBy);
		exportJsonData(result, "TestGetSaibanCount.json");
	}

}
