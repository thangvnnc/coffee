package jp.ne.yec.seagullLC.stagia.test.junit.logic.master.MShukeiLogic;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.entity.MShukei;
import jp.ne.yec.seagullLC.stagia.logic.master.MShukeiLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestMShukeiLogic extends JunitBase {

	@Autowired
	MShukeiLogic mShukeiLogic;

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetMShukei.xlsx")
	public void TestgetMShukei() throws Exception
	{
		List<Short> kanriCodes = new ArrayList<>();
		kanriCodes.add((short)10);
		List<MShukei>  ret = mShukeiLogic.getMShukei(kanriCodes);
		exportJsonData(ret, "TestgetMShukei.json");
	}

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetMShukei.xlsx")
	public void TestgetMShukei_List() throws Exception
	{
		Short kanriCode = 10;
		List<MShukei> ret = mShukeiLogic.getMShukei(kanriCode);
		exportJsonData(ret, "TestgetMShukei_List.json");
	}

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	//@TestInitDataFile("TestgetMBashoList.xlsx")
	public void TestgetDao() throws Exception
	{
		GenericDao<MShukei, ?> ret =  mShukeiLogic.getDao();
	}
}