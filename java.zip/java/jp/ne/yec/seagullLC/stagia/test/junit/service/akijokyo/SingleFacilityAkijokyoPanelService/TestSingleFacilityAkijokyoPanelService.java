package jp.ne.yec.seagullLC.stagia.test.junit.service.akijokyo.SingleFacilityAkijokyoPanelService;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.beans.StringCodeNamePair;
import jp.ne.yec.seagullLC.stagia.entity.MShisetsu;
import jp.ne.yec.seagullLC.stagia.service.akijokyo.SingleFacilityAkijokyoPanelService;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestSingleFacilityAkijokyoPanelService extends JunitBase {

	@Autowired
	SingleFacilityAkijokyoPanelService singleFacilityAkijokyoPanelService;

//	@Test
//	@DisplayName("データ更新に使用するDaoを取得します")
//	//@TestInitDataFile("TestgetMBashoList.xlsx")
//	public void TestCreateAkijokyo() throws Exception
//	{
//		List<MShisetsu> mShisetsus = new ArrayList<>();
//		mShisetsus.add(new MShisetsu());
//
//		List<List<LocalDate>> dateLists = new ArrayList<>();
//		List<LocalDate> localDates = new ArrayList<>();
//		localDates.add(LocalDate.now());
//		dateLists.add(localDates);
//
//		List<Map<LocalDate, MKomaPattern>> dateToMKomaPatterns = new ArrayList<>();
//		Map<LocalDate, MKomaPattern> mKomaPatternMap = new HashMap<>();
//		mKomaPatternMap.put(LocalDate.now(), new MKomaPattern());
//		dateToMKomaPatterns.add(mKomaPatternMap);
//
//		List<Map<Short, List<MKoma>>> mKomaListToKomaPattrens = new ArrayList<>();
//		Map<Short, List<MKoma>> mKomaMap = new HashMap<>();
//		List<MKoma> mKomas = new ArrayList<>();
//		mKomas.add(new MKoma());
//		mKomaMap.put((short) 1,	mKomas);
//		mKomaListToKomaPattrens.add(mKomaMap);
//
//		List<Map<Short, Map<Short, MKomaGroup>>> mKomaGroupMaps = new ArrayList<>();
//		Map<Short, Map<Short, MKomaGroup>> mMapMKomaGroup = new HashMap<>();
//		Map<Short, MKomaGroup> mKomaGroupMap = new HashMap<>();
//		mKomaGroupMap.put((short) 10, new MKomaGroup());
//		mMapMKomaGroup.put((short) 10, mKomaGroupMap);
//		mKomaGroupMaps.add(mMapMKomaGroup);
//
//		List<List<AkijokyoRowDto>> exports = new ArrayList<>();
//		for (int item = 0; item < mShisetsus.size(); item++)
//		{
//			List<AkijokyoRowDto> ret = singleFacilityAkijokyoPanelService.createAkijokyo(
//					mShisetsus.get(item),
//					dateLists.get(item),
//					dateToMKomaPatterns.get(item),
//					mKomaListToKomaPattrens.get(item),
//					mKomaGroupMaps.get(item));
//			exports.add(ret);
//		}
//		exportJsonData(exports, "TestCreateAkijokyo.json");
//	}

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	//@TestInitDataFile("TestgetMBashoList.xlsx")
	public void TestGetBashoButtons() throws Exception
	{
		List<List<MShisetsu>> mShisetsuLists = new ArrayList<List<MShisetsu>>();
		List<MShisetsu> mShisetsuss = new ArrayList<MShisetsu>();
		MShisetsu mShisetsus = new MShisetsu();
		mShisetsuss.add(mShisetsus);
		mShisetsuLists.add(mShisetsuss);

		List<List<StringCodeNamePair>> exports = new ArrayList<>();
		for (int item = 0; item < mShisetsuLists.size(); item++)
		{
			List<StringCodeNamePair> ret = singleFacilityAkijokyoPanelService.getBashoButtons(
					mShisetsuLists.get(item)
					);
			exports.add(ret);
		}
		exportJsonData(exports, "TestGetBashoButtons.json");
	}

//	@Test
//	@DisplayName("データ更新に使用するDaoを取得します")
//	//@TestInitDataFile("TestgetMBashoList.xlsx")
//	public void TestGetYoyakuUketsukeKikan() throws Exception
//	{
//		//
//		List<MShisetsu> params = new ArrayList<MShisetsu>();
//		MShisetsu mShisetsus = new MShisetsu();
//		params.add(mShisetsus);
//
//		List<LocalDate[]> exports = new ArrayList<>();
//		for (int item = 0; item < params.size(); item++)
//		{
//			LocalDate[] ret = singleFacilityAkijokyoPanelService.getYoyakuUketsukeKikan(params.get(item));
//			exports.add(ret);
//		}
//		exportJsonData(exports, "TestGetYoyakuUketsukeKikan.json");
//	}

//	@Test
//	@DisplayName("データ更新に使用するDaoを取得します")
//	//@TestInitDataFile("TestgetMBashoList.xlsx")
//	public void TestGetChusenTaishoKikan() throws Exception
//	{
//		List<MShisetsu> params = new ArrayList<MShisetsu>();
//		MShisetsu mShisetsus = new MShisetsu();
//		params.add(mShisetsus);
//
//		List<LocalDate[]> exports = new ArrayList<>();
//		for (int item = 0; item < params.size(); item++)
//		{
//			LocalDate[] ret = singleFacilityAkijokyoPanelService.getChusenTaishoKikan(params.get(item));
//			exports.add(ret);
//		}
//		exportJsonData(exports, "TestGetChusenTaishoKikan.json");
//	}

//	@Test
//	@DisplayName("データ更新に使用するDaoを取得します")
//	//@TestInitDataFile("TestgetMBashoList.xlsx")
//	public void TestIsChusenUketsukeKikan() throws Exception
//	{
//		List<MShisetsu> params = new ArrayList<MShisetsu>();
//		MShisetsu mShisetsus = new MShisetsu();
//		params.add(mShisetsus);
//
//		List<Boolean> exports = new ArrayList<>();
//		for (int item = 0; item < params.size(); item++)
//		{
//			boolean ret = singleFacilityAkijokyoPanelService.isChusenUketsukeKikan(params.get(item));
//			exports.add(ret);
//		}
//		exportJsonData(exports, "TestIsChusenUketsukeKikan.json");
//	}
}