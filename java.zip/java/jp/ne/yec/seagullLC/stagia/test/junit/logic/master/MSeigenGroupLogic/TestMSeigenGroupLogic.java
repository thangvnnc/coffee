package jp.ne.yec.seagullLC.stagia.test.junit.logic.master.MSeigenGroupLogic;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.entity.MSeigenGroup;
import jp.ne.yec.seagullLC.stagia.logic.master.MSeigenGroupLogic;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestMSeigenGroupLogic extends JunitBase {


	@Autowired
	MSeigenGroupLogic mSeigenGroupLogic;

	@Test
	@DisplayName("検索条件なしで場所マスタを取得し、返却します")
	//@TestInitDataFile("TestgetMBashoList.xlsx")
	public void TestGetDAO() throws Exception {
		GenericDao<MSeigenGroup, ?> ret = mSeigenGroupLogic.getDao();
		//assertEquals(mRyokinTaikeiDao, ret);
	}
}

