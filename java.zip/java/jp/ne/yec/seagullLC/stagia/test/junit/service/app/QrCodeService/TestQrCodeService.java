package jp.ne.yec.seagullLC.stagia.test.junit.service.app.QrCodeService;

import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.seagullLC.stagia.service.app.QrCodeService;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = { "classpath:TestApplicationContext.xml" })
@WebAppConfiguration
public class TestQrCodeService extends JunitBase {

	@Autowired
	QrCodeService qrCodeService;

//	@Test
//	public void TestAppGetQrCodeData() throws Exception {
//
//		List<String> listText = new ArrayList<>();
//		listText.add("test");
//
//		List<Map<String, String>> exports = new ArrayList<>();
//		for (int idx = 0; idx < listText.size(); idx++) {
//			Map<String, String> map = qrCodeService.appGetQrCodeData(listText.get(idx));
//			exports.add(map);
//		}
//		exportJsonData(exports,	"TestAppGetQrCodeData.json");
//	}

}
