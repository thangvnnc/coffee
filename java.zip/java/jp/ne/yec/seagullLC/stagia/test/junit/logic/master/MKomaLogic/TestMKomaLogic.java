package jp.ne.yec.seagullLC.stagia.test.junit.logic.master.MKomaLogic;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.entity.MKoma;
import jp.ne.yec.seagullLC.stagia.logic.master.MKomaLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestMKomaLogic extends JunitBase {

	@Autowired
	MKomaLogic mKomaLogic;

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetMKomaList.xlsx")
	public void TestgetMKomaList() throws Exception
	{
		Short komaPatternCode = 2;
		List<MKoma>  ret = mKomaLogic.getMKomaList(komaPatternCode);
		exportJsonData(ret, "TestgetMKomaList.json");
	}
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetMKomaList.xlsx")
	public void TestgetMKomaList_LisSort() throws Exception
	{
		List<Short> komaPatternCodeList = new ArrayList<Short>();
		komaPatternCodeList.add((short)2);
		List<MKoma> ret = mKomaLogic.getMKomaList(komaPatternCodeList);
		exportJsonData(ret, "TestgetMKomaList_LisSort.json");
	}
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetMKomaList.xlsx")
	public void TestgetMKomaList_LisSort_double() throws Exception
	{
		List<Short> komaPatternCodeLists =  new ArrayList<Short>();
		komaPatternCodeLists.add((short)2);
		Short startTime = 900;
		List<MKoma>  ret = mKomaLogic.getMKomaList(komaPatternCodeLists, startTime );
		exportJsonData(ret, "TestgetMKomaList_LisSort_double.json");
	}
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetMKomaList.xlsx")
	public void TestgetMKomaList_LisSort_double_short() throws Exception
	{
		List<Short> komaPatternCodeLists =  new ArrayList<Short>();
		komaPatternCodeLists.add((short)2);
		Short startTime = 900;
		Short endTime = 1200;
		List<MKoma> ret = mKomaLogic.getMKomaList(komaPatternCodeLists, startTime, endTime);
		exportJsonData(ret, "TestgetMKomaList_LisSort_double_short.json");
	}

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetMKomaList.xlsx")
	public void TestgetMKomaList_ShortString1() throws Exception
	{
		Short komaPatternCode= 2;
		String startTime = "900";
		String endTime = "1200";
		List<MKoma> ret = mKomaLogic.getMKomaList(komaPatternCode, startTime, endTime);
		exportJsonData(ret, "TestgetMKomaList_ShortString1.json");
	}
	
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetMKomaList.xlsx")
	public void TestgetMKomaList_ShortString2() throws Exception
	{
		Short komaPatternCode= 2;
		String startTime = "";
		String endTime = "";
		List<MKoma> ret = mKomaLogic.getMKomaList(komaPatternCode, startTime, endTime);
		exportJsonData(ret, "TestgetMKomaList_ShortString2.json");
	}
	
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetMKomaList.xlsx")
	public void TestgetMKomaList_ShortString3() throws Exception
	{
		Short komaPatternCode= 2;
		String startTime = "1000";
		String endTime = "1200";
		List<MKoma> ret = mKomaLogic.getMKomaList(komaPatternCode, startTime, endTime);
		exportJsonData(ret, "TestgetMKomaList_ShortString3.json");
	}
	
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetMKomaList.xlsx")
	public void TestgetMKomaList_ShortString4() throws Exception
	{
		Short komaPatternCode= 2;
		String startTime = "1500";
		String endTime = "";
		List<MKoma> ret = mKomaLogic.getMKomaList(komaPatternCode, startTime, endTime);
		exportJsonData(ret, "TestgetMKomaList_ShortString4.json");
	}
	
	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	//@TestInitDataFile("TestgetMKomaList.xlsx")
	public void TestgetDao() throws Exception
	{
		GenericDao<MKoma, ?> ret = mKomaLogic.getDao();
	}
}