package jp.ne.yec.seagullLC.stagia.test.junit.logic.master.MSetsubiLogic;

import static org.junit.Assert.*;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.beans.shinsei.SetsubiInfoDto;
import jp.ne.yec.seagullLC.stagia.beans.shinsei.ShinseiMeisaiDto;
import jp.ne.yec.seagullLC.stagia.entity.MSetsubi;
import jp.ne.yec.seagullLC.stagia.logic.master.MSetsubiLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestMSetsubiLogic extends JunitBase {

	@Autowired
	MSetsubiLogic mSetsubiLogic;
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetSetsubi.xlsx")
	public void TestgetSetsubi() throws Exception
	{
		Short kanriCode = 10;
		Short bashoCode = 10;

		List<SetsubiInfoDto> ret = mSetsubiLogic.getSetsubi(kanriCode, bashoCode);
		exportJsonData(ret, "TestgetSetsubi.json");
	}

	@Test
	@DisplayName("検索条件なしで場所マスタを取得し、返却します")
	@TestInitDataFile("TestGetJidoSetsubiInfoInit.xlsx")
	public void TestGetJidoSetsubiInfo() throws Exception
	{
		SimpleDateFormat sd = new SimpleDateFormat("yyyy/M/d");
		Date shiyoDate = new Date();
		shiyoDate = sd.parse("2016/1/1");
		ShinseiMeisaiDto shinseiMeisaiDto = new ShinseiMeisaiDto();
		shinseiMeisaiDto.setKanriCode((short)10);
		shinseiMeisaiDto.setBashoCode((short)10);
		shinseiMeisaiDto.setShisetsuCode((short)1);
		shinseiMeisaiDto.setShiyoDate(shiyoDate);

		List<SetsubiInfoDto> ret = mSetsubiLogic.getJidoSetsubiInfo(shinseiMeisaiDto);

		exportJsonData(ret, "TestGetJidoSetsubiInfo.json");
	}

	@Test
	@DisplayName("検索条件なしで場所マスタを取得し、返却します")
	@TestInitDataFile("TestGetAvailableSetsubiInit.xlsx")
	public void TestGetAvailableSetsubi() throws Exception
	{
		
		SimpleDateFormat sd = new SimpleDateFormat("yyyy/M/d");
		Date shiyoDate = new Date();
		shiyoDate = sd.parse("2018/12/31");
		ShinseiMeisaiDto shinseiMeisaiDto = new ShinseiMeisaiDto();
		shinseiMeisaiDto.setKanriCode((short)10);
		shinseiMeisaiDto.setBashoCode((short)10);
		shinseiMeisaiDto.setShisetsuCode((short)1);
		shinseiMeisaiDto.setShiyoDate(shiyoDate);
		
		String shinseiShuruis = "0";

		Short startKomas = 0;

		Short endKomas = 3;

		boolean isShokuins = false;

		List<SetsubiInfoDto> ret = mSetsubiLogic.getAvailableSetsubi(shinseiShuruis, shinseiMeisaiDto, startKomas, endKomas, isShokuins);
		exportJsonData(ret, "TestGetAvailableSetsubi.json");
	}

	@Test
	@DisplayName("検索条件なしで場所マスタを取得し、返却します")
	@TestInitDataFile("TestGetAvailableSetsubiCountInit.xlsx")
	public void TestGetAvailableSetsubiCount() throws Exception
	{
		SimpleDateFormat sd = new SimpleDateFormat("yyyy/M/d");
		Date shiyoDate = new Date();
		shiyoDate = sd.parse("2018/12/31");
		ShinseiMeisaiDto shinseiMeisaiDto = new ShinseiMeisaiDto();
		shinseiMeisaiDto.setKanriCode((short)10);
		shinseiMeisaiDto.setBashoCode((short)10);
		shinseiMeisaiDto.setShisetsuCode((short)1);
		shinseiMeisaiDto.setShiyoDate(shiyoDate);
		
		String shinseiShuruis = "1";

		Short startKomas = 0;

		Short endKomas = 3;

		boolean isShokuins = true;

		int ret = mSetsubiLogic.getAvailableSetsubiCount(shinseiShuruis, shinseiMeisaiDto, startKomas, endKomas, isShokuins);
		
		assertEquals(0, ret);
	}

	@Test
	@DisplayName("検索条件なしで場所マスタを取得し、返却します")
	//@TestInitDataFile("TestgetMBashoList.xlsx")
	public void TestgetDao() throws Exception
	{
			GenericDao<MSetsubi, ?> ret =  mSetsubiLogic.getDao();
	}
}