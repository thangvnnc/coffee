package jp.ne.yec.seagullLC.stagia.test.junit.logic.shinsei.SetsubiLogic;

import static org.junit.Assert.*;

import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.google.common.reflect.TypeToken;

import jp.ne.yec.seagullLC.stagia.beans.shinsei.SetsubiInfoDto;
import jp.ne.yec.seagullLC.stagia.beans.shinsei.SetsubiShinseiDto;
import jp.ne.yec.seagullLC.stagia.beans.shinsei.SetsubiShinseiKomaDto;
import jp.ne.yec.seagullLC.stagia.beans.shinsei.ShinseiDto;
import jp.ne.yec.seagullLC.stagia.beans.shinsei.ShinseiMeisaiDto;
import jp.ne.yec.seagullLC.stagia.beans.shinsei.ShisetsuKomaDto;
import jp.ne.yec.seagullLC.stagia.entity.MWebZaiko;
import jp.ne.yec.seagullLC.stagia.logic.shinsei.SetsubiLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestSetsubiLogic extends JunitBase {

	@Autowired
	SetsubiLogic setsubiLogic;

//	@Test
//	@DisplayName("データ更新に使用するDaoを取得します")
//	public void TestMakeShinseiSetsubiListForDisplay_Step1() throws Exception
//	{
//		SetsubiShinseiDto setsubiShinseiDto = readJson("TestMakeShinseiSetsubiListForDisplay_Step1_setsubiShinseiDto.pra", new TypeToken<SetsubiShinseiDto>() {}.getType());
//		List<SetsubiShinseiDto> ret = setsubiLogic.makeShinseiSetsubiListForDisplay(setsubiShinseiDto);
//		exportJsonData(ret, "TestMakeShinseiSetsubiListForDisplay_Step1.json");
//	}
//
//	@Test
//	@DisplayName("データ更新に使用するDaoを取得します")
//	public void TestMakeShinseiSetsubiListForDisplay_Step2() throws Exception
//	{
//		SetsubiShinseiDto setsubiShinseiDto = readJson("TestMakeShinseiSetsubiListForDisplay_Step2_setsubiShinseiDto.pra", new TypeToken<SetsubiShinseiDto>() {}.getType());
//		List<SetsubiShinseiDto> ret = setsubiLogic.makeShinseiSetsubiListForDisplay(setsubiShinseiDto);
//		assertEquals(0, ret.size());
//	}
//
//	@Test
//	public void TestGetRenzokuAndSameSuryoSetsubiMap_Step1() throws Exception
//	{
//		List<SetsubiShinseiKomaDto> setsubiKomas = readJson("TestGetRenzokuAndSameSuryoSetsubiMap_Step1_setsubiKomas.pra", new TypeToken<List<SetsubiShinseiKomaDto>>() {}.getType());
//		Map<Integer, List<SetsubiShinseiKomaDto>> ret = setsubiLogic.getRenzokuAndSameSuryoSetsubiMap(setsubiKomas);
//		exportJsonData(ret, "TestGetRenzokuAndSameSuryoSetsubiMap_Step1.json");
//	}
//
//	@Test
//	public void TestGetRenzokuAndSameSuryoSetsubiMap_Step2() throws Exception
//	{
//		List<SetsubiShinseiKomaDto> setsubiKomas = readJson("TestGetRenzokuAndSameSuryoSetsubiMap_Step2_setsubiKomas.pra", new TypeToken<List<SetsubiShinseiKomaDto>>() {}.getType());
//		Map<Integer, List<SetsubiShinseiKomaDto>> ret = setsubiLogic.getRenzokuAndSameSuryoSetsubiMap(setsubiKomas);
//		exportJsonData(ret, "TestGetRenzokuAndSameSuryoSetsubiMap_Step2.json");
//	}
//
//	@Test
//	public void TestGetRenzokuAndSameSuryoSetsubiMap_Step3() throws Exception
//	{
//		List<SetsubiShinseiKomaDto> setsubiKomas = readJson("TestGetRenzokuAndSameSuryoSetsubiMap_Step3_setsubiKomas.pra", new TypeToken<List<SetsubiShinseiKomaDto>>() {}.getType());
//		Map<Integer, List<SetsubiShinseiKomaDto>> ret = setsubiLogic.getRenzokuAndSameSuryoSetsubiMap(setsubiKomas);
//		exportJsonData(ret, "TestGetRenzokuAndSameSuryoSetsubiMap_Step3.json");
//	}
//
//	@Test
//	public void TestGetRenzokuAndSameSuryoSetsubiMap_Step4() throws Exception
//	{
//		List<SetsubiShinseiKomaDto> setsubiKomas = readJson("TestGetRenzokuAndSameSuryoSetsubiMap_Step4_setsubiKomas.pra", new TypeToken<List<SetsubiShinseiKomaDto>>() {}.getType());
//		Map<Integer, List<SetsubiShinseiKomaDto>> ret = setsubiLogic.getRenzokuAndSameSuryoSetsubiMap(setsubiKomas);
//		exportJsonData(ret, "TestGetRenzokuAndSameSuryoSetsubiMap_Step4.json");
//	}
//
//	@Test
//	@TestInitDataFile("TestGetJidoSetsubi_Step1_Init.xlsx")
//	public void TestGetJidoSetsubi_Step1() throws Exception
//	{
//		ShinseiMeisaiDto meisaiDto = readJson("TestGetJidoSetsubi_Step1_meisaiDto.pra", new TypeToken<ShinseiMeisaiDto>() {}.getType());
//		List<SetsubiShinseiDto> ret = setsubiLogic.getJidoSetsubi(meisaiDto);
//		assertEquals(0, ret.size());
//	}
//
//	@Test
//	@TestInitDataFile("TestGetJidoSetsubi_Step2_Init.xlsx")
//	public void TestGetJidoSetsubi_Step2() throws Exception
//	{
//		ShinseiMeisaiDto meisaiDto = readJson("TestGetJidoSetsubi_Step2_meisaiDto.pra", new TypeToken<ShinseiMeisaiDto>() {}.getType());
//		List<SetsubiShinseiDto> ret = setsubiLogic.getJidoSetsubi(meisaiDto);
//		assertEquals(0, ret.size());
//	}
//
//	@Test
//	@TestInitDataFile("TestGetJidoSetsubi_Step3_Init.xlsx")
//	public void TestGetJidoSetsubi_Step3() throws Exception
//	{
//		ShinseiMeisaiDto meisaiDto = readJson("TestGetJidoSetsubi_Step3_meisaiDto.pra", new TypeToken<ShinseiMeisaiDto>() {}.getType());
//		List<SetsubiShinseiDto> ret = setsubiLogic.getJidoSetsubi(meisaiDto);
//		exportJsonData(ret, "TestGetJidoSetsubi_Step3.json");
//	}
//
//	@Test
//	@TestInitDataFile("TestGetJidoSetsubi_Step4_Init.xlsx")
//	public void TestGetJidoSetsubi_Step4() throws Exception
//	{
//		ShinseiMeisaiDto meisaiDto = readJson("TestGetJidoSetsubi_Step4_meisaiDto.pra", new TypeToken<ShinseiMeisaiDto>() {}.getType());
//		List<SetsubiShinseiDto> ret = setsubiLogic.getJidoSetsubi(meisaiDto);
//		assertEquals(0, ret.size());
//	}
//
//	@Test
//	@TestInitDataFile("TestGetJidoSetsubi_Step5_Init.xlsx")
//	public void TestGetJidoSetsubi_Step5() throws Exception
//	{
//		ShinseiMeisaiDto meisaiDto = readJson("TestGetJidoSetsubi_Step5_meisaiDto.pra", new TypeToken<ShinseiMeisaiDto>() {}.getType());
//		List<SetsubiShinseiDto> ret = setsubiLogic.getJidoSetsubi(meisaiDto);
//		assertEquals(0, ret.size());
//	}
//
//	@Test
//	@DisplayName("データ更新に使用するDaoを取得します")
//	public void TestGetAvailableSetsubi_Step1() throws Exception
//	{
//		List<SetsubiInfoDto> setsubiInfoDtos = readJson("TestGetAvailableSetsubi_Step1_setsubiInfoDtos.pra", new TypeToken<List<SetsubiInfoDto>>() {}.getType());
//		List<ShisetsuKomaDto> selectedKomas = readJson("TestGetAvailableSetsubi_Step1_selectedKomas.pra", new TypeToken<List<ShisetsuKomaDto>>() {}.getType());;
//		List<SetsubiInfoDto>  ret = setsubiLogic.getAvailableSetsubi(setsubiInfoDtos, selectedKomas, false);
//		exportJsonData(ret, "TestGetAvailableSetsubi_Step1.json");
//	}
//
//	@Test
//	@DisplayName("データ更新に使用するDaoを取得します")
//	public void TestGetAvailableSetsubi_Step2() throws Exception
//	{
//		List<SetsubiInfoDto> setsubiInfoDtos = readJson("TestGetAvailableSetsubi_Step2_setsubiInfoDtos.pra", new TypeToken<List<SetsubiInfoDto>>() {}.getType());
//		List<ShisetsuKomaDto> selectedKomas = readJson("TestGetAvailableSetsubi_Step2_selectedKomas.pra", new TypeToken<List<ShisetsuKomaDto>>() {}.getType());;
//		List<SetsubiInfoDto>  ret = setsubiLogic.getAvailableSetsubi(setsubiInfoDtos, selectedKomas, false);
//		exportJsonData(ret, "TestGetAvailableSetsubi_Step2.json");
//	}
//
//	@Test
//	@DisplayName("データ更新に使用するDaoを取得します")
//	public void TestGetAvailableSetsubi_Step3() throws Exception
//	{
//		List<SetsubiInfoDto> setsubiInfoDtos = readJson("TestGetAvailableSetsubi_Step3_setsubiInfoDtos.pra", new TypeToken<List<SetsubiInfoDto>>() {}.getType());
//		List<ShisetsuKomaDto> selectedKomas = readJson("TestGetAvailableSetsubi_Step3_selectedKomas.pra", new TypeToken<List<ShisetsuKomaDto>>() {}.getType());;
//		List<SetsubiInfoDto>  ret = setsubiLogic.getAvailableSetsubi(setsubiInfoDtos, selectedKomas, false);
//		assertEquals(0, ret.size());
//	}
//
//	@Test
//	@DisplayName("データ更新に使用するDaoを取得します")
//	public void TestGetAvailableSetsubi_Step4() throws Exception
//	{
//		List<SetsubiInfoDto> setsubiInfoDtos = readJson("TestGetAvailableSetsubi_Step4_setsubiInfoDtos.pra", new TypeToken<List<SetsubiInfoDto>>() {}.getType());
//		List<ShisetsuKomaDto> selectedKomas = readJson("TestGetAvailableSetsubi_Step4_selectedKomas.pra", new TypeToken<List<ShisetsuKomaDto>>() {}.getType());;
//		List<SetsubiInfoDto>  ret = setsubiLogic.getAvailableSetsubi(setsubiInfoDtos, selectedKomas, false);
//		assertEquals(0, ret.size());
//	}
//
//	@Test
//	@DisplayName("データ更新に使用するDaoを取得します")
//	public void TestGetAvailableSetsubi_Step5() throws Exception
//	{
//		List<SetsubiInfoDto> setsubiInfoDtos = readJson("TestGetAvailableSetsubi_Step5_setsubiInfoDtos.pra", new TypeToken<List<SetsubiInfoDto>>() {}.getType());
//		List<ShisetsuKomaDto> selectedKomas = readJson("TestGetAvailableSetsubi_Step5_selectedKomas.pra", new TypeToken<List<ShisetsuKomaDto>>() {}.getType());;
//		List<SetsubiInfoDto>  ret = setsubiLogic.getAvailableSetsubi(setsubiInfoDtos, selectedKomas, false);
//		exportJsonData(ret, "TestGetAvailableSetsubi_Step5.json");
//	}
//
//	@Test
//	@TestInitDataFile("TestUpdateSetsubiZaiko_Step1_Init.xlsx")
//	public void TestUpdateSetsubiZaiko_Step1() throws Exception
//	{
//		List<SetsubiInfoDto> availableSetsubi = readJson("TestUpdateSetsubiZaiko_Step1_availableSetsubi.pra", new TypeToken<List<SetsubiInfoDto>>() {}.getType());
//		ShinseiDto shinseiDto = readJson("TestUpdateSetsubiZaiko_Step1_shinseiDto.pra", new TypeToken<ShinseiDto>() {}.getType());
//		ShinseiMeisaiDto meisaiDto = readJson("TestUpdateSetsubiZaiko_Step1_meisaiDto.pra", new TypeToken<ShinseiMeisaiDto>() {}.getType());
//		List<ShinseiMeisaiDto> meisaiDtos = readJson("TestUpdateSetsubiZaiko_Step1_meisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>() {}.getType());
//		List<MWebZaiko> mWebZaikoList = readJson("TestUpdateSetsubiZaiko_Step1_mWebZaikoList.pra", new TypeToken<List<MWebZaiko>>() {}.getType());
//
//		setsubiLogic.updateSetsubiZaiko(availableSetsubi, shinseiDto, meisaiDto, meisaiDtos, (short)900, (short)1000, mWebZaikoList);
//	}
//
//	@Test
//	@TestInitDataFile("TestUpdateSetsubiZaiko_Step2_Init.xlsx")
//	public void TestUpdateSetsubiZaiko_Step2() throws Exception
//	{
//		List<SetsubiInfoDto> availableSetsubi = readJson("TestUpdateSetsubiZaiko_Step2_availableSetsubi.pra", new TypeToken<List<SetsubiInfoDto>>() {}.getType());
//		ShinseiDto shinseiDto = readJson("TestUpdateSetsubiZaiko_Step2_shinseiDto.pra", new TypeToken<ShinseiDto>() {}.getType());
//		ShinseiMeisaiDto meisaiDto = readJson("TestUpdateSetsubiZaiko_Step2_meisaiDto.pra", new TypeToken<ShinseiMeisaiDto>() {}.getType());
//		List<ShinseiMeisaiDto> meisaiDtos = readJson("TestUpdateSetsubiZaiko_Step2_meisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>() {}.getType());
//		List<MWebZaiko> mWebZaikoList = readJson("TestUpdateSetsubiZaiko_Step2_mWebZaikoList.pra", new TypeToken<List<MWebZaiko>>() {}.getType());
//
//		setsubiLogic.updateSetsubiZaiko(availableSetsubi, shinseiDto, meisaiDto, meisaiDtos, (short)900, (short)1000, mWebZaikoList);
//	}
//
//	@Test
//	@TestInitDataFile("TestUpdateSetsubiZaiko_Step3_Init.xlsx")
//	public void TestUpdateSetsubiZaiko_Step3() throws Exception
//	{
//		List<SetsubiInfoDto> availableSetsubi = readJson("TestUpdateSetsubiZaiko_Step3_availableSetsubi.pra", new TypeToken<List<SetsubiInfoDto>>() {}.getType());
//		ShinseiDto shinseiDto = readJson("TestUpdateSetsubiZaiko_Step3_shinseiDto.pra", new TypeToken<ShinseiDto>() {}.getType());
//		ShinseiMeisaiDto meisaiDto = readJson("TestUpdateSetsubiZaiko_Step3_meisaiDto.pra", new TypeToken<ShinseiMeisaiDto>() {}.getType());
//		List<ShinseiMeisaiDto> meisaiDtos = readJson("TestUpdateSetsubiZaiko_Step3_meisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>() {}.getType());
//		List<MWebZaiko> mWebZaikoList = readJson("TestUpdateSetsubiZaiko_Step3_mWebZaikoList.pra", new TypeToken<List<MWebZaiko>>() {}.getType());
//
//		setsubiLogic.updateSetsubiZaiko(availableSetsubi, shinseiDto, meisaiDto, meisaiDtos, (short)900, (short)1000, mWebZaikoList);
//	}
//
//	@Test
//	@TestInitDataFile("TestUpdateSetsubiZaiko_Step4_Init.xlsx")
//	public void TestUpdateSetsubiZaiko_Step4() throws Exception
//	{
//		List<SetsubiInfoDto> availableSetsubi = readJson("TestUpdateSetsubiZaiko_Step4_availableSetsubi.pra", new TypeToken<List<SetsubiInfoDto>>() {}.getType());
//		ShinseiDto shinseiDto = readJson("TestUpdateSetsubiZaiko_Step4_shinseiDto.pra", new TypeToken<ShinseiDto>() {}.getType());
//		ShinseiMeisaiDto meisaiDto = readJson("TestUpdateSetsubiZaiko_Step4_meisaiDto.pra", new TypeToken<ShinseiMeisaiDto>() {}.getType());
//		List<ShinseiMeisaiDto> meisaiDtos = readJson("TestUpdateSetsubiZaiko_Step4_meisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>() {}.getType());
//		List<MWebZaiko> mWebZaikoList = readJson("TestUpdateSetsubiZaiko_Step4_mWebZaikoList.pra", new TypeToken<List<MWebZaiko>>() {}.getType());
//
//		setsubiLogic.updateSetsubiZaiko(availableSetsubi, shinseiDto, meisaiDto, meisaiDtos, (short)900, (short)1000, mWebZaikoList);
//	}
//
//	@Test
//	@TestInitDataFile("TestUpdateSetsubiZaiko_Step5_Init.xlsx")
//	public void TestUpdateSetsubiZaiko_Step5() throws Exception
//	{
//		List<SetsubiInfoDto> availableSetsubi = readJson("TestUpdateSetsubiZaiko_Step5_availableSetsubi.pra", new TypeToken<List<SetsubiInfoDto>>() {}.getType());
//		ShinseiDto shinseiDto = readJson("TestUpdateSetsubiZaiko_Step5_shinseiDto.pra", new TypeToken<ShinseiDto>() {}.getType());
//		ShinseiMeisaiDto meisaiDto = readJson("TestUpdateSetsubiZaiko_Step5_meisaiDto.pra", new TypeToken<ShinseiMeisaiDto>() {}.getType());
//		List<ShinseiMeisaiDto> meisaiDtos = readJson("TestUpdateSetsubiZaiko_Step5_meisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>() {}.getType());
//		List<MWebZaiko> mWebZaikoList = readJson("TestUpdateSetsubiZaiko_Step5_mWebZaikoList.pra", new TypeToken<List<MWebZaiko>>() {}.getType());
//
//		setsubiLogic.updateSetsubiZaiko(availableSetsubi, shinseiDto, meisaiDto, meisaiDtos, (short)900, (short)1000, mWebZaikoList);
//	}
//
//	@Test
//	@TestInitDataFile("TestUpdateSetsubiZaiko_Step6_Init.xlsx")
//	public void TestUpdateSetsubiZaiko_Step6() throws Exception
//	{
//		List<SetsubiInfoDto> availableSetsubi = readJson("TestUpdateSetsubiZaiko_Step6_availableSetsubi.pra", new TypeToken<List<SetsubiInfoDto>>() {}.getType());
//		ShinseiDto shinseiDto = readJson("TestUpdateSetsubiZaiko_Step6_shinseiDto.pra", new TypeToken<ShinseiDto>() {}.getType());
//		ShinseiMeisaiDto meisaiDto = readJson("TestUpdateSetsubiZaiko_Step6_meisaiDto.pra", new TypeToken<ShinseiMeisaiDto>() {}.getType());
//		List<ShinseiMeisaiDto> meisaiDtos = readJson("TestUpdateSetsubiZaiko_Step6_meisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>() {}.getType());
//		List<MWebZaiko> mWebZaikoList = readJson("TestUpdateSetsubiZaiko_Step6_mWebZaikoList.pra", new TypeToken<List<MWebZaiko>>() {}.getType());
//
//		setsubiLogic.updateSetsubiZaiko(availableSetsubi, shinseiDto, meisaiDto, meisaiDtos, (short)1500, (short)1600, mWebZaikoList);
//	}
//
//	@Test
//	@TestInitDataFile("TestUpdateSetsubiZaiko_Step7_Init.xlsx")
//	public void TestUpdateSetsubiZaiko_Step7() throws Exception
//	{
//		List<SetsubiInfoDto> availableSetsubi = readJson("TestUpdateSetsubiZaiko_Step7_availableSetsubi.pra", new TypeToken<List<SetsubiInfoDto>>() {}.getType());
//		ShinseiDto shinseiDto = readJson("TestUpdateSetsubiZaiko_Step7_shinseiDto.pra", new TypeToken<ShinseiDto>() {}.getType());
//		ShinseiMeisaiDto meisaiDto = readJson("TestUpdateSetsubiZaiko_Step7_meisaiDto.pra", new TypeToken<ShinseiMeisaiDto>() {}.getType());
//		List<ShinseiMeisaiDto> meisaiDtos = readJson("TestUpdateSetsubiZaiko_Step7_meisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>() {}.getType());
//		List<MWebZaiko> mWebZaikoList = readJson("TestUpdateSetsubiZaiko_Step7_mWebZaikoList.pra", new TypeToken<List<MWebZaiko>>() {}.getType());
//
//		setsubiLogic.updateSetsubiZaiko(availableSetsubi, shinseiDto, meisaiDto, meisaiDtos, (short)800, (short)1600, mWebZaikoList);
//	}
//
//	@Test
//	@TestInitDataFile("TestUpdateSetsubiZaiko_Step8_Init.xlsx")
//	public void TestUpdateSetsubiZaiko_Step8() throws Exception
//	{
//		List<SetsubiInfoDto> availableSetsubi = readJson("TestUpdateSetsubiZaiko_Step8_availableSetsubi.pra", new TypeToken<List<SetsubiInfoDto>>() {}.getType());
//		ShinseiDto shinseiDto = readJson("TestUpdateSetsubiZaiko_Step8_shinseiDto.pra", new TypeToken<ShinseiDto>() {}.getType());
//		ShinseiMeisaiDto meisaiDto = readJson("TestUpdateSetsubiZaiko_Step8_meisaiDto.pra", new TypeToken<ShinseiMeisaiDto>() {}.getType());
//		List<ShinseiMeisaiDto> meisaiDtos = readJson("TestUpdateSetsubiZaiko_Step8_meisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>() {}.getType());
//		List<MWebZaiko> mWebZaikoList = readJson("TestUpdateSetsubiZaiko_Step8_mWebZaikoList.pra", new TypeToken<List<MWebZaiko>>() {}.getType());
//
//		setsubiLogic.updateSetsubiZaiko(availableSetsubi, shinseiDto, meisaiDto, meisaiDtos, (short)800, (short)900, mWebZaikoList);
//	}
//
//	@Test
//	@TestInitDataFile("TestUpdateSetsubiZaiko_Step9_Init.xlsx")
//	public void TestUpdateSetsubiZaiko_Step9() throws Exception
//	{
//		List<SetsubiInfoDto> availableSetsubi = readJson("TestUpdateSetsubiZaiko_Step9_availableSetsubi.pra", new TypeToken<List<SetsubiInfoDto>>() {}.getType());
//		ShinseiDto shinseiDto = readJson("TestUpdateSetsubiZaiko_Step9_shinseiDto.pra", new TypeToken<ShinseiDto>() {}.getType());
//		ShinseiMeisaiDto meisaiDto = readJson("TestUpdateSetsubiZaiko_Step9_meisaiDto.pra", new TypeToken<ShinseiMeisaiDto>() {}.getType());
//		List<ShinseiMeisaiDto> meisaiDtos = readJson("TestUpdateSetsubiZaiko_Step9_meisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>() {}.getType());
//		List<MWebZaiko> mWebZaikoList = readJson("TestUpdateSetsubiZaiko_Step9_mWebZaikoList.pra", new TypeToken<List<MWebZaiko>>() {}.getType());
//
//		setsubiLogic.updateSetsubiZaiko(availableSetsubi, shinseiDto, meisaiDto, meisaiDtos, (short)800, (short)1600, mWebZaikoList);
//	}
//
//	@Test
//	@TestInitDataFile("TestUpdateSetsubiZaiko_Step10_Init.xlsx")
//	public void TestUpdateSetsubiZaiko_Step10() throws Exception
//	{
//		List<SetsubiInfoDto> availableSetsubi = readJson("TestUpdateSetsubiZaiko_Step10_availableSetsubi.pra", new TypeToken<List<SetsubiInfoDto>>() {}.getType());
//		ShinseiDto shinseiDto = readJson("TestUpdateSetsubiZaiko_Step10_shinseiDto.pra", new TypeToken<ShinseiDto>() {}.getType());
//		ShinseiMeisaiDto meisaiDto = readJson("TestUpdateSetsubiZaiko_Step10_meisaiDto.pra", new TypeToken<ShinseiMeisaiDto>() {}.getType());
//		List<ShinseiMeisaiDto> meisaiDtos = readJson("TestUpdateSetsubiZaiko_Step10_meisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>() {}.getType());
//		List<MWebZaiko> mWebZaikoList = readJson("TestUpdateSetsubiZaiko_Step10_mWebZaikoList.pra", new TypeToken<List<MWebZaiko>>() {}.getType());
//
//		setsubiLogic.updateSetsubiZaiko(availableSetsubi, shinseiDto, meisaiDto, meisaiDtos, (short)800, (short)1600, mWebZaikoList);
//	}
//
//	@Test
//	@TestInitDataFile("TestUpdateSetsubiZaiko_Step11_Init.xlsx")
//	public void TestUpdateSetsubiZaiko_Step11() throws Exception
//	{
//		List<SetsubiInfoDto> availableSetsubi = readJson("TestUpdateSetsubiZaiko_Step11_availableSetsubi.pra", new TypeToken<List<SetsubiInfoDto>>() {}.getType());
//		ShinseiDto shinseiDto = readJson("TestUpdateSetsubiZaiko_Step11_shinseiDto.pra", new TypeToken<ShinseiDto>() {}.getType());
//		ShinseiMeisaiDto meisaiDto = readJson("TestUpdateSetsubiZaiko_Step11_meisaiDto.pra", new TypeToken<ShinseiMeisaiDto>() {}.getType());
//		List<ShinseiMeisaiDto> meisaiDtos = readJson("TestUpdateSetsubiZaiko_Step11_meisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>() {}.getType());
//		List<MWebZaiko> mWebZaikoList = readJson("TestUpdateSetsubiZaiko_Step11_mWebZaikoList.pra", new TypeToken<List<MWebZaiko>>() {}.getType());
//
//		setsubiLogic.updateSetsubiZaiko(availableSetsubi, shinseiDto, meisaiDto, meisaiDtos, (short)800, (short)1600, mWebZaikoList);
//	}
//
//	@Test
//	@TestInitDataFile("TestUpdateSetsubiZaiko_Step12_Init.xlsx")
//	public void TestUpdateSetsubiZaiko_Step12() throws Exception
//	{
//		List<SetsubiInfoDto> availableSetsubi = readJson("TestUpdateSetsubiZaiko_Step12_availableSetsubi.pra", new TypeToken<List<SetsubiInfoDto>>() {}.getType());
//		ShinseiDto shinseiDto = readJson("TestUpdateSetsubiZaiko_Step12_shinseiDto.pra", new TypeToken<ShinseiDto>() {}.getType());
//		ShinseiMeisaiDto meisaiDto = readJson("TestUpdateSetsubiZaiko_Step12_meisaiDto.pra", new TypeToken<ShinseiMeisaiDto>() {}.getType());
//		List<ShinseiMeisaiDto> meisaiDtos = readJson("TestUpdateSetsubiZaiko_Step12_meisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>() {}.getType());
//		List<MWebZaiko> mWebZaikoList = readJson("TestUpdateSetsubiZaiko_Step12_mWebZaikoList.pra", new TypeToken<List<MWebZaiko>>() {}.getType());
//
//		setsubiLogic.updateSetsubiZaiko(availableSetsubi, shinseiDto, meisaiDto, meisaiDtos, (short)800, (short)1600, mWebZaikoList);
//	}
//
//	@Test
//	@TestInitDataFile("TestUpdateSetsubiZaiko_Step13_Init.xlsx")
//	public void TestUpdateSetsubiZaiko_Step13() throws Exception
//	{
//		List<SetsubiInfoDto> availableSetsubi = readJson("TestUpdateSetsubiZaiko_Step13_availableSetsubi.pra", new TypeToken<List<SetsubiInfoDto>>() {}.getType());
//		ShinseiDto shinseiDto = readJson("TestUpdateSetsubiZaiko_Step13_shinseiDto.pra", new TypeToken<ShinseiDto>() {}.getType());
//		ShinseiMeisaiDto meisaiDto = readJson("TestUpdateSetsubiZaiko_Step13_meisaiDto.pra", new TypeToken<ShinseiMeisaiDto>() {}.getType());
//		List<ShinseiMeisaiDto> meisaiDtos = readJson("TestUpdateSetsubiZaiko_Step13_meisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>() {}.getType());
//		List<MWebZaiko> mWebZaikoList = readJson("TestUpdateSetsubiZaiko_Step13_mWebZaikoList.pra", new TypeToken<List<MWebZaiko>>() {}.getType());
//
//		setsubiLogic.updateSetsubiZaiko(availableSetsubi, shinseiDto, meisaiDto, meisaiDtos, (short)800, (short)1600, mWebZaikoList);
//	}
//
//	@Test
//	@TestInitDataFile("TestUpdateSetsubiZaiko_Step14_Init.xlsx")
//	public void TestUpdateSetsubiZaiko_Step14() throws Exception
//	{
//		List<SetsubiInfoDto> availableSetsubi = readJson("TestUpdateSetsubiZaiko_Step14_availableSetsubi.pra", new TypeToken<List<SetsubiInfoDto>>() {}.getType());
//		ShinseiDto shinseiDto = readJson("TestUpdateSetsubiZaiko_Step14_shinseiDto.pra", new TypeToken<ShinseiDto>() {}.getType());
//		ShinseiMeisaiDto meisaiDto = readJson("TestUpdateSetsubiZaiko_Step14_meisaiDto.pra", new TypeToken<ShinseiMeisaiDto>() {}.getType());
//		List<ShinseiMeisaiDto> meisaiDtos = readJson("TestUpdateSetsubiZaiko_Step14_meisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>() {}.getType());
//		List<MWebZaiko> mWebZaikoList = readJson("TestUpdateSetsubiZaiko_Step14_mWebZaikoList.pra", new TypeToken<List<MWebZaiko>>() {}.getType());
//
//		setsubiLogic.updateSetsubiZaiko(availableSetsubi, shinseiDto, meisaiDto, meisaiDtos, (short)800, (short)1600, mWebZaikoList);
//	}
//
//	@Test
//	@TestInitDataFile("TestUpdateSetsubiZaiko_Step15_Init.xlsx")
//	public void TestUpdateSetsubiZaiko_Step15() throws Exception
//	{
//		List<SetsubiInfoDto> availableSetsubi = readJson("TestUpdateSetsubiZaiko_Step15_availableSetsubi.pra", new TypeToken<List<SetsubiInfoDto>>() {}.getType());
//		ShinseiDto shinseiDto = readJson("TestUpdateSetsubiZaiko_Step15_shinseiDto.pra", new TypeToken<ShinseiDto>() {}.getType());
//		ShinseiMeisaiDto meisaiDto = readJson("TestUpdateSetsubiZaiko_Step15_meisaiDto.pra", new TypeToken<ShinseiMeisaiDto>() {}.getType());
//		List<ShinseiMeisaiDto> meisaiDtos = readJson("TestUpdateSetsubiZaiko_Step15_meisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>() {}.getType());
//		List<MWebZaiko> mWebZaikoList = readJson("TestUpdateSetsubiZaiko_Step15_mWebZaikoList.pra", new TypeToken<List<MWebZaiko>>() {}.getType());
//
//		setsubiLogic.updateSetsubiZaiko(availableSetsubi, shinseiDto, meisaiDto, meisaiDtos, (short)800, (short)1600, mWebZaikoList);
//	}
//
//	@Test
//	@TestInitDataFile("TestUpdateSetsubiZaiko_Step16_Init.xlsx")
//	public void TestUpdateSetsubiZaiko_Step16() throws Exception
//	{
//		List<SetsubiInfoDto> availableSetsubi = readJson("TestUpdateSetsubiZaiko_Step16_availableSetsubi.pra", new TypeToken<List<SetsubiInfoDto>>() {}.getType());
//		ShinseiDto shinseiDto = readJson("TestUpdateSetsubiZaiko_Step16_shinseiDto.pra", new TypeToken<ShinseiDto>() {}.getType());
//		ShinseiMeisaiDto meisaiDto = readJson("TestUpdateSetsubiZaiko_Step16_meisaiDto.pra", new TypeToken<ShinseiMeisaiDto>() {}.getType());
//		List<ShinseiMeisaiDto> meisaiDtos = readJson("TestUpdateSetsubiZaiko_Step16_meisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>() {}.getType());
//		List<MWebZaiko> mWebZaikoList = readJson("TestUpdateSetsubiZaiko_Step16_mWebZaikoList.pra", new TypeToken<List<MWebZaiko>>() {}.getType());
//
//		setsubiLogic.updateSetsubiZaiko(availableSetsubi, shinseiDto, meisaiDto, meisaiDtos, (short)800, (short)1600, mWebZaikoList);
//	}
//
//	@Test
//	@TestInitDataFile("TestUpdateSetsubiZaiko_Step17_Init.xlsx")
//	public void TestUpdateSetsubiZaiko_Step17() throws Exception
//	{
//		List<SetsubiInfoDto> availableSetsubi = readJson("TestUpdateSetsubiZaiko_Step17_availableSetsubi.pra", new TypeToken<List<SetsubiInfoDto>>() {}.getType());
//		ShinseiDto shinseiDto = readJson("TestUpdateSetsubiZaiko_Step17_shinseiDto.pra", new TypeToken<ShinseiDto>() {}.getType());
//		ShinseiMeisaiDto meisaiDto = readJson("TestUpdateSetsubiZaiko_Step17_meisaiDto.pra", new TypeToken<ShinseiMeisaiDto>() {}.getType());
//		List<ShinseiMeisaiDto> meisaiDtos = readJson("TestUpdateSetsubiZaiko_Step17_meisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>() {}.getType());
//		List<MWebZaiko> mWebZaikoList = readJson("TestUpdateSetsubiZaiko_Step17_mWebZaikoList.pra", new TypeToken<List<MWebZaiko>>() {}.getType());
//
//		setsubiLogic.updateSetsubiZaiko(availableSetsubi, shinseiDto, meisaiDto, meisaiDtos, (short)800, (short)1600, mWebZaikoList);
//	}

//	@Test
//	@TestInitDataFile("TestCheckSetsubiZaikoOver_Step1_Init.xlsx")
//	public void TestCheckSetsubiZaikoOver_Step1() throws Exception
//	{
//		ShinseiDto shinseiDto = readJson("TestCheckSetsubiZaikoOver_Step1_shinseiDto.pra", new TypeToken<ShinseiDto>() {}.getType());
//		List<ShinseiMeisaiDto> meisaiDtos = readJson("TestCheckSetsubiZaikoOver_Step1_meisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>(){}.getType());
//		setsubiLogic.checkSetsubiZaikoOver(shinseiDto, meisaiDtos, false);
//	}
//
//	@Test
//	@TestInitDataFile("TestCheckSetsubiZaikoOver_Step2_Init.xlsx")
//	public void TestCheckSetsubiZaikoOver_Step2() throws Exception
//	{
//		try
//		{
//			ShinseiDto shinseiDto = readJson("TestCheckSetsubiZaikoOver_Step2_shinseiDto.pra", new TypeToken<ShinseiDto>() {}.getType());
//			List<ShinseiMeisaiDto> meisaiDtos = readJson("TestCheckSetsubiZaikoOver_Step2_meisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>(){}.getType());
//			setsubiLogic.checkSetsubiZaikoOver(shinseiDto, meisaiDtos, false);
//		}
//		catch (Exception e) {
//			String message = "申請[ 生涯学習センター 会議室 １：2018/7/13 09：00～10：00 ]の設備[ ポインター ]の使用数量が在庫数を超えています。再度設備設定画面にて数量を確認してください。~申請[ 生涯学習センター 会議室 ２：2018/7/13 09：00～10：00 ]の設備[ ポインター ]の使用数量が在庫数を超えています。再度設備設定画面にて数量を確認してください。~申請[ 生涯学習センター 会議室 ３：2018/7/13 09：00～10：00 ]の設備[ ポインター ]の使用数量が在庫数を超えています。再度設備設定画面にて数量を確認してください。";
//			assertEquals(message, e.getMessage());
//		}
//	}
//
//	@Test
//	@TestInitDataFile("TestCheckSetsubiZaikoOver_Step3_Init.xlsx")
//	public void TestCheckSetsubiZaikoOver_Step3() throws Exception
//	{
//		ShinseiDto shinseiDto = readJson("TestCheckSetsubiZaikoOver_Step3_shinseiDto.pra", new TypeToken<ShinseiDto>() {}.getType());
//		List<ShinseiMeisaiDto> meisaiDtos = readJson("TestCheckSetsubiZaikoOver_Step3_meisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>(){}.getType());
//		setsubiLogic.checkSetsubiZaikoOver(shinseiDto, meisaiDtos, true);
//	}
//
//	@Test
//	@TestInitDataFile("TestCheckSetsubiZaikoOver_Step4_Init.xlsx")
//	public void TestCheckSetsubiZaikoOver_Step4() throws Exception
//	{
//		ShinseiDto shinseiDto = readJson("TestCheckSetsubiZaikoOver_Step4_shinseiDto.pra", new TypeToken<ShinseiDto>() {}.getType());
//		List<ShinseiMeisaiDto> meisaiDtos = readJson("TestCheckSetsubiZaikoOver_Step4_meisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>(){}.getType());
//		setsubiLogic.checkSetsubiZaikoOver(shinseiDto, meisaiDtos, false);
//	}
//
//	@Test
//	@TestInitDataFile("TestCheckSetsubiZaikoOver_Step5_Init.xlsx")
//	public void TestCheckSetsubiZaikoOver_Step5() throws Exception
//	{
//			ShinseiDto shinseiDto = readJson("TestCheckSetsubiZaikoOver_Step5_shinseiDto.pra", new TypeToken<ShinseiDto>() {}.getType());
//			List<ShinseiMeisaiDto> meisaiDtos = readJson("TestCheckSetsubiZaikoOver_Step5_meisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>(){}.getType());
//			setsubiLogic.checkSetsubiZaikoOver(shinseiDto, meisaiDtos, false);
//	}

	@Test
	@TestInitDataFile("TestCheckSetsubiZaikoOver_Step6_Init2.xlsx")
	public void TestCheckSetsubiZaikoOver_Step6() throws Exception
	{
			ShinseiDto shinseiDto = readJson("TestCheckSetsubiZaikoOver_Step6_shinseiDto.pra", new TypeToken<ShinseiDto>() {}.getType());
			List<ShinseiMeisaiDto> meisaiDtos = readJson("TestCheckSetsubiZaikoOver_Step6_meisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>(){}.getType());
			setsubiLogic.checkSetsubiZaikoOver(shinseiDto, meisaiDtos, false);
	}

//	@Test
//	@TestInitDataFile("TestUpdSetsubiShinseiByChangedTime_Step1_Init.xlsx")
//	public void TestUpdSetsubiShinseiByChangedTime_Step1() throws Exception
//	{
//		List<ShinseiMeisaiDto> timeChangedList = readJson("TestUpdSetsubiShinseiByChangedTime_Step1_timeChangedList.pra", new TypeToken<List<ShinseiMeisaiDto>>(){}.getType());
//		setsubiLogic.updSetsubiShinseiByChangedTime(timeChangedList);
//	}
//
//	@Test
//	@TestInitDataFile("TestUpdSetsubiShinseiByChangedTime_Step2_Init.xlsx")
//	public void TestUpdSetsubiShinseiByChangedTime_Step2() throws Exception
//	{
//		List<ShinseiMeisaiDto> timeChangedList = readJson("TestUpdSetsubiShinseiByChangedTime_Step2_timeChangedList.pra", new TypeToken<List<ShinseiMeisaiDto>>(){}.getType());
//		setsubiLogic.updSetsubiShinseiByChangedTime(timeChangedList);
//	}
//
//	@Test
//	@TestInitDataFile("TestUpdSetsubiShinseiByChangedTime_Step3_Init.xlsx")
//	public void TestUpdSetsubiShinseiByChangedTime_Step3() throws Exception
//	{
//		List<ShinseiMeisaiDto> timeChangedList = readJson("TestUpdSetsubiShinseiByChangedTime_Step3_timeChangedList.pra", new TypeToken<List<ShinseiMeisaiDto>>(){}.getType());
//		setsubiLogic.updSetsubiShinseiByChangedTime(timeChangedList);
//	}
//
//	@Test
//	@TestInitDataFile("TestUpdSetsubiShinseiByChangedTime_Step4_Init.xlsx")
//	public void TestUpdSetsubiShinseiByChangedTime_Step4() throws Exception
//	{
//		List<ShinseiMeisaiDto> timeChangedList = readJson("TestUpdSetsubiShinseiByChangedTime_Step4_timeChangedList.pra", new TypeToken<List<ShinseiMeisaiDto>>(){}.getType());
//		setsubiLogic.updSetsubiShinseiByChangedTime(timeChangedList);
//	}
//
//	@Test
//	@TestInitDataFile("TestUpdSetsubiShinseiByChangedTime_Step5_Init.xlsx")
//	public void TestUpdSetsubiShinseiByChangedTime_Step5() throws Exception
//	{
//		List<ShinseiMeisaiDto> timeChangedList = readJson("TestUpdSetsubiShinseiByChangedTime_Step5_timeChangedList.pra", new TypeToken<List<ShinseiMeisaiDto>>(){}.getType());
//		setsubiLogic.updSetsubiShinseiByChangedTime(timeChangedList);
//	}
//
//	@Test
//	@TestInitDataFile("TestUpdSetsubiShinseiByChangedTime_Step6_Init.xlsx")
//	public void TestUpdSetsubiShinseiByChangedTime_Step6() throws Exception
//	{
//		List<ShinseiMeisaiDto> timeChangedList = readJson("TestUpdSetsubiShinseiByChangedTime_Step6_timeChangedList.pra", new TypeToken<List<ShinseiMeisaiDto>>(){}.getType());
//		setsubiLogic.updSetsubiShinseiByChangedTime(timeChangedList);
//	}
//
//	@Test
//	@TestInitDataFile("TestUpdSetsubiShinseiByChangedTime_Step7_Init.xlsx")
//	public void TestUpdSetsubiShinseiByChangedTime_Step7() throws Exception
//	{
//		List<ShinseiMeisaiDto> timeChangedList = readJson("TestUpdSetsubiShinseiByChangedTime_Step7_timeChangedList.pra", new TypeToken<List<ShinseiMeisaiDto>>(){}.getType());
//		setsubiLogic.updSetsubiShinseiByChangedTime(timeChangedList);
//	}
}

