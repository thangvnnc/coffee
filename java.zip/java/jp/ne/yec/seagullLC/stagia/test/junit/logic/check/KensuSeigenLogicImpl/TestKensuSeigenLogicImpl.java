package jp.ne.yec.seagullLC.stagia.test.junit.logic.check.KensuSeigenLogicImpl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.google.gson.reflect.TypeToken;

import jp.ne.yec.seagullLC.stagia.beans.enums.domain.ShinseiShurui;
import jp.ne.yec.seagullLC.stagia.beans.riyosha.KoseiinJohoDto;
import jp.ne.yec.seagullLC.stagia.entity.MSeigenGroupKanren;
import jp.ne.yec.seagullLC.stagia.entity.TKoseiin;
import jp.ne.yec.seagullLC.stagia.entity.TShinseiMeisai;
import jp.ne.yec.seagullLC.stagia.logic.check.KensuSeigenLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestKensuSeigenLogicImpl extends JunitBase {


	@Autowired
	KensuSeigenLogic kensuSeigenLogic;

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestcheckInit.xlsx")
	public void Testcheck() throws Exception
	{
		String loginId = "sicvn";
		Short riyoshaGroupCode = 1;
		Date uketsukeDate = new Date();
		Map<ShinseiShurui, List<TShinseiMeisai>> meisaiMap = new HashMap<ShinseiShurui, List<TShinseiMeisai>>();
		//
		kensuSeigenLogic.check(loginId,riyoshaGroupCode,meisaiMap, uketsukeDate);

	}

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestKoseiinJohoEntityToKoseiinJohoDtoInit2.xlsx")
	public void Testcheck_Step2() throws Exception
	{
		String loginId = "sicvn";
		Short riyoshaGroupCode = 1;
		Date uketsukeDate = new Date();
		Map<ShinseiShurui, List<TShinseiMeisai>> meisaiMap = new HashMap<>();
		//String loginId, Map<ShinseiShurui, List<T>> meisaiMap, Date uketsukeDate
		List<TShinseiMeisai> shinseiMeisaiDtos = readJson("TestGetTShinseiMeisaiList10pra_1.json", new TypeToken<List<TShinseiMeisai> >(){}.getType());
		shinseiMeisaiDtos.get(0).setKanriCode((short)10);
		meisaiMap.put(ShinseiShurui.CHUSEN, shinseiMeisaiDtos);
		//
		kensuSeigenLogic.check(loginId,riyoshaGroupCode,meisaiMap, uketsukeDate);

	}

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestKoseiinJohoEntityToKoseiinJohoDtoInit3.xlsx")
	public void Testcheck_Step3() throws Exception
	{
		String loginId = "sicvn";
		Short riyoshaGroupCode = 8;
		Date uketsukeDate = new Date();
		Map<ShinseiShurui, List<TShinseiMeisai>> meisaiMap = new HashMap<>();
		//String loginId, Map<ShinseiShurui, List<T>> meisaiMap, Date uketsukeDate
		List<TShinseiMeisai> shinseiMeisaiDtos = readJson("TestGetTShinseiMeisaiList10pra_1.json", new TypeToken<List<TShinseiMeisai> >(){}.getType());
		shinseiMeisaiDtos.get(0).setKanriCode((short)100);
		meisaiMap.put(ShinseiShurui.CHUSEN, shinseiMeisaiDtos);
		//
		kensuSeigenLogic.check(loginId,riyoshaGroupCode,meisaiMap, uketsukeDate);

	}

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestcheckInit.xlsx")
	public void Testcheck_4() throws Exception
	{
		String loginId = "sicvn";
		Short riyoshaGroupCode = 1;
		Date uketsukeDate = new Date();
		Map<ShinseiShurui, List<TShinseiMeisai>> meisaiMap = new HashMap<>();
		//String loginId, Map<ShinseiShurui, List<T>> meisaiMap, Date uketsukeDate
		List<TShinseiMeisai> shinseiMeisaiDtos = readJson("TestGetTShinseiMeisaiList10pra_1.json", new TypeToken<List<TShinseiMeisai> >(){}.getType());
		shinseiMeisaiDtos.get(0).setKanriCode((short)10);
		meisaiMap.put(ShinseiShurui.CHUSEN, shinseiMeisaiDtos);
		//
		kensuSeigenLogic.check(loginId,riyoshaGroupCode,meisaiMap, uketsukeDate);

	}

//	@Test
//	@DisplayName("データ更新に使用するDaoを取得します")
//	@TestInitDataFile("TestKoseiinJohoEntityToKoseiinJohoDtoInit1.xlsx")
//	public void Testcheck_Step4() throws Exception
//	{
//		String loginId = "sicvn";
//		Short riyoshaGroupCode = 1;
//		Date uketsukeDate = new Date();
//		Map<ShinseiShurui, List<TShinseiMeisai>> meisaiMap = new HashMap<>();
//		//String loginId, Map<ShinseiShurui, List<T>> meisaiMap, Date uketsukeDate
//		List<TShinseiMeisai> shinseiMeisaiDtos = readJson("TestGetTShinseiMeisaiList10pra_1.json", new TypeToken<List<TShinseiMeisai> >(){}.getType());
//		shinseiMeisaiDtos.get(0).setKanriCode((short)100);
//		meisaiMap.put(ShinseiShurui.CHUSEN, shinseiMeisaiDtos);
//		//
//		kensuSeigenLogic.check(loginId,riyoshaGroupCode,meisaiMap, uketsukeDate);
//
//	}
}

