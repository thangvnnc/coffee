package jp.ne.yec.seagullLC.stagia.test.junit.sample;

import static org.junit.Assert.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.beans.StringCodeNamePair;
import jp.ne.yec.seagullLC.stagia.service.riyosha.RiyoshaService;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestRiyoshaService extends JunitBase {

	@Autowired
	RiyoshaService riyoshaService;

	@Test
	@DisplayName("銀行マスタ全件抽出")
	@TestInitDataFile("TestRiyoshaServiceInit.xlsx")
	public void sample() throws Exception {
		List<StringCodeNamePair> ret = riyoshaService.getGinkoNameList();
		assertEquals(2, ret.size());
		Map<String, List<StringCodeNamePair>> assertMap = new HashMap<String, List<StringCodeNamePair>>();
		assertMap.put("StringCodeNamePair", ret);
		assertList("TestRiyoshaServiceExp.xlsx", assertMap);
	}

}
