package jp.ne.yec.seagullLC.stagia.test.junit.service.Check;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.google.gson.reflect.TypeToken;

import jp.ne.yec.seagullLC.stagia.beans.enums.domain.ShinseiShurui;
import jp.ne.yec.seagullLC.stagia.beans.shinsei.ShinseiMeisaiDto;
import jp.ne.yec.seagullLC.stagia.entity.MChusenGroup;
import jp.ne.yec.seagullLC.stagia.service.check.SeigenCheckService;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = { "classpath:TestApplicationContext.xml" })
@WebAppConfiguration
public class TestSeigenCheckService extends JunitBase {

	@Autowired
	SeigenCheckService seigenCheckService;

	@Test
	@DisplayName("ログイン職員が参照可能な管理名を取得します")
	public void TestShinseiSeigenCheck() throws Exception {
//		List<List<MKanri>> jsonData = new ArrayList<List<MKanri>>();
//
//		String loginId = "";
//		Short riyoshaGroupCode = 1;
//
//		List<Map<ShinseiShurui, List<T>>> shinseiMaps = new ArrayList<Map<ShinseiShurui, List<T>>>();
//		Map<ShinseiShurui, List<T>> shinseiMap = new HashMap<ShinseiShurui, List<T>>();
//		ShinseiShurui ShinseiDto = ShinseiShurui.CHUSEN;
//		List<ShinseiMeisaiDto> shinseiMeisaiDtos = new ArrayList<ShinseiMeisaiDto>();
//		ShinseiMeisaiDto shinseiMeisai = new ShinseiMeisaiDto();
//		shinseiMeisaiDtos.add(shinseiMeisai);
//		shinseiMap.put(ShinseiDto, shinseiMeisaiDtos);
//		shinseiMaps.add(shinseiMap);
//
//		Date uketsukeDate = new Date();
//
//		//String loginId, Short riyoshaGroupCode,
//		//Map<ShinseiShurui, List<T>> meisaiMap, Date uketsukeDate
//		List<ShinseiMeisaiDto extends TShinseiMeisai> list = seigenCheckService.shinseiSeigenCheck(loginId, riyoshaGroupCode, shinseiMaps.get(0), uketsukeDate);
//		assertEquals(2, list.size());
//		jsonData.add(list);
//		exportJsonData(jsonData, "TestGetKanrimeiList.json");
	}

	@Test
	@DisplayName("ログインID、管理コード、使用日(From)、使用日(To)を元に仮予約のT_申請明細を取得します.")
	@TestInitDataFile("TestKoseiinJohoEntityToKoseiinJohoDtoInit.xlsx")
	public void TestGetShinseiMeisai() throws Exception {
		String loginId = "tnt";
		 List<ShinseiMeisaiDto> shinseiMeisaiDtos = readJson("shinseiMeisaiDtos_in.json", new TypeToken<List<ShinseiMeisaiDto> >(){}.getType());

		seigenCheckService.riyoshaSeigenCheck(loginId, shinseiMeisaiDtos);

	}

	@Test
	@DisplayName("ログインID、管理コード、使用日(From)、使用日(To)を元に仮予約のT_申請明細を取得します.")
	@TestInitDataFile("TestKoseiinJohoEntityToKoseiinJohoDtoInit.xlsx")
	public void TestShinseiKomaCheck() throws Exception {
		 List<ShinseiMeisaiDto> shinseiMeisaiDtos = readJson("shinseiMeisaiDtos_in.json", new TypeToken<List<ShinseiMeisaiDto> >(){}.getType());
		 shinseiMeisaiDtos.get(0).setShinseiShurui(ShinseiShurui.CHUSEN);
		 MChusenGroup mChusenGroup = new MChusenGroup();
		 mChusenGroup.setAllowedPenaltyRiyosha(true);
		 shinseiMeisaiDtos.get(0).setMChusenGroup(mChusenGroup);
		seigenCheckService.shinseiKomaCheck(shinseiMeisaiDtos, true);

	}

	@Test
	@DisplayName("ログインID、管理コード、使用日(From)、使用日(To)を元に仮予約のT_申請明細を取得します.")
	@TestInitDataFile("TestKoseiinJohoEntityToKoseiinJohoDtoInit.xlsx")
	public void TestShinseiKomaCheck_step2() throws Exception {
		List<ShinseiMeisaiDto> shinseiMeisaiDtos = readJson("shinseiMeisaiDtos_in.json", new TypeToken<List<ShinseiMeisaiDto> >(){}.getType());
		 shinseiMeisaiDtos.get(0).setShinseiShurui(ShinseiShurui.CHUSEN);
		 MChusenGroup mChusenGroup = new MChusenGroup();
		 mChusenGroup.setAllowedPenaltyRiyosha(true);
		 shinseiMeisaiDtos.get(0).setMChusenGroup(mChusenGroup);
		seigenCheckService.shinseiKomaCheck(shinseiMeisaiDtos, false);

	}

	@Test
	@DisplayName("ログインID、管理コード、使用日(From)、使用日(To)を元に仮予約のT_申請明細を取得します.")
	@TestInitDataFile("TestKoseiinJohoEntityToKoseiinJohoDtoInit.xlsx")
	public void TestshinseiSeigenCheck() throws Exception {
		String loginId = "1";
		Short riyoshaGroupCode = 1;
		Map<ShinseiShurui, List<ShinseiMeisaiDto>> meisaiMap = new HashMap<>();
		//String loginId, Map<ShinseiShurui, List<T>> meisaiMap, Date uketsukeDate
		List<ShinseiMeisaiDto> shinseiMeisaiDtos = readJson("shinseiMeisaiDtos_in.json", new TypeToken<List<ShinseiMeisaiDto> >(){}.getType());
		meisaiMap.put(ShinseiShurui.CHUSEN, shinseiMeisaiDtos);
		Date uketsukeDate = new Date();
		seigenCheckService.shinseiSeigenCheck(loginId,riyoshaGroupCode, meisaiMap, uketsukeDate);

	}
}
