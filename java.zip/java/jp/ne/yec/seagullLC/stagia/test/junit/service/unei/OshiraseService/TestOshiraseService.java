package jp.ne.yec.seagullLC.stagia.test.junit.service.unei.OshiraseService;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.google.gson.reflect.TypeToken;

import jp.ne.yec.seagullLC.stagia.beans.enums.UpdateKubun;
import jp.ne.yec.seagullLC.stagia.beans.unei.OshiraseSetteiDto;
import jp.ne.yec.seagullLC.stagia.service.unei.OshiraseService;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestOshiraseService extends JunitBase{

	@Autowired
	OshiraseService oshiraseService;

//	@Test
//	@DisplayName("初期表示 情報(検索)を取得します。")
//	@TestInitDataFile("TestgetInitDataInit.xlsx")
//	public void TestGetInitData() throws Exception{
//		List<OshiraseKensakuDto> jsonData = new ArrayList<OshiraseKensakuDto>();
//		OshiraseKensakuDto oshiraseKensakuDto = oshiraseService.getInitData();
//		assertNotNull(oshiraseKensakuDto);
//		jsonData.add(oshiraseKensakuDto);
//		exportJsonData(jsonData, "TestGetInitData.json");
//	}

//	@Test
//	@DisplayName("引数の条件を基に職員・メディア全体 情報を取得します。")
//	@TestInitDataFile("TestGetZentaiInit.xlsx")
//	public void TestGetZentai() throws Exception{
//		List<List<OshiraseViewDto> > jsonData = new ArrayList<List<OshiraseViewDto> >();
//		List<String> listHyojisakiShurui = new ArrayList<String>();
//		listHyojisakiShurui.add("1");
//
//		LocalDate hyojiStartDate = CreateLocalDate(2017, 01, 01);
//		LocalDate hyojiEndDate = CreateLocalDate(2019, 01, 01);
//
//		List<Boolean> listIsIncludeDeleted = new ArrayList<Boolean>();
//		listIsIncludeDeleted.add(true);
//
//
//		List<OshiraseViewDto> list = oshiraseService.getZentai(
//				listHyojisakiShurui.get(0),
//				hyojiStartDate,
//				hyojiEndDate,
//				listIsIncludeDeleted.get(0)
//				);
//
//		//assertEquals(2, list.size());
//		jsonData.add(list);
//
//		exportJsonData(jsonData, "TestGetZentai.json");
//	}
//
//	@Test
//	@DisplayName("引数の条件を基に職員所属 情報を取得します。")
//	@TestInitDataFile("TestGetShokuinShozokuInit.xlsx")
//	public void TestGetShokuinShozoku() throws Exception{
//
//		List<List<OshiraseViewDto> > jsonData = new ArrayList<List<OshiraseViewDto> >();
//		List<String> listHyojisakiShurui = new ArrayList<String>();
//		listHyojisakiShurui.add("1");
//
//		List<StringCodeNamePair> kanriCodes = new ArrayList<StringCodeNamePair>();
//		StringCodeNamePair kanriCode = new StringCodeNamePair();
//		kanriCode.setCode("92");
//		kanriCodes.add(kanriCode);
//
//		LocalDate hyojiStartDate = CreateLocalDate(2017, 01, 01);
//		LocalDate hyojiEndDate = CreateLocalDate(2019, 01, 01);
//
//		List<Boolean> listIsIncludeDeleted = new ArrayList<Boolean>();
//		listIsIncludeDeleted.add(true);
//
//
//		List<OshiraseViewDto> ret = oshiraseService.getShokuinShozoku(
//				listHyojisakiShurui.get(0),
//				kanriCodes,
//				hyojiStartDate,
//				hyojiEndDate,
//				listIsIncludeDeleted.get(0)
//				);
//		//assertEquals(2, ret.size());
//		jsonData.add(ret);
//		exportJsonData(jsonData, "TestGetShokuinShozoku.json");
//	}
//
//	@Test
//	@DisplayName("引数の条件を基に職員・利用者個人 情報を取得します。")
//	@TestInitDataFile("TestTestGetKojinInit.xlsx")
//	public void TestGetKojin() throws Exception{
//		List<List<OshiraseViewDto> > jsonData = new ArrayList<List<OshiraseViewDto> >();
//		List<String> listHyojisakiShurui = new ArrayList<String>();
//		listHyojisakiShurui.add("1");
//
//		List<String> listLoginId = new ArrayList<String>();
//		listLoginId.add("sicvn");
//
//		List<String> listLoginKind = new ArrayList<String>();
//		listLoginKind.add("1");
//
//		LocalDate hyojiStartDate = CreateLocalDate(2017, 01, 01);
//		LocalDate hyojiEndDate = CreateLocalDate(2019, 01, 01);
//
//		List<Boolean> listIsIncludeDeleted = new ArrayList<Boolean>();
//		listIsIncludeDeleted.add(true);
//
//
//		List<OshiraseViewDto> list = oshiraseService.getKojin(
//				listHyojisakiShurui.get(0),
//				listLoginId.get(0),
//				listLoginKind.get(0),
//				hyojiStartDate,
//				hyojiEndDate,
//				listIsIncludeDeleted.get(0)
//				);
//		//assertEquals(2, list.size());
//		jsonData.add(list);
//
//		exportJsonData(jsonData, "TestGetKojin.json");
//	}
//
//	@Test
//	@DisplayName("引数の条件を基に職員・利用者個人 情報を取得します。")
//	@TestInitDataFile("TestTestGetKojinInit.xlsx")
//	public void TestGetKojin_step1() throws Exception{
//		List<List<OshiraseViewDto> > jsonData = new ArrayList<List<OshiraseViewDto> >();
//		List<String> listHyojisakiShurui = new ArrayList<String>();
//		listHyojisakiShurui.add("1");
//
//		List<String> listLoginId = new ArrayList<String>();
//		listLoginId.add("sicvn");
//
//		List<String> listLoginKind = new ArrayList<String>();
//		listLoginKind.add("1");
//
//		LocalDate hyojiStartDate = CreateLocalDate(2017, 01, 01);
//		LocalDate hyojiEndDate = CreateLocalDate(2019, 01, 01);
//
//		List<Boolean> listIsIncludeDeleted = new ArrayList<Boolean>();
//		listIsIncludeDeleted.add(false);
//
//
//		List<OshiraseViewDto> list = oshiraseService.getKojin(
//				listHyojisakiShurui.get(0),
//				listLoginId.get(0),
//				listLoginKind.get(0),
//				hyojiStartDate,
//				hyojiEndDate,
//				listIsIncludeDeleted.get(0)
//				);
//		//assertEquals(2, list.size());
//		jsonData.add(list);
//
//		exportJsonData(jsonData, "TestGetKojin_step1.json");
//	}
//
//	@Test
//	@DisplayName("引数の条件を基にメディア申請グループ 情報を取得します。")
//	@TestInitDataFile("TestGetMedhiaShinseiGroupInit.xlsx")
//	public void TestGetMedhiaShinseiGroup() throws Exception
//	{
//		List<List<OshiraseViewDto> > jsonData = new ArrayList<List<OshiraseViewDto> >();
//		List<String> listHyojisakiShurui = new ArrayList<String>();
//		listHyojisakiShurui.add("1");
//
//		List<StringCodeNamePair> listShinseiGroupCodes = readJson("getMedhiaShinseiGroup_StringCodeNamePair.json", new TypeToken<List<StringCodeNamePair>>(){}.getType());
//
//		LocalDate hyojiStartDate = CreateLocalDate(2018, 02, 01);
//		LocalDate hyojiEndDate = CreateLocalDate(2019, 07, 30);
//
//		List<Boolean> listIsIncludeDeleted = new ArrayList<Boolean>();
//		listIsIncludeDeleted.add(true);
//
//
//		List<OshiraseViewDto> list = oshiraseService.getMedhiaShinseiGroup(
//				listHyojisakiShurui.get(0),
//				listShinseiGroupCodes,
//				hyojiStartDate,
//				hyojiEndDate,
//				listIsIncludeDeleted.get(0)
//				);
//		//assertEquals(1, list.size());
//		jsonData.add(list);
//
//		exportJsonData(jsonData, "TestGetMedhiaShinseiGroup.json");
//
//	}
//
//	@Test
//	@DisplayName("お知らせ設定画面の表示用情報を取得します.")
//	@TestInitDataFile("TestGetOshiraseSetteiInitDataInit.xlsx")
//	public void TestGetOshiraseSetteiInitData() throws Exception
//	{
//		List<OshiraseSetteiDto > jsonData = new ArrayList<OshiraseSetteiDto >();
//		List<Integer> listOshiraseId = new ArrayList<Integer>();
//		listOshiraseId.add(1);
//
//		OshiraseSetteiDto oshiraseSetteiDto = oshiraseService.getOshiraseSetteiInitData(listOshiraseId.get(0));
//		//assertNotNull(oshiraseSetteiDto);
//		jsonData.add(oshiraseSetteiDto);
//		exportJsonData(jsonData, "TestGetOshiraseSetteiInitData.json");
//	}
//
//	@Test
//	@DisplayName("お知らせ設定画面の表示用情報を取得します.")
//	@TestInitDataFile("TestGetOshiraseSetteiInitDataInit.xlsx")
//	public void TestGetOshiraseSetteiInitData_step1() throws Exception
//	{
//		List<OshiraseSetteiDto > jsonData = new ArrayList<OshiraseSetteiDto >();
//		List<Integer> listOshiraseId = new ArrayList<Integer>();
//		listOshiraseId.add(null);
//
//		OshiraseSetteiDto oshiraseSetteiDto = oshiraseService.getOshiraseSetteiInitData(listOshiraseId.get(0));
//		assertNotNull(oshiraseSetteiDto);
//		jsonData.add(oshiraseSetteiDto);
//		exportJsonData(jsonData, "TestGetOshiraseSetteiInitData_step1.json");
//	}
//
//	@Test
//	@DisplayName("画面ヘッダー部のドロップダウンに表示するお知らせ情報を取得し返却します.")
//	@TestInitDataFile("TestGetHeaderMessageListInit.xlsx")
//	public void TestGetHeaderMessageList() throws Exception
//	{
//		List<List<StagiaMessageDto> > jsonData = new ArrayList<List<StagiaMessageDto> >();
//		List<Boolean> listIsLogin = new ArrayList<Boolean>();
//		listIsLogin.add(true);
//
//		List<Boolean> listIsShokuin = new ArrayList<Boolean>();
//		listIsShokuin.add(true);
//
//		List<String> listLoginId = new ArrayList<String>();
//		listLoginId.add("sicvn");
//
//		List<StagiaMessageDto> list = oshiraseService.getHeaderMessageList(
//				listIsLogin.get(0),
//				listIsShokuin.get(0),
//				listLoginId.get(0)
//				);
//		assertEquals(1, list.size());
//		jsonData.add(list);
//
//		exportJsonData(jsonData, "TestGetHeaderMessageList.json");
//	}
//
//	@Test
//	@DisplayName("画面ヘッダー部のドロップダウンに表示するお知らせ情報を取得し返却します.")
//	@TestInitDataFile("TestGetHeaderMessageListInit.xlsx")
//	public void TestGetHeaderMessageList_step1() throws Exception
//	{
//		List<List<StagiaMessageDto> > jsonData = new ArrayList<List<StagiaMessageDto> >();
//		List<Boolean> listIsLogin = new ArrayList<Boolean>();
//		listIsLogin.add(false);
//
//		List<Boolean> listIsShokuin = new ArrayList<Boolean>();
//		listIsShokuin.add(false);
//
//		List<String> listLoginId = new ArrayList<String>();
//		listLoginId.add("sicvn");
//
//		List<StagiaMessageDto> list = oshiraseService.getHeaderMessageList(
//				listIsLogin.get(0),
//				listIsShokuin.get(0),
//				listLoginId.get(0)
//				);
//		assertEquals(1, list.size());
//		jsonData.add(list);
//
//		exportJsonData(jsonData, "TestGetHeaderMessageList_step1.json");
//	}

//	@Test
//	@DisplayName("お知らせ選択後のダイアログに表示するお知らせ情報を取得し返却します.")
//	@TestInitDataFile("TestGetMessageListInit.xlsx")
//	public void TestGetMessageList() throws Exception
//	{
//		List<List<StagiaMessageDto> > jsonData = new ArrayList<List<StagiaMessageDto> >();
//		List<Boolean> listIsLogin = new ArrayList<Boolean>();
//		listIsLogin.add(true);
//
//		List<Boolean> listIsShokuin = new ArrayList<Boolean>();
//		listIsShokuin.add(true);
//
//		List<String> listLoginId = new ArrayList<String>();
//		listLoginId.add("sicvn");
//
//		List<StagiaMessageDto> list = oshiraseService.getMessageList(
//				listIsLogin.get(0),
//				listIsShokuin.get(0),
//				listLoginId.get(0)
//				);
//		//assertEquals(2, list.size());
//		jsonData.add(list);
//
//		exportJsonData(jsonData, "TestGetMessageList.json");
//
//	}
//
//	@Test
//	@DisplayName("お知らせ選択後のダイアログに表示するお知らせ情報を取得し返却します.")
//	@TestInitDataFile("TestGetMessageListInit.xlsx")
//	public void TestGetMessageList_Step2() throws Exception
//	{
//		List<List<StagiaMessageDto> > jsonData = new ArrayList<List<StagiaMessageDto> >();
//		List<Boolean> listIsLogin = new ArrayList<Boolean>();
//		listIsLogin.add(false);
//
//		List<Boolean> listIsShokuin = new ArrayList<Boolean>();
//		listIsShokuin.add(false);
//
//		List<String> listLoginId = new ArrayList<String>();
//		listLoginId.add("sicvn");
//
//		List<StagiaMessageDto> list = oshiraseService.getMessageList(
//				listIsLogin.get(0),
//				listIsShokuin.get(0),
//				listLoginId.get(0)
//				);
//		//assertEquals(2, list.size());
//		jsonData.add(list);
//
//		exportJsonData(jsonData, "TestGetMessageList_Step2.json");
//
//	}

//	@Test
//	@DisplayName("引数のお知らせIDの情報が既読扱いとなるように、DB更新を行います. 「T_お知らせ既読」へInsert処理を行います.")
//	@TestInitDataFile("TestInsReadMessageInit.xlsx")
//	public void TestInsReadMessage() throws Exception {
//		List<Integer> listOshiraseId = new ArrayList<Integer>();
//		listOshiraseId.add(29);
//
//		List<String> listLoginId = new ArrayList<String>();
//		listLoginId.add("sicvn");
//
//		List<String> listLoginKind = new ArrayList<String>();
//		listLoginKind.add("1");
//
//		List<String> listUpdateBy = new ArrayList<String>();
//		listUpdateBy.add("8000");
//
//
//		oshiraseService.insReadMessage(
//				listOshiraseId.get(0),
//				listLoginId.get(0),
//				listLoginKind.get(0),
//				listUpdateBy.get(0)
//				);
//
//	}

	@Test
	@DisplayName("引数のお知らせIDの情報が既読扱いとなるように、DB更新を行います. 「T_お知らせ既読」へInsert処理を行います.")
	public void TestOshiraseSettei() throws Exception {
		List<String> updatedBy = new ArrayList<String>();
		updatedBy.add("8000");

		List<OshiraseSetteiDto> setteiDtos = readJson("TestOshiraseSettei_param.json", new TypeToken<List<OshiraseSetteiDto>>(){}.getType());

			//OshiraseSetteiDto setteiDto, String updatedBy
			OshiraseSetteiDto setteiDto1 = setteiDtos.get(0);
			setteiDto1.setUpdateKbn("1");
			setteiDto1.setSelectedUpdateKbn(UpdateKubun.NEW);

			oshiraseService.oshiraseSettei(setteiDtos.get(0),updatedBy.get(0));

	}

	@Test
	@DisplayName("引数のお知らせIDの情報が既読扱いとなるように、DB更新を行います. 「T_お知らせ既読」へInsert処理を行います.")
	public void TestOshiraseSettei_step2() throws Exception {
		List<String> updatedBy = new ArrayList<String>();
		updatedBy.add("8000");

		List<OshiraseSetteiDto> setteiDtos = readJson("TestOshiraseSettei_param.json", new TypeToken<List<OshiraseSetteiDto>>(){}.getType());

			//OshiraseSetteiDto setteiDto, String updatedBy
			OshiraseSetteiDto setteiDto1 = setteiDtos.get(0);
			setteiDto1.setUpdateKbn("2");
			setteiDto1.setSelectedUpdateKbn(UpdateKubun.UPD);

			oshiraseService.oshiraseSettei(setteiDtos.get(0),updatedBy.get(0));

	}

	@Test
	@DisplayName("引数のお知らせIDの情報が既読扱いとなるように、DB更新を行います. 「T_お知らせ既読」へInsert処理を行います.")
	public void TestOshiraseSettei_step3() throws Exception {
		List<String> updatedBy = new ArrayList<String>();
		updatedBy.add("8000");

		List<OshiraseSetteiDto> setteiDtos = readJson("TestOshiraseSettei_param.json", new TypeToken<List<OshiraseSetteiDto>>(){}.getType());

			//OshiraseSetteiDto setteiDto, String updatedBy
			OshiraseSetteiDto setteiDto1 = setteiDtos.get(0);
			setteiDto1.setUpdateKbn("3");
			setteiDto1.setSelectedUpdateKbn(UpdateKubun.DEL);

			oshiraseService.oshiraseSettei(setteiDtos.get(0),updatedBy.get(0));

	}
}
