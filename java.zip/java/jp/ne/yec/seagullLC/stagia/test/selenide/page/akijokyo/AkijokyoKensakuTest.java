package jp.ne.yec.seagullLC.stagia.test.selenide.page.akijokyo;

import static com.codeborne.selenide.Selenide.*;

import org.apache.commons.lang.StringUtils;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;

import jp.ne.yec.seagullLC.stagia.test.selenide.page.base.SelenidePageBase;
import jp.ne.yec.seagullLC.stagia.test.selenide.page.shinsei.MeisaiIchiranTest;

/**
 * 空き状況検索ページのテストクラス.
 *
 * @author nao-hirata
 *
 */
public class AkijokyoKensakuTest extends SelenidePageBase {

	@FindBy(how = How.CSS, using = "input[wicketpath=searchForm_searchText]")
	private SelenideElement searchText;

	@FindBy(how = How.CSS, using = "button[wicketpath=searchForm_searchButton]")
	private SelenideElement searchButton;

	@FindBy(how = How.CSS, using = "div[wicketpath=akijokyoPanel_bashoBox] > div.box-body input[type=button]")
	private ElementsCollection bashoButtons;

	@FindBy(how = How.CSS, using = "div[wicketpath=akijokyoPanel_shisetsuBox] > div.box-body input[type=button]")
	private ElementsCollection shisetsuButtons;

	@FindBy(how = How.CSS, using = "button[wicketpath=nextButtonArea_shinseiInfoPageButton]")
	private SelenideElement meisaiIchiranButton;

	/**
	 * 検索ボタンをクリックします.
	 */
	public void search() {
		searchButton.click();
	}

	/**
	 * 検索ワードを入力し、検索ボタンをクリックします.
	 *
	 * @param text - 検索条件テキストに入力する検索条件
	 */
	public void search(String text) {
		if (StringUtils.isNotBlank(text)) {
			searchText.val(text);
		}
		search();
	}

	/**
	 * 場所を選択します.
	 *
	 * @param name - 選択する場所名称
	 */
	public void selectBasho(String name) {
		bashoButtons.findBy(Condition.value(name)).click();
	}

	/**
	 * 施設を選択します.
	 *
	 * @param name - 選択する施設名称
	 */
	public void selectShisetsu(String name) {
		shisetsuButtons.findBy(Condition.value(name)).click();
	}


	/**
	 * 空き状況のコマをクリックします.
	 *
	 * @param row - 空き状況テーブルの行。１行目は0。
	 * @param col - 空き状況テーブルの列。１列目は0。
	 */
	public void komaClick(int row, int col) {
		String selector = "td[wicketpath=akijokyoPanel_form_daichoContainer_akijokyo_areaToDateAndKomaDisplay_komaGroup_komaRows_"
				+ String.valueOf(row) + "_komaCols_" + String.valueOf(col) + "]";
		$(selector).click();
	}

	/**
	 * 明細一覧ページへ遷移します.
	 *
	 * @return
	 */
	public MeisaiIchiranTest nextPage() {
		return takeScreenShotAndMovePage(meisaiIchiranButton, MeisaiIchiranTest.class);
	}
}
