package jp.ne.yec.seagullLC.stagia.test.junit.service.madoguchi.ShinsaNyuryokuService;

import static org.junit.Assert.*;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.google.gson.reflect.TypeToken;

import jp.ne.yec.seagullLC.stagia.beans.madoguchi.ShinseiMeisaiDtoForMadoguchi;
import jp.ne.yec.seagullLC.stagia.entity.MBasho;
import jp.ne.yec.seagullLC.stagia.entity.MKanri;
import jp.ne.yec.seagullLC.stagia.entity.MShinsaRiyu;
import jp.ne.yec.seagullLC.stagia.entity.MShisetsu;
import jp.ne.yec.seagullLC.stagia.service.madoguchi.ShinsaNyuryokuService;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = { "classpath:TestApplicationContext.xml" })
@WebAppConfiguration
public class TestShinsaNyuryokuService extends JunitBase {

	@Autowired
	ShinsaNyuryokuService shinsaNyuryokuService;

	@Test
	@DisplayName("場所名を取得します")
	@TestInitDataFile("TestGetKanrimeiListInit.xlsx")
	public void TestGetKanrimeiList() throws Exception {
		List<List<MKanri>> jsonData = new ArrayList<List<MKanri>>();
		List<Short> kanriCodes = new ArrayList<>();
		kanriCodes.add((short)10);
		List<MKanri> list = shinsaNyuryokuService.getKanrimeiList(kanriCodes);
		//assertEquals(2, list.size());
		jsonData.add(list);
		exportJsonData(jsonData, "TestGetKanrimeiList.json");
	}

	@Test
	@DisplayName("場所名を取得します")
	@TestInitDataFile("TestgetMBashoList.xlsx")
	public void TestGetBashomeiList() throws Exception {
		List<List<MBasho>> jsonData = new ArrayList<List<MBasho>>();
		List<MBasho> list = shinsaNyuryokuService.getBashomeiList();
		//assertEquals(2, list.size());
		jsonData.add(list);
		exportJsonData(jsonData, "TestGetBashomeiList.json");
	}

	@Test
	@DisplayName("施設名を取得します")
	@TestInitDataFile("TestGetShisetsumeiListInit.xlsx")
	public void TestGetShisetsumeiList() throws Exception {
		List<List<MShisetsu>> jsonData = new ArrayList<List<MShisetsu>>();
		List<Short> listKanriCode = new ArrayList<Short>();
		listKanriCode.add((short)10);
		listKanriCode.add((short)14);

		List<Short> listBashoCode = new ArrayList<Short>();
		listBashoCode.add((short)10);
		listBashoCode.add((short)30);


		List<MShisetsu> list = shinsaNyuryokuService.getShisetsumeiList(listKanriCode.get(0), listBashoCode.get(0));
		//assertEquals(2, list.size());
		jsonData.add(list);

		exportJsonData(jsonData, "TestGetShisetsumeiList.json");
	}

	@Test
	@DisplayName("申請番号(From)、申請番号(To)、管理コード、場所コード、施設コード、使用日(From)、使用日(To)、受付日(From)、受付日(To)、審査区分を元に仮予約のT_申請明細を取得します.")
	@TestInitDataFile("TestGetShinseiDto_Init.xlsx")
	public void TestGetShinseiMeisaiList() throws Exception {
		List<List<ShinseiMeisaiDtoForMadoguchi>> jsonData = new ArrayList<List<ShinseiMeisaiDtoForMadoguchi>>();
		List<Integer> listShinseiBangoFrom = new ArrayList<Integer>();
		listShinseiBangoFrom.add(772);

		List<Integer> listShinseiBangoTo = new ArrayList<Integer>();
		listShinseiBangoTo.add(772);

		List<Short> listKanriCode = new ArrayList<Short>();
		listKanriCode.add((short)10);

		List<Short> listBashoCode = new ArrayList<Short>();
		listBashoCode.add((short)10);

		List<Short> listShisetsuCode = new ArrayList<Short>();
		listShisetsuCode.add((short)10);

		List<String> shinsaKubunCodeList = new ArrayList<String>();
		shinsaKubunCodeList.add("1");

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
		Date shiyoDateFrom = formatter.parse("2018/07/05");

		Date shiyoDateTo = formatter.parse("2018/07/05");

		Date uketukebiFrom = formatter.parse("2018/07/04");

		Date uketukebiTo = formatter.parse("2018/07/04");

		boolean isShokuinLogin = true;


			List<ShinseiMeisaiDtoForMadoguchi> list = shinsaNyuryokuService.getShinseiMeisaiList(
					listShinseiBangoFrom.get(0),
					listShinseiBangoTo.get(0),
					listKanriCode.get(0),
					listBashoCode.get(0),
					listShisetsuCode.get(0),
					shiyoDateFrom,
					shiyoDateTo,
					uketukebiFrom,
					uketukebiTo,
					shinsaKubunCodeList,
					isShokuinLogin
					);
			//assertEquals(2, list.size());
			jsonData.add(list);

		exportJsonData(jsonData, "TestGetShinseiMeisaiList.json");
	}

	@Test
	@DisplayName("申請番号(From)、申請番号(To)、管理コード、場所コード、施設コード、使用日(From)、使用日(To)、受付日(From)、受付日(To)、審査区分を元に仮予約のT_申請明細を取得します.")
	@TestInitDataFile("TestGetShinseiDto_Init.xlsx")
	public void TestGetShinseiMeisaiList_step2() throws Exception {
		List<List<ShinseiMeisaiDtoForMadoguchi>> jsonData = new ArrayList<List<ShinseiMeisaiDtoForMadoguchi>>();
		List<Integer> listShinseiBangoFrom = new ArrayList<Integer>();
		listShinseiBangoFrom.add(772);

		List<Integer> listShinseiBangoTo = new ArrayList<Integer>();
		listShinseiBangoTo.add(772);

		List<Short> listKanriCode = new ArrayList<Short>();
		listKanriCode.add((short)10);

		List<Short> listBashoCode = new ArrayList<Short>();
		listBashoCode.add((short)90);

		List<Short> listShisetsuCode = new ArrayList<Short>();
		listShisetsuCode.add((short)10);

		List<String> shinsaKubunCodeList = new ArrayList<String>();
		shinsaKubunCodeList.add("1");

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
		Date shiyoDateFrom = formatter.parse("2018/07/05");

		Date shiyoDateTo = formatter.parse("2018/07/05");

		Date uketukebiFrom = formatter.parse("2018/07/04");

		Date uketukebiTo = formatter.parse("2018/07/04");

		boolean isShokuinLogin = true;


			List<ShinseiMeisaiDtoForMadoguchi> list = shinsaNyuryokuService.getShinseiMeisaiList(
					listShinseiBangoFrom.get(0),
					listShinseiBangoTo.get(0),
					listKanriCode.get(0),
					listBashoCode.get(0),
					listShisetsuCode.get(0),
					shiyoDateFrom,
					shiyoDateTo,
					uketukebiFrom,
					uketukebiTo,
					shinsaKubunCodeList,
					isShokuinLogin
					);
			//assertEquals(2, list.size());
			jsonData.add(list);

		exportJsonData(jsonData, "TestGetShinseiMeisaiList.json");
	}

	@Test
	@DisplayName("申請番号(From)、申請番号(To)、管理コード、場所コード、施設コード、使用日(From)、使用日(To)、受付日(From)、受付日(To)、審査区分を元に仮予約のT_申請明細を取得します.")
	@TestInitDataFile("TestGetShinseiDto_Init_null.xlsx")
	public void TestGetShinseiMeisaiList_step3() throws Exception {
		List<List<ShinseiMeisaiDtoForMadoguchi>> jsonData = new ArrayList<List<ShinseiMeisaiDtoForMadoguchi>>();
		List<Integer> listShinseiBangoFrom = new ArrayList<Integer>();
		listShinseiBangoFrom.add(772);

		List<Integer> listShinseiBangoTo = new ArrayList<Integer>();
		listShinseiBangoTo.add(772);

		List<Short> listKanriCode = new ArrayList<Short>();
		listKanriCode.add((short)10);

		List<Short> listBashoCode = new ArrayList<Short>();
		listBashoCode.add((short)10);

		List<Short> listShisetsuCode = new ArrayList<Short>();
		listShisetsuCode.add((short)10);

		List<String> shinsaKubunCodeList = null;

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
		Date shiyoDateFrom = formatter.parse("2018/07/05");

		Date shiyoDateTo = formatter.parse("2018/07/05");

		Date uketukebiFrom = formatter.parse("2018/07/04");

		Date uketukebiTo = formatter.parse("2018/07/04");

		boolean isShokuinLogin = true;


			List<ShinseiMeisaiDtoForMadoguchi> list = shinsaNyuryokuService.getShinseiMeisaiList(
					listShinseiBangoFrom.get(0),
					listShinseiBangoTo.get(0),
					listKanriCode.get(0),
					listBashoCode.get(0),
					listShisetsuCode.get(0),
					shiyoDateFrom,
					shiyoDateTo,
					uketukebiFrom,
					uketukebiTo,
					shinsaKubunCodeList,
					isShokuinLogin
					);
			//assertEquals(2, list.size());
			jsonData.add(list);

		exportJsonData(jsonData, "TestGetShinseiMeisaiList.json");
	}

	@Test
	@DisplayName("管理コードを元に審査理由取得します")
	@TestInitDataFile("TestGetShinsaRiyuListInit.xlsx")
	public void TestGetShinsaRiyuList() throws Exception {
		List<List<MShinsaRiyu>> jsonData = new ArrayList<List<MShinsaRiyu>>();
		List<Short> listKanriCode = new ArrayList<Short>();
		listKanriCode.add((short)10);

		List<MShinsaRiyu> list = shinsaNyuryokuService.getShinsaRiyuList(listKanriCode.get(0));
		//assertEquals(2, list.size());
		jsonData.add(list);

		exportJsonData(jsonData, "TestGetShinsaRiyuList.json");
	}

	@Test
	@DisplayName("管理コードを元に審査理由取得します")
	@TestInitDataFile("TestUpdateTShinseiMeisaiListInit.xlsx")
	public void TestUpdateTShinseiMeisaiList() throws Exception {
		List<ShinseiMeisaiDtoForMadoguchi> shinseiMeisaiEntitys = readJson("TestUpdateTShinseiMeisaiList_para.json", new TypeToken<List<ShinseiMeisaiDtoForMadoguchi>>(){}.getType());
		shinseiMeisaiEntitys.get(0).setBashoCode((short)100);

		String updateBy = "8000";
		// List<ShinseiMeisaiDtoForMadoguchi> shinseiMeisaiEntityList
		shinsaNyuryokuService.updateTShinseiMeisaiList(shinseiMeisaiEntitys, updateBy);
	}
}
