package jp.ne.yec.seagullLC.stagia.test.junit.logic.master.MShokuinLogic;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.beans.shokai.ShokuinDto;
import jp.ne.yec.seagullLC.stagia.entity.MShokuin;
import jp.ne.yec.seagullLC.stagia.logic.master.MShokuinLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestMShokuinLogic extends JunitBase {

	@Autowired
	MShokuinLogic mShokuinLogic;

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	//@TestInitDataFile("TestgetMBashoList.xlsx")
	public void TestgetDao() throws Exception
	{
		GenericDao<MShokuin, ?> ret = mShokuinLogic.getDao();
	}

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestlogicalDeleteShokuin.xlsx")
	public void TestgetMRyokinTaikeiList() throws Exception
	{
		List<String> loginIds = new ArrayList<>();
		loginIds.add("0_test");

		List<MShokuin> exports = new ArrayList<>();
		for(int item = 0; item < loginIds .size(); item ++)
		{
			String loginId = loginIds.get(item);
			MShokuin ret =  mShokuinLogic.getMShokuin(loginId);
			exports.add(ret);
		}
		exportJsonData(exports, "TestgetMRyokinTaikeiList.json");
	}

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestlogicalDeleteShokuin.xlsx")
	public void TestgetShokuinKensaku() throws Exception
	{
		List<String> loginIds = new ArrayList<>();
		loginIds.add("0_test");

		List<String> sLoginIdMuchSelectCodes = new ArrayList<>();
		sLoginIdMuchSelectCodes.add("test");

		List<String> shokuinKanaNames = new ArrayList<>();
		shokuinKanaNames.add("test");

		List<String> loginKinds = new ArrayList<>();
		loginKinds.add("test");

		List<List<Short>> kanriCodeLists = new ArrayList<>();
		List<Short> kanriCodesItem = new ArrayList<>();
		kanriCodesItem.add((short)10);
		kanriCodeLists.add(kanriCodesItem);

		List<List<ShokuinDto>> exports = new ArrayList<>();
		for(int item = 0; item < loginIds.size(); item ++)
		{
			String loginId = loginIds.get(item);
			String sLoginIdMuchSelectCode= sLoginIdMuchSelectCodes.get(item);
			String shokuinKanaName= shokuinKanaNames.get(item);
			String loginKind = loginKinds.get(item);
			List<Short> kanriCodes = kanriCodeLists.get(item);
			List<ShokuinDto> ret =  mShokuinLogic.getShokuinKensaku(loginId,sLoginIdMuchSelectCode,
									shokuinKanaName,kanriCodes,loginKind);
			exports.add(ret);
		}
		exportJsonData(exports, "TestgetShokuinKensaku.json");
	}

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestlogicalDeleteShokuin.xlsx")
	public void TestlogicalDeleteShokuin() throws Exception
	{
		List<String> updatedBys = new ArrayList<>();
		updatedBys.add("0-3333");

		String loginId = "0_test";
		String sLoginIdMuchSelectCode= "";
		String shokuinKanaName= "";
		String loginKind = "";
		List<Short> kanriCodes = new ArrayList<>();
		kanriCodes.add((short)10);
		List<ShokuinDto> shokuinDtos = mShokuinLogic.getShokuinKensaku(loginId,sLoginIdMuchSelectCode,shokuinKanaName,
										kanriCodes,loginKind);
		shokuinDtos.add(new ShokuinDto());
		for(int item = 0; item < updatedBys.size(); item ++)
		{
			mShokuinLogic.logicalDeleteShokuin(shokuinDtos.get(item),updatedBys.get(item));
		}
	}
}