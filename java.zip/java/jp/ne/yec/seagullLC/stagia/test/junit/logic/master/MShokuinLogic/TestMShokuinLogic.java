package jp.ne.yec.seagullLC.stagia.test.junit.logic.master.MShokuinLogic;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.google.common.reflect.TypeToken;

import jp.ne.yec.seagullLC.stagia.beans.shokai.ShokuinDto;
import jp.ne.yec.seagullLC.stagia.logic.master.MShokuinLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestMShokuinLogic extends JunitBase {

	@Autowired
	MShokuinLogic mShokuinLogic;

//	@Test
//	@DisplayName("検索条件なしでM_管理を取得します")
//	//@TestInitDataFile("TestgetMBashoList.xlsx")
//	public void TestgetDao() throws Exception
//	{
//		GenericDao<MShokuin, ?> ret = mShokuinLogic.getDao();
//	}
//
//	@Test
//	@DisplayName("検索条件なしでM_管理を取得します")
//	@TestInitDataFile("TestlogicalDeleteShokuin.xlsx")
//	public void TestgetMRyokinTaikeiList() throws Exception
//	{
//		String loginId = "0_test";
//
//		MShokuin ret =  mShokuinLogic.getMShokuin(loginId);
//		exportJsonData(ret, "TestgetMRyokinTaikeiList.json");
//	}
//
//	@Test
//	@DisplayName("検索条件なしでM_管理を取得します")
//	@TestInitDataFile("TestlogicalDeleteShokuin.xlsx")
//	public void TestgetShokuinKensaku() throws Exception
//	{
//		List<Short> kanriCodes = new ArrayList<>();
//		kanriCodes.add((short)10);
//		String loginId = "1";
//		String sLoginIdMuchSelectCode= "0";
//		String shokuinKanaName= "test";
//		String loginKind = "0";
//
//		List<ShokuinDto> ret =  mShokuinLogic.getShokuinKensaku(loginId,sLoginIdMuchSelectCode,
//								shokuinKanaName,kanriCodes,loginKind);
//		exportJsonData(ret, "TestgetShokuinKensaku.json");
//	}
//
//	@Test
//	@DisplayName("検索条件なしでM_管理を取得します")
//	@TestInitDataFile("TestlogicalDeleteShokuin.xlsx")
//	public void TestgetShokuinKensaku2() throws Exception
//	{
//		List<Short> kanriCodes = null;
//		String loginId = "1";
//		String sLoginIdMuchSelectCode= "1";
//		String shokuinKanaName= null;
//		String loginKind = "0";
//
//		List<ShokuinDto> ret =  mShokuinLogic.getShokuinKensaku(loginId,sLoginIdMuchSelectCode,
//								shokuinKanaName,kanriCodes,loginKind);
//		exportJsonData(ret, "TestgetShokuinKensaku2.json");
//	}
//
//	@Test
//	@DisplayName("検索条件なしでM_管理を取得します")
//	@TestInitDataFile("TestlogicalDeleteShokuin.xlsx")
//	public void TestgetShokuinKensaku3() throws Exception
//	{
//		List<Short> kanriCodes = null;
//		String loginId = null;
//		String sLoginIdMuchSelectCode= null;
//		String shokuinKanaName= null;
//		String loginKind = "0";
//
//		List<ShokuinDto> ret =  mShokuinLogic.getShokuinKensaku(loginId,sLoginIdMuchSelectCode,
//								shokuinKanaName,kanriCodes,loginKind);
//		exportJsonData(ret, "TestgetShokuinKensaku3.json");
//	}
//
//
//
//	@Test
//	@DisplayName("検索条件なしでM_管理を取得します")
//	@TestInitDataFile("TestlogicalDeleteShokuin.xlsx")
//	public void TestgetShokuinKensaku4() throws Exception
//	{
//		List<Short> kanriCodes = null;
//		String loginId = "1";
//		String sLoginIdMuchSelectCode = "ads";
//		String shokuinKanaName= null;
//		String loginKind = "0";
//
//		List<ShokuinDto> ret =  mShokuinLogic.getShokuinKensaku(loginId,sLoginIdMuchSelectCode,
//								shokuinKanaName,kanriCodes,loginKind);
//		exportJsonData(ret, "TestgetShokuinKensaku4.json");
//	}
//
//	@Test
//	@DisplayName("検索条件なしでM_管理を取得します")
//	@TestInitDataFile("TestlogicalDeleteShokuin.xlsx")
//	public void TestgetShokuinKensaku5() throws Exception
//	{
//		List<Short> kanriCodes = null;
//		String loginId = null;
//		String sLoginIdMuchSelectCode= "0";
//		String shokuinKanaName= null;
//		String loginKind = "0";
//
//		List<ShokuinDto> ret =  mShokuinLogic.getShokuinKensaku(loginId,sLoginIdMuchSelectCode,
//								shokuinKanaName,kanriCodes,loginKind);
//		exportJsonData(ret, "TestgetShokuinKensaku5.json");
//	}
//
//	@Test
//	@TestInitDataFile("TestlogicalDeleteShokuin.xlsx")
//	public void TestgetShokuinKensaku6() throws Exception
//	{
//		List<Short> kanriCodes = null;
//		String loginId = "1";
//		String sLoginIdMuchSelectCode= null;
//		String shokuinKanaName= null;
//		String loginKind = "0";
//
//		List<ShokuinDto> ret =  mShokuinLogic.getShokuinKensaku(loginId,sLoginIdMuchSelectCode,
//								shokuinKanaName,kanriCodes,loginKind);
//		exportJsonData(ret, "TestgetShokuinKensaku6.json");
//	}

	@Test
	@TestInitDataFile("TestlogicalDeleteShokuin.xlsx")
	public void TestlogicalDeleteShokuin() throws Exception
	{
		String updatedBy = "test";
		
		ShokuinDto shokuinDto = readJson("ShokuinDto.json", new TypeToken<ShokuinDto>(){}.getType());
		mShokuinLogic.logicalDeleteShokuin(shokuinDto, updatedBy);
	}
	
//	@Test
//	@TestInitDataFile("TestlogicalDeleteShokuin.xlsx")
//	public void TestlogicalDeleteShokuin2() throws Exception
//	{
//		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/M/d HH:mm");
//		Date dateCreate = new Date();
//		dateCreate = dateFormat.parse("2018/1/22 14:17");
//		long timeCreate = dateCreate.getTime();
//		Timestamp tCreate = new Timestamp(timeCreate);
//
//		Date dateUpdate = new Date();
//		dateUpdate = dateFormat.parse("2018/1/23 14:19");
//		long timeUpdate= dateUpdate.getTime();
//		Timestamp tUpdate = new Timestamp(timeUpdate);
//
//		ShokuinDto shokuinDto = new ShokuinDto();
//		shokuinDto.setVersion(5);
//		shokuinDto.setLoginId("1");
//		shokuinDto.setDeleted(false);
//		shokuinDto.setSyokuinKanaName("test");
//		shokuinDto.setUketsukeBashoCode((short)10);
//		shokuinDto.setUpdatedBy("test");
//		shokuinDto.setCreatedBy("test");
//		shokuinDto.setCreatedAt(tCreate);
//		shokuinDto.setUpdatedAt(tUpdate);
//
//		List<MKanri> mKanriList = new ArrayList<>();
//		MKanri kanriCode = new MKanri();
//		kanriCode.setKanriCode((short)10);
//		mKanriList.add(kanriCode);
//		shokuinDto.setKanriCodeCK(mKanriList);
//
//		List<MShokuinKengen> mShokuinKengenList = new ArrayList<>();
//
//		MShokuinKengen mSho = new MShokuinKengen();
//		mSho.setKanriCode((short)10);
//		mSho.setVersion(5);
//		mSho.setAllowedUpdate(false);
//		mSho.setLoginId("1");
//		mSho.setUpdatedAt(tUpdate);
//		mSho.setUpdatedBy("test");
//		mSho.setCreatedAt(tCreate);
//		mSho.setCreatedBy("test");
//		mShokuinKengenList.add(mSho);
//
//		shokuinDto.setMShokuinKengenList(mShokuinKengenList);
//		shokuinDto.setPassword("000000");
//		shokuinDto.setUserName("test");
//		StringCodeNamePair selectedUketsukeBasho = new StringCodeNamePair();
//		selectedUketsukeBasho.setCode("10");
//		shokuinDto.setSelectedUketsukeBasho(selectedUketsukeBasho);
//		String updatedBy = "ad";
//
//		mShokuinLogic.logicalDeleteShokuin(shokuinDto, updatedBy);
//	}
}
