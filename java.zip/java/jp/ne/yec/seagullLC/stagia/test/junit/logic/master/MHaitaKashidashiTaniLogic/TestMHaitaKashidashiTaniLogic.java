package jp.ne.yec.seagullLC.stagia.test.junit.logic.master.MHaitaKashidashiTaniLogic;

import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.entity.MHaitaKashidashiTani;
import jp.ne.yec.seagullLC.stagia.entity.MShisetsu;
import jp.ne.yec.seagullLC.stagia.logic.master.MHaitaKashidashiTaniLogic;
import jp.ne.yec.seagullLC.stagia.logic.master.MShisetsuLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestMHaitaKashidashiTaniLogic extends JunitBase {

	@Autowired
	MHaitaKashidashiTaniLogic mHaitaKashidashiTaniLogic;

	@Autowired
	MShisetsuLogic mShisetsuLogic;

	@Test
	@DisplayName("検索条件なしでM_銀行を取得しStringCodeNamePairの形式で返却します")
	@TestInitDataFile("TestGetHaitaKashidashiTaniByShisetsuCodeList.xlsx")
	public void TestGetHaitaKashidashiTaniByShisetsuCode() throws Exception
	{
		List<MShisetsu> mShisetsus = mShisetsuLogic.getMShisetsuList();
		List<MHaitaKashidashiTani>  ret = mHaitaKashidashiTaniLogic.getHaitaKashidashiTaniByShisetsuCode(mShisetsus);
		exportJsonData(ret, "TestGetHaitaKashidashiTaniByShisetsuCode.json");
	}

	@Test
	@DisplayName("検索条件なしでM_銀行を取得しStringCodeNamePairの形式で返却します")
	@TestInitDataFile("TestGetHaitaKashidashiTaniByShisetsuCode.xlsx")
	public void TestGetHaitaInfoByHaitaKanren() throws Exception
	{
		Short kanriCodes = 10;

		Short haitaShisetsuCodes = 10;

		Short haitaKashidashiTaniCodes = 10;

		List<MHaitaKashidashiTani>  ret = mHaitaKashidashiTaniLogic.getHaitaInfoByHaitaKanren(kanriCodes, haitaShisetsuCodes, haitaKashidashiTaniCodes);

		exportJsonData(ret, "TestGetHaitaInfoByHaitaKanren.json");
	}
	@Test
	@DisplayName("検索条件なしでM_銀行を取得しStringCodeNamePairの形式で返却します")
	//@TestInitDataFile("TestgetMGinkoList.xlsx")
	public void TestgetDao() throws Exception
	{
		GenericDao<MHaitaKashidashiTani, ?> ret =  mHaitaKashidashiTaniLogic.getDao();
	}
}