package jp.ne.yec.seagullLC.stagia.test.selenide.page.shinsei;

import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.codeborne.selenide.SelenideElement;

import jp.ne.yec.seagullLC.stagia.test.selenide.page.akijokyo.AkijokyoKensakuTest;
import jp.ne.yec.seagullLC.stagia.test.selenide.page.base.SelenidePageBase;

/**
 * 申請完了画面のテストクラス.
 *
 * @author nao-hirata
 *
 */
public class ShinseiKanryoTest extends SelenidePageBase {

	@FindBy(how = How.CSS, using = "button[wicketpath=form_top]")
	protected SelenideElement topButton;

	public AkijokyoKensakuTest clickTopButton() {
		return takeScreenShotAndMovePage(topButton, AkijokyoKensakuTest.class);
	}


}
