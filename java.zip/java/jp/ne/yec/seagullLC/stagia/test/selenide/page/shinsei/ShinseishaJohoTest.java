package jp.ne.yec.seagullLC.stagia.test.selenide.page.shinsei;

import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.codeborne.selenide.SelenideElement;

import jp.ne.yec.seagullLC.stagia.test.selenide.page.base.SelenidePageBase;

/**
 * 申請者情報画面のテストクラス.
 *
 * @author nao-hirata
 *
 */
public class ShinseishaJohoTest extends SelenidePageBase {

	@FindBy(how = How.CSS, using = "input[wicketpath=form_loginIdInputArea_loginId]")
	private SelenideElement loginIdText;

	@FindBy(how = How.CSS, using = "button[wicketpath=form_loginIdInputArea_setRiyoshaInformation]")
	private SelenideElement loginIdSetteiButton;

	@FindBy(how = How.CSS, using = "button[wicketpath=form_settei]")
	private SelenideElement shinseishaSetteiButton;


	/**
	 * ログインIDを入力します.
	 *
	 * @param loginId
	 */
	public void setLoginId(String loginId) {
		loginIdText.val(loginId);
	}

	/**
	 * ログインID設定ボタンをクリックします.
	 */
	public void clickLoginIdSetteiButton() {
		click(loginIdSetteiButton);
	}

	/**
	 * ログインIDを入力し、設定ボタンをクリックします.
	 *
	 * @param loginId
	 */
	public void setLoginIdAndClickSetteiButton(String loginId) {
		setLoginId(loginId);
		clickLoginIdSetteiButton();
	}

	/**
	 * ログインID設定ボタンをクリックします.
	 */
	public void clickShinseishaSetteiButton() {
		click(shinseishaSetteiButton);
	}

	/**
	 * ログインID設定ボタンをクリックします.
	 */
	public void clickConfirmNo() {
		click(confirmNo);
	}

}
