package jp.ne.yec.seagullLC.stagia.test.junit.logic.master.MJoreiLogic;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.entity.MJorei;
import jp.ne.yec.seagullLC.stagia.logic.master.MJoreiLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestMJoreiLogic extends JunitBase {

	@Autowired
	MJoreiLogic mJoreiLogic;

	@Test
	@DisplayName("検索条件なしでM_銀行を取得しStringCodeNamePairの形式で返却します")
	@TestInitDataFile("TestGetMJoreiInit.xlsx")
	public void TestGetMJorei() throws Exception
	{
		Short kanriCode = 10;
		MJorei ret = mJoreiLogic.getMJorei(kanriCode);
		exportJsonData(ret, "TestGetMJorei.json");
	}

	@Test
	public void TestGetDao() throws Exception
	{
		GenericDao<MJorei, ?> ret = mJoreiLogic.getDao();
	}
}