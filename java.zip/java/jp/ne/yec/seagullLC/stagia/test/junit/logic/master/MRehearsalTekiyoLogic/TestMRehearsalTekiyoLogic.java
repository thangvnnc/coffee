package jp.ne.yec.seagullLC.stagia.test.junit.logic.master.MRehearsalTekiyoLogic;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.entity.MRehearsalTekiyo;
import jp.ne.yec.seagullLC.stagia.logic.master.MRehearsalTekiyoLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestMRehearsalTekiyoLogic extends JunitBase {

	@Autowired
	MRehearsalTekiyoLogic mRehearsalTekiyoLogic;

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetMRehearsalTekiyo_Map.xlsx")
	public void TestgetMRehearsalTekiyo() throws Exception
	{
		Short kanriCode = 10;
		Short shisetsuCode = 10;
		SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
		String ryokinKeisanKijunDates = "04/01/2010";
		Date ryokinKeisanKijunDate = formatter.parse(ryokinKeisanKijunDates);
		List<MRehearsalTekiyo> ret =  mRehearsalTekiyoLogic.getMRehearsalTekiyo(kanriCode,shisetsuCode,
					ryokinKeisanKijunDate);
		exportJsonData(ret, "TestgetMRehearsalTekiyo.json");
	}
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetMRehearsalTekiyo_Map.xlsx")
	public void TestgetMRehearsalTekiyo_Map() throws Exception
	{
		Map<Short, List<Short>> kanriShisetsuCodeMap = new HashMap<>();
		List<Short> mList = new ArrayList <>();
		mList.add((short)10);
		kanriShisetsuCodeMap.put((short)10, mList);
		List<MRehearsalTekiyo> ret =  mRehearsalTekiyoLogic.getMRehearsalTekiyo(kanriShisetsuCodeMap);
		exportJsonData(ret, "TestgetMRehearsalTekiyo_Map.json");
	}
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	//@TestInitDataFile("TestgetMBashoList.xlsx")
	public void TestgetDao() throws Exception
	{
		GenericDao<MRehearsalTekiyo, ?> ret = mRehearsalTekiyoLogic.getDao();
	}
}