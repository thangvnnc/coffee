package jp.ne.yec.seagullLC.stagia.test.junit.service.riyosha;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import jp.ne.yec.sane.beans.StringCodeNamePair;
import jp.ne.yec.seagullLC.stagia.beans.enums.domain.KozaShubetsu;
import jp.ne.yec.seagullLC.stagia.beans.enums.domain.TorokuKubun;
import jp.ne.yec.seagullLC.stagia.beans.riyosha.KanribetsuRiyoshaJohoDto;
import jp.ne.yec.seagullLC.stagia.beans.riyosha.KoseiinJohoDto;
import jp.ne.yec.seagullLC.stagia.beans.riyosha.RiyoKanoShinseiGroupDto;
import jp.ne.yec.seagullLC.stagia.beans.riyosha.RiyoshaUketoriMailDto;
import jp.ne.yec.seagullLC.stagia.beans.riyosha.RyokinSetteiDto;
import jp.ne.yec.seagullLC.stagia.entity.TRiyosha;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@SuppressWarnings("serial")
public class RiyoshaDtoTest extends TRiyosha implements Serializable {
	StringCodeNamePair kannriCode;
	String password;
	TorokuKubun selectedTorokuKubun;
	StringCodeNamePair selectedGinkoCode;
	StringCodeNamePair selectedShitenCode;
	KozaShubetsu selectedKozaShubetsu;
	StringCodeNamePair selectedRiyoshaGroupCode;
	List<StringCodeNamePair> selectedSoshinTiming = new ArrayList<>();
	List<StringCodeNamePair> selectedShinseiGroupCode = new ArrayList<>();
	String userName;
	short maxKoseiinCode = 0;
	List<KoseiinJohoDto> koseiinJohoDto = new ArrayList<>();
	List<RiyoKanoShinseiGroupDto> riyoKanoShinseiGroupDto = new ArrayList<>();
	List<KanribetsuRiyoshaJohoDto> kanribetsuRiyoshaJohoDto = new ArrayList<>();
	List<RyokinSetteiDto> ryokinSetteiDto = new ArrayList<>();
	List<RiyoshaUketoriMailDto> riyoshaUketoriMailDto = new ArrayList<>();
	// カレンダー用
	Object datepick;
	Object datepickStart;
	Object datepickEnd;

	// 職員検索用
	//String loginId;
	String shokuinKanaName;
	String kanrimei;
}
