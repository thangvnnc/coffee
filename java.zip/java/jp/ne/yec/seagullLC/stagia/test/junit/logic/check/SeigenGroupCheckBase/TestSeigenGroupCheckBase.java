package jp.ne.yec.seagullLC.stagia.test.junit.logic.check.SeigenGroupCheckBase;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.seagullLC.stagia.logic.riyosha.RiyoshaUtilityLogic;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestSeigenGroupCheckBase extends JunitBase {


	@Autowired
	RiyoshaUtilityLogic riyoshaUtilityLogic;

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	//@TestInitDataFile("TestgetMBashoList.xlsx")
	public void TestKoseiinJohoEntityToKoseiinJohoDto() throws Exception
	{
//		List<List<KoseiinJohoDto>> jsonData = new ArrayList<List<KoseiinJohoDto>>();
//		List<List<TKoseiin>> params = new ArrayList<List<TKoseiin>>();
//		List<TKoseiin> koseiinJohoEntityList = new ArrayList<TKoseiin>();
//		TKoseiin tKoseiin = new TKoseiin();
//		koseiinJohoEntityList.add(tKoseiin);
//		params.add(koseiinJohoEntityList);
//
//		List<KoseiinJohoDto>  ret = riyoshaUtilityLogic.koseiinJohoEntityToKoseiinJohoDto(params.get(0));
//		assertEquals(2, ret.size());
//		jsonData.add(ret);
//		exportJsonData(jsonData, "TestKoseiinJohoEntityToKoseiinJohoDto.json");
	}
}

