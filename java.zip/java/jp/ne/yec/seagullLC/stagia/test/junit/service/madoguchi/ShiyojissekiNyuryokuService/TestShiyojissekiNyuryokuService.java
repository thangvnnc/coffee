package jp.ne.yec.seagullLC.stagia.test.junit.service.madoguchi.ShiyojissekiNyuryokuService;

import static org.junit.Assert.*;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.google.gson.reflect.TypeToken;

import jp.ne.yec.seagullLC.stagia.beans.madoguchi.ShinseiMeisaiDtoForMadoguchi;
import jp.ne.yec.seagullLC.stagia.entity.MBasho;
import jp.ne.yec.seagullLC.stagia.entity.MKanri;
import jp.ne.yec.seagullLC.stagia.entity.MShisetsu;
import jp.ne.yec.seagullLC.stagia.service.madoguchi.ShiyojissekiNyuryokuService;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestShiyojissekiNyuryokuService extends JunitBase{

	@Autowired
	ShiyojissekiNyuryokuService shiyojissekiNyuryokuService;

	@Test
	@DisplayName("場所名を取得します")
	@TestInitDataFile("TestgetKanriByUserAuthority.xlsx")
	public void TestGetJissekiKanrimeiList() throws Exception{
		List<List<MKanri>> jsonData = new ArrayList<List<MKanri>>();

		List<Short> liShorts = new ArrayList<Short>();
		Short KanriCode = 10;
		liShorts.add(KanriCode);
		List<MKanri> list = shiyojissekiNyuryokuService.getJissekiKanrimeiList(liShorts);
		jsonData.add(list);
		exportJsonData(jsonData, "TestGetJissekiKanrimeiList.json");
	}

	@Test
	@DisplayName("場所名を取得します")
	@TestInitDataFile("TestgetMBashoList.xlsx")
	public void TestGetBashomeiList() throws Exception{
		List<List<MBasho>> jsonData = new ArrayList<List<MBasho>>();
		List<MBasho> list = shiyojissekiNyuryokuService.getBashomeiList();
		jsonData.add(list);
		exportJsonData(jsonData, "TestGetBashomeiList.json");
	}

	@Test
	@DisplayName("施設名を取得します")
	@TestInitDataFile("TestgetMShisetsuList.xlsx")
	public void TestGetShisetsumeiList() throws Exception{
		List<List<MShisetsu>> jsonData = new ArrayList<List<MShisetsu>>();
		List<Short> listKanriCode = new ArrayList<Short>();
		listKanriCode.add((short)10);
		List<Short> bashoCodes = new ArrayList<>();
		bashoCodes.add((short)10);
		List<MShisetsu> list = shiyojissekiNyuryokuService.getShisetsumeiList(
				listKanriCode.get(0),
				bashoCodes.get(0)
				);
		jsonData.add(list);
		exportJsonData(jsonData, "TestGetShisetsumeiList.json");
	}

	@Test
	@DisplayName("申請番号(From)、申請番号(To)、管理コード、場所コード、施設コード、使用日(From)、使用日(To)、受付日(From)、受付日(To)、使用日実績有無を元に予約のT_申請明細を取得します.")
	@TestInitDataFile("TestGetShinseiDto_Init.xlsx")
	public void TestGetShinseiMeisaiList() throws Exception{
		List<List<ShinseiMeisaiDtoForMadoguchi>> jsonData = new ArrayList<List<ShinseiMeisaiDtoForMadoguchi>>();
		int shinseiBangoFrom = 10;

		int shinseiBangoTo = 10;

		short kanriCode = 10;

		short bashoCode = 90;

		short shisetsuCode = 10;

		boolean shiyojissekiUmuFlg = true;

		boolean isShokuinLogin = true;

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/M/d");
		Date shiyoDateFrom = new Date();
		shiyoDateFrom = formatter.parse("2018/04/19");

		Date shiyoDateTo = new Date();
		shiyoDateTo = formatter.parse("2018/5/17");

		Date uketukebiFrom = new Date();
		uketukebiFrom = formatter.parse("2016/9/12");

		Date uketukebiTo = new Date();
		uketukebiTo = formatter.parse("2016/9/14");

		List<ShinseiMeisaiDtoForMadoguchi> list = shiyojissekiNyuryokuService.getShinseiMeisaiList(
				shinseiBangoFrom,
				shinseiBangoTo,
				kanriCode,
				bashoCode,
				shisetsuCode,
				shiyoDateFrom,
				shiyoDateTo,
				uketukebiFrom,
				uketukebiTo,
				shiyojissekiUmuFlg,
				isShokuinLogin
				);
		assertEquals(0, list.size());
	}

	@Test
	@DisplayName("申請番号(From)、申請番号(To)、管理コード、場所コード、施設コード、使用日(From)、使用日(To)、受付日(From)、受付日(To)、使用日実績有無を元に予約のT_申請明細を取得します.")
	@TestInitDataFile("TestGetShinseiDto_Init.xlsx")
	public void TestGetShinseiMeisaiList_step2() throws Exception{
		int shinseiBangoFrom = 772;

		int shinseiBangoTo = 772;

		short kanriCode = 10;

		short bashoCode = 10;

		short shisetsuCode = 10;

		boolean shiyojissekiUmuFlg = true;

		boolean isShokuinLogin = true;

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/M/d");
		Date shiyoDateFrom = formatter.parse("2018/07/05");

		Date shiyoDateTo = formatter.parse("2018/07/05");

		Date uketukebiFrom = formatter.parse("2018/07/04");

		Date uketukebiTo = formatter.parse("2018/07/04");

		List<ShinseiMeisaiDtoForMadoguchi> list = shiyojissekiNyuryokuService.getShinseiMeisaiList(
				shinseiBangoFrom,
				shinseiBangoTo,
				kanriCode,
				bashoCode,
				shisetsuCode,
				shiyoDateFrom,
				shiyoDateTo,
				uketukebiFrom,
				uketukebiTo,
				shiyojissekiUmuFlg,
				isShokuinLogin
				);
		//assertEquals(2, list.size());
		exportJsonData(list, "TestGetShinseiMeisaiList.json");
	}

	@Test
	@DisplayName("申請番号(From)、申請番号(To)、管理コード、場所コード、施設コード、使用日(From)、使用日(To)、受付日(From)、受付日(To)、使用日実績有無を元に予約のT_申請明細を取得します.")
	@TestInitDataFile("TestGetShinseiDto_Init_null.xlsx")
	public void TestGetShinseiMeisaiList_step3() throws Exception{
		List<List<ShinseiMeisaiDtoForMadoguchi>> jsonData = new ArrayList<List<ShinseiMeisaiDtoForMadoguchi>>();
		int shinseiBangoFrom = 772;

		int shinseiBangoTo = 772;

		short kanriCode = 10;

		short bashoCode = 10;

		short shisetsuCode = 10;

		boolean shiyojissekiUmuFlg = true;

		boolean isShokuinLogin = true;

		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/M/d");
		Date shiyoDateFrom = formatter.parse("2018/07/05");

		Date shiyoDateTo = formatter.parse("2018/07/05");

		Date uketukebiFrom = formatter.parse("2018/07/04");

		Date uketukebiTo = formatter.parse("2018/07/04");

		List<ShinseiMeisaiDtoForMadoguchi> list = shiyojissekiNyuryokuService.getShinseiMeisaiList(
				shinseiBangoFrom,
				shinseiBangoTo,
				kanriCode,
				bashoCode,
				shisetsuCode,
				shiyoDateFrom,
				shiyoDateTo,
				uketukebiFrom,
				uketukebiTo,
				shiyojissekiUmuFlg,
				isShokuinLogin
				);
		assertEquals(0, list.size());

	}

	@Test
	@DisplayName("管理コードを元に審査理由取得します")
	@TestInitDataFile("TestUpdateTShinseiMeisaiListInit.xlsx")
	public void TestUpdateTShinseiMeisaiList() throws Exception {
		List<ShinseiMeisaiDtoForMadoguchi> shinseiMeisaiEntitys = readJson("TestUpdateTShinseiMeisaiList_para.json", new TypeToken<List<ShinseiMeisaiDtoForMadoguchi>>(){}.getType());
		shinseiMeisaiEntitys.get(0).setBashoCode((short)11);
		String updateBy = "8000";
		// List<ShinseiMeisaiDtoForMadoguchi> shinseiMeisaiEntityList
			shiyojissekiNyuryokuService.updateTShinseiMeisaiList(shinseiMeisaiEntitys, updateBy);
	}
}
