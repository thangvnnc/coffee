package jp.ne.yec.seagullLC.stagia.test.junit.service.madoguchi.YoyakuIkoService;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.seagullLC.stagia.beans.shinsei.ShinseiDto;
import jp.ne.yec.seagullLC.stagia.beans.shinsei.ShinseiMeisaiDto;
import jp.ne.yec.seagullLC.stagia.entity.MChusenGroup;
import jp.ne.yec.seagullLC.stagia.entity.MKanri;
import jp.ne.yec.seagullLC.stagia.entity.MShisetsu;
import jp.ne.yec.seagullLC.stagia.entity.TRiyosha;
import jp.ne.yec.seagullLC.stagia.service.madoguchi.YoyakuIkoService;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestYoyakuIkoService extends JunitBase{

	@Autowired
	YoyakuIkoService yoyakuIkoService;
	MShisetsu mShisetsu;

	@Test
	@DisplayName("ログイン職員が参照可能な管理名を取得します")
	public void TestGetKanrimeiList() throws Exception{
		List<List<MKanri>> jsonData = new ArrayList<List<MKanri>>();
		List<Short> kanriCodes = new ArrayList<>();
		List<MKanri> list = yoyakuIkoService.getKanrimeiList(kanriCodes);
		assertEquals(2, list.size());
		jsonData.add(list);
		exportJsonData(jsonData, "TestGetKanrimeiList.json");
	}

	@Test
	@DisplayName("管理コードと仮予約番号を元に仮予約のT_申請明細を取得します")
	@TestInitDataFile("TestYoyakuIkoService.xlsx")
	public void TestGetShinseiMeisai() throws Exception{
		List<List<ShinseiMeisaiDto>> jsonData = new ArrayList<List<ShinseiMeisaiDto>>();

		List<Short> listKanriCode = new ArrayList<Short>();
		listKanriCode.add((short)26);
		listKanriCode.add((short)10);

		List<Integer> listShinseiNumber = new ArrayList<Integer>();
		listShinseiNumber.add(2016000445);
		listShinseiNumber.add(444);

		boolean isShokuinLogin = false;


		List<ShinseiMeisaiDto> list = yoyakuIkoService.getShinseiMeisai(listKanriCode.get(0), listShinseiNumber.get(0), isShokuinLogin);
		assertEquals(2, list.size());
		jsonData.add(list);
		exportJsonData(jsonData, "TestGetShinseiMeisai.json");
	}

	@Test
	@DisplayName("管理コードと申請番号を元にT_申請を取得します.")
	@TestInitDataFile("TestGetShinseiDto.xlsx")
	public void TestGetShinseiDto() throws Exception{
		List<ShinseiDto> jsonData = new ArrayList<ShinseiDto>();
		List<Short> listKanriCode = new ArrayList<Short>();
		listKanriCode.add((short)10);
		listKanriCode.add((short)10);

		List<Integer> listShinseiNumber = new ArrayList<Integer>();
		listShinseiNumber.add(1);
		listShinseiNumber.add(2);

		ShinseiDto shinseiDto = yoyakuIkoService.getShinseiDto(listKanriCode.get(0), listShinseiNumber.get(0));
		assertNotNull(shinseiDto);
		jsonData.add(shinseiDto);
		exportJsonData(jsonData, "TestGetShinseiDto.json");
	}

	@Test
	@DisplayName("ログインIDを元にT_利用者を取得します")
	@TestInitDataFile("TestGetRiyoshaInit.xlsx")
	public void TestGetRiyosha() throws Exception{
		List<TRiyosha> jsonData = new ArrayList<TRiyosha>();
		List<String> listLoginId = new ArrayList<String>();
		listLoginId.add("1");
		listLoginId.add("2");

		TRiyosha tRiyosha = yoyakuIkoService.getRiyosha(listLoginId.get(0));
		assertNotNull(tRiyosha);
		jsonData.add(tRiyosha);
		exportJsonData(jsonData, "TestGetRiyosha.json");
	}

	@Test
	@DisplayName("抽選グループコードを元に抽選グループを取得します")
	@TestInitDataFile("TestGetShokuinInfopInit.xlsx")
	public void TestGetShokuinInfop() throws Exception{
		List<MChusenGroup> jsonData = new ArrayList<MChusenGroup>();
		List<Short> listChusenGroupCode = new ArrayList<Short>();
		listChusenGroupCode.add((short)12);
		listChusenGroupCode.add((short)13);
		listChusenGroupCode.add((short)1);


		MChusenGroup mChusenGroup = yoyakuIkoService.getChusenGroup(listChusenGroupCode.get(0));
		assertNotNull(mChusenGroup);
		jsonData.add(mChusenGroup);
		exportJsonData(jsonData, "TestGetShokuinInfop.json");
	}

	@Test
	@DisplayName("抽選グループコードを元に抽選グループを取得します")
	@TestInitDataFile("TestSetMeisaiSubTables.xlsx")
	public void TestSetMeisaiSubTables() throws Exception{
		List<ShinseiDto> shinseiDtos = new ArrayList<ShinseiDto>();
		List<Short> listKanriCode = new ArrayList<Short>();
		listKanriCode.add((short)10);
		listKanriCode.add((short)10);

		List<Integer> listShinseiNumber = new ArrayList<Integer>();
		listShinseiNumber.add(1);
		listShinseiNumber.add(2);

		// TBD gọi hàm lấy parameter từ json
//		for (int idx = 0; idx < listKanriCode.size(); idx++) {
//			ShinseiDto shinseiDto = yoyakuIkoService.getShinseiDto(listKanriCode.get(idx), listShinseiNumber.get(idx));
//			shinseiDtos.add(shinseiDto);
//		}

		List<List<ShinseiMeisaiDto>> dtos = new ArrayList<List<ShinseiMeisaiDto>>();
		List<Short> listKanriCode1 = new ArrayList<Short>();
		listKanriCode.add((short)26);
		listKanriCode.add((short)10);

		List<Integer> listShinseiNumber1 = new ArrayList<Integer>();
		listShinseiNumber.add(2016000445);
		listShinseiNumber.add(444);

		boolean isShokuinLogin = false;

		// TBD gọi hàm lấy parameter từ json
//		for (int idx = 0; idx < listKanriCode.size(); idx++) {
//			List<ShinseiMeisaiDto> list = yoyakuIkoService.getShinseiMeisai(listKanriCode.get(idx), listShinseiNumber.get(idx), isShokuinLogin);
//			dtos.add(list);
//		}

		// ShinseiDto shinseiDto, List<ShinseiMeisaiDto> dtos
			yoyakuIkoService.setMeisaiSubTables(shinseiDtos.get(0), dtos.get(0) );
	}
}
