package jp.ne.yec.seagullLC.stagia.test.junit.service.master;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.seagullLC.stagia.entity.MKanri;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;
import jp.ne.yec.seagullLC.stagia.test.junit.support.JUnitSupport;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestMShokuinService extends JunitBase{
	JUnitSupport jUnitSupport = new JUnitSupport<MKanri>();

	@Autowired
	//MShokuinService mShokuinService;

	@Test
	public void TestGetKanriMap() throws Exception {
		//Map<Short, MKanri> kanriMap = mShokuinService.getKanriMap();
		//List<MKanri> ret = new ArrayList<>(kanriMap.values());
		// TBD System.out.println("ppppppppppppppppppppp");
		// TBD Gson gson= new Gson();
		// TBD System.out.println(gson.toJson(ret));
		// TBD Map<String, List<MKanri>> assertMap = new HashMap<String, List<MKanri>>();
		// TBD assertMap.put("MKanri", ret);
		// TBD assertList("TestGetKanriMapExp2.xlsx", assertMap);
	}

	@Test
	public void TestGetUketukeBashoList() throws Exception {
		//List<StringCodeNamePair> ret = mShokuinService.getUketukeBashoList();
		// TBD assertEquals(22, ret.size());
		// TBD Map<String, List<StringCodeNamePair>> assertMap = new HashMap<String, List<StringCodeNamePair>>();
		// TBD assertMap.put("StringCodeNamePair", ret);
		// TBD assertList("TestGetUketukeBashoListExp.xlsx", assertMap);
	}

	@Test
	public void TestGetShokuinInfo() throws Exception {
		//ShokuinDto shokuinDto = mShokuinService.getShokuinInfo("hirata");
		// TBD
	}

	@Test
	public void TestGetShokuinInfoGetIsNull() throws Exception {
		//ShokuinDto shokuinDto = mShokuinService.getShokuinInfo("dd");
		// TBD
	}

	@Test
	public void TestRegisterShokuin_updateMShokuinKengen() throws Exception {
//		Map<Short, MKanri> kanriMap = mShokuinService.getKanriMap();
//		ShokuinDto shokuinDto = mShokuinService.getShokuinInfo("hirata");
//		mShokuinService.registerShokuin(kanriMap, shokuinDto, "tester");
	}

	@Test
	public void TestLogicalDeleteShokuin() throws Exception {
//		ShokuinDto shokuinDto = mShokuinService.getShokuinInfo("1111");
//		mShokuinService.logicalDeleteShokuin(shokuinDto, "testdelete");
	}
}
