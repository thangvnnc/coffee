package jp.ne.yec.seagullLC.stagia.test.junit.service.app.RiyoshaHenkoService;

import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.seagullLC.stagia.service.app.RiyoshaHenkoService;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = { "classpath:TestApplicationContext.xml" })
@WebAppConfiguration
public class TestRiyoshaHenkoService extends JunitBase {

	@Autowired
	RiyoshaHenkoService riyoshaHenkoService;

//	@Test
//	public void TestAppPasswordUpdate() throws Exception {
//		Map<String, String> mapUnitTest = new HashMap<String, String>();
//		mapUnitTest.put("1", "0");
//		mapUnitTest.put("2", "1");
//
//		List<Map<String, String>> jsonData = new ArrayList<Map<String, String>>();
//		Map<String, String> map = riyoshaHenkoService.appPasswordUpdate(mapUnitTest);
//		jsonData.add(map);
//		exportJsonData(jsonData, "TestAppReadRenraku.json");
//	}

}
