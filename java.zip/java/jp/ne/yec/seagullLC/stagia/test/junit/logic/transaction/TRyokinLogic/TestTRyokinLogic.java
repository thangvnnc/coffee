package jp.ne.yec.seagullLC.stagia.test.junit.logic.transaction.TRyokinLogic;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.beans.criteria.SearchIKeshikomiDto;
import jp.ne.yec.seagullLC.stagia.beans.enums.JokenHukumu;
import jp.ne.yec.seagullLC.stagia.beans.enums.domain.RyokinKubun;
import jp.ne.yec.seagullLC.stagia.beans.madoguchi.RyoshuKeshikomiDto;
import jp.ne.yec.seagullLC.stagia.entity.MBasho;
import jp.ne.yec.seagullLC.stagia.entity.MKanri;
import jp.ne.yec.seagullLC.stagia.entity.MShisetsu;
import jp.ne.yec.seagullLC.stagia.entity.TRyokin;
import jp.ne.yec.seagullLC.stagia.logic.transaction.TRyokinLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestTRyokinLogic extends JunitBase {

	@Autowired
	TRyokinLogic tRyokinLogic;
//	@Test
//	@DisplayName("検索条件なしでM_管理を取得します")
//	@TestInitDataFile("TestgetTRyokinInit.xlsx")
//	public void TestgetTRyokin() throws Exception
//	{
//		int id = 37955;
//		List<TRyokin> ret =  tRyokinLogic.getTRyokin(id);
//		exportJsonData(ret, "TestgetTRyokin.json");
//	}
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetTRyokinInit.xlsx")
	public void TestgetTRyokin() throws Exception
	{
		List<Integer> ids = new ArrayList<>();
		ids.add(37955);
		ids.add(37956);
		ids.add(37957);
		List<TRyokin> ret =  tRyokinLogic.getTRyokin(ids);
		exportJsonData(ret, "TestgetTRyokin.json");
	}

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetRyokinSeisanDtoInit.xlsx")
	public void TestgetRyokinSeisanDto1() throws Exception
	{
		SearchIKeshikomiDto searchIKeshikomiDto = new SearchIKeshikomiDto();

		SimpleDateFormat sd = new SimpleDateFormat("yyyy/M/d");

		Date shiyoDateFrom = new Date();
		shiyoDateFrom = sd.parse("2018/4/19");

		Date shiyoDateTo = new Date();
		shiyoDateTo = sd.parse("2018/4/19");

		searchIKeshikomiDto.setLoginId("37955");
		searchIKeshikomiDto.setShinseiNoFrom(12);
		searchIKeshikomiDto.setShinseiNoTo(12);
		searchIKeshikomiDto.setShiyoDateFrom(shiyoDateFrom);
		searchIKeshikomiDto.setShiyoDateTo(shiyoDateTo);

		MKanri mKanri = new MKanri();
		mKanri.setKanriCode((short)10);
		searchIKeshikomiDto.setMKanri(mKanri);
		MBasho mBasho = new MBasho();
		mBasho.setBashoCode((short)10);
		searchIKeshikomiDto.setMBasho(mBasho);
		searchIKeshikomiDto.setJoken(JokenHukumu.HUKUMU);


		List<MShisetsu> mShisetsuList = new ArrayList<>();

		List<RyokinKubun> ryokinKubunList = new ArrayList<>();

		searchIKeshikomiDto.setMShisetsuList(mShisetsuList);
		searchIKeshikomiDto.setRyokinKubunList(ryokinKubunList);

		List<RyoshuKeshikomiDto> ret =  tRyokinLogic.getRyokinSeisanDto(searchIKeshikomiDto);
		exportJsonData(ret, "TestgetRyokinSeisanDto1.json");
	}

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetRyokinSeisanDtoInit.xlsx")
	public void TestgetRyokinSeisanDto2() throws Exception
	{
		SearchIKeshikomiDto searchIKeshikomiDto = new SearchIKeshikomiDto();

		SimpleDateFormat sd = new SimpleDateFormat("yyyy/M/d");

		Date shiyoDateFrom = new Date();
		shiyoDateFrom = sd.parse("2018/4/19");

		Date shiyoDateTo = new Date();
		shiyoDateTo = sd.parse("2018/4/19");

		searchIKeshikomiDto.setLoginId("37955");
		searchIKeshikomiDto.setShinseiNoFrom(12);
		searchIKeshikomiDto.setShinseiNoTo(12);
		searchIKeshikomiDto.setShiyoDateFrom(shiyoDateFrom);
		searchIKeshikomiDto.setShiyoDateTo(shiyoDateTo);

		MKanri mKanri = new MKanri();
		mKanri.setKanriCode((short)10);
		searchIKeshikomiDto.setMKanri(mKanri);
		MBasho mBasho = new MBasho();
		mBasho.setBashoCode((short)10);
		searchIKeshikomiDto.setMBasho(mBasho);
		searchIKeshikomiDto.setJoken(JokenHukumu.ICCHI);


		List<MShisetsu> mShisetsuList = new ArrayList<>();
		MShisetsu mShisetsu = new MShisetsu();
		mShisetsu.setKanriCode((short)10);
		mShisetsu.setBashoCode((short)10);
		mShisetsu.setShisetsuCode((short)10);
		mShisetsuList.add(mShisetsu);

		List<RyokinKubun> ryokinKubunList = new ArrayList<>();
		ryokinKubunList.add(RyokinKubun.SHISETSU);

		searchIKeshikomiDto.setMShisetsuList(mShisetsuList);
		searchIKeshikomiDto.setRyokinKubunList(ryokinKubunList);


		List<RyoshuKeshikomiDto> ret =  tRyokinLogic.getRyokinSeisanDto(searchIKeshikomiDto);
		exportJsonData(ret, "TestgetRyokinSeisanDto2.json");
	}
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	//@TestInitDataFile("TestgetMBashoList.xlsx")
	public void TestgetDao() throws Exception
	{
		GenericDao<TRyokin, ?> ret = tRyokinLogic.getDao();
	}
}