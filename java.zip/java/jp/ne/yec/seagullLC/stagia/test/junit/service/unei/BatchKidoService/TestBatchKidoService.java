package jp.ne.yec.seagullLC.stagia.test.junit.service.unei.BatchKidoService;

import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.seagullLC.stagia.beans.enums.domain.BatchShurui;
import jp.ne.yec.seagullLC.stagia.beans.unei.BatchKidoDto;
import jp.ne.yec.seagullLC.stagia.beans.unei.BatchKidoViewDto;
import jp.ne.yec.seagullLC.stagia.beans.unei.BatchLotoExeViewDto;
import jp.ne.yec.seagullLC.stagia.service.unei.BatchKidoService;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestBatchKidoService extends JunitBase{

	@Autowired
	BatchKidoService batchKidoService;

	@Test
	@DisplayName("引数の基準日を基に無断キャンセル更新の一覧を取得し返却します.")
	@TestInitDataFile("TestGetMudanCancelListInit.xlsx")
	public void TestGetMudanCancelList() throws Exception{
		List<List<BatchKidoViewDto>> jsonData = new ArrayList<List<BatchKidoViewDto>>();

		String date = 2018 + "/" + 06 + "/" + 27;
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
		Date MudanDate = formatter.parse(date);

		Instant instant = Instant.ofEpochMilli(MudanDate.getTime());
		LocalDate baseDate = LocalDateTime.ofInstant(instant, ZoneId.systemDefault()).toLocalDate();

		List<BatchKidoViewDto> list = batchKidoService.getMudanCancelList(baseDate);
		jsonData.add(list);
		exportJsonData(jsonData, "TestGetMudanCancelList.json");
	}

	@Test
	@DisplayName("引数の基準日を基に仮予約削除の一覧を取得し返却します.")
	@TestInitDataFile("TestGetKariSakujoListInit.xlsx")
	public void TestGetKariSakujoList() throws Exception{
		List<List<BatchKidoViewDto>> jsonData = new ArrayList<List<BatchKidoViewDto>>();
		String date = 2018 + "/" + 06 + "/" + 27;
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
		Date MudanDate = formatter.parse(date);

		Instant instant = Instant.ofEpochMilli(MudanDate.getTime());
		LocalDate baseDate = LocalDateTime.ofInstant(instant, ZoneId.systemDefault()).toLocalDate();

		List<BatchKidoViewDto> list = batchKidoService.getKariSakujoList(baseDate);
		jsonData.add(list);
		exportJsonData(jsonData, "TestGetKariSakujoListInit.json");
	}

	@Test
	@DisplayName("当選削除の一覧を取得し返却します.")
	@TestInitDataFile("TestGetTosenSakujoListInit.xlsx")
	public void TestGetTosenSakujoList() throws Exception{
		List<List<BatchKidoViewDto>> jsonData = new ArrayList<List<BatchKidoViewDto>>();
		String date = 2018 + "/" + 06 + "/" + 27;
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
		Date MudanDate = formatter.parse(date);

		Instant instant = Instant.ofEpochMilli(MudanDate.getTime());
		LocalDate baseDate = LocalDateTime.ofInstant(instant, ZoneId.systemDefault()).toLocalDate();

		List<BatchKidoViewDto> list = batchKidoService.getTosenSakujoList();
		jsonData.add(list);
		exportJsonData(jsonData, "TestGetTosenSakujoList.json");
	}

	@Test
	@DisplayName("抽選実行の一覧を取得し返却します.")
	@TestInitDataFile("TestGetMudanCancelListInit.xlsx")
	public void TestGetChusenJikkoList() throws Exception{
		List<List<BatchLotoExeViewDto>> jsonData = new ArrayList<List<BatchLotoExeViewDto>>();
		String date = 2017 + "/" + 11 + "/" + 30;
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
		Date MudanDate = formatter.parse(date);

		Instant instant = Instant.ofEpochMilli(MudanDate.getTime());
		LocalDate baseDate = LocalDateTime.ofInstant(instant, ZoneId.systemDefault()).toLocalDate();

		List<BatchLotoExeViewDto> list = batchKidoService.getChusenJikkoList();
		jsonData.add(list);
		exportJsonData(jsonData, "TestGetChusenJikkoList.json");
	}


	@Test
	@DisplayName("バッチ種類のリストを取得します。マスタ設定値により、表示するリストを制御します")
	@TestInitDataFile("TestGetBatchTypeListInit.xlsx")
	public void TestGetBatchTypeList() throws Exception{
		List<List<BatchShurui>> jsonData = new ArrayList<List<BatchShurui>>();
		List<BatchShurui> list = batchKidoService.getBatchTypeList();
		jsonData.add(list);
		exportJsonData(jsonData, "TestGetBatchTypeList.json");
	}

	@Test
	@DisplayName("バッチ種類のリストを取得します。マスタ設定値により、表示するリストを制御します")
	@TestInitDataFile("TestGetBatchTypeListInit_null.xlsx")
	public void TestGetBatchTypeList_null() throws Exception{
		List<List<BatchShurui>> jsonData = new ArrayList<List<BatchShurui>>();
		List<BatchShurui> list = batchKidoService.getBatchTypeList();
		jsonData.add(list);
		exportJsonData(jsonData, "TestGetBatchTypeList_null.json");
	}

	@Test
	@DisplayName("バッチ種類のリストを取得します。マスタ設定値により、表示するリストを制御します")
	@TestInitDataFile("TestGetBatchTypeListInit.xlsx")
	public void TestBatchKido() throws Exception{

		List<BatchShurui> list = batchKidoService.getBatchTypeList();
		List<BatchKidoDto> batchKidoDtos = new ArrayList<BatchKidoDto>();

		for (int idx = 0; idx < list.size(); idx++)
		{
			BatchKidoDto batchKidoDto = new BatchKidoDto();
			batchKidoDto.setSelectedBatchType(list.get(idx));
			batchKidoDtos.add(batchKidoDto);
		}

		List<List<BatchShurui>> jsonData = new ArrayList<List<BatchShurui>>();

		//BatchKidoDto batchKidoDto
		for (int idx = 0; idx < batchKidoDtos.size(); idx++)
		{
			batchKidoService.batchKido(batchKidoDtos.get(idx));
		}

	}
}
