package jp.ne.yec.seagullLC.stagia.test.junit.logic.master.MRenzokuShiyoSeigenLogic;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.entity.MRenzokuShiyoSeigen;
import jp.ne.yec.seagullLC.stagia.logic.master.MRenzokuShiyoSeigenLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestMRenzokuShiyoSeigenLogic extends JunitBase {

	@Autowired
	MRenzokuShiyoSeigenLogic mRenzokuShiyoSeigenLogic;

	@Test
	@DisplayName("引数なしでM_料金体系を取得します.")
	@TestInitDataFile("TestgetList.xlsx")
	public void TestgetList() throws Exception {
		Map<Short, List<Short>> kanriShisetsuMap = new HashMap<>();
		List<Short> mList = new ArrayList<>();
		mList.add((short)10);
		mList.add((short)20);
		kanriShisetsuMap.put((short)10, mList);
		List<MRenzokuShiyoSeigen> ret =  mRenzokuShiyoSeigenLogic.getList(kanriShisetsuMap);
		exportJsonData(ret, "TestgetList.json");
	}
	@Test
	@DisplayName("引数なしでM_料金体系を取得します.")
	//@TestInitDataFile("TestRiyoshaServiceInit.xlsx")
	public void TestGetDAO() throws Exception {
		GenericDao<MRenzokuShiyoSeigen, ?> ret = mRenzokuShiyoSeigenLogic.getDao();
	}
}
