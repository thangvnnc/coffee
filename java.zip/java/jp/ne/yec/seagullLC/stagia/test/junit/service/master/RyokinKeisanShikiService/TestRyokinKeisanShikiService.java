package jp.ne.yec.seagullLC.stagia.test.junit.service.master.RyokinKeisanShikiService;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.beans.StringCodeNamePair;
import jp.ne.yec.seagullLC.stagia.service.master.RyokinKeisanShikiService;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestRyokinKeisanShikiService extends JunitBase{

	@Autowired
	RyokinKeisanShikiService ryokinKeisanShikiService;

//	@Test
//	@TestInitDataFile("TestMakeRyokinKeisanExcelInit.xlsx")
//	public void TestMakeRyokinKeisanExcel() throws Exception{
//		StringCodeNamePair kanriCode = new StringCodeNamePair();
//		kanriCode.setCode("10");
//		kanriCode.setName("kanri_code");
//
//		String path = this.getClass().getPackage().getName();
//		String pathOutPut = "D:/stagia2/stagia2_svn/module/src-test/java/" + path.replaceAll("\\.", "/");
//		OutputStream output = new FileOutputStream(pathOutPut + "/" + "Test.xlsx", false);
//		ryokinKeisanShikiService.makeRyokinKeisanExcel(kanriCode, output);
//	}
//
//	@Test
//	@TestInitDataFile("TestMakeRyokinKeisanExcelInit.xlsx")
//	public void TestMakeRyokinKeisanExcel2() throws Exception{
//		StringCodeNamePair kanriCode = new StringCodeNamePair();
//		kanriCode.setCode("11");
//		kanriCode.setName("kanri_code");
//
//		String path = this.getClass().getPackage().getName();
//		String pathOutPut = "D:/stagia2/stagia2_svn/module/src-test/java/" + path.replaceAll("\\.", "/");
//		OutputStream output = new FileOutputStream(pathOutPut + "/" + "Test2.xlsx", false);
//		ryokinKeisanShikiService.makeRyokinKeisanExcel(kanriCode, output);
//	}


//	@Test
//	@DisplayName("ログイン職員に対して権限が付与されているM_管理のStringCodeNamePariリストを返却します.")
//	@TestInitDataFile("TestMakeRyokinKeisanExcelInit.xlsx")
//	public void TestRegisterRyokinKeisan() throws Exception{
//		String loginId = "1";
//		ryokinKeisanShikiService.registerRyokinKeisan(fileUpload, loginId);
//	}

	@Test
	@DisplayName("ログイン職員に対して権限が付与されているM_管理のStringCodeNamePariリストを返却します.")
	@TestInitDataFile("TestGetKanriByShokuinKengenInit.xlsx")
	public void TestGetKanriByShokuinKengen() throws Exception{
		List<Short> kanriCodes = new ArrayList<>();
		kanriCodes.add((short)10);
		List<StringCodeNamePair> ret = ryokinKeisanShikiService.getKanriByShokuinKengen(kanriCodes);
		exportJsonData(ret, "TestGetKanriByShokuinKengen.json");
	}

}
