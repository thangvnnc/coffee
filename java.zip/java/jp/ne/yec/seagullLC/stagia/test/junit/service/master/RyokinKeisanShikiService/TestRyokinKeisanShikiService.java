package jp.ne.yec.seagullLC.stagia.test.junit.service.master.RyokinKeisanShikiService;

import static org.junit.Assert.*;

import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.beans.StringCodeNamePair;
import jp.ne.yec.seagullLC.stagia.service.master.RyokinKeisanShikiService;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestRyokinKeisanShikiService extends JunitBase{

	@Autowired
	RyokinKeisanShikiService ryokinKeisanShikiService;


	@Test
	@DisplayName("")
	public void makeRyokinKeisanExcel() throws Exception{
		List<StringCodeNamePair> kanriDropDowns = new ArrayList<>();
		OutputStream output = new ByteArrayOutputStream();
		//StringCodeNamePair kanriDropDown, OutputStream output kanriDropDown, OutputStream output
		ryokinKeisanShikiService.makeRyokinKeisanExcel(kanriDropDowns.get(0), output);
	}

	@Test
	@DisplayName("ログイン職員に対して権限が付与されているM_管理のStringCodeNamePariリストを返却します.")
	public void TestGetBashoMap() throws Exception{
		List<Short> kanriCodes = new ArrayList<>();
		List<StringCodeNamePair> list = ryokinKeisanShikiService.getKanriByShokuinKengen(kanriCodes);
		assertEquals(2, list.size());
		exportJsonData(list, "TestgetMKashidashiTani_map.json");
	}

}
