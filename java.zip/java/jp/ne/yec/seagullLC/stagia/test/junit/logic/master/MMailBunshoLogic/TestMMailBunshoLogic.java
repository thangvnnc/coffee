package jp.ne.yec.seagullLC.stagia.test.junit.logic.master.MMailBunshoLogic;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.entity.MMailBunsho;
import jp.ne.yec.seagullLC.stagia.logic.master.MMailBunshoLogic;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestMMailBunshoLogic extends JunitBase {

	@Autowired
	MMailBunshoLogic mMailBunshoLogic;

	@Test
	@DisplayName("引数なしでM_料金体系を取得します.")
	//@TestInitDataFile("TestRiyoshaServiceInit.xlsx")
	public void TestGetDAO() throws Exception {
		GenericDao<MMailBunsho, ?> ret = mMailBunshoLogic.getDao();
		//assertEquals(mRyokinTaikeiDao, ret);
	}
}
