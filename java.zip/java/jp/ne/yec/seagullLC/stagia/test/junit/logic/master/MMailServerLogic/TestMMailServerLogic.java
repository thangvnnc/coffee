package jp.ne.yec.seagullLC.stagia.test.junit.logic.master.MMailServerLogic;

import static org.junit.Assert.*;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.entity.MMailServer;
import jp.ne.yec.seagullLC.stagia.logic.master.MMailServerLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestMMailServerLogic extends JunitBase {

	@Autowired
	MMailServerLogic mMailServerLogic;

	@Test
	@DisplayName("引数なしでM_料金体系を取得します.")
	@TestInitDataFile("TestinsertMMailServer.xlsx")
	public void TestGetMMailServer() throws Exception {
		MMailServer ret = mMailServerLogic.getMMailServer();
		exportJsonData(ret, "TestGetMMailServer.json");
	}

	@Test
	@DisplayName("引数なしでM_料金体系を取得します.")
	@TestInitDataFile("TestinsertMMailServer.xlsx")
	public void TestinsertMMailServer() throws Exception {
		MMailServer mMailServer = new MMailServer();
		mMailServer.setHostName("host name");
		mMailServer.setPassword("123456");
		mMailServer.setUserName("thuan");
		mMailServer.setVersion(5);
		mMailServer.setCreatedBy("3333");
		mMailServer.setUpdatedBy("4444");

		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/M/d HH:mm");
		Date dateCreate = new Date();
		dateCreate = dateFormat.parse("2018/6/27 14:04");
		long timeCreate = dateCreate.getTime();
		Timestamp tCreate = new Timestamp(timeCreate);

		mMailServer.setCreatedAt(tCreate);

		Date dateUpdate = new Date();
		dateUpdate = dateFormat.parse("2018/6/27 14:04");
		long timeUpdate= dateUpdate.getTime();
		Timestamp tUpdate = new Timestamp(timeUpdate);
		mMailServer.setUpdatedAt(tUpdate);
		String updatedBy = "4444";
		mMailServerLogic.insertMMailServer(mMailServer , updatedBy);
	}

	@Test
	@DisplayName("引数なしでM_料金体系を取得します.")
	@TestInitDataFile("TestinsertMMailServer.xlsx")
	public void TestupdateMMailServer() throws Exception {
		MMailServer mMailServer = new MMailServer();
		mMailServer.setHostName("host name");
		mMailServer.setPassword("123456");
		mMailServer.setUserName("thuan");
		mMailServer.setVersion(5);
		mMailServer.setCreatedBy("3333");
		mMailServer.setUpdatedBy("4444");

		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/M/d HH:mm");
		Date dateCreate = new Date();
		dateCreate = dateFormat.parse("2018/6/27 14:04");
		long timeCreate = dateCreate.getTime();
		Timestamp tCreate = new Timestamp(timeCreate);

		mMailServer.setCreatedAt(tCreate);

		Date dateUpdate = new Date();
		dateUpdate = dateFormat.parse("2018/6/27 14:04");
		long timeUpdate= dateUpdate.getTime();
		Timestamp tUpdate = new Timestamp(timeUpdate);
		mMailServer.setUpdatedAt(tUpdate);
		String updatedBy = "4444";

		mMailServerLogic.updateMMailServer(mMailServer, updatedBy);

	}

	@Test
	@DisplayName("引数なしでM_料金体系を取得します.")
	@TestInitDataFile("TestinsertMMailServer2.xlsx")
	public void TestupdateMMailServer2() throws Exception {
		MMailServer mMailServer = new MMailServer();
		mMailServer.setHostName("host name");
		mMailServer.setPassword("123456");
		mMailServer.setUserName("thuan");
		mMailServer.setVersion(1);
		mMailServer.setCreatedBy("3333");
		mMailServer.setUpdatedBy("4444");

		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/M/d HH:mm");
		Date dateCreate = new Date();
		dateCreate = dateFormat.parse("2018/6/27 14:04");
		long timeCreate = dateCreate.getTime();
		Timestamp tCreate = new Timestamp(timeCreate);

		mMailServer.setCreatedAt(tCreate);

		Date dateUpdate = new Date();
		dateUpdate = dateFormat.parse("2018/6/27 14:04");
		long timeUpdate= dateUpdate.getTime();
		Timestamp tUpdate = new Timestamp(timeUpdate);
		mMailServer.setUpdatedAt(tUpdate);
		String updatedBy = "222";

		try
		{
			mMailServerLogic.updateMMailServer(mMailServer, updatedBy);
		}
		catch (Exception e) {
			
			String messageExp = "m_mail_server Optimistic lock error";
			assertEquals(messageExp, e.getMessage());
		}

	}


	@Test
	@DisplayName("引数なしでM_料金体系を取得します.")
	@TestInitDataFile("TestinsertMMailServer.xlsx")
	public void TestdeleteMMailServer() throws Exception {
		mMailServerLogic.deleteMMailServer();
	}
	@Test
	@DisplayName("引数なしでM_料金体系を取得します.")
	//@TestInitDataFile("TestRiyoshaServiceInit.xlsx")
	public void TestGetDAO() throws Exception {
		GenericDao<MMailServer, ?> ret = mMailServerLogic.getDao();
	}


}
