package jp.ne.yec.seagullLC.stagia.test.junit.service.shinsei.ShinseiKakuninService;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.seagullLC.stagia.service.shinsei.ShinseiKakuninService;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestShinseiKakuninService extends JunitBase{
	@Autowired
	ShinseiKakuninService shinseiKakuninService;

	@Test
	@DisplayName("引数の管理コード、申請番号よりDBに登録されている最大の明細番号を取得します.")
	public void TestGetMaxMeisaiNumber() throws Exception{
		List<Short> listKanriCode = readArrShort("TestGetMaxMeisaiNumber_kanriCode.txt");
		List<Integer> listShinseiNumber = readArrInteger("TestGetMaxMeisaiNumber_shinseiNumber.txt");
		for (int idx = 0; idx < listKanriCode.size(); idx++)
		{
			int maxMeisaiNumber = shinseiKakuninService.getMaxMeisaiNumber(
					listKanriCode.get(idx),
					listShinseiNumber.get(idx)
					);
			assertEquals(4, maxMeisaiNumber);
		}
	}

}
