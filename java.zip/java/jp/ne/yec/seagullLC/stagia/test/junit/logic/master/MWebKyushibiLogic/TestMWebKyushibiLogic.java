package jp.ne.yec.seagullLC.stagia.test.junit.logic.master.MWebKyushibiLogic;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.entity.MWebKyushibi;
import jp.ne.yec.seagullLC.stagia.logic.master.MWebKyushibiLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestMWebKyushibiLogic extends JunitBase {


	@Autowired
	MWebKyushibiLogic mWebKyushibiLogic;

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	//@TestInitDataFile("TestgetMBashoList.xlsx")
	public void TestgetDao() throws Exception
	{
		GenericDao<MWebKyushibi, ?> ret = mWebKyushibiLogic.getDao();
	}
	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestgetMWebKyushibi.xlsx")
	public void TestgetMWebKyushibi() throws Exception
	{
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("M/d/yyyy");
		String date = "6/26/2018";
        LocalDate localDate = LocalDate.parse(date, formatter);
		MWebKyushibi ret =  mWebKyushibiLogic.getMWebKyushibi(localDate);
		exportJsonData(ret, "TestgetMWebKyushibi.json");
	}

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestgetMWebKyushibi.xlsx")
	public void TestgetMWebKyushibiList() throws Exception
	{
		List<MWebKyushibi> ret = mWebKyushibiLogic.getMWebKyushibiList();
		exportJsonData(ret, "TestgetMWebKyushibiList.json");
	}
	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestgetMWebKyushibi.xlsx")
	public void TestinsertMWebKyushibi() throws Exception
	{
		String updatedBy = "ta";
		List<MWebKyushibi> list = new ArrayList<>();
		MWebKyushibi mWebKyushibi = new MWebKyushibi();
		SimpleDateFormat formatter = new SimpleDateFormat("M/d/yyyy");
        Date kyushiDate = new Date();
        kyushiDate = formatter.parse("6/30/2018");
        
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/M/d HH:mm");
		Date dateCreate = new Date();
		dateCreate = dateFormat.parse("2018/6/15 14:15");
		long timeCreate = dateCreate.getTime();
		Timestamp tCreate = new Timestamp(timeCreate);

		Date dateUpdate = new Date();
		dateUpdate = dateFormat.parse("2018/6/15 15:38");
		long timeUpdate= dateUpdate.getTime();
		Timestamp tUpdate = new Timestamp(timeUpdate);
        
		mWebKyushibi.setKyushiDate(kyushiDate);
		mWebKyushibi.setCreatedBy("k");
		mWebKyushibi.setUpdatedBy("k");
		mWebKyushibi.setCreatedAt(tCreate);
		mWebKyushibi.setUpdatedAt(tUpdate);
		mWebKyushibi.setVersion(2);
		
		list.add(mWebKyushibi);

		mWebKyushibiLogic.insertMWebKyushibi(list, updatedBy);
	}

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestgetMWebKyushibi.xlsx")
	public void TestdeleteMWebKyushibi() throws Exception
	{
		List<MWebKyushibi> list = new ArrayList<>();
		list.add(new MWebKyushibi());
		mWebKyushibiLogic.deleteMWebKyushibi(list);
	}
}

