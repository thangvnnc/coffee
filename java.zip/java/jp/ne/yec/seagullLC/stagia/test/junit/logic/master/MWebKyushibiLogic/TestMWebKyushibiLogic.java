package jp.ne.yec.seagullLC.stagia.test.junit.logic.master.MWebKyushibiLogic;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.entity.MWebKyushibi;
import jp.ne.yec.seagullLC.stagia.logic.master.MWebKyushibiLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestMWebKyushibiLogic extends JunitBase {


	@Autowired
	MWebKyushibiLogic mWebKyushibiLogic;

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	//@TestInitDataFile("TestgetMBashoList.xlsx")
	public void TestgetDao() throws Exception
	{
		GenericDao<MWebKyushibi, ?> ret = mWebKyushibiLogic.getDao();
	}
	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestgetMWebKyushibi.xlsx")
	public void TestgetMWebKyushibi() throws Exception
	{
		List<LocalDate> dates = new ArrayList<>();
		dates.add(LocalDate.now());

		List<MWebKyushibi> exports = new ArrayList<>();
		for(int item = 0; item < dates.size(); item ++)
		{
			MWebKyushibi ret =  mWebKyushibiLogic.getMWebKyushibi(dates.get(item));
			exports.add(ret);
		}
		exportJsonData(exports, "TestgetMWebKyushibi.json");
	}

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestgetMWebKyushibi.xlsx")
	public void TestgetMWebKyushibiList() throws Exception
	{
		List<List<MWebKyushibi> > exports = new ArrayList<>();
		List<MWebKyushibi> ret = mWebKyushibiLogic.getMWebKyushibiList();
		exports.add(ret);
		exportJsonData(exports, "TestgetMWebKyushibiList.json");
	}
	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	//@TestInitDataFile("TestgetMBashoList.xlsx")
	public void TestinsertMWebKyushibi() throws Exception
	{
		List<String> updatedBys = new ArrayList<>();
		updatedBys.add("tsest");

		List<List<MWebKyushibi>> params = new ArrayList<List<MWebKyushibi>>();
		List<MWebKyushibi> list = new ArrayList<>();
		list.add(new MWebKyushibi());
		params.add(list);

		for (int item = 0; item < params.size(); item++)
		{
			mWebKyushibiLogic.insertMWebKyushibi(params.get(item),updatedBys.get(item));
		}
	}

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestgetMWebKyushibi.xlsx")
	public void TestdeleteMWebKyushibi() throws Exception
	{
		List<List<MWebKyushibi>> params = new ArrayList<List<MWebKyushibi>>();
		List<MWebKyushibi> list = new ArrayList<>();
		list.add(new MWebKyushibi());
		params.add(list);
		for (int item = 0; item < params.size(); item++)
		{
			mWebKyushibiLogic.deleteMWebKyushibi(params.get(item));
		}
	}
}

