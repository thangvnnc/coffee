package jp.ne.yec.seagullLC.stagia.test.junit.logic.master.MShokuinKengenLogic;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.beans.shokai.ShokuinDto;
import jp.ne.yec.seagullLC.stagia.entity.MKanri;
import jp.ne.yec.seagullLC.stagia.entity.MShokuinKengen;
import jp.ne.yec.seagullLC.stagia.logic.master.MShokuinKengenLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestMShokuinKengenLogic extends JunitBase {

	@Autowired
	MShokuinKengenLogic mShokuinKengenLogic;

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetShokuinkengen.xlsx")
	public void TestgetShokuinkengen() throws Exception
	{
		String loginId = "0_test";
		List<MShokuinKengen> ret = mShokuinKengenLogic.getShokuinkengen(loginId);
		exportJsonData(ret, "TestgetShokuinkengen.json");
	}

	@Test
	@DisplayName("検索条件なしで場所マスタを取得し、返却します")
	@TestInitDataFile("TestgetShokuinkengen.xlsx")
	public void TestInsertMShokuinKengen() throws Exception
	{
		Map<Short, MKanri> mMapMKanri = new HashMap<>();
		MKanri mKanri = new MKanri();
		mKanri.setKanriCode((short)12);
		mMapMKanri.put((short) 12, mKanri);

		ShokuinDto shokuinDto = new ShokuinDto();
		shokuinDto.setLoginId("abc");
		String updatedBys = "test";
	
		mShokuinKengenLogic.insertMShokuinKengen(mMapMKanri, shokuinDto, updatedBys);
	}
	
	@Test
	@DisplayName("検索条件なしで場所マスタを取得し、返却します")
	@TestInitDataFile("TestgetShokuinkengen.xlsx")
	public void TestInsertMShokuinKengen2() throws Exception
	{
		Map<Short, MKanri> mMapMKanri = new HashMap<>();
		MKanri mKanri = new MKanri();
		mKanri.setKanriCode((short)12);
		mMapMKanri.put((short) 12, mKanri);

		ShokuinDto shokuinDto = new ShokuinDto();
		shokuinDto.setLoginId("abc");
		List<MKanri> listKanri = new ArrayList<>();
		listKanri.add(mKanri);
		shokuinDto.setKanriCodeCK(listKanri);
		String updatedBys = "test";
	
		mShokuinKengenLogic.insertMShokuinKengen(mMapMKanri, shokuinDto, updatedBys);
	}

	@Test
	@DisplayName("検索条件なしで場所マスタを取得し、返却します")
	@TestInitDataFile("TestgetShokuinkengen.xlsx")
	public void TestUpdateMShokuinKengen() throws Exception
	{
		Map<Short, MKanri> mMapMKanri = new HashMap<>();
		MKanri mKanri = new MKanri();
		mKanri.setKanriCode((short)12);
		mMapMKanri.put((short) 12, mKanri);

		ShokuinDto shokuinDto = new ShokuinDto();
		shokuinDto.setLoginId("0");
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/M/d HH:mm");
		Date dateCreate = new Date();
		dateCreate = dateFormat.parse("2018/6/5 14:03");
		long timeCreate = dateCreate.getTime();
		Timestamp tCreate = new Timestamp(timeCreate);

		Date dateUpdate = new Date();
		dateUpdate = dateFormat.parse("2018/6/5 14:03");
		long timeUpdate= dateUpdate.getTime();
		Timestamp tUpdate = new Timestamp(timeUpdate);
		
		List<MShokuinKengen> mShokuinKengenList = new ArrayList<>();
		MShokuinKengen mSho = new MShokuinKengen();
		mSho.setKanriCode((short)12);
		mSho.setLoginId("ads");
		
		mShokuinKengenList.add(mSho);
		
		shokuinDto.setMShokuinKengenList(mShokuinKengenList);
		List<MKanri> listKanri = new ArrayList<>();
		MKanri mKanri2 = new MKanri();
		mKanri2.setKanriCode((short)10);
		listKanri.add(mKanri2);
		shokuinDto.setKanriCodeCK(listKanri);
		shokuinDto.setVersion(1);
		shokuinDto.setDeleted(false);
		shokuinDto.setPassword("123");
		shokuinDto.setCreatedAt(tCreate);
		shokuinDto.setCreatedBy("k");
		shokuinDto.setUpdatedAt(tUpdate);
		shokuinDto.setUpdatedBy("k");
		
		String updatedBys = "test";
		
		mShokuinKengenLogic.updateMShokuinKengen(mMapMKanri, shokuinDto, updatedBys);
	}
	
	@Test
	@DisplayName("検索条件なしで場所マスタを取得し、返却します")
	@TestInitDataFile("TestgetShokuinkengen.xlsx")
	public void TestUpdateMShokuinKengen2() throws Exception
	{
		Map<Short, MKanri> mMapMKanri = new HashMap<>();
		MKanri mKanri = new MKanri();
		mKanri.setKanriCode((short)10);
		mMapMKanri.put((short) 10, mKanri);

		ShokuinDto shokuinDto = new ShokuinDto();
		shokuinDto.setLoginId("0");
		
		List<MShokuinKengen> mShokuinKengenList = new ArrayList<>();
		MShokuinKengen mSho = new MShokuinKengen();
		mSho.setKanriCode((short)10);
		mSho.setVersion(1);
		
		mShokuinKengenList.add(mSho);
		
		shokuinDto.setMShokuinKengenList(mShokuinKengenList);
		List<MKanri> listKanri = new ArrayList<>();
		listKanri.add(mKanri);
		shokuinDto.setKanriCodeCK(listKanri);
		shokuinDto.setVersion(1);
		
		String updatedBys = "test";
		
		mShokuinKengenLogic.updateMShokuinKengen(mMapMKanri, shokuinDto, updatedBys);
	}
	
	@Test
	@DisplayName("検索条件なしで場所マスタを取得し、返却します")
	@TestInitDataFile("TestgetShokuinkengen.xlsx")
	public void TestUpdateMShokuinKengen3() throws Exception
	{
		Map<Short, MKanri> mMapMKanri = new HashMap<>();
		MKanri mKanri = new MKanri();
		mKanri.setKanriCode((short)10);
		mMapMKanri.put((short) 10, mKanri);

		ShokuinDto shokuinDto = new ShokuinDto();
		shokuinDto.setLoginId("0_test");
		
		List<MShokuinKengen> mShokuinKengenList = new ArrayList<>();
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/M/d HH:mm");
		Date dateCreate = new Date();
		dateCreate = dateFormat.parse("2018/6/5 14:03");
		long timeCreate = dateCreate.getTime();
		Timestamp tCreate = new Timestamp(timeCreate);

		Date dateUpdate = new Date();
		dateUpdate = dateFormat.parse("2018/6/5 14:03");
		long timeUpdate= dateUpdate.getTime();
		Timestamp tUpdate = new Timestamp(timeUpdate);
		
		MShokuinKengen mSho = new MShokuinKengen();
		mSho.setKanriCode((short)10);
		mSho.setVersion(1);
		mSho.setAllowedUpdate(false);
		mSho.setLoginId("0_test");
		mSho.setUpdatedAt(tUpdate);
		mSho.setUpdatedBy("0-3333");
		mSho.setCreatedAt(tCreate);
		mSho.setCreatedBy("0-3333");
		mShokuinKengenList.add(mSho);
		
		shokuinDto.setMShokuinKengenList(mShokuinKengenList);
		List<MKanri> listKanri = new ArrayList<>();
		listKanri.add(mKanri);
		shokuinDto.setKanriCodeCK(listKanri);
		shokuinDto.setVersion(1);
		shokuinDto.setDeleted(false);
		
		String updatedBys = "test";
		
		mShokuinKengenLogic.updateMShokuinKengen(mMapMKanri, shokuinDto, updatedBys);
	}
	

	
	@Test
	@DisplayName("検索条件なしで場所マスタを取得し、返却します")
	//@TestInitDataFile("TestgetShokuinkengen.xlsx")
	public void TestgetDao() throws Exception
	{
		GenericDao<MShokuinKengen, ?> ret = mShokuinKengenLogic.getDao();
	}
}