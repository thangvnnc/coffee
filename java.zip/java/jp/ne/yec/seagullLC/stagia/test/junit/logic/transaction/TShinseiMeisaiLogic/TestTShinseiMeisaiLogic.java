package jp.ne.yec.seagullLC.stagia.test.junit.logic.transaction.TShinseiMeisaiLogic;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.beans.StringCodeNamePair;
import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.beans.enums.AriNashi;
import jp.ne.yec.seagullLC.stagia.beans.enums.JokenHukumu;
import jp.ne.yec.seagullLC.stagia.beans.enums.domain.ChusenKekka;
import jp.ne.yec.seagullLC.stagia.beans.enums.domain.MeisaiJotai;
import jp.ne.yec.seagullLC.stagia.beans.enums.domain.ShinseiShurui;
import jp.ne.yec.seagullLC.stagia.beans.enums.domain.TosenShinseiJotai;
import jp.ne.yec.seagullLC.stagia.beans.shokai.SearchConditionsDto;
import jp.ne.yec.seagullLC.stagia.entity.MKanri;
import jp.ne.yec.seagullLC.stagia.entity.TShinseiMeisai;
import jp.ne.yec.seagullLC.stagia.logic.transaction.TShinseiMeisaiLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = { "classpath:TestApplicationContext.xml" })
@WebAppConfiguration
public class TestTShinseiMeisaiLogic extends JunitBase {

	@Autowired
	TShinseiMeisaiLogic tShinseiMeisaiLogic;

//	@Test
//	@DisplayName("引数の条件を基に住民機能の申請一覧画面に表示するための情報をT申請明細より取得し返却します. 返却リストは管理コード、申請番号、明細番号の昇順となります.")
//	@TestInitDataFile("TestGetShinseiIchiranDtoByLoginIdInit.xlsx")
//	public void TestGetShinseiIchiranDtoByLoginId() throws Exception {
//		String loginId = "1";
//		List<ShinseiIchiranDto> ret = tShinseiMeisaiLogic.getShinseiIchiranDtoByLoginId(loginId);
//		exportJsonData(ret, "TestGetShinseiIchiranDtoByLoginId.json");
//	}
//
//	@Test
//	@DisplayName("引数の条件に合致するT_申請明細を返却します")
//	@TestInitDataFile("TestGetTShinseiMeisaiInit.xlsx")
//	public void TestGetTShinseiMeisai() throws Exception {
//		short kanriCode = 10;
//		int shinseiNumber = 444;;
//		List<TShinseiMeisai> ret = tShinseiMeisaiLogic.getTShinseiMeisai(kanriCode, shinseiNumber);
//		exportJsonData(ret, "TestGetTShinseiMeisai.json");
//	}
//
//	@Test
//	@DisplayName("引数の条件に合致する取消されていないT_申請明細を返却します.")
//	@TestInitDataFile("TestGetValidTShinseiMeisaiInit.xlsx")
//	public void TestGetValidTShinseiMeisai() throws Exception {
//		short kanriCode = 10;
//		int shinseiNumber = 444;
//		List<TShinseiMeisai> ret = tShinseiMeisaiLogic.getValidTShinseiMeisai(kanriCode, shinseiNumber);
//		exportJsonData(ret, "TestGetValidTShinseiMeisai.json");
//	}
//
//
//	@Test
//	@DisplayName("引数の条件に合致する取消されていない仮予約のT_申請明細を返却します.")
//	@TestInitDataFile("TestGetTShinseiMeisaiList3praInit.xlsx")
//	public void TestGetTShinseiMeisaiList3pra() throws Exception {
//		String loginId = "1";
//		short kanriCode = 10;
//		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/M/d");
//		Date shiyoDateFrom = new Date();
//		shiyoDateFrom = formatter.parse("2017/5/14");
//		Date shiyoDateTo = new Date();
//		shiyoDateTo = formatter.parse("2017/5/17");
//
//		List<TShinseiMeisai> ret = tShinseiMeisaiLogic.getTShinseiMeisaiList(loginId, kanriCode,
//				shiyoDateFrom, shiyoDateTo);
//		exportJsonData(ret, "TestGetTShinseiMeisaiList3pra.json");
//	}
//
//	@Test
//	@DisplayName("引数の条件に合致する取消されていない仮予約のT_申請明細を返却します.")
//	@TestInitDataFile("TestGetTShinseiMeisaiList3pra_2Init.xlsx")
//	public void TestGetTShinseiMeisaiList3pra_2() throws Exception {
//		List<MShisetsu> mShisetsus = new ArrayList<>();
//		MShisetsu mShi = new MShisetsu();
//		mShi.setKanriCode((short)10);
//		mShi.setShisetsuCode((short)444);
//		mShisetsus.add(mShi);
//		Date fromDate = new Date();
//		Date toDate = new Date();
//
//		SimpleDateFormat sd = new SimpleDateFormat("yyyy/M/d");
//		fromDate = sd.parse("2018/4/19");
//		toDate = sd.parse("2018/4/19");
//
//		List<TShinseiMeisai> ret = tShinseiMeisaiLogic.getTShinseiMeisaiList(mShisetsus, fromDate,
//				toDate);
//		exportJsonData(ret, "TestGetTShinseiMeisaiList3pra_2.json");
//	}
//
//	@Test
//	@DisplayName("引数の条件に合致する取消されていない本予約のT_申請明細を返却します.（使用実績入力で使用）")
//	@TestInitDataFile("TestGetTShinseiMeisaiList10praInit.xlsx")
//	public void TestGetTShinseiMeisaiList10pra_1() throws Exception {
//		int shinseiBangoFrom = 10;
//
//		int shinseiBangoTo = 10;
//
//		short kanriCode = 10;
//
//		short bashoCode = 90;
//
//		short shisetsuCode = 10;
//
//		boolean shiyojissekiUmuFlg = true;
//
//		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/M/d");
//		Date shiyoDateFrom = new Date();
//		shiyoDateFrom = formatter.parse("2017/5/15");
//
//		Date shiyoDateTo = new Date();
//		shiyoDateTo = formatter.parse("2017/5/17");
//
//		Date uketukebiFrom = new Date();
//		uketukebiFrom = formatter.parse("2016/9/12");
//
//		Date uketukebiTo = new Date();
//		uketukebiTo = formatter.parse("2016/9/14");
//
//		List<ShinseiMeisaiDtoForMadoguchi> ret = tShinseiMeisaiLogic.getTShinseiMeisaiList(
//				shinseiBangoFrom,
//				shinseiBangoTo,
//				kanriCode,
//				bashoCode,
//				shisetsuCode,
//				shiyoDateFrom,
//				shiyoDateTo,
//				uketukebiFrom,
//				uketukebiTo,
//				shiyojissekiUmuFlg
//				);
//		exportJsonData(ret, "TestGetTShinseiMeisaiList10pra_1.json");
//	}
//
//	@Test
//	@DisplayName("引数の条件に合致する取消されていない本予約のT_申請明細を返却します.（使用実績入力で使用）")
//	@TestInitDataFile("TestGetTShinseiMeisaiList10praInit.xlsx")
//	public void TestGetTShinseiMeisaiList10pra_2() throws Exception {
//		int shinseiBangoFrom = 9;
//
//		Integer shinseiBangoTo = null;
//
//		short kanriCode = 10;
//
//		short bashoCode = 90;
//
//		short shisetsuCode = 10;
//
//		Boolean shiyojissekiUmuFlg = null;
//
//		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/M/d");
//		Date shiyoDateFrom = new Date();
//		shiyoDateFrom = formatter.parse("2017/5/15");
//
//		Date shiyoDateTo = null;
//
//		Date uketukebiFrom = new Date();
//		uketukebiFrom = formatter.parse("2016/9/12");
//
//		Date uketukebiTo = null;
//
//		List<ShinseiMeisaiDtoForMadoguchi> ret = tShinseiMeisaiLogic.getTShinseiMeisaiList(
//				shinseiBangoFrom,
//				shinseiBangoTo,
//				kanriCode,
//				bashoCode,
//				shisetsuCode,
//				shiyoDateFrom,
//				shiyoDateTo,
//				uketukebiFrom,
//				uketukebiTo,
//				shiyojissekiUmuFlg
//				);
//		exportJsonData(ret, "TestGetTShinseiMeisaiList10pra_2.json");
//	}
//
//	@Test
//	@DisplayName("引数の条件に合致する取消されていない本予約のT_申請明細を返却します.（使用実績入力で使用）")
//	@TestInitDataFile("TestGetTShinseiMeisaiList10praInit.xlsx")
//	public void TestGetTShinseiMeisaiList10pra_3() throws Exception {
//		Integer shinseiBangoFrom = null;
//
//		Integer shinseiBangoTo = 11;
//
//		short kanriCode = 10;
//
//		short bashoCode = 90;
//
//		short shisetsuCode = 10;
//
//		Boolean shiyojissekiUmuFlg = null;
//
//		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/M/d");
//		Date shiyoDateFrom = null;
//
//		Date shiyoDateTo = new Date();
//		shiyoDateTo = formatter.parse("2017/5/17");
//
//		Date uketukebiFrom = null;
//
//		Date uketukebiTo = new Date();
//		uketukebiTo = formatter.parse("2016/9/14");
//
//		List<ShinseiMeisaiDtoForMadoguchi> ret = tShinseiMeisaiLogic.getTShinseiMeisaiList(
//				shinseiBangoFrom,
//				shinseiBangoTo,
//				kanriCode,
//				bashoCode,
//				shisetsuCode,
//				shiyoDateFrom,
//				shiyoDateTo,
//				uketukebiFrom,
//				uketukebiTo,
//				shiyojissekiUmuFlg
//				);
//		exportJsonData(ret, "TestGetTShinseiMeisaiList10pra_3.json");
//	}
//
//	@Test
//	@DisplayName("引数の条件に合致する取消されていない本予約のT_申請明細を返却します.（使用実績入力で使用）")
//	@TestInitDataFile("TestGetTShinseiMeisaiList10praInit.xlsx")
//	public void TestGetTShinseiMeisaiList10pra_4() throws Exception {
//		Integer shinseiBangoFrom = null;
//
//		Integer shinseiBangoTo = null;
//
//		Short kanriCode = null;
//
//		Short bashoCode = null;
//
//		Short shisetsuCode = null;
//
//		Boolean shiyojissekiUmuFlg = null;
//
//		Date shiyoDateFrom = null;
//
//		Date shiyoDateTo = null;
//
//		Date uketukebiFrom = null;
//
//		Date uketukebiTo = null;
//
//		List<ShinseiMeisaiDtoForMadoguchi> ret = tShinseiMeisaiLogic.getTShinseiMeisaiList(
//				shinseiBangoFrom,
//				shinseiBangoTo,
//				kanriCode,
//				bashoCode,
//				shisetsuCode,
//				shiyoDateFrom,
//				shiyoDateTo,
//				uketukebiFrom,
//				uketukebiTo,
//				shiyojissekiUmuFlg
//				);
//		exportJsonData(ret, "TestGetTShinseiMeisaiList10pra_4.json");
//	}
//
//	@Test
//	@DisplayName("引数の条件に合致する取消されていない本予約のT_申請明細を返却します.（審査入力で使用）")
//	@TestInitDataFile("TestGetTShinseiMeisaiList11praInit.xlsx")
//	public void TestGetTShinseiMeisaiList11pra_1() throws Exception {
//		Integer shinseiBangoFrom = 10;
//
//		Integer shinseiBangoTo = 10;
//
//		Short kanriCode = 10;
//
//		Short bashoCode = 90;
//
//		Short shisetsuCode = 10;
//
//		List<String> shinsaKubunCode = new ArrayList<>();
//		shinsaKubunCode.add("1");
//
//		List<Short> riyoshaGroupCodeList = new ArrayList<>();
//		riyoshaGroupCodeList.add((short)1);
//
//		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/M/d");
//		Date shiyoDateFrom = new Date();
//		shiyoDateFrom = formatter.parse("2017/5/15");
//
//		Date shiyoDateTo = new Date();
//		shiyoDateTo = formatter.parse("2017/5/17");
//
//		Date uketukebiFrom = new Date();
//		uketukebiFrom = formatter.parse("2016/9/12");
//
//		Date uketukebiTo = new Date();
//		uketukebiTo = formatter.parse("2016/9/14");
//
//		List<ShinseiMeisaiDtoForMadoguchi> ret = tShinseiMeisaiLogic.getTShinseiMeisaiList(
//				shinseiBangoFrom,
//				shinseiBangoTo,
//				kanriCode,
//				bashoCode,
//				shisetsuCode,
//				shiyoDateFrom,
//				shiyoDateTo,
//				uketukebiFrom,
//				uketukebiTo,
//				shinsaKubunCode,
//				riyoshaGroupCodeList
//				);
//		exportJsonData(ret, "TestGetTShinseiMeisaiList11pra_1.json");
//	}
//
//	@Test
//	@DisplayName("引数の条件に合致する取消されていない本予約のT_申請明細を返却します.（審査入力で使用）")
//	@TestInitDataFile("TestGetTShinseiMeisaiList11praInit.xlsx")
//	public void TestGetTShinseiMeisaiList11pra_2() throws Exception {
//		Integer shinseiBangoFrom = 10;
//
//		Integer shinseiBangoTo = null;
//
//		Short kanriCode = 10;
//
//		Short bashoCode = 90;
//
//		Short shisetsuCode = 10;
//
//		List<String> shinsaKubunCode = new ArrayList<>();
//
//		List<Short> riyoshaGroupCodeList = new ArrayList<>();
//
//		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/M/d");
//		Date shiyoDateFrom = null;
//
//		Date shiyoDateTo = new Date();
//		shiyoDateTo = formatter.parse("2017/5/17");
//
//		Date uketukebiFrom = null;
//
//		Date uketukebiTo = new Date();
//		uketukebiTo = formatter.parse("2016/9/14");
//
//		List<ShinseiMeisaiDtoForMadoguchi> ret = tShinseiMeisaiLogic.getTShinseiMeisaiList(
//				shinseiBangoFrom,
//				shinseiBangoTo,
//				kanriCode,
//				bashoCode,
//				shisetsuCode,
//				shiyoDateFrom,
//				shiyoDateTo,
//				uketukebiFrom,
//				uketukebiTo,
//				shinsaKubunCode,
//				riyoshaGroupCodeList
//				);
//		exportJsonData(ret, "TestGetTShinseiMeisaiList11pra_2.json");
//	}
//
//	@Test
//	@DisplayName("引数の条件に合致する取消されていない本予約のT_申請明細を返却します.（審査入力で使用）")
//	@TestInitDataFile("TestGetTShinseiMeisaiList11praInit.xlsx")
//	public void TestGetTShinseiMeisaiList11pra_3() throws Exception {
//		Integer shinseiBangoFrom = null;
//
//		Integer shinseiBangoTo = 11;
//
//		Short kanriCode = 10;
//
//		Short bashoCode = 90;
//
//		Short shisetsuCode = 10;
//
//		List<String> shinsaKubunCode = new ArrayList<>();
//
//		List<Short> riyoshaGroupCodeList = new ArrayList<>();
//
//		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/M/d");
//		Date shiyoDateFrom = new Date();
//		shiyoDateFrom = formatter.parse("2017/5/15");
//
//		Date shiyoDateTo = null;
//
//		Date uketukebiFrom = new Date();
//		uketukebiFrom = formatter.parse("2016/9/12");
//
//		Date uketukebiTo = null;
//
//		List<ShinseiMeisaiDtoForMadoguchi> ret = tShinseiMeisaiLogic.getTShinseiMeisaiList(
//				shinseiBangoFrom,
//				shinseiBangoTo,
//				kanriCode,
//				bashoCode,
//				shisetsuCode,
//				shiyoDateFrom,
//				shiyoDateTo,
//				uketukebiFrom,
//				uketukebiTo,
//				shinsaKubunCode,
//				riyoshaGroupCodeList
//				);
//		exportJsonData(ret, "TestGetTShinseiMeisaiList11pra_3.json");
//	}
//
//	@Test
//	@DisplayName("引数の条件に合致する取消されていない本予約のT_申請明細を返却します.（審査入力で使用）")
//	@TestInitDataFile("TestGetTShinseiMeisaiList11praInit.xlsx")
//	public void TestGetTShinseiMeisaiList11pra_4() throws Exception {
//		Integer shinseiBangoFrom = null;
//
//		Integer shinseiBangoTo = null;
//
//		Short kanriCode = null;
//
//		Short bashoCode = null;
//
//		Short shisetsuCode = null;
//
//		List<String> shinsaKubunCode = new ArrayList<>();
//
//		List<Short> riyoshaGroupCodeList = new ArrayList<>();
//
//		Date shiyoDateFrom = null;
//
//		Date shiyoDateTo = null;
//
//		Date uketukebiFrom = null;
//
//		Date uketukebiTo = null;
//
//		List<ShinseiMeisaiDtoForMadoguchi> ret = tShinseiMeisaiLogic.getTShinseiMeisaiList(
//				shinseiBangoFrom,
//				shinseiBangoTo,
//				kanriCode,
//				bashoCode,
//				shisetsuCode,
//				shiyoDateFrom,
//				shiyoDateTo,
//				uketukebiFrom,
//				uketukebiTo,
//				shinsaKubunCode,
//				riyoshaGroupCodeList
//				);
//		exportJsonData(ret, "TestGetTShinseiMeisaiList11pra_4.json");
//	}
//
//	@Test
//	@DisplayName("引数の条件に合致する取消されていない仮予約のT_申請明細を返却します.")
//	@TestInitDataFile("TestGetTShinseiMeisaiList4praInit.xlsx")
//	public void TestGetTShinseiMeisaiList4pra() throws Exception {
//		String loginId = "1";
//
//		Short kanriCode = 10;
//
//		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/M/d");
//		Date shiyoDateFrom = new Date();
//		shiyoDateFrom = formatter.parse("2017/5/16");
//
//		Date shiyoDateTo = new Date();
//		shiyoDateTo = formatter.parse("2017/5/17");
//
//		List<TShinseiMeisai> ret = tShinseiMeisaiLogic.getTShinseiMeisaiList(
//				loginId,
//				kanriCode,
//				shiyoDateFrom,
//				shiyoDateTo
//				);
//		exportJsonData(ret, "TestGetTShinseiMeisaiList4pra.json");
//	}
//
//	@Test
//	@DisplayName("引数の条件に合致する取消されていない仮予約のT_申請明細を返却します.")
//	@TestInitDataFile("TestGetTosenMeisaiListInit.xlsx")
//	public void TestGetTosenMeisaiList() throws Exception {
//		String loginId = "1";
//		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/M/d");
//		Date shiyoDateFrom = new Date();
//		shiyoDateFrom = formatter.parse("2017/5/16");
//
//		Date shiyoDateTo = new Date();
//		shiyoDateTo = formatter.parse("2017/5/17");
//
//		List<TShinseiMeisai> ret = tShinseiMeisaiLogic.getTosenMeisaiList(
//				loginId,
//				shiyoDateFrom,
//				shiyoDateTo
//				);
//		exportJsonData(ret, "TestGetTosenMeisaiList.json");
//	}
//
//	@Test
//	@DisplayName("引数の条件に合致する取消されていない仮予約のT_申請明細を返却します.")
//	@TestInitDataFile("TestGetDateToDeleteInit.xlsx")
//	public void TestGetDateToDelete() throws Exception {
//		List<TShinsei> expiredlist = new ArrayList<>();
//		TShinsei tShinsei = new TShinsei();
//		tShinsei.setKanriCode((short)10);
//		tShinsei.setShinseiNumber(444);
//		expiredlist.add(tShinsei);
//
//		List<TShinseiMeisai> ret = tShinseiMeisaiLogic.getDateToDelete(expiredlist);
//		exportJsonData(ret, "TestGetDateToDelete.json");
//	}
//
//	@Test
//	@DisplayName("引数の条件に合致する取消されていない仮予約のT_申請明細を返却します.")
//	@TestInitDataFile("TestGetMudanCancelMeisaiInit.xlsx")
//	public void TestGetMudanCancelMeisai() throws Exception {
//		List<TShinseiMeisai> ret = tShinseiMeisaiLogic.getMudanCancelMeisai();
//		exportJsonData(ret, "TestGetMudanCancelMeisai.json");
//	}
//
//	@Test
//	@DisplayName("引数の条件に合致する取消されていない仮予約のT_申請明細を返却します.")
//	@TestInitDataFile("TestGetYoyakuDateListInit.xlsx")
//	public void TestGetYoyakuDateList() throws Exception {
//
//		short bashoCode = 90;
//		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/M/d");
//		Date shiyoDateFrom = new Date();
//		shiyoDateFrom = formatter.parse("2017/5/16");
//
//		Date shiyoDateTo = new Date();
//		shiyoDateTo = formatter.parse("2017/5/17");
//
//		List<LocalDate> ret = tShinseiMeisaiLogic.getYoyakuDateList(bashoCode, shiyoDateFrom, shiyoDateTo);
//		exportJsonData(ret, "TestGetYoyakuDateList.json");
//	}
//
//	@Test
//	@DisplayName("引数の条件に合致する取消されていない仮予約のT_申請明細を返却します.")
//	@TestInitDataFile("TestGetBatchKidoViewDataInit.xlsx")
//	public void TestGetBatchKidoViewData1() throws Exception
//	{
//		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/M/d");
//		Date baseDate = new Date();
//		baseDate = formatter.parse("2017/12/29");
//
//		List<BatchKidoViewDto> ret = tShinseiMeisaiLogic.getBatchKidoViewData(BatchShurui.TOSEN_SAKUJO, baseDate);
//		exportJsonData(ret, "TestGetBatchKidoViewData1.json");
//	}
//
//	@Test
//	@DisplayName("引数の条件に合致する取消されていない仮予約のT_申請明細を返却します.")
//	@TestInitDataFile("TestGetBatchKidoViewDataInit.xlsx")
//	public void TestGetBatchKidoViewData2() throws Exception
//	{
//		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/M/d");
//		Date baseDate = new Date();
//		baseDate = formatter.parse("2017/12/29");
//
//		List<BatchKidoViewDto> ret = tShinseiMeisaiLogic.getBatchKidoViewData(BatchShurui.KARIYOYAKU_SAKUJO, baseDate);
//		exportJsonData(ret, "TestGetBatchKidoViewData2.json");
//	}
//
//	@Test
//	@DisplayName("引数の条件に合致する取消されていない仮予約のT_申請明細を返却します.")
//	@TestInitDataFile("TestGetBatchKidoViewDataInit.xlsx")
//	public void TestGetBatchKidoViewData3() throws Exception
//	{
//		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/M/d");
//		Date baseDate = new Date();
//		baseDate = formatter.parse("2018/4/20");
//
//		List<BatchKidoViewDto> ret = tShinseiMeisaiLogic.getBatchKidoViewData(BatchShurui.MUDAN_CANCEL_KOSHIN, baseDate);
//		exportJsonData(ret, "TestGetBatchKidoViewData3.json");
//	}
//
//	@Test
//	@DisplayName("引数の条件に合致する取消されていない仮予約のT_申請明細を返却します.")
//	@TestInitDataFile("TestGetBatchKidoViewDataInit.xlsx")
//	public void TestGetBatchKidoViewData4() throws Exception
//	{
//		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/M/d");
//		Date baseDate = new Date();
//		baseDate = formatter.parse("2018/4/20");
//
//		List<BatchKidoViewDto> ret = tShinseiMeisaiLogic.getBatchKidoViewData(BatchShurui.CHUSEN_JIKKO, baseDate);
//		exportJsonData(ret, "TestGetBatchKidoViewData4.json");
//	}
//
//	@Test
//	@DisplayName("引数の条件に合致する取消されていない仮予約のT_申請明細を返却します.")
//	@TestInitDataFile("TestGetDoubleBookingChkInfoInit.xlsx")
//	public void TestGetDoubleBookingChkInfo1() throws Exception
//	{
//		ShinseiMeisaiDto meisaiDto = new ShinseiMeisaiDto();
//		meisaiDto.setKanriCode((short)10);
//		//meisaiDto.setShinseiNumber(10);
//		meisaiDto.setBashoCode((short)10);
//		meisaiDto.setStartKoma((short)2);
//		meisaiDto.setEndKoma((short)6);
//		meisaiDto.setShisetsuCode((short)10);
//		meisaiDto.setKashidashiTaniCode((short)0);
//
//		List<MHaitaKashidashiTani> meisaiHaitaTaniList = new ArrayList<>();
//		MHaitaKashidashiTani mHaitaKashidashiTani = new MHaitaKashidashiTani();
//		mHaitaKashidashiTani.setShisetsuCode((short)10);
//		mHaitaKashidashiTani.setKashidashiTaniCode((short)0);
//		meisaiHaitaTaniList.add(mHaitaKashidashiTani);
//		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/M/d");
//		Date shiyoDate = new Date();
//		shiyoDate = formatter.parse("2018/4/19");
//		meisaiDto.setShiyoDate(shiyoDate);
//
//		List<TShinseiMeisai> ret = tShinseiMeisaiLogic.getDoubleBookingChkInfo(meisaiDto, meisaiHaitaTaniList);
//		exportJsonData(ret, "TestGetDoubleBookingChkInfo1.json");
//	}
//
//	@Test
//	@DisplayName("引数の条件に合致する取消されていない仮予約のT_申請明細を返却します.")
//	@TestInitDataFile("TestGetDoubleBookingChkInfoInit.xlsx")
//	public void TestGetDoubleBookingChkInfo2() throws Exception
//	{
//		ShinseiMeisaiDto meisaiDto = new ShinseiMeisaiDto();
//		meisaiDto.setKanriCode((short)10);
//		meisaiDto.setShinseiNumber(0);
//		meisaiDto.setBashoCode((short)10);
//		meisaiDto.setStartKoma((short)2);
//		meisaiDto.setEndKoma((short)6);
//		meisaiDto.setShisetsuCode((short)10);
//		meisaiDto.setKashidashiTaniCode((short)0);
//
//		List<MHaitaKashidashiTani> meisaiHaitaTaniList = new ArrayList<>();
//		MHaitaKashidashiTani mHaitaKashidashiTani = new MHaitaKashidashiTani();
//		mHaitaKashidashiTani.setShisetsuCode((short)10);
//		mHaitaKashidashiTani.setKashidashiTaniCode((short)0);
//		meisaiHaitaTaniList.add(mHaitaKashidashiTani);
//		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/M/d");
//		Date shiyoDate = new Date();
//		shiyoDate = formatter.parse("2018/4/19");
//		meisaiDto.setShiyoDate(shiyoDate);
//
//		List<TShinseiMeisai> ret = tShinseiMeisaiLogic.getDoubleBookingChkInfo(meisaiDto, meisaiHaitaTaniList);
//		exportJsonData(ret, "TestGetDoubleBookingChkInfo2.json");
//	}
//
//	@Test
//	@DisplayName("引数の条件に合致する取消されていない仮予約のT_申請明細を返却します.")
//	@TestInitDataFile("TestGetTosenSakujoListInit.xlsx")
//	public void TestGetTosenSakujoList() throws Exception
//	{
//		List<TShinsei> tosenlist = new ArrayList<>();
//		TShinsei tShinsei = new TShinsei();
//		tShinsei.setKanriCode((short)10);
//		tosenlist.add(tShinsei);
//		List<TShinseiMeisai> ret = tShinseiMeisaiLogic.getTosenSakujoList(tosenlist);
//		exportJsonData(ret, "TestGetTosenSakujoList.json");
//	}
//
//	@Test
//	@DisplayName("引数の条件に合致する取消されていない仮予約のT_申請明細を返却します.")
//	@TestInitDataFile("TestGetDoubleBookingChkInfoForKyukanBashoInit.xlsx")
//	public void TestGetDoubleBookingChkInfoForKyukanBasho() throws Exception
//	{
//		TShisetsuHeisa tShisetsuHeisa = new TShisetsuHeisa();
//		tShisetsuHeisa.setKanriCode((short)10);
//		tShisetsuHeisa.setShisetsuCode((short)10);
//		Date heisaDate = new Date();
//		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/M/d");
//		heisaDate = formatter.parse("2018/4/19");
//		tShisetsuHeisa.setHeisaDate(heisaDate);
//		tShisetsuHeisa.setStartKoma((short)2);
//		tShisetsuHeisa.setEndKoma((short)6);
//
//		List<TShinseiMeisai> ret = tShinseiMeisaiLogic.getDoubleBookingChkInfoForKyukanIkkatsuSettei(tShisetsuHeisa);
//		exportJsonData(ret, "TestGetDoubleBookingChkInfoForKyukanBasho.json");
//	}
//
//	@Test
//	@DisplayName("引数の条件に合致する取消されていない仮予約のT_申請明細を返却します.")
//	@TestInitDataFile("TestGetYoyakuByLoginIdKanriShisetsuShiyoDateInit.xlsx")
//	public void TestGetYoyakuByLoginIdKanriShisetsuShiyoDate() throws Exception
//	{
//		String loginId = "0";
//		Map<Short, List<Short>> kanriShisetsuMap = new HashMap<Short, List<Short>>();
//		Short kanriCode = 10;
//		List<Short> shisetsuCodes = new ArrayList<>();
//		shisetsuCodes.add((short)10);
//		kanriShisetsuMap.put(kanriCode, shisetsuCodes);
//
//		Date from = new Date();
//		Date to = new Date();
//
//		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/M/d");
//
//		from = formatter.parse("2018/4/18");
//		to = formatter.parse("2018/4/20");
//
//		List<TShinseiMeisai> ret = tShinseiMeisaiLogic.getYoyakuByLoginIdKanriShisetsuShiyoDate(loginId, kanriShisetsuMap, from, to);
//		exportJsonData(ret, "TestGetYoyakuByLoginIdKanriShisetsuShiyoDate.json");
//	}
//
//	@Test
//	@DisplayName("引数の条件に合致する取消されていない仮予約のT_申請明細を返却します.")
//	@TestInitDataFile("TestGetTShinseiMeisaisInit.xlsx")
//	public void TestGetTShinseiMeisais() throws Exception
//	{
//		String loginId = "0";
//		Map<Short, List<Short>> kanriShisetsuMap = new HashMap<Short, List<Short>>();
//		Short kanriCode = 10;
//		List<Short> shisetsuCodes = new ArrayList<>();
//		shisetsuCodes.add((short)10);
//		kanriShisetsuMap.put(kanriCode, shisetsuCodes);
//
//		Date from = new Date();
//		Date to = new Date();
//
//		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/M/d");
//
//		from = formatter.parse("2018/4/18");
//		to = formatter.parse("2018/4/20");
//
//		List<ShinseiShurui> shinseiShuruis = new ArrayList<>();
//		shinseiShuruis.add(ShinseiShurui.KARIYOYAKU);
//		shinseiShuruis.add(ShinseiShurui.MITSUMORI);
//
//		List<TShinseiMeisai> ret = tShinseiMeisaiLogic.getTShinseiMeisais(loginId, shinseiShuruis, kanriShisetsuMap, from, to);
//		exportJsonData(ret, "TestGetTShinseiMeisais.json");
//	}
//
//	@Test
//	@DisplayName("引数の条件に合致する取消されていない仮予約のT_申請明細を返却します.")
//	@TestInitDataFile("TestGetRyoshuAriShinseiIchiranDtoByLoginIdInit.xlsx")
//	public void TestGetRyoshuAriShinseiIchiranDtoByLoginId() throws Exception
//	{
//		String loginId = "0";
//		List<ShinseiIchiranDto> ret = tShinseiMeisaiLogic.getRyoshuAriShinseiIchiranDtoByLoginId(loginId);
//		exportJsonData(ret, "TestGetRyoshuAriShinseiIchiranDtoByLoginId.json");
//	}
//
//	@Test
//	@DisplayName("引数の条件に合致する取消されていない仮予約のT_申請明細を返却します.")
//	@TestInitDataFile("TestGetMeisaiListByHaitaKanrenInit.xlsx")
//	public void TestGetMeisaiListByHaitaKanren() throws Exception
//	{
//		List<MHaitaKashidashiTani> mHaitaKashidashiTanis = new ArrayList<>();
//		MHaitaKashidashiTani mHai = new MHaitaKashidashiTani();
//		mHai.setKanriCode((short)10);
//		mHai.setHaitaShisetsuCode((short)10);
//		mHai.setHaitaKashidashiTaniCode((short)1);
//		mHaitaKashidashiTanis.add(mHai);
//		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/M/d");
//		Date fromDate = new Date();
//		Date toDate = new Date();
//		fromDate = formatter.parse("2018/4/18");
//		toDate = formatter.parse("2018/4/20");
//		List<TShinseiMeisai> ret = tShinseiMeisaiLogic.getMeisaiListByHaitaKanren(mHaitaKashidashiTanis, fromDate, toDate);
//		exportJsonData(ret, "TestGetMeisaiListByHaitaKanren.json");
//	}
//
//	@Test
//	@DisplayName("引数の条件に合致する取消されていない仮予約のT_申請明細を返却します.")
//	@TestInitDataFile("TestGetMeisaiListByHaitaKanrenInit.xlsx")
//	public void TestGetTShinseiMeisaiByTShinseiMeisai() throws Exception
//	{
//		List<TShinseiMeisai> listTshinsei = new ArrayList<>();
//		TShinseiMeisai tShinsei = new TShinseiMeisai();
//		tShinsei.setKanriCode((short)10);
//		tShinsei.setShisetsuCode((short)10);
//		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/M/d");
//		Date date = new Date();
//		date = formatter.parse("2018/4/19");
//		tShinsei.setShiyoDate(date);
//		listTshinsei.add(tShinsei);
//		List<? extends TShinseiMeisai> tShinseiMeisais = listTshinsei;
//		List<TShinseiMeisai> ret = tShinseiMeisaiLogic.getTShinseiMeisaiByTShinseiMeisai(tShinseiMeisais);
//		exportJsonData(ret, "TestGetTShinseiMeisaiByTShinseiMeisai.json");
//	}
//
//	@Test
//	@DisplayName("引数の条件に合致する取消されていない仮予約のT_申請明細を返却します.")
//	@TestInitDataFile("TestGetMeisaiListByHaitaKanrenInit.xlsx")
//	public void TestGetTShinseiMeisai_List() throws Exception
//	{
//		List<TShinsei> listTshinsei = new ArrayList<>();
//		TShinsei tShinsei = new TShinsei();
//		tShinsei.setKanriCode((short)10);
//		tShinsei.setShinseiNumber(444);
//		listTshinsei.add(tShinsei);
//		List<TShinseiMeisai> ret = tShinseiMeisaiLogic.getTShinseiMeisai(listTshinsei);
//		exportJsonData(ret, "TestGetTShinseiMeisai_List.json");
//	}
//
//	@Test
//	@DisplayName("引数の条件に合致する取消されていない仮予約のT_申請明細を返却します.")
//	@TestInitDataFile("TestGetShinseiMeisaiListByDispConditionInit.xlsx")
//	public void TestGetShinseiMeisaiListByDispCondition() throws Exception
//	{
//		SearchConditionsDto conditionsDto = new SearchConditionsDto();
//
//		List<ShinseiIchiranDto> ret = tShinseiMeisaiLogic.getShinseiMeisaiListByDispCondition(conditionsDto);
//		exportJsonData(ret, "TestGetShinseiMeisaiListByDispCondition.json");
//	}
//	
//	
//	@Test
//	@DisplayName("引数の条件に合致する取消されていない仮予約のT_申請明細を返却します.")
//	@TestInitDataFile("TestGetShinseiMeisaiListByDispConditionInit.xlsx")
//	public void TestGetShinseiMeisaiListByDispCondition2() throws Exception
//	{
//		SearchConditionsDto conditionsDto = new SearchConditionsDto();
//		conditionsDto.setSLoginId("1");
//		conditionsDto.setSShinseiBango(444);
//		conditionsDto.setSShinseishaShimei("住民テスト利用者");
//		//conditionsDto.setSShinseishaShimeiKana("ジュウミンテストリヨウシャ");
//		//conditionsDto.setSDaihyoshaShimei("住民テスト利用者");
//		//conditionsDto.setSDaihyoshaShimeiKana("ジュウミンテストリヨウシャ");
//		//conditionsDto.setSRenrakushaShimei("住民テスト利用者");
//		//conditionsDto.setSRenrakushaShimeiKana("ジュウミンテストリヨウシャ");
//		//conditionsDto.setSRenrakushaDenwaBango("0456645381");
//		//conditionsDto.setSRenrakushaYubinBango("2210001");
//		conditionsDto.setSUketsukeStartDate("2018/4/18");
//		conditionsDto.setSUketsukeEndDate("2018/4/18");
//		conditionsDto.setSShiyoStartDate("2018/4/19");
//		conditionsDto.setSShiyoEndDate("2018/4/19");
//		conditionsDto.setSToshoUketsukeStartDate("2017/11/30");
//		conditionsDto.setSToshoUketsukeEndDate("2017/11/30");
//		//conditionsDto.setSSakujoKijitsuStart("2018/7/10");
//		//conditionsDto.setSSakujoKijitsuEnd("2018/7/10");
//		conditionsDto.setSGyoji("行事１");
//		conditionsDto.setSMemo("メモ");
//		conditionsDto.setSGenmenSelect(AriNashi.NASHI);
//		conditionsDto.setSKasanSelect(AriNashi.ARI);
//		conditionsDto.setSWaribikiSelect(AriNashi.NASHI);
//		
//		MKanri mKanri = new MKanri();
//		mKanri.setKanriCode((short)10);
//		conditionsDto.setSKanrimeiSelect(mKanri);
//		StringCodeNamePair bashoCode = new StringCodeNamePair();
//		bashoCode.setCode("10");
//		conditionsDto.setSBashomeiSelect(bashoCode);
//		StringCodeNamePair shisetsuCode = new StringCodeNamePair();
//		shisetsuCode.setCode("10");
//		conditionsDto.setSShisetsumeiSelect(shisetsuCode);
//		StringCodeNamePair kashidashiTaniCode = new StringCodeNamePair();
//		kashidashiTaniCode.setCode("1");
//		conditionsDto.setSKashidashiTaniSelect(kashidashiTaniCode);
//		
//		List<StringCodeNamePair> listUsu = new ArrayList<>();
//		StringCodeNamePair uSu = new StringCodeNamePair();
//		uSu.setCode("10");
//		listUsu.add(uSu);
//		conditionsDto.setSUketsukeBashoList(listUsu);
//		
//		List<MeisaiJotai> listMeisaiJotai = new ArrayList<>();
//		listMeisaiJotai.add(MeisaiJotai.SHINKI);
//		conditionsDto.setSMeisaiJotaiList(listMeisaiJotai);
//		
//		List<StringCodeNamePair> listChusenGroup = new ArrayList<>();
//		StringCodeNamePair chusen = new StringCodeNamePair();
//		chusen.setCode("1");
//		listChusenGroup.add(chusen);
//		conditionsDto.setSChusenGroupList(listChusenGroup);
//		
//		List<ChusenKekka> listToraku = new ArrayList<>();
//		listToraku.add(ChusenKekka.TOSEN);
//		conditionsDto.setSTorakuList(listToraku);
//		
//		List<TosenShinseiJotai> listTosenShinseiJotai = new ArrayList<>();
//		listTosenShinseiJotai.add(TosenShinseiJotai.SHINSEIZUMI);
//		conditionsDto.setSTosenShinseiJotaiList(listTosenShinseiJotai);
//		
//		conditionsDto.setSLoginIdMuchSelect(JokenHukumu.ICCHI);
//	
//		List<ShinseiIchiranDto> ret = tShinseiMeisaiLogic.getShinseiMeisaiListByDispCondition(conditionsDto);
//		exportJsonData(ret, "TestGetShinseiMeisaiListByDispCondition2.json");
//	}
	
	@Test
	@DisplayName("引数の条件に合致する取消されていない仮予約のT_申請明細を返却します.")
	@TestInitDataFile("TestGetShinseiMeisaiListByDispConditionInit.xlsx")
	public void TestGetShinseiMeisaiListByDispCondition3() throws Exception
	{
		SearchConditionsDto conditionsDto = new SearchConditionsDto();
		conditionsDto.setSLoginId("1");
		conditionsDto.setSShinseiBango(444);
		conditionsDto.setSShinseishaShimei("住民テスト利用者");
		
		conditionsDto.setSShinseishaShimeiKana("ジュウミンテストリヨウシャ");
		conditionsDto.setSDaihyoshaShimei("住民テスト利用者");
		conditionsDto.setSDaihyoshaShimeiKana("ジュウミンテストリヨウシャ");
		conditionsDto.setSRenrakushaShimei("住民テスト利用者");
		conditionsDto.setSRenrakushaShimeiKana("ジュウミンテストリヨウシャ");
		conditionsDto.setSRenrakushaDenwaBango("0456645381");
		conditionsDto.setSRenrakushaYubinBango("2210001");
		
		conditionsDto.setSUketsukeStartDate("2018/4/18");
		conditionsDto.setSUketsukeEndDate("2018/4/18");
		conditionsDto.setSShiyoStartDate("2018/4/19");
		conditionsDto.setSShiyoEndDate("2018/4/19");
		conditionsDto.setSToshoUketsukeStartDate("2017/11/30");
		conditionsDto.setSToshoUketsukeEndDate("2017/11/30");
		
		conditionsDto.setSSakujoKijitsuStart("2018/7/10");
		conditionsDto.setSSakujoKijitsuEnd("2018/7/10");
		
		conditionsDto.setSGyoji("行事１");
		conditionsDto.setSMemo("メモ");
		conditionsDto.setSGenmenSelect(AriNashi.NASHI);
		conditionsDto.setSKasanSelect(AriNashi.ARI);
		conditionsDto.setSWaribikiSelect(AriNashi.NASHI);
		
		MKanri mKanri = new MKanri();
		mKanri.setKanriCode((short)10);
		conditionsDto.setSKanrimeiSelect(mKanri);
		StringCodeNamePair bashoCode = new StringCodeNamePair();
		bashoCode.setCode("10");
		conditionsDto.setSBashomeiSelect(bashoCode);
		StringCodeNamePair shisetsuCode = new StringCodeNamePair();
		shisetsuCode.setCode("10");
		conditionsDto.setSShisetsumeiSelect(shisetsuCode);
		StringCodeNamePair kashidashiTaniCode = new StringCodeNamePair();
		kashidashiTaniCode.setCode("1");
		conditionsDto.setSKashidashiTaniSelect(kashidashiTaniCode);
		
		List<StringCodeNamePair> listUsu = new ArrayList<>();
		StringCodeNamePair uSu = new StringCodeNamePair();
		uSu.setCode("10");
		listUsu.add(uSu);
		conditionsDto.setSUketsukeBashoList(listUsu);
		
		List<MeisaiJotai> listMeisaiJotai = new ArrayList<>();
		listMeisaiJotai.add(MeisaiJotai.SHINKI);
		conditionsDto.setSMeisaiJotaiList(listMeisaiJotai);
		
		List<StringCodeNamePair> listChusenGroup = new ArrayList<>();
		StringCodeNamePair chusen = new StringCodeNamePair();
		chusen.setCode("1");
		listChusenGroup.add(chusen);
		conditionsDto.setSChusenGroupList(listChusenGroup);
		
		List<ChusenKekka> listToraku = new ArrayList<>();
		listToraku.add(ChusenKekka.TOSEN);
		conditionsDto.setSTorakuList(listToraku);
		
		List<TosenShinseiJotai> listTosenShinseiJotai = new ArrayList<>();
		listTosenShinseiJotai.add(TosenShinseiJotai.SHINSEIZUMI);
		conditionsDto.setSTosenShinseiJotaiList(listTosenShinseiJotai);
		
		conditionsDto.setSShinseiShuruiSelect(ShinseiShurui.HONYOYAKU);
		
		List<StringCodeNamePair> listShiyoMokute = new ArrayList<>();
		StringCodeNamePair shiyoMokute = new StringCodeNamePair();
		shiyoMokute.setCode("1010");
		listShiyoMokute.add(shiyoMokute);
		conditionsDto.setSShiyoMokutekiList(listShiyoMokute);
		
		conditionsDto.setSLoginIdMuchSelect(JokenHukumu.ICCHI);
		
		try
		{
			tShinseiMeisaiLogic.getShinseiMeisaiListByDispCondition(conditionsDto);
		}
		catch (Exception e) {
			
			String messageExp = "m_mail_server Optimistic lock error";
			assertEquals(messageExp, e.getMessage());
		}
	
		
	}
	
	@Test
	@DisplayName("引数の条件に合致するT_申請を返却します")
	public void TestgetDao() throws Exception {
		GenericDao<TShinseiMeisai, ?> ret =  tShinseiMeisaiLogic.getDao();
	}
}
