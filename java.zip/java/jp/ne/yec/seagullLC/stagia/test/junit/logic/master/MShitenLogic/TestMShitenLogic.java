package jp.ne.yec.seagullLC.stagia.test.junit.logic.master.MShitenLogic;

import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.beans.StringCodeNamePair;
import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.entity.MShiten;
import jp.ne.yec.seagullLC.stagia.logic.master.MShitenLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestMShitenLogic extends JunitBase {

	@Autowired
	MShitenLogic mShitenLogic;

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetMShiten.xlsx")
	public void TestgetMShiten() throws Exception
	{
		List<MShiten> ret =  mShitenLogic.getMShiten();
		exportJsonData(ret, "TestgetMRyokinTaikeiList.json");
	}

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetMShiten.xlsx")
	public void TestgetMShitenList() throws Exception
	{
		Short ginkoCodes = 1;
		List<MShiten> ret = mShitenLogic.getMShitenList(ginkoCodes);
		exportJsonData(ret, "TestgetMShitenList.json");
	}

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetMShiten.xlsx")
	public void TestgetStringCodeNamePairList() throws Exception
	{
		Short ginkoCodes = 1;
		List<StringCodeNamePair> ret = mShitenLogic.getStringCodeNamePairList(ginkoCodes);
		exportJsonData(ret, "TestgetStringCodeNamePairList.json");
	}

	@Test
	@DisplayName("検索条件なしで場所マスタを取得し、返却します")
	@TestInitDataFile("TestgetMShiten.xlsx")
	public void TestToStringCodeNamePair() throws Exception
	{
		List<MShiten> list = mShitenLogic.getMShitenList((short)1);
		List<StringCodeNamePair>  ret = mShitenLogic.toStringCodeNamePair(list);
		exportJsonData(ret, "TestToStringCodeNamePair.json");

	}

	@Test
	@DisplayName("検索条件なしで場所マスタを取得し、返却します")
	//@TestInitDataFile("TestgetMBashoList.xlsx")
	public void TestgetDao() throws Exception
	{
		GenericDao<MShiten, ?> ret =  mShitenLogic.getDao();
	}
}