package jp.ne.yec.seagullLC.stagia.test.selenide.base;

import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.DriverManager;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Stream;

import javax.imageio.ImageIO;

import org.apache.commons.lang.StringUtils;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.ClientAnchor;
import org.apache.poi.ss.usermodel.ClientAnchor.AnchorType;
import org.apache.poi.ss.usermodel.Drawing;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.util.CellReference;
import org.dbunit.database.DatabaseConnection;
import org.dbunit.database.IDatabaseConnection;
import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.rules.TestRule;

import com.codeborne.selenide.Configuration;
import com.codeborne.selenide.Selenide;
import com.codeborne.selenide.junit.TextReport;
import com.jcraft.jsch.ChannelExec;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;

import jp.ne.yec.seagullLC.stagia.test.base.TestBase;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestServer;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestServer.Browzer;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestServerDate;

public class SelenideBase extends TestBase {
	protected static final String PROTOCOL_BASE = "http://";

	protected static final String TEST_LINUX_SV_ROOT = "root";
	protected static final String TEST_LINUX_SV_PASS = ".cultos.";

	private TestServer testServer;
	protected TestServerDate testServerDate;

	private static final String RESULT_DIR = "src-test/result";
	protected static final String EXCEL_TEMPLATE = "SelenideTemplate.xlsx";
	protected static String DRIVERS_DIR = "src-test/resources/drivers/";

	@Rule
	public TestRule report = new TextReport();

	@Before
	public void setUp() throws Exception {
		super.setUp();
		Configuration.reportsFolder = RESULT_DIR;
		Configuration.fastSetValue = true;
		setServerInfo();
		setServerDateTime();
	}

	@After
	public void tearDown() throws Exception {
		super.tearDown();
		Selenide.close();
		if (Objects.nonNull(testServerDate)) {
			if (testServer.serverOs().equals(TestServer.Os.WINDOWS)) {
				execWindowsNTP();
			} else {
				execLinuxNTP();
			}
		}
		makeWorkBook();
	}

	@Override
	protected IDatabaseConnection getIConnection() throws Exception {
		return new DatabaseConnection(
				DriverManager.getConnection("jdbc:postgresql://192.168.112.200:5432/stagia2", "stagia2", "stagia2"));
	}

	/**
	 * テストクラスのアノテーションを取得します.
	 *
	 * @return
	 * @throws Exception
	 */
	protected void setServerInfo() throws Exception {
		this.testServer = Optional.ofNullable(getClass().getAnnotationsByType(TestServer.class))
									.orElseThrow(() -> new Exception("サーバ定義がありません。"))[0];
		Configuration.baseUrl = PROTOCOL_BASE + this.testServer.serverIp() + "/" + this.testServer.context();
		Browzer browzer = this.testServer.testBrowzer();
		Configuration.browser = browzer.getWebDriverRunner();
		System.setProperty(browzer.getPropertyKey(), DRIVERS_DIR + browzer.getDriverName());
	}

	/**
	 * テストサーバの時刻を設定します.
	 *
	 * @throws Exception
	 */
	protected void setServerDateTime() throws Exception {
		Arrays.stream(getClass().getMethods())
			.filter(method -> method.getName().equals(testName.getMethodName()))
			.map(method -> method.getDeclaredAnnotation(TestServerDate.class))
			.filter(Objects::nonNull)
			.findFirst()
			.ifPresent(this::setServerDateAndTime);
	}

	/**
	 * テストサーバの日付を設定します.
	 *
	 * @param testServerDate
	 */
	protected void setServerDateAndTime(TestServerDate testServerDate) {
		if (testServer.serverOs().equals(TestServer.Os.WINDOWS)) {
			setServerDateTime4Windows(testServerDate);
			return;
		}
		setServerDateTime4Linux(testServerDate);
	}

	/**
	 * WINDOWSコマンドプロンプトでコマンドを実行します.
	 *
	 * @param cmd
	 * @param value
	 * @throws Exception
	 */
	protected void setServerDateTime4Windows(TestServerDate testServerDate) {
		String date = testServerDate.date();
		String time = testServerDate.time();
		boolean isSetDateTime = false;
		try {
			if (StringUtils.isNotEmpty(date)) {
				Runtime.getRuntime().exec(new String[] { "cmd.exe", "/C", "date", date });
				isSetDateTime = true;
			}
			if (StringUtils.isNotEmpty(time)) {
				Runtime.getRuntime().exec(new String[] { "cmd.exe", "/C", "time", time });
				isSetDateTime = true;
			}
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
		if (isSetDateTime) {
			this.testServerDate = testServerDate;
		}
	}

	/**
	 * サーバ日付をNTPで戻します.
	 *
	 * @param cmd
	 * @param value
	 * @throws Exception
	 */
	protected void execWindowsNTP() {
		try {
			Runtime.getRuntime().exec(new String[] { "cmd.exe", "/C", "w32tm", "/resync" });
		} catch (IOException e) {
			throw new RuntimeException(e);
		}
	}

	/**
	 * サーバ日付を指定した日時に設定します.
	 *
	 * @param setDate
	 * @param setTime
	 * @throws Exception
	 */
	protected void setServerDateTime4Linux(TestServerDate testServerDate) {
		if (StringUtils.isBlank(testServerDate.date()) && StringUtils.isBlank(testServerDate.time())) {
			return;
		}
		this.testServerDate = testServerDate;
		String date = StringUtils.isNotBlank(testServerDate.date()) ? testServerDate.date() : LocalDate.now().format(DateTimeFormatter.ISO_LOCAL_DATE);
		String time = StringUtils.isNotBlank(testServerDate.time()) ? testServerDate.time() : LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm"));
		execLinuxCmd("date -s " + "'" + date + " " + time + "'");
	}

	/**
	 * サーバ日付をNTPで戻します..
	 *
	 * @param setDate
	 * @param setTime
	 * @throws Exception
	 */
	protected void execLinuxNTP() {
		execLinuxCmd("date -s " + "'" + LocalDate.now().format(DateTimeFormatter.ISO_LOCAL_DATE) + " " + LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm")) + "'");
	}

	/**
	 * SSH経由でLINUXコマンドを実行します.
	 *
	 * @throws Exception
	 */
	protected void execLinuxCmd(String command) {
		Session session = null;
		ChannelExec channel = null;
		try {
			try (ByteArrayOutputStream bout = new ByteArrayOutputStream();) {
				JSch jsch = new JSch();
				session = jsch.getSession(TEST_LINUX_SV_ROOT, this.testServer.serverIp(), 22);
				session.setConfig("StrictHostKeyChecking", "no");
				session.setPassword(TEST_LINUX_SV_PASS);
				session.connect();
				channel = (ChannelExec) session.openChannel("exec");
				channel.setCommand(command);
				channel.connect();
				try (BufferedInputStream bin = new BufferedInputStream(channel.getInputStream());) {
					byte[] buf = new byte[1024];
					int length;
					while (true) {
						length = bin.read(buf);
						if (length == -1) {
							break;
						}
						bout.write(buf, 0, length);
					}
					System.out.format("サーバ日付=%1$s", new String(bout.toByteArray(), "UTF-8"));
				}
			} finally {
				channel.disconnect();
				session.disconnect();
			}
		} catch (IOException | JSchException e) {
			throw new RuntimeException(e);
		}

	}

	/**
	 * エビデンス用WorkBookを保存します.
	 *
	 * @return
	 * @throws Exception
	 * @throws InvalidFormatException
	 * @throws IOException
	 */
	protected void makeWorkBook() throws Exception {
		Workbook workbook = WorkbookFactory.create(SelenideBase.class.getResource(EXCEL_TEMPLATE).openStream());
		try (Stream<Path> pathStream = Files.walk(Paths.get(RESULT_DIR))) {
			pathStream
				.map(Path::toFile)
				.filter(File::isFile)
				.sorted(Comparator.comparing(File::getName))
				.forEach(f -> pasteScreenShotAndDeleteFile(workbook, f));
		}
		workbook.removeSheetAt(0);
		try (FileOutputStream o = new FileOutputStream(RESULT_DIR + "/" + getDisplayName() + "_" + Configuration.browser
				+ "_" + LocalDate.now().format(DateTimeFormatter.ofPattern("yyyyMMdd")) + ".xlsx");) {
			workbook.write(o);
		}
		workbook.close();
	}

	/**
	 * テストのスクリーンショットをエクセルに貼り付け、ファイルを削除します.
	 *
	 * @param f
	 * @return
	 */
	private void pasteScreenShotAndDeleteFile(Workbook workbook, File f) {
		if (f.getName().endsWith("html")) {
			f.delete();
		}
		if (!f.getName().endsWith("png")) {
			return;
		}
		workbook.cloneSheet(0);
		int curSheet = workbook.getNumberOfSheets() - 1;
		workbook.setSheetName(curSheet, String.valueOf(curSheet));
		try (ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();) {
			BufferedImage bufferedImage = ImageIO.read(f);
			ImageIO.write(bufferedImage, "png", byteArrayOutputStream);
			Drawing drawing = workbook.getSheetAt(workbook.getNumberOfSheets() - 1).createDrawingPatriarch();
			ClientAnchor anchor = drawing.createAnchor(0, 0, 0, 0, 2, 5, 40, 28);
			anchor.setAnchorType(AnchorType.MOVE_AND_RESIZE);
			drawing.createPicture(anchor, workbook.addPicture(byteArrayOutputStream.toByteArray(), Workbook.PICTURE_TYPE_PNG));
		} catch (Exception e) {
		}
		setCellValue(workbook.getSheetAt(curSheet), "A2", this.testServer.context().split("/")[0]);
		setCellValue(workbook.getSheetAt(curSheet), "J2", this.getClass().getSimpleName());
		setCellValue(workbook.getSheetAt(curSheet), "S2", Configuration.browser);
		setCellValue(workbook.getSheetAt(curSheet), "AB2", getDisplayName());
		setCellValue(workbook.getSheetAt(curSheet), "AK2", getTestDateTime(f));
		f.delete();
	}

	/**
	 * 指定されたセルに値をマッピングします.
	 *
	 * @param sheet
	 * @param cellPosition
	 * @param value
	 */
	private void setCellValue(Sheet sheet, String cellPosition, String value) {
		CellReference cellReference = new CellReference(cellPosition);
		Row row = sheet.getRow(cellReference.getRow());
		Cell cell = row.getCell(cellReference.getCol());
		cell.setCellValue(value);
	}

	/**
	 * エビデンス取得日時を返します.
	 *
	 * @return
	 */
	protected String getTestDateTime(File f) {
		Instant instant = Instant.ofEpochMilli(Long.parseLong(f.getName().split("\\.")[0]));
		LocalDateTime d = LocalDateTime.ofInstant(instant, ZoneId.systemDefault());
		return d.format(DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss"));
	}
}
