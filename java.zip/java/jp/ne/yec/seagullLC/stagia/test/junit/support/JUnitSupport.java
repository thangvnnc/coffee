package jp.ne.yec.seagullLC.stagia.test.junit.support;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import jp.ne.yec.sane.beans.StringCodeNamePair;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

public class JUnitSupport<T> extends JunitBase{
	public static void logFields(Object obj)
	{
		if (obj instanceof Map<?, ?>)
		{
			System.out.println("Map:");
			Map<?, ?> mapper = (Map<?,?>) obj;

			for(Object key: mapper.keySet()) {
				System.out.println(key + " - " + mapper.get(key));
			}

			return;
		}

		Field[] fields = obj.getClass().getDeclaredFields();
		for (int idx = 0; idx < fields.length; idx++)
		{
			System.out.println("Field (" + idx + ") :" + fields[idx].getName());
		}
	}

	private List<Field> getFields(T t) {
        List<Field> fields = new ArrayList<>();
        Class clazz = t.getClass();
        while (clazz != Object.class) {
            fields.addAll(Arrays.asList(clazz.getDeclaredFields()));
            clazz = clazz.getSuperclass();
        }
        return fields;
    }

	public static <T>void logItemFieldCSV(List<T> list)
	{
		if (list.size() > 0)
		{
			Field[] fields = list.get(0).getClass().getSuperclass().getDeclaredFields();
			System.out.println("Fields : ");
			for (int idx = 0; idx < fields.length; idx++)
			{
				System.out.print(fields[idx].getName() + ",");
			}
			System.out.println();
		}
	}

	public static <T>void exItemFieldCSV(List<T> list) throws IOException
	{
		if (list.size() > 0)
		{
			Field[] fields = list.get(0).getClass().getSuperclass().getDeclaredFields();
			System.out.println("Fields : ");
			System.out.println("----------------------------------EXPORT StringCodeNamePair-------------------------------");
			BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(new File("D:\\export\\ItemFieldCSV.csv")));
			StringBuilder stringBuilder = new StringBuilder();
			for (int idx = 0; idx < fields.length; idx++)
			{
				stringBuilder.append(fields[idx].getName());
				if (idx != fields.length - 1)
				{
					stringBuilder.append(",");
				}
			}
			bufferedWriter.write(stringBuilder.toString());

			bufferedWriter.close();
			System.out.println();
		}
	}

	public static void logListStringCodeNamePair(List<StringCodeNamePair> list)
	{
		System.out.println("ListStringCodeNamePair : ");
		for (StringCodeNamePair stringCodeNamePair : list) {
			System.out.println(stringCodeNamePair.getCode() + "," + stringCodeNamePair.getName());
		}
	}

	public static void exListStringCodeNamePair(List<StringCodeNamePair> list) throws Exception
	{
		System.out.println("----------------------------------EXPORT StringCodeNamePair-------------------------------");

		BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(new File("D:\\export\\StringCodeNamePair.csv")));
		for (StringCodeNamePair stringCodeNamePair : list) {
			bufferedWriter.write(stringCodeNamePair.getCode() + "," + stringCodeNamePair.getName());
			bufferedWriter.newLine();
		}
		bufferedWriter.close();
	}
}
