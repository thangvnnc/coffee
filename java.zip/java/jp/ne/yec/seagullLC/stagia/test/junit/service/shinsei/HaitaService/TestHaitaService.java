package jp.ne.yec.seagullLC.stagia.test.junit.service.shinsei.HaitaService;

import static org.junit.Assert.*;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.annotation.Rollback;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.google.common.reflect.TypeToken;

import jp.ne.yec.seagullLC.stagia.beans.shinsei.ShinseiMeisaiDto;
import jp.ne.yec.seagullLC.stagia.beans.unei.KyukanSetteiDataDto;
import jp.ne.yec.seagullLC.stagia.logic.transaction.TSetsubiHaitaWorkLogic;
import jp.ne.yec.seagullLC.stagia.service.shinsei.HaitaService;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestHaitaService extends JunitBase{

	@Autowired
	HaitaService haitaService;

	@Test
	@TestInitDataFile("TestInsShisetsuHaitaInfo_Step1_Init.xlsx")
	public void TestInsShisetsuHaitaInfo_Step1() throws Exception{
		List<ShinseiMeisaiDto> meisaiDtos = readJson("TestInsShisetsuHaitaInfo_Step1_meisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>() {}.getType());
		haitaService.insShisetsuHaitaInfo(meisaiDtos, "769529A597C9137B8DB58C290D2C52B7", "1-tnt");
	}

	@Test
	@TestInitDataFile("TestInsShisetsuHaitaInfo_Step2_Init.xlsx")
	public void TestInsShisetsuHaitaInfo_Step2() throws Exception{
		List<ShinseiMeisaiDto> meisaiDtos = readJson("TestInsShisetsuHaitaInfo_Step2_meisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>() {}.getType());
		haitaService.insShisetsuHaitaInfo(meisaiDtos, "769529A597C9137B8DB58C290D2C52B7", "1-tnt");
	}

	@Test
	@TestInitDataFile("TestInsShisetsuHaitaInfo_Step3_Init.xlsx")
	public void TestInsShisetsuHaitaInfo_Step3() throws Exception{
		List<ShinseiMeisaiDto> meisaiDtos = readJson("TestInsShisetsuHaitaInfo_Step3_meisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>() {}.getType());
		haitaService.insShisetsuHaitaInfo(meisaiDtos, "769529A597C9137B8DB58C290D2C52B7", "1-tnt");
	}

	@Test
	@TestInitDataFile("TestInsShisetsuHaitaInfo_Step4_Init.xlsx")
	public void TestInsShisetsuHaitaInfo_Step4() throws Exception{
		List<ShinseiMeisaiDto> meisaiDtos = readJson("TestInsShisetsuHaitaInfo_Step4_meisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>() {}.getType());
		haitaService.insShisetsuHaitaInfo(meisaiDtos, "769529A597C9137B8DB58C290D2C52B7", "1-tnt");
	}

	@Test
	@TestInitDataFile("TestInsShisetsuHaitaInfo_Step5_Init.xlsx")
	public void TestInsShisetsuHaitaInfo_Step5() throws Exception{
		List<ShinseiMeisaiDto> meisaiDtos = readJson("TestInsShisetsuHaitaInfo_Step5_meisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>() {}.getType());
		haitaService.insShisetsuHaitaInfo(meisaiDtos, "769529A597C9137B8DB58C290D2C52B7", "1-tnt");
	}

	@Test
	@TestInitDataFile("TestInsShisetsuHaitaInfo_Step6_Init.xlsx")
	public void TestInsShisetsuHaitaInfo_Step6() throws Exception{
		try{
			List<ShinseiMeisaiDto> meisaiDtos = readJson("TestInsShisetsuHaitaInfo_Step6_meisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>() {}.getType());
			haitaService.insShisetsuHaitaInfo(meisaiDtos, "769529A597C9137B8DB58C290D2C52B7", "1-tnt");
		}catch (Exception e) {
			String message = "申請対象の施設は更新された可能性があります。お手数ですが、時間をおいてから再度申請を行ってください。";
			assertEquals(message, e.getMessage());
		}
	}

	@Test
	@TestInitDataFile("TestInsSetsubiHaitaInfo_Step1_Init.xlsx")
	public void TestInsSetsubiHaitaInfo_Step1() throws Exception{
		List<ShinseiMeisaiDto> meisaiDtos = readJson("TestInsSetsubiHaitaInfo_Step1_meisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>() {}.getType());
		haitaService.insSetsubiHaitaInfo(meisaiDtos, "F26092F71344F75A9ED595A0C52472C3", "1-tnt");
	}

	@Test
	@TestInitDataFile("TestInsSetsubiHaitaInfo_Step2_Init.xlsx")
	public void TestInsSetsubiHaitaInfo_Step2() throws Exception{
		List<ShinseiMeisaiDto> meisaiDtos = readJson("TestInsSetsubiHaitaInfo_Step2_meisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>() {}.getType());
		try
		{
			haitaService.insSetsubiHaitaInfo(meisaiDtos, "F26092F71344F75A9ED595A0C52472C3", "1-tnt");
		}
		catch (Exception ex) {
			String messsageExp = "申請対象の設備は更新された可能性があります。お手数ですが、時間をおいてから再度申請を行ってください。";
			assertEquals(messsageExp, ex.getMessage());
		}
	}

	@Test
	@TestInitDataFile("TestDelHaitaInfo_Init.xlsx")
	public void TestDelHaitaInfo() throws Exception{
		haitaService.delHaitaInfo("769529A597C9137B8DB58C290D2C52B7");
	}

	@Test
	@TestInitDataFile("TestInsKyukanBashoHaitaInfo_Step1_Init.xlsx")
	public void TestInsKyukanBashoHaitaInfo_Step1() throws Exception{
		Short bashoCode = 10;
		List<LocalDate> kyukanbiList = new ArrayList<>();
        LocalDate localDate = LocalDate.of(2018, 7, 7);
		kyukanbiList.add(localDate);
		String updatedBy = "1-tnt";
		String sessionId = "1-tnt";
		haitaService.insKyukanBashoHaitaInfo(bashoCode, kyukanbiList, sessionId, updatedBy);
	}

	@Test
	@TestInitDataFile("TestInsKyukanBashoHaitaInfo_Step2_Init.xlsx")
	public void TestInsKyukanBashoHaitaInfo_Step2() throws Exception{
		Short bashoCode = 10;
		List<LocalDate> kyukanbiList = new ArrayList<>();
        LocalDate localDate = LocalDate.of(2018, 7, 3);
		kyukanbiList.add(localDate);
		String updatedBy = "1-tnt";
		String sessionId = "1-tnt";
		try
		{
			haitaService.insKyukanBashoHaitaInfo(bashoCode, kyukanbiList, sessionId, updatedBy);
		}
		catch (Exception e) {
			String exp = "休館設定対象は更新された可能性があります。お手数ですが、時間をおいてから再度設定処理を行ってください。";
			assertEquals(exp, e.getMessage());
		}
	}

	@Test
	@TestInitDataFile("TestInsSetsubHenkoiHaitaInfo_Step1_Init.xlsx")
	public void TestInsSetsubHenkoiHaitaInfo_Step1() throws Exception{
		List<ShinseiMeisaiDto> meisaiDtos = readJson("TestInsSetsubHenkoiHaitaInfo_Step1_meisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>() {}.getType());
		haitaService.insSetsubHenkoiHaitaInfo(meisaiDtos, meisaiDtos, "sessionId", "1-tnt");
	}

	@Test
	@TestInitDataFile("TestInsSetsubHenkoiHaitaInfo_Step2_Init.xlsx")
	public void TestInsSetsubHenkoiHaitaInfo_Step2() throws Exception{
		List<ShinseiMeisaiDto> afterMeisaiDtos = readJson("TestInsSetsubHenkoiHaitaInfo_Step2_afterMeisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>() {}.getType());;
		List<ShinseiMeisaiDto> beforeMeisaiDtos = readJson("TestInsSetsubHenkoiHaitaInfo_Step2_beforeMeisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>() {}.getType());;;
		haitaService.insSetsubHenkoiHaitaInfo(afterMeisaiDtos, beforeMeisaiDtos, "sessionId", "1-tnt");
	}

	@Test
	@TestInitDataFile("TestInsSetsubHenkoiHaitaInfo_Step3_Init.xlsx")
	public void TestInsSetsubHenkoiHaitaInfo_Step3() throws Exception{
		List<ShinseiMeisaiDto> afterMeisaiDtos = readJson("TestInsSetsubHenkoiHaitaInfo_Step3_afterMeisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>() {}.getType());;
		List<ShinseiMeisaiDto> beforeMeisaiDtos = readJson("TestInsSetsubHenkoiHaitaInfo_Step3_beforeMeisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>() {}.getType());;;
		try
		{
			haitaService.insSetsubHenkoiHaitaInfo(afterMeisaiDtos, beforeMeisaiDtos, "sessionId", "1-tnt");
		}
		catch (Exception e) {
			String exp = "申請対象の設備は更新された可能性があります。お手数ですが、時間をおいてから再度申請を行ってください。";
			assertEquals(exp, e.getMessage());
		}
	}

	@Test
	@TestInitDataFile("TestInsSetsubHenkoiHaitaInfo_Step4_Init.xlsx")
	public void TestInsSetsubHenkoiHaitaInfo_Step4() throws Exception{
		List<ShinseiMeisaiDto> afterMeisaiDtos = readJson("TestInsSetsubHenkoiHaitaInfo_Step4_afterMeisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>() {}.getType());;
		List<ShinseiMeisaiDto> beforeMeisaiDtos = readJson("TestInsSetsubHenkoiHaitaInfo_Step4_beforeMeisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>() {}.getType());;;
		haitaService.insSetsubHenkoiHaitaInfo(afterMeisaiDtos, beforeMeisaiDtos, "sessionId", "1-tnt");
	}

	@Test
	@TestInitDataFile("TestInsSetsubHenkoiHaitaInfo_Step5_Init.xlsx")
	public void TestInsSetsubHenkoiHaitaInfo_Step5() throws Exception{
		List<ShinseiMeisaiDto> afterMeisaiDtos = readJson("TestInsSetsubHenkoiHaitaInfo_Step5_afterMeisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>() {}.getType());;
		List<ShinseiMeisaiDto> beforeMeisaiDtos = readJson("TestInsSetsubHenkoiHaitaInfo_Step5_beforeMeisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>() {}.getType());;;
		haitaService.insSetsubHenkoiHaitaInfo(afterMeisaiDtos, beforeMeisaiDtos, "sessionId", "1-tnt");
	}

	@Test
	@TestInitDataFile("TestInsSetsubHenkoiHaitaInfo_Step6_Init.xlsx")
	public void TestInsSetsubHenkoiHaitaInfo_Step6() throws Exception{
		List<ShinseiMeisaiDto> afterMeisaiDtos = readJson("TestInsSetsubHenkoiHaitaInfo_Step6_afterMeisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>() {}.getType());;
		List<ShinseiMeisaiDto> beforeMeisaiDtos = readJson("TestInsSetsubHenkoiHaitaInfo_Step6_beforeMeisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>() {}.getType());;;
		haitaService.insSetsubHenkoiHaitaInfo(afterMeisaiDtos, beforeMeisaiDtos, "sessionId", "1-tnt");
	}

	@Test
	// Test continue hàm isNeedHaitaSetsubiShinsei
	@TestInitDataFile("TestInsSetsubHenkoiHaitaInfo_Step7_Init.xlsx")
	public void TestInsSetsubHenkoiHaitaInfo_Step7() throws Exception{
		List<ShinseiMeisaiDto> afterMeisaiDtos = readJson("TestInsSetsubHenkoiHaitaInfo_Step7_afterMeisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>() {}.getType());;
		List<ShinseiMeisaiDto> beforeMeisaiDtos = readJson("TestInsSetsubHenkoiHaitaInfo_Step7_beforeMeisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>() {}.getType());;;
		haitaService.insSetsubHenkoiHaitaInfo(beforeMeisaiDtos, afterMeisaiDtos, "sessionId", "1-tnt");
	}

	@Test
	@TestInitDataFile("TestInsKyukanIkkatsuSetteiHaitaInfo_Step1_Init.xlsx")
	public void TestInsKyukanIkkatsuSetteiHaitaInfo_Step1() throws Exception{
		List<KyukanSetteiDataDto> ikkatsuSetteiList = readJson("TestInsKyukanIkkatsuSetteiHaitaInfo_Step1_ikkatsuSetteiList.pra", new TypeToken<List<KyukanSetteiDataDto>>() {}.getType());
		haitaService.insKyukanIkkatsuSetteiHaitaInfo(ikkatsuSetteiList, "sessionId", "1-tnt");
	}

	@Test
	@TestInitDataFile("TestInsKyukanIkkatsuSetteiHaitaInfo_Step2_Init.xlsx")
	public void TestInsKyukanIkkatsuSetteiHaitaInfo_Step2() throws Exception{
		List<KyukanSetteiDataDto> ikkatsuSetteiList = readJson("TestInsKyukanIkkatsuSetteiHaitaInfo_Step2_ikkatsuSetteiList.pra", new TypeToken<List<KyukanSetteiDataDto>>() {}.getType());
		try
		{
			haitaService.insKyukanIkkatsuSetteiHaitaInfo(ikkatsuSetteiList, "sessionId", "1-tnt");
		}
		catch (Exception e) {
			String exp = "休館設定対象は更新された可能性があります。お手数ですが、時間をおいてから再度設定処理を行ってください。";
			assertEquals(exp, e.getMessage());
		}
	}
}
