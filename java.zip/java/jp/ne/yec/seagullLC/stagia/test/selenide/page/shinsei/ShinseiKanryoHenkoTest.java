package jp.ne.yec.seagullLC.stagia.test.selenide.page.shinsei;

/**
 * 申請完了変更画面のテストクラス.
 *
 * @author nao-hirata
 *
 */
public class ShinseiKanryoHenkoTest extends ShinseiKanryoTest {

}
