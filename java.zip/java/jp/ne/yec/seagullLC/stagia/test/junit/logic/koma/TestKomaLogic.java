package jp.ne.yec.seagullLC.stagia.test.junit.logic.koma;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.seagullLC.stagia.beans.shinsei.ShinseiMeisaiDto;
import jp.ne.yec.seagullLC.stagia.entity.MKashidashiGroup;
import jp.ne.yec.seagullLC.stagia.entity.MKoma;
import jp.ne.yec.seagullLC.stagia.entity.MShisetsu;
import jp.ne.yec.seagullLC.stagia.logic.koma.KomaLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestKomaLogic extends JunitBase {

	@Autowired
	KomaLogic komaLogic;

	@Test
	@DisplayName("引数のコマ情報から申請明細DTOListを生成し返却します.")
	public void TestGetMKashidashiGroupByDateStep1() throws Exception {
		List<MKashidashiGroup> mKashidashiGroups = new ArrayList<MKashidashiGroup>();
		MKashidashiGroup mKashidashiGroup = new MKashidashiGroup();
		mKashidashiGroup.setCreatedAt(new Timestamp(System.currentTimeMillis()));
		mKashidashiGroup.setUpdatedAt(new Timestamp(System.currentTimeMillis()));
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date dateStart = simpleDateFormat.parse("2018-06-06");
		Date dateEnd = simpleDateFormat.parse("2018-06-08");
		mKashidashiGroup.setYukokikanStartDate(dateStart);
		mKashidashiGroup.setKikanStartDate((short)1);
		mKashidashiGroup.setYukokikanEndDate(dateEnd);
		mKashidashiGroup.setKikanEndDate((short)608);
		mKashidashiGroups.add(mKashidashiGroup);

		MKashidashiGroup ret = komaLogic.getMKashidashiGroupByDate(mKashidashiGroups, LocalDate.of(2018, 6, 7));
		exportJsonData(ret, "TestGetMKashidashiGroupByDateStep1.json");
	}

	@Test
	@DisplayName("引数のコマ情報から申請明細DTOListを生成し返却します.")
	public void TestGetMKashidashiGroupByDateStep2() throws Exception {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
		List<MKashidashiGroup> mKashidashiGroups2 = new ArrayList<MKashidashiGroup>();
		MKashidashiGroup mKashidashiGroup2 = new MKashidashiGroup();
		mKashidashiGroup2.setCreatedAt(new Timestamp(System.currentTimeMillis()));
		mKashidashiGroup2.setUpdatedAt(new Timestamp(System.currentTimeMillis()));
		Date dateStart2 = simpleDateFormat.parse("2018-06-06");
		Date dateEnd2 = simpleDateFormat.parse("2018-06-08");
		mKashidashiGroup2.setYukokikanStartDate(dateStart2);
		mKashidashiGroup2.setKikanStartDate((short)1);
		mKashidashiGroup2.setYukokikanEndDate(dateEnd2);
		mKashidashiGroup2.setKikanEndDate((short)2);
		mKashidashiGroups2.add(mKashidashiGroup2);

		try
		{
			MKashidashiGroup ret = komaLogic.getMKashidashiGroupByDate(mKashidashiGroups2, LocalDate.of(2018, 6, 7));
			exportJsonData(ret, "TestGetMKashidashiGroupByDateStep2.json");
		}
		catch (Exception ex){
			ex.printStackTrace();
		}
	}

	@Test
	@DisplayName("引数のコマ情報から申請明細DTOListを生成し返却します.")
	public void TestGetMKashidashiGroupByDateStep3() throws Exception {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");

		List<MKashidashiGroup> mKashidashiGroups3 = new ArrayList<MKashidashiGroup>();
		MKashidashiGroup mKashidashiGroup3 = new MKashidashiGroup();
		mKashidashiGroup3.setCreatedAt(new Timestamp(System.currentTimeMillis()));
		mKashidashiGroup3.setUpdatedAt(new Timestamp(System.currentTimeMillis()));
		Date dateStart3 = simpleDateFormat.parse("2018-06-08");
		Date dateEnd3 = simpleDateFormat.parse("2018-06-09");
		mKashidashiGroup3.setYukokikanStartDate(dateStart3);
		mKashidashiGroup3.setKikanStartDate((short)1);
		mKashidashiGroup3.setYukokikanEndDate(dateEnd3);
		mKashidashiGroup3.setKikanEndDate((short)2);
		mKashidashiGroups3.add(mKashidashiGroup3);

		List<LocalDate> siyoDates = new ArrayList<>();
		siyoDates.add(LocalDate.of(2018, 6, 7));

		try
		{
			MKashidashiGroup ret = komaLogic.getMKashidashiGroupByDate(mKashidashiGroups3, LocalDate.of(2018, 6, 7));
			exportJsonData(ret, "TestGetMKashidashiGroupByDateStep3.json");
		}
		catch (Exception ex){
			ex.printStackTrace();
		}
	}

	@Test
	@DisplayName("引数のコマ情報から申請明細DTOListを生成し返却します.")
	public void TestGetStartEndKomaByTimeStep1() throws Exception {

		List<MKoma> mKomas = new ArrayList<MKoma>();
		MKoma mKoma = new MKoma();
		mKoma.setKomaCode((short)10);
		mKoma.setStartTime((short)1);
		mKoma.setEndTime((short)2);
		mKomas.add(mKoma);

		Short[] ret = komaLogic.getStartEndKomaByTime((short)10, (short)10, mKomas);
		exportJsonData(ret, "TestGetStartEndKomaByTimeStep1.json");
	}

	@Test
	@DisplayName("引数のコマ情報から申請明細DTOListを生成し返却します.")
	public void TestGetStartEndKomaByTimeStep2() throws Exception {

		List<MKoma> mKomas2 = new ArrayList<MKoma>();
		MKoma mKoma2 = new MKoma();
		mKoma2.setKomaCode((short)10);
		mKoma2.setStartTime((short)12);
		mKoma2.setEndTime((short)10);
		mKomas2.add(mKoma2);

		Short[] ret = komaLogic.getStartEndKomaByTime((short)10, (short)10, mKomas2);
		exportJsonData(ret, "TestGetStartEndKomaByTimeStep2.json");
	}

	@Test
	@DisplayName("引数のコマ情報から申請明細DTOListを生成し返却します.")
	public void TestGetStartEndKomaByTimeStep3() throws Exception {

		List<MKoma> mKomas3 = new ArrayList<MKoma>();
		MKoma mKoma3 = new MKoma();
		mKoma3.setKomaCode((short)10);
		mKoma3.setStartTime((short)9);
		mKoma3.setEndTime((short)20);
		mKomas3.add(mKoma3);

		Short[] ret = komaLogic.getStartEndKomaByTime((short)10, (short)10, mKomas3);
		exportJsonData(ret, "TestGetStartEndKomaByTimeStep3.json");
	}

	@Test
	@TestInitDataFile("TestSetMKomaMapInit.xlsx")
	@DisplayName("引数のコマ情報から申請明細DTOListを生成し返却します.")
	public void TestSetMKomaMap() throws Exception {
		ShinseiMeisaiDto meisaiDto = new ShinseiMeisaiDto();
		meisaiDto.setId(113);
		meisaiDto.setKanriCode((short)10);
		MShisetsu mShisetsu = new MShisetsu();
		mShisetsu.setKanriCode((short)10);
		mShisetsu.setKashidashiGroupCode((short)103);
		meisaiDto.setMShisetsu(mShisetsu);
		meisaiDto.setShiyoDate(new Date());
		Set<String> komaCodeMap = new HashSet<>();
		komaCodeMap.add("1001");
		meisaiDto.setKomaCode(komaCodeMap);

		komaLogic.setMKomaMap(meisaiDto);
	}
}
