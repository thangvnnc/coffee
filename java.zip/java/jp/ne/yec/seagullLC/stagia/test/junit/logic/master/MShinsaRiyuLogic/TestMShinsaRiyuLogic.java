package jp.ne.yec.seagullLC.stagia.test.junit.logic.master.MShinsaRiyuLogic;

import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.entity.MShinsaRiyu;
import jp.ne.yec.seagullLC.stagia.logic.master.MShinsaRiyuLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestMShinsaRiyuLogic extends JunitBase {

	@Autowired
	MShinsaRiyuLogic mShinsaRiyuLogic;

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetMShinsaRiyu.xlsx")
	public void TestgetMShinsaRiyu() throws Exception
	{
		Short kanriCode =  10;
		List<MShinsaRiyu> ret =  mShinsaRiyuLogic.getMShinsaRiyu(kanriCode);
		exportJsonData(ret, "TestgetMShinsaRiyu.json");
	}

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetMShinsaRiyu.xlsx")
	public void TestgetMShinsaRiyu_MShinsaRiyu() throws Exception
	{
		Short kanriCode = 10;
		Short shinsaRiyuCode = 1;

		MShinsaRiyu  ret = mShinsaRiyuLogic.getMShinsaRiyu(kanriCode, shinsaRiyuCode);
		exportJsonData(ret, "TestgetMShinsaRiyu_MShinsaRiyu.json");
	}
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	public void TestgetDao() throws Exception
	{
		GenericDao<MShinsaRiyu, ?> ret = mShinsaRiyuLogic.getDao();
	}
}