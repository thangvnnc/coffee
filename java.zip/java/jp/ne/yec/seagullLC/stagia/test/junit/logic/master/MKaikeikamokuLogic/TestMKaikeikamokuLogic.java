package jp.ne.yec.seagullLC.stagia.test.junit.logic.master.MKaikeikamokuLogic;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.entity.MKembaikiButton;
import jp.ne.yec.seagullLC.stagia.logic.master.MKembaikiButtonLogic;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestMKaikeikamokuLogic extends JunitBase {

	@Autowired
	MKembaikiButtonLogic mKembaikiButtonLogic;

	@Test
	@DisplayName("引数なしでM_料金体系を取得します.")
	//@TestInitDataFile("TestRiyoshaServiceInit.xlsx")
	public void TestGetDAO() throws Exception {
		GenericDao<MKembaikiButton, ?> ret = mKembaikiButtonLogic.getDao();
		//assertEquals(mRyokinTaikeiDao, ret);
	}
}
