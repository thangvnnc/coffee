package jp.ne.yec.seagullLC.stagia.test.junit.service.ryokin.RyoshuKampuKeshikomiService;

import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.seagullLC.stagia.service.ryokin.RyoshuKampuKeshikomiService;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestRyoshuKampuKeshikomiService extends JunitBase{

	@Autowired
	RyoshuKampuKeshikomiService ryoshuKampuKeshikomiService;

}
