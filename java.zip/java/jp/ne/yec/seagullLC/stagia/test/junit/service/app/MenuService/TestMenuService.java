package jp.ne.yec.seagullLC.stagia.test.junit.service.app.MenuService;

import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.seagullLC.stagia.service.app.MenuService;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = { "classpath:TestApplicationContext.xml" })
@WebAppConfiguration
public class TestMenuService extends JunitBase {

	@Autowired
	MenuService menuService;

//	@Test
//	public void TestAppGetChokinSinsei() throws Exception {
//		List<String> listText = new ArrayList<String>();
//
//		List<Map<String, String>> jsonData = new ArrayList<Map<String, String>>();
//		listText.add("1");
//		for (String text : listText) {
//			Map<String, String> map = menuService.appGetChokinSinsei(text);
//			jsonData.add(map);
//		}
//
//		exportJsonData(jsonData, "TestAppGetChokinSinsei.json");
//	}

//	@Test
//	public void TestAppGetRenrakuNoReadCount() throws Exception {
//		List<String> listText = new ArrayList<String>();
//		listText.add("1");
//		listText.add("2");
//
//		List<Integer> jsonData = new ArrayList<Integer>();
//		for (String text : listText) {
//			int result = menuService.appGetRenrakuNoReadCount(text);
//			jsonData.add(result);
//		}
//
//		exportJsonData(jsonData, "TestAppGetRenrakuNoReadCount.json");
//	}
}
