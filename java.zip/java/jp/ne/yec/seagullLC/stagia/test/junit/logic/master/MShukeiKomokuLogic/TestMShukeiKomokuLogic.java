package jp.ne.yec.seagullLC.stagia.test.junit.logic.master.MShukeiKomokuLogic;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.entity.MShukeiKomoku;
import jp.ne.yec.seagullLC.stagia.logic.master.MShukeiKomokuLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestMShukeiKomokuLogic extends JunitBase {

	@Autowired
	MShukeiKomokuLogic mShukeiKomokuLogic;

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetMShukeiKomoku.xlsx")
	public void TestgetMShukeiKomoku() throws Exception
	{
		List<Short> kanriCodes = new ArrayList<>();
		kanriCodes.add((short)10);

		List<MShukeiKomoku>  ret = mShukeiKomokuLogic.getMShukeiKomoku(kanriCodes);
		exportJsonData(ret, "TestgetMShukeiKomoku.json");
	}

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetMShukeiKomoku.xlsx")
	public void TestgetMShukeiKomoku_List() throws Exception
	{
		Short kanriCode = 10;
		List<MShukeiKomoku> ret =  mShukeiKomokuLogic.getMShukeiKomoku(kanriCode);
		exportJsonData(ret, "TestgetMShukeiKomoku_List.json");
	}

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	//@TestInitDataFile("TestgetMBashoList.xlsx")
	public void TestgetDao() throws Exception
	{
		GenericDao<MShukeiKomoku, ?> ret = mShukeiKomokuLogic.getDao();
	}
}