package jp.ne.yec.seagullLC.stagia.test.junit.service.shinsei.MeisaiIchiranService;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.google.gson.reflect.TypeToken;

import jp.ne.yec.seagullLC.stagia.beans.enums.domain.ShinseiShurui;
import jp.ne.yec.seagullLC.stagia.beans.shinsei.ShinseiDto;
import jp.ne.yec.seagullLC.stagia.beans.shinsei.ShinseiMeisaiDto;
import jp.ne.yec.seagullLC.stagia.entity.MBasho;
import jp.ne.yec.seagullLC.stagia.entity.MShisetsu;
import jp.ne.yec.seagullLC.stagia.service.shinsei.MeisaiIchiranService;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestMeisaiIchiranService extends JunitBase{

	@Autowired
	MeisaiIchiranService meisaiIchiranService;

	@Test
	@TestInitDataFile("TestGetBashoMap_Init.xlsx")
	public void TestGetBashoMap() throws Exception{
		List<Short> bashoCodeList = new ArrayList<Short>();
		bashoCodeList.add((short)10);
		Map<Short, MBasho> ret = meisaiIchiranService.getBashoMap(bashoCodeList);
		exportJsonData(ret, "TestGetBashoMap.json");
	}

	@Test
	@DisplayName("引数の管理コードに紐付くM_施設を返却します.")
	@TestInitDataFile("TestgetMShisetsuList_Init.xlsx")
	public void TestGetMShisetsuList() throws Exception
	{
		List<MShisetsu> ret =  meisaiIchiranService.getShisetsuList((short) 10);
		exportJsonData(ret, "TestGetMShisetsuList.json");
	}

	// chua du 20%
	@Test
	@TestInitDataFile("TestMakeChangedMeisais_Step1_Init.xlsx")
	public void TestMakeChangedMeisais_Step1() throws Exception
	{
		ShinseiDto shinseiDto = readJson("TestMakeChangedMeisais_Step1_shinseiDto.pra", new TypeToken<ShinseiDto>() {}.getType());
		List<ShinseiMeisaiDto> shinseiMeisaiDtos = readJson("TestMakeChangedMeisais_Step1_shinseiMeisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>() {}.getType());
		Map<Integer, ShinseiMeisaiDto> meisaiBeforeChanges = readJson("TestMakeChangedMeisais_Step1_meisaiBeforeChanges.pra", new TypeToken<Map<Integer, ShinseiMeisaiDto>>() {}.getType());
		List<ShinseiMeisaiDto> ret = meisaiIchiranService.makeChangedMeisais(shinseiDto, shinseiMeisaiDtos, meisaiBeforeChanges, false);
		exportJsonData(ret, "TestMakeChangedMeisais_Step1.json");
	}

	// chua du 80%
	@Test
	@DisplayName("引数の管理コードに紐付くM_施設を返却します.")
	@TestInitDataFile("TestCalcSetsubiRyokint_Step1_Init.xlsx")
	public void TestCalcSetsubiRyokint_Step1() throws Exception
	{
		ShinseiDto shinseiDto = readJson("TestCalcSetsubiRyokint_Step1_shinseiDto.pra", new TypeToken<ShinseiDto>() {}.getType());
		List<ShinseiMeisaiDto> shinseiMeisaiDtos = readJson("TestCalcSetsubiRyokint_Step1_shinseiMeisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>() {}.getType());
		meisaiIchiranService.calcSetsubiRyokin(shinseiDto, shinseiMeisaiDtos);;
	}

	// 30%
	@Test
	public void TestMakeShinseiMap_Step1() throws Exception
	{
		ShinseiDto shinseiDto = readJson("TestMakeShinseiMap_Step1_shinseiDto.pra", new TypeToken<ShinseiDto>() {}.getType());
		List<ShinseiMeisaiDto> meisaiDtos = readJson("TestMakeShinseiMap_Step1_meisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>() {}.getType());
		Map<ShinseiShurui, Map<ShinseiDto, List<ShinseiMeisaiDto>>> ret = meisaiIchiranService.makeShinseiMap(shinseiDto, meisaiDtos, false);
		exportJsonData(ret, "TestMakeShinseiMap_Step1.json");
	}
}
