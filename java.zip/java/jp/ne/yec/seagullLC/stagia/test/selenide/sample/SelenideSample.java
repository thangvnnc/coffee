package jp.ne.yec.seagullLC.stagia.test.selenide.sample;

import static com.codeborne.selenide.Selenide.*;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;

import jp.ne.yec.seagullLC.stagia.beans.enums.domain.MeisaiJotai;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestServer;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestServer.Browzer;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestServer.Os;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestServerDate;
import jp.ne.yec.seagullLC.stagia.test.selenide.base.SelenideBase;
import jp.ne.yec.seagullLC.stagia.test.selenide.page.akijokyo.AkijokyoKensakuTest;
import jp.ne.yec.seagullLC.stagia.test.selenide.page.login.LoginTest;
import jp.ne.yec.seagullLC.stagia.test.selenide.page.madoguchi.ShokaiTest;
import jp.ne.yec.seagullLC.stagia.test.selenide.page.shinsei.MeisaiIchiranHenkoTest;
import jp.ne.yec.seagullLC.stagia.test.selenide.page.shinsei.MeisaiIchiranTest;
import jp.ne.yec.seagullLC.stagia.test.selenide.page.shinsei.ShinseiKakuninHenkoTest;
import jp.ne.yec.seagullLC.stagia.test.selenide.page.shinsei.ShinseiKakuninTest;
import jp.ne.yec.seagullLC.stagia.test.selenide.page.shinsei.ShinseiKanryoHenkoTest;
import jp.ne.yec.seagullLC.stagia.test.selenide.page.shinsei.ShinseiKanryoTest;
import jp.ne.yec.seagullLC.stagia.test.selenide.page.shinsei.ShinseishaJohoTest;

@TestServer(serverIp = "127.0.0.1:8080", serverOs = Os.LINUX, context = "stagia2", testBrowzer = Browzer.Chrome)
public class SelenideSample extends SelenideBase {

	@Test
	@TestServerDate(date="2018-04-30")
	@DisplayName(value = "新規予約→照会→取消")
	public void sample() {
		LoginTest loginPage = open("/", LoginTest.class);
		AkijokyoKensakuTest akijokyoKensakuTest = loginPage.login("hirata", "9999");
		akijokyoKensakuTest.search();
		akijokyoKensakuTest.selectBasho("生涯学習センター");
		akijokyoKensakuTest.selectShisetsu("会議室");
		akijokyoKensakuTest.komaClick(0, 3);
		MeisaiIchiranTest meisaiIchiranTest = akijokyoKensakuTest.nextPage();
		ShinseishaJohoTest shinseishaJohoTest = meisaiIchiranTest.shinseishaJohoButtonClick();
		shinseishaJohoTest.setLoginIdAndClickSetteiButton("8000");
		shinseishaJohoTest.clickShinseishaSetteiButton();
		meisaiIchiranTest = shinseishaJohoTest.clickConfirmYes(MeisaiIchiranTest.class);
		meisaiIchiranTest.setKashidashiTaniByName(0, "１");
		ShinseiKakuninTest shinseiKakuninTest = meisaiIchiranTest.nextPage();
		shinseiKakuninTest.kakuteiButtonClick();
		ShinseiKanryoTest shinseiKanryoTest = shinseiKakuninTest.clickConfirmYes(ShinseiKanryoTest.class);
		ShokaiTest shokaiTest = shinseiKanryoTest.clickSidebarMenu(ShokaiTest.class, "窓口業務", "照会");
		shokaiTest.setShiyoDateFrom("2018/5/3");
		shokaiTest.setShiyoDateTo("2018/5/3");
		shokaiTest.setMeisaiJotai(MeisaiJotai.SHINKI.getName());
		shokaiTest.search();
		shokaiTest.clickMeisaiResult(0);
		MeisaiIchiranHenkoTest meisaiIchiranHenkoTest = shokaiTest.clickHenkoButton();
		meisaiIchiranHenkoTest.clickTrashIcon(0);
		ShinseiKakuninHenkoTest shinseiKakuninHenkoTest = meisaiIchiranHenkoTest.nextPage();
		shinseiKakuninHenkoTest.kakuteiButtonClick();
		ShinseiKanryoHenkoTest shinseiKanryoHenkoTest = shinseiKakuninHenkoTest.clickConfirmYes(ShinseiKanryoHenkoTest.class);
		shinseiKanryoHenkoTest.clickTopButton();
		sleep(2000);
	}

	@Test
	public void riyoshaLogin() {
		AkijokyoKensakuTest akijokyoKensakuTest = open("/", AkijokyoKensakuTest.class);
		LoginTest loginPage = akijokyoKensakuTest.clickLoginButton();
		akijokyoKensakuTest = loginPage.login("8000", "9999");
		akijokyoKensakuTest.search();
		akijokyoKensakuTest.selectBasho("生涯学習センター");
		akijokyoKensakuTest.selectShisetsu("会議室");
		akijokyoKensakuTest.komaClick(0, 3);
		MeisaiIchiranTest meisaiIchiranTest = akijokyoKensakuTest.nextPage();
		meisaiIchiranTest.clickLogoutButton();
		sleep(2000);
	}

}
