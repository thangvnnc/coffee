package jp.ne.yec.seagullLC.stagia.test.junit.service.madoguchi.TosenKakuninService;

import static org.junit.Assert.*;

import java.time.YearMonth;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.google.gson.reflect.TypeToken;

import jp.ne.yec.seagullLC.stagia.beans.shinsei.ShinseiDto;
import jp.ne.yec.seagullLC.stagia.beans.shinsei.ShinseiMeisaiDto;
import jp.ne.yec.seagullLC.stagia.service.madoguchi.TosenKakuninService;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestTosenKakuninService extends JunitBase{

	@Autowired
	TosenKakuninService tosenKakuninService;

	@Test
	@DisplayName("管理コードと申請番号を元に申請Dtoを取得します.")
	@TestInitDataFile("TestGetTosenMeisaiListInit.xlsx")
	public void TestGetShinseiMeisai() throws Exception{
		List<List<ShinseiMeisaiDto>> jsonData = new ArrayList<List<ShinseiMeisaiDto>>();
		List<String> listLoginId = new ArrayList<String>();
		listLoginId.add("1");

		List<YearMonth> shiyoMonthFroms = new ArrayList<YearMonth>();
		YearMonth shiyoMonthFrom1 = YearMonth.of(2017,05);
		shiyoMonthFroms.add(shiyoMonthFrom1);

		List<YearMonth> shiyoMonthTos = new ArrayList<YearMonth>();
		YearMonth shiyoMonthTo1 = YearMonth.of(2017, 05);
		shiyoMonthTos.add(shiyoMonthTo1);

		boolean isShokuinLogin = false;


		List<ShinseiMeisaiDto> list = tosenKakuninService.getShinseiMeisai(
				listLoginId.get(0),
				shiyoMonthFroms.get(0),
				shiyoMonthTos.get(0),
				isShokuinLogin
				);
		//assertEquals(2, list.size());
		jsonData.add(list);

		exportJsonData(jsonData, "TestGetShinseiMeisai.json");

	}

	@Test
	@DisplayName("管理コードと申請番号を元に申請Dtoを取得します.")
	@TestInitDataFile("TestGetTosenMeisaiListInit.xlsx")
	public void TestGetShinseiMeisai_Step2() throws Exception{
		List<List<ShinseiMeisaiDto>> jsonData = new ArrayList<List<ShinseiMeisaiDto>>();
		List<String> listLoginId = new ArrayList<String>();
		listLoginId.add("10");

		List<YearMonth> shiyoMonthFroms = new ArrayList<YearMonth>();
		shiyoMonthFroms.add(null);

		List<YearMonth> shiyoMonthTos = new ArrayList<YearMonth>();
		shiyoMonthTos.add(null);

		boolean isShokuinLogin = false;


		List<ShinseiMeisaiDto> list = tosenKakuninService.getShinseiMeisai(
				listLoginId.get(0),
				shiyoMonthFroms.get(0),
				shiyoMonthTos.get(0),
				isShokuinLogin
				);
		//assertEquals(2, list.size());
		jsonData.add(list);

		exportJsonData(jsonData, "TestGetShinseiMeisai.json");

	}

	@Test
	@DisplayName("管理コードと申請番号を元に申請Dtoを取得します.")
	@TestInitDataFile("TestGetTShinseiInit.xlsx")
	public void TestGetShinseiDto() throws Exception{
		List<ShinseiDto> jsonData = new ArrayList<ShinseiDto>();
		List<Short> listKanriCode = new ArrayList<Short>();// readArrShort("TestGetKanrimeiList_kanriCode.txt");
		listKanriCode.add((short)10);


		List<Integer> listShinseiNumber = new ArrayList<Integer>();//readArrInteger("TestGetKanrimeiList_shinseiNumber.txt");
		listShinseiNumber.add(1);

		ShinseiDto shinseiDto = tosenKakuninService.getShinseiDto(
				listKanriCode.get(0),
				listShinseiNumber.get(0)
				);

		assertNotNull(shinseiDto);
		jsonData.add(shinseiDto);
		exportJsonData(jsonData, "TestGetShinseiDto.json");

	}

	@Test
	@DisplayName("管理コードと申請番号を元に申請Dtoを取得します.")
	@TestInitDataFile("TestGetTShinseiInit.xlsx")
	public void TestUpdateTShinseiList() throws Exception{
		String updateBy = "800";
		//List<ShinseiDto> shinseiDtoList
		List<ShinseiDto> shinseiDtoList = readJson("TestUpdateTShinseiList_ShinseiDto.json", new TypeToken<List<ShinseiDto>>(){}.getType());
		tosenKakuninService.updateTShinseiList(shinseiDtoList, updateBy);

	}
}
