package jp.ne.yec.seagullLC.stagia.test.junit.logic.riyosha;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.seagullLC.stagia.beans.enums.domain.NijutorokuHanteiHani;
import jp.ne.yec.seagullLC.stagia.beans.riyosha.KoseiinJohoDto;
import jp.ne.yec.seagullLC.stagia.beans.riyosha.RiyoshaDto;
import jp.ne.yec.seagullLC.stagia.entity.TKoseiin;
import jp.ne.yec.seagullLC.stagia.logic.riyosha.RiyoshaUtilityLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestRiyoshaUtilityLogic extends JunitBase {


	@Autowired
	RiyoshaUtilityLogic riyoshaUtilityLogic;

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	//@TestInitDataFile("TestgetMBashoList.xlsx")
	public void TestKoseiinJohoEntityToKoseiinJohoDto() throws Exception
	{
		List<List<KoseiinJohoDto>> jsonData = new ArrayList<List<KoseiinJohoDto>>();
		List<List<TKoseiin>> params = new ArrayList<List<TKoseiin>>();
		List<TKoseiin> koseiinJohoEntityList = new ArrayList<TKoseiin>();
		TKoseiin tKoseiin = new TKoseiin();
		koseiinJohoEntityList.add(tKoseiin);
		params.add(koseiinJohoEntityList);

		List<KoseiinJohoDto>  ret = riyoshaUtilityLogic.koseiinJohoEntityToKoseiinJohoDto(params.get(0));
		assertEquals(2, ret.size());
		jsonData.add(ret);
		exportJsonData(jsonData, "TestKoseiinJohoEntityToKoseiinJohoDto.json");
	}

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestcheckDoubleRegistrationInit2.xlsx")
	public void TestCheckDoubleRegistration() throws Exception
	{
		List<RiyoshaDto> params = new ArrayList<RiyoshaDto>();
		RiyoshaDto RiyoshaDto = new RiyoshaDto();
		params.add(RiyoshaDto);

		RiyoshaDto RiyoshaDto1 = new RiyoshaDto();
		params.add(RiyoshaDto1);

		RiyoshaDto RiyoshaDto2 = new RiyoshaDto();
		params.add(RiyoshaDto2);

		RiyoshaDto RiyoshaDto3 = new RiyoshaDto();
		params.add(RiyoshaDto3);

		List<String> updateCodes = new ArrayList<String>();
		updateCodes.add("8000");
		updateCodes.add("1");
		updateCodes.add("1");
		updateCodes.add("1");

		List<NijutorokuHanteiHani> nijutorokuHanteiHanis = new ArrayList<NijutorokuHanteiHani>();
		nijutorokuHanteiHanis.add(NijutorokuHanteiHani.DOITSU);
		nijutorokuHanteiHanis.add(NijutorokuHanteiHani.NONE);
		nijutorokuHanteiHanis.add(NijutorokuHanteiHani.NONE);
		nijutorokuHanteiHanis.add(NijutorokuHanteiHani.KONZAI);

		//NijutorokuHanteiHani nijutorokuHanteiHani

		riyoshaUtilityLogic.checkDoubleRegistration(params.get(0), updateCodes.get(0), nijutorokuHanteiHanis.get(0));
	}

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestcheckDoubleRegistrationInit2.xlsx")
	public void TestCheckDoubleRegistration_2() throws Exception
	{
		List<RiyoshaDto> params = new ArrayList<RiyoshaDto>();
		RiyoshaDto RiyoshaDto = new RiyoshaDto();
		params.add(RiyoshaDto);

		RiyoshaDto RiyoshaDto1 = new RiyoshaDto();
		params.add(RiyoshaDto1);

		List<String> updateCodes = new ArrayList<String>();
		updateCodes.add("8000");
		updateCodes.add("1");

		List<NijutorokuHanteiHani> nijutorokuHanteiHanis = new ArrayList<NijutorokuHanteiHani>();
		nijutorokuHanteiHanis.add(NijutorokuHanteiHani.NONE);
		nijutorokuHanteiHanis.add(NijutorokuHanteiHani.KONZAI);

		//NijutorokuHanteiHani nijutorokuHanteiHani
		riyoshaUtilityLogic.checkDoubleRegistration(params.get(0), updateCodes.get(0), nijutorokuHanteiHanis.get(0));
	}
}

