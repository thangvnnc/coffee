package jp.ne.yec.seagullLC.stagia.test.junit.logic.riyosha;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.google.gson.reflect.TypeToken;

import jp.ne.yec.seagullLC.stagia.beans.enums.domain.NijutorokuHanteiHani;
import jp.ne.yec.seagullLC.stagia.beans.riyosha.KoseiinJohoDto;
import jp.ne.yec.seagullLC.stagia.beans.riyosha.RiyoshaDto;
import jp.ne.yec.seagullLC.stagia.entity.TKoseiin;
import jp.ne.yec.seagullLC.stagia.logic.riyosha.RiyoshaUtilityLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;
import jp.ne.yec.seagullLC.stagia.test.junit.service.riyosha.RiyoshaDtoTest;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestRiyoshaUtilityLogic extends JunitBase {


	@Autowired
	RiyoshaUtilityLogic riyoshaUtilityLogic;

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	public void TestKoseiinJohoEntityToKoseiinJohoDto() throws Exception
	{
		List<List<KoseiinJohoDto>> jsonData = new ArrayList<List<KoseiinJohoDto>>();
		List<List<TKoseiin>> params = new ArrayList<List<TKoseiin>>();
		List<TKoseiin> koseiinJohoEntityList = readJson("TestKoseiinJohoEntityToKoseiinJohoDto_ListTKoseiin.json", new TypeToken<List<TKoseiin>>(){}.getType());
		params.add(koseiinJohoEntityList);

		List<KoseiinJohoDto>  ret = riyoshaUtilityLogic.koseiinJohoEntityToKoseiinJohoDto(params.get(0));
		assertTrue(ret.size() > 0);
		jsonData.add(ret);
		exportJsonData(jsonData, "TestKoseiinJohoEntityToKoseiinJohoDto.json");
	}

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestcheckDoubleRegistrationInit.xlsx")
	public void TestCheckDoubleRegistration() throws Exception
	{
		List<RiyoshaDto> params = new ArrayList<RiyoshaDto>();
		RiyoshaDtoTest riyoshaDtotest = readJson("TestCheckDoubleRegistration_riyoshaDto.json", new TypeToken<RiyoshaDtoTest>(){}.getType());
		RiyoshaDto riyoshaDto = new RiyoshaDto();
		riyoshaDto.setLoginId("sicvn1");
		riyoshaDto.setKannriCode(riyoshaDtotest.getKannriCode());
		riyoshaDto.setPassword(riyoshaDtotest.getPassword());
		riyoshaDto.setSelectedTorokuKubun(riyoshaDtotest.getSelectedTorokuKubun());
		riyoshaDto.setSelectedGinkoCode(riyoshaDtotest.getSelectedGinkoCode());
		riyoshaDto.setSelectedShitenCode(riyoshaDtotest.getSelectedShitenCode());
		riyoshaDto.setSelectedKozaShubetsu(riyoshaDtotest.getSelectedKozaShubetsu());
		riyoshaDto.setSelectedRiyoshaGroupCode(riyoshaDtotest.getSelectedRiyoshaGroupCode());
		riyoshaDto.setSelectedSoshinTiming(riyoshaDtotest.getSelectedSoshinTiming());
		riyoshaDto.setSelectedShinseiGroupCode(riyoshaDtotest.getSelectedShinseiGroupCode());
		riyoshaDto.setUserName(riyoshaDtotest.getUserName());
		riyoshaDto.setMaxKoseiinCode(riyoshaDtotest.getMaxKoseiinCode());
		riyoshaDto.setKoseiinJohoDto(riyoshaDtotest.getKoseiinJohoDto());
		riyoshaDto.setRiyoKanoShinseiGroupDto(riyoshaDtotest.getRiyoKanoShinseiGroupDto());
		riyoshaDto.setKanribetsuRiyoshaJohoDto(riyoshaDtotest.getKanribetsuRiyoshaJohoDto());
		riyoshaDto.setRyokinSetteiDto(riyoshaDtotest.getRyokinSetteiDto());
		riyoshaDto.setRiyoshaUketoriMailDto(riyoshaDtotest.getRiyoshaUketoriMailDto());
		// カレンダー用
		riyoshaDto.setDatepick(riyoshaDtotest.getDatepick());
		riyoshaDto.setDatepickStart(riyoshaDtotest.getDatepickStart());
		riyoshaDto.setDatepickEnd(riyoshaDtotest.getDatepickEnd());

		// 職員検索用
		//String loginId;
		riyoshaDto.setShokuinKanaName(riyoshaDtotest.getShokuinKanaName());
		riyoshaDto.setKanrimei(riyoshaDtotest.getKanrimei());


		List<String> updateCodes = new ArrayList<String>();
		updateCodes.add("8000");

		List<NijutorokuHanteiHani> nijutorokuHanteiHanis = new ArrayList<NijutorokuHanteiHani>();
		nijutorokuHanteiHanis.add(NijutorokuHanteiHani.NONE);

		params.add(riyoshaDto);
		//NijutorokuHanteiHani nijutorokuHanteiHani

		riyoshaUtilityLogic.checkDoubleRegistration(params.get(0), updateCodes.get(0), nijutorokuHanteiHanis.get(0));
	}

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestcheckDoubleRegistrationInit.xlsx")
	public void TestCheckDoubleRegistration_Step1() throws Exception
	{
		List<RiyoshaDto> params = new ArrayList<RiyoshaDto>();
		RiyoshaDtoTest riyoshaDtotest = readJson("TestCheckDoubleRegistration_riyoshaDto.json", new TypeToken<RiyoshaDtoTest>(){}.getType());
		RiyoshaDto riyoshaDto = new RiyoshaDto();
		riyoshaDto.setLoginId("sicvn1");
		riyoshaDto.setKannriCode(riyoshaDtotest.getKannriCode());
		riyoshaDto.setPassword(riyoshaDtotest.getPassword());
		riyoshaDto.setSelectedTorokuKubun(riyoshaDtotest.getSelectedTorokuKubun());
		riyoshaDto.setSelectedGinkoCode(riyoshaDtotest.getSelectedGinkoCode());
		riyoshaDto.setSelectedShitenCode(riyoshaDtotest.getSelectedShitenCode());
		riyoshaDto.setSelectedKozaShubetsu(riyoshaDtotest.getSelectedKozaShubetsu());
		riyoshaDto.setSelectedRiyoshaGroupCode(riyoshaDtotest.getSelectedRiyoshaGroupCode());
		riyoshaDto.setSelectedSoshinTiming(riyoshaDtotest.getSelectedSoshinTiming());
		riyoshaDto.setSelectedShinseiGroupCode(riyoshaDtotest.getSelectedShinseiGroupCode());
		riyoshaDto.setUserName(riyoshaDtotest.getUserName());
		riyoshaDto.setMaxKoseiinCode(riyoshaDtotest.getMaxKoseiinCode());
		riyoshaDto.setKoseiinJohoDto(riyoshaDtotest.getKoseiinJohoDto());
		riyoshaDto.setRiyoKanoShinseiGroupDto(riyoshaDtotest.getRiyoKanoShinseiGroupDto());
		riyoshaDto.setKanribetsuRiyoshaJohoDto(riyoshaDtotest.getKanribetsuRiyoshaJohoDto());
		riyoshaDto.setRyokinSetteiDto(riyoshaDtotest.getRyokinSetteiDto());
		riyoshaDto.setRiyoshaUketoriMailDto(riyoshaDtotest.getRiyoshaUketoriMailDto());
		// カレンダー用
		riyoshaDto.setDatepick(riyoshaDtotest.getDatepick());
		riyoshaDto.setDatepickStart(riyoshaDtotest.getDatepickStart());
		riyoshaDto.setDatepickEnd(riyoshaDtotest.getDatepickEnd());

		// 職員検索用
		//String loginId;
		riyoshaDto.setShokuinKanaName(riyoshaDtotest.getShokuinKanaName());
		riyoshaDto.setKanrimei(riyoshaDtotest.getKanrimei());


		List<String> updateCodes = new ArrayList<String>();
		updateCodes.add("8000");

		List<NijutorokuHanteiHani> nijutorokuHanteiHanis = new ArrayList<NijutorokuHanteiHani>();
		nijutorokuHanteiHanis.add(NijutorokuHanteiHani.DOITSU);

		params.add(riyoshaDto);
		//NijutorokuHanteiHani nijutorokuHanteiHani

		riyoshaUtilityLogic.checkDoubleRegistration(params.get(0), updateCodes.get(0), nijutorokuHanteiHanis.get(0));
	}

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestcheckDoubleRegistrationInit2.xlsx")
	public void TestCheckDoubleRegistration_Step2() throws Exception
	{
		List<RiyoshaDto> params = new ArrayList<RiyoshaDto>();
		RiyoshaDtoTest riyoshaDtotest = readJson("TestCheckDoubleRegistration_riyoshaDto.json", new TypeToken<RiyoshaDtoTest>(){}.getType());
		RiyoshaDto riyoshaDto = new RiyoshaDto();
		riyoshaDto.setLoginId("sicvn1");
		riyoshaDto.setKannriCode(riyoshaDtotest.getKannriCode());
		riyoshaDto.setPassword(riyoshaDtotest.getPassword());
		riyoshaDto.setSelectedTorokuKubun(riyoshaDtotest.getSelectedTorokuKubun());
		riyoshaDto.setSelectedGinkoCode(riyoshaDtotest.getSelectedGinkoCode());
		riyoshaDto.setSelectedShitenCode(riyoshaDtotest.getSelectedShitenCode());
		riyoshaDto.setSelectedKozaShubetsu(riyoshaDtotest.getSelectedKozaShubetsu());
		riyoshaDto.setSelectedRiyoshaGroupCode(riyoshaDtotest.getSelectedRiyoshaGroupCode());
		riyoshaDto.setSelectedSoshinTiming(riyoshaDtotest.getSelectedSoshinTiming());
		riyoshaDto.setSelectedShinseiGroupCode(riyoshaDtotest.getSelectedShinseiGroupCode());
		riyoshaDto.setUserName(riyoshaDtotest.getUserName());
		riyoshaDto.setMaxKoseiinCode(riyoshaDtotest.getMaxKoseiinCode());
		riyoshaDto.setKoseiinJohoDto(riyoshaDtotest.getKoseiinJohoDto());
		riyoshaDto.setRiyoKanoShinseiGroupDto(riyoshaDtotest.getRiyoKanoShinseiGroupDto());
		riyoshaDto.setKanribetsuRiyoshaJohoDto(riyoshaDtotest.getKanribetsuRiyoshaJohoDto());
		riyoshaDto.setRyokinSetteiDto(riyoshaDtotest.getRyokinSetteiDto());
		riyoshaDto.setRiyoshaUketoriMailDto(riyoshaDtotest.getRiyoshaUketoriMailDto());
		// カレンダー用
		riyoshaDto.setDatepick(riyoshaDtotest.getDatepick());
		riyoshaDto.setDatepickStart(riyoshaDtotest.getDatepickStart());
		riyoshaDto.setDatepickEnd(riyoshaDtotest.getDatepickEnd());

		// 職員検索用
		//String loginId;
		riyoshaDto.setShokuinKanaName(riyoshaDtotest.getShokuinKanaName());
		riyoshaDto.setKanrimei(riyoshaDtotest.getKanrimei());


		List<String> updateCodes = new ArrayList<String>();
		updateCodes.add("8000");

		List<NijutorokuHanteiHani> nijutorokuHanteiHanis = new ArrayList<NijutorokuHanteiHani>();
		nijutorokuHanteiHanis.add(NijutorokuHanteiHani.DOITSU);

		params.add(riyoshaDto);
		//NijutorokuHanteiHani nijutorokuHanteiHani

		riyoshaUtilityLogic.checkDoubleRegistration(params.get(0), updateCodes.get(0), nijutorokuHanteiHanis.get(0));
	}

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestcheckDoubleRegistrationInit2.xlsx")
	public void TestCheckDoubleRegistration_Step3() throws Exception
	{
		List<RiyoshaDto> params = new ArrayList<RiyoshaDto>();
		RiyoshaDtoTest riyoshaDtotest = readJson("TestCheckDoubleRegistration_riyoshaDto.json", new TypeToken<RiyoshaDtoTest>(){}.getType());
		RiyoshaDto riyoshaDto = new RiyoshaDto();
		riyoshaDto.setLoginId("1");
		riyoshaDto.setKannriCode(riyoshaDtotest.getKannriCode());
		riyoshaDto.setPassword(riyoshaDtotest.getPassword());
		riyoshaDto.setSelectedTorokuKubun(riyoshaDtotest.getSelectedTorokuKubun());
		riyoshaDto.setSelectedGinkoCode(riyoshaDtotest.getSelectedGinkoCode());
		riyoshaDto.setSelectedShitenCode(riyoshaDtotest.getSelectedShitenCode());
		riyoshaDto.setSelectedKozaShubetsu(riyoshaDtotest.getSelectedKozaShubetsu());
		riyoshaDto.setSelectedRiyoshaGroupCode(riyoshaDtotest.getSelectedRiyoshaGroupCode());
		riyoshaDto.setSelectedSoshinTiming(riyoshaDtotest.getSelectedSoshinTiming());
		riyoshaDto.setSelectedShinseiGroupCode(riyoshaDtotest.getSelectedShinseiGroupCode());
		riyoshaDto.setUserName(riyoshaDtotest.getUserName());
		riyoshaDto.setMaxKoseiinCode(riyoshaDtotest.getMaxKoseiinCode());
		riyoshaDto.setKoseiinJohoDto(riyoshaDtotest.getKoseiinJohoDto());
		riyoshaDto.setRiyoKanoShinseiGroupDto(riyoshaDtotest.getRiyoKanoShinseiGroupDto());
		riyoshaDto.setKanribetsuRiyoshaJohoDto(riyoshaDtotest.getKanribetsuRiyoshaJohoDto());
		riyoshaDto.setRyokinSetteiDto(riyoshaDtotest.getRyokinSetteiDto());
		riyoshaDto.setRiyoshaUketoriMailDto(riyoshaDtotest.getRiyoshaUketoriMailDto());
		// カレンダー用
		riyoshaDto.setDatepick(riyoshaDtotest.getDatepick());
		riyoshaDto.setDatepickStart(riyoshaDtotest.getDatepickStart());
		riyoshaDto.setDatepickEnd(riyoshaDtotest.getDatepickEnd());

		// 職員検索用
		//String loginId;
		riyoshaDto.setShokuinKanaName(riyoshaDtotest.getShokuinKanaName());
		riyoshaDto.setKanrimei(riyoshaDtotest.getKanrimei());


		List<String> updateCodes = new ArrayList<String>();
		updateCodes.add("8000");

		List<NijutorokuHanteiHani> nijutorokuHanteiHanis = new ArrayList<NijutorokuHanteiHani>();
		nijutorokuHanteiHanis.add(NijutorokuHanteiHani.DOITSU);

		params.add(riyoshaDto);
		//NijutorokuHanteiHani nijutorokuHanteiHani

		try
		{
			riyoshaUtilityLogic.checkDoubleRegistration(params.get(0), updateCodes.get(0), nijutorokuHanteiHanis.get(0));
		}
		catch(Exception ex)
		{
			assertEquals("入力された利用者情報は既に登録されています。利用者情報を確認してください。",ex.getMessage());
		}
	}

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestcheckDoubleRegistrationInit2.xlsx")
	public void TestCheckDoubleRegistration_Step4() throws Exception
	{
		List<RiyoshaDto> params = new ArrayList<RiyoshaDto>();
		RiyoshaDtoTest riyoshaDtotest = readJson("TestCheckDoubleRegistration_riyoshaDto.json", new TypeToken<RiyoshaDtoTest>(){}.getType());
		RiyoshaDto riyoshaDto = new RiyoshaDto();
		riyoshaDto.setLoginId("sicvn");
		riyoshaDto.setKannriCode(riyoshaDtotest.getKannriCode());
		riyoshaDto.setPassword(riyoshaDtotest.getPassword());
		riyoshaDto.setSelectedTorokuKubun(riyoshaDtotest.getSelectedTorokuKubun());
		riyoshaDto.setSelectedGinkoCode(riyoshaDtotest.getSelectedGinkoCode());
		riyoshaDto.setSelectedShitenCode(riyoshaDtotest.getSelectedShitenCode());
		riyoshaDto.setSelectedKozaShubetsu(riyoshaDtotest.getSelectedKozaShubetsu());
		riyoshaDto.setSelectedRiyoshaGroupCode(riyoshaDtotest.getSelectedRiyoshaGroupCode());
		riyoshaDto.setSelectedSoshinTiming(riyoshaDtotest.getSelectedSoshinTiming());
		riyoshaDto.setSelectedShinseiGroupCode(riyoshaDtotest.getSelectedShinseiGroupCode());
		riyoshaDto.setUserName(riyoshaDtotest.getUserName());
		riyoshaDto.setMaxKoseiinCode(riyoshaDtotest.getMaxKoseiinCode());
		riyoshaDto.setKoseiinJohoDto(riyoshaDtotest.getKoseiinJohoDto());
		riyoshaDto.setRiyoKanoShinseiGroupDto(riyoshaDtotest.getRiyoKanoShinseiGroupDto());
		riyoshaDto.setKanribetsuRiyoshaJohoDto(riyoshaDtotest.getKanribetsuRiyoshaJohoDto());
		riyoshaDto.setRyokinSetteiDto(riyoshaDtotest.getRyokinSetteiDto());
		riyoshaDto.setRiyoshaUketoriMailDto(riyoshaDtotest.getRiyoshaUketoriMailDto());
		// カレンダー用
		riyoshaDto.setDatepick(riyoshaDtotest.getDatepick());
		riyoshaDto.setDatepickStart(riyoshaDtotest.getDatepickStart());
		riyoshaDto.setDatepickEnd(riyoshaDtotest.getDatepickEnd());

		// 職員検索用
		//String loginId;
		riyoshaDto.setShokuinKanaName(riyoshaDtotest.getShokuinKanaName());
		riyoshaDto.setKanrimei(riyoshaDtotest.getKanrimei());


		List<String> updateCodes = new ArrayList<String>();
		updateCodes.add("8000");

		List<NijutorokuHanteiHani> nijutorokuHanteiHanis = new ArrayList<NijutorokuHanteiHani>();
		nijutorokuHanteiHanis.add(NijutorokuHanteiHani.KONZAI);

		params.add(riyoshaDto);
		//NijutorokuHanteiHani nijutorokuHanteiHani

		try
		{
			riyoshaUtilityLogic.checkDoubleRegistration(params.get(0), updateCodes.get(0), nijutorokuHanteiHanis.get(0));
		}
		catch(Exception ex)
		{
			assertEquals("入力された構成員情報は既に他の利用者の構成員として登録されています。構成員情報を確認してください。",ex.getMessage());
		}
	}

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestcheckDoubleRegistrationInit.xlsx")
	public void TestCheckDoubleRegistration_Step5() throws Exception
	{
		List<RiyoshaDto> params = new ArrayList<RiyoshaDto>();
		RiyoshaDtoTest riyoshaDtotest = readJson("TestCheckDoubleRegistration_riyoshaDto.json", new TypeToken<RiyoshaDtoTest>(){}.getType());
		RiyoshaDto riyoshaDto = new RiyoshaDto();
		riyoshaDto.setLoginId("sicvn1");
		riyoshaDto.setKannriCode(riyoshaDtotest.getKannriCode());
		riyoshaDto.setPassword(riyoshaDtotest.getPassword());
		riyoshaDto.setSelectedTorokuKubun(riyoshaDtotest.getSelectedTorokuKubun());
		riyoshaDto.setSelectedGinkoCode(riyoshaDtotest.getSelectedGinkoCode());
		riyoshaDto.setSelectedShitenCode(riyoshaDtotest.getSelectedShitenCode());
		riyoshaDto.setSelectedKozaShubetsu(riyoshaDtotest.getSelectedKozaShubetsu());
		riyoshaDto.setSelectedRiyoshaGroupCode(riyoshaDtotest.getSelectedRiyoshaGroupCode());
		riyoshaDto.setSelectedSoshinTiming(riyoshaDtotest.getSelectedSoshinTiming());
		riyoshaDto.setSelectedShinseiGroupCode(riyoshaDtotest.getSelectedShinseiGroupCode());
		riyoshaDto.setUserName(riyoshaDtotest.getUserName());
		riyoshaDto.setMaxKoseiinCode(riyoshaDtotest.getMaxKoseiinCode());
		riyoshaDto.setKoseiinJohoDto(riyoshaDtotest.getKoseiinJohoDto());
		riyoshaDto.setRiyoKanoShinseiGroupDto(riyoshaDtotest.getRiyoKanoShinseiGroupDto());
		riyoshaDto.setKanribetsuRiyoshaJohoDto(riyoshaDtotest.getKanribetsuRiyoshaJohoDto());
		riyoshaDto.setRyokinSetteiDto(riyoshaDtotest.getRyokinSetteiDto());
		riyoshaDto.setRiyoshaUketoriMailDto(riyoshaDtotest.getRiyoshaUketoriMailDto());
		// カレンダー用
		riyoshaDto.setDatepick(riyoshaDtotest.getDatepick());
		riyoshaDto.setDatepickStart(riyoshaDtotest.getDatepickStart());
		riyoshaDto.setDatepickEnd(riyoshaDtotest.getDatepickEnd());

		// 職員検索用
		//String loginId;
		riyoshaDto.setShokuinKanaName(riyoshaDtotest.getShokuinKanaName());
		riyoshaDto.setKanrimei(riyoshaDtotest.getKanrimei());


		List<String> updateCodes = new ArrayList<String>();
		updateCodes.add("1");

		List<NijutorokuHanteiHani> nijutorokuHanteiHanis = new ArrayList<NijutorokuHanteiHani>();
		nijutorokuHanteiHanis.add(NijutorokuHanteiHani.NONE);

		params.add(riyoshaDto);
		//NijutorokuHanteiHani nijutorokuHanteiHani

		try
		{
		riyoshaUtilityLogic.checkDoubleRegistration(params.get(0), updateCodes.get(0), nijutorokuHanteiHanis.get(0));
		}
		catch(Exception ex)
		{
			assertEquals("入力されたログインIDは既に使用されています。",ex.getMessage());
		}


	}

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestcheckDoubleRegistrationInit.xlsx")
	public void TestCheckDoubleRegistration_Step6() throws Exception
	{
		List<RiyoshaDto> params = new ArrayList<RiyoshaDto>();
		RiyoshaDtoTest riyoshaDtotest = readJson("TestCheckDoubleRegistration_riyoshaDto.json", new TypeToken<RiyoshaDtoTest>(){}.getType());
		RiyoshaDto riyoshaDto = new RiyoshaDto();
		riyoshaDto.setLoginId("sicvn123");
		riyoshaDto.setKannriCode(riyoshaDtotest.getKannriCode());
		riyoshaDto.setPassword(riyoshaDtotest.getPassword());
		riyoshaDto.setSelectedTorokuKubun(riyoshaDtotest.getSelectedTorokuKubun());
		riyoshaDto.setSelectedGinkoCode(riyoshaDtotest.getSelectedGinkoCode());
		riyoshaDto.setSelectedShitenCode(riyoshaDtotest.getSelectedShitenCode());
		riyoshaDto.setSelectedKozaShubetsu(riyoshaDtotest.getSelectedKozaShubetsu());
		riyoshaDto.setSelectedRiyoshaGroupCode(riyoshaDtotest.getSelectedRiyoshaGroupCode());
		riyoshaDto.setSelectedSoshinTiming(riyoshaDtotest.getSelectedSoshinTiming());
		riyoshaDto.setSelectedShinseiGroupCode(riyoshaDtotest.getSelectedShinseiGroupCode());
		riyoshaDto.setUserName(riyoshaDtotest.getUserName());
		riyoshaDto.setMaxKoseiinCode(riyoshaDtotest.getMaxKoseiinCode());
		riyoshaDto.setKoseiinJohoDto(riyoshaDtotest.getKoseiinJohoDto());
		riyoshaDto.setRiyoKanoShinseiGroupDto(riyoshaDtotest.getRiyoKanoShinseiGroupDto());
		riyoshaDto.setKanribetsuRiyoshaJohoDto(riyoshaDtotest.getKanribetsuRiyoshaJohoDto());
		riyoshaDto.setRyokinSetteiDto(riyoshaDtotest.getRyokinSetteiDto());
		riyoshaDto.setRiyoshaUketoriMailDto(riyoshaDtotest.getRiyoshaUketoriMailDto());
		// カレンダー用
		riyoshaDto.setDatepick(riyoshaDtotest.getDatepick());
		riyoshaDto.setDatepickStart(riyoshaDtotest.getDatepickStart());
		riyoshaDto.setDatepickEnd(riyoshaDtotest.getDatepickEnd());

		// 職員検索用
		//String loginId;
		riyoshaDto.setShokuinKanaName(riyoshaDtotest.getShokuinKanaName());
		riyoshaDto.setKanrimei(riyoshaDtotest.getKanrimei());


		List<String> updateCodes = new ArrayList<String>();
		updateCodes.add("1");

		List<NijutorokuHanteiHani> nijutorokuHanteiHanis = new ArrayList<NijutorokuHanteiHani>();
		nijutorokuHanteiHanis.add(NijutorokuHanteiHani.NONE);

		params.add(riyoshaDto);
		//NijutorokuHanteiHani nijutorokuHanteiHani

		try
		{
		riyoshaUtilityLogic.checkDoubleRegistration(params.get(0), updateCodes.get(0), nijutorokuHanteiHanis.get(0));
		}
		catch(Exception ex)
		{
			assertEquals("入力されたログインIDは既に使用されています。",ex.getMessage());
		}
	}
}

