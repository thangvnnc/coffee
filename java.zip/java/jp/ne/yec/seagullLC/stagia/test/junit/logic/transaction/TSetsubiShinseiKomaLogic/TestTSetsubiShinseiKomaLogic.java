package jp.ne.yec.seagullLC.stagia.test.junit.logic.transaction.TSetsubiShinseiKomaLogic;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.beans.shinsei.SetsubiShinseiKomaDto;
import jp.ne.yec.seagullLC.stagia.beans.shinsei.ShinseiDto;
import jp.ne.yec.seagullLC.stagia.beans.shinsei.ShinseiMeisaiDto;
import jp.ne.yec.seagullLC.stagia.entity.TSetsubiShinseiKoma;
import jp.ne.yec.seagullLC.stagia.logic.transaction.TSetsubiShinseiKomaLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = { "classpath:TestApplicationContext.xml" })
@WebAppConfiguration
public class TestTSetsubiShinseiKomaLogic extends JunitBase {

	@Autowired
	TSetsubiShinseiKomaLogic tSetsubiShinseiKomaLogic;

	@Test
	@DisplayName("引数の申請明細IDリストを基に設備情報を取得し、設備予約があるIDリストを返却します.")
	@TestInitDataFile("TestGetIdListInit.xlsx")
	public void TestgetTSetsubiShinseiKomaList() throws Exception {
		List<Integer> meisaiIdList = new ArrayList<>();
		meisaiIdList.add(37830);
		meisaiIdList.add(37832);
		meisaiIdList.add(37833);
		
		List<TSetsubiShinseiKoma> ret = tSetsubiShinseiKomaLogic.getTSetsubiShinseiKomaList(meisaiIdList);
		exportJsonData(ret, "TestgetTSetsubiShinseiKomaList.json");
	}

	@Test
	@DisplayName("引数の明細IDを基にT設備申請の情報を取得し、設備申請情報Dtoリストを返却します.")
	@TestInitDataFile("TestgetUseSetsubiInit.xlsx")
	public void TestgetUseSetsubi1() throws Exception {
		short startTime = 1100;
		short endTime = 1200;
		
		ShinseiDto shinseiDto = new ShinseiDto();
		
		shinseiDto.setKanriCode((short)10);
		shinseiDto.setShinseiNumber(445);
		shinseiDto.setVersion(1);

		ShinseiMeisaiDto meisaiDto = new ShinseiMeisaiDto();
		meisaiDto.setKanriCode((short)10);
		meisaiDto.setShinseiNumber(444);
		meisaiDto.setBashoCode((short)10);
		
		SimpleDateFormat sd = new SimpleDateFormat("yyyy/M/d");
		Date shiyoDate = sd.parse("2018/4/19");
		meisaiDto.setShiyoDate(shiyoDate);
		
		List<SetsubiShinseiKomaDto> ret = tSetsubiShinseiKomaLogic.getUseSetsubi(shinseiDto, meisaiDto,
				startTime, endTime);
		exportJsonData(ret, "TestgetUseSetsubi1.json");
	}
	
	@Test
	@DisplayName("引数の明細IDを基にT設備申請の情報を取得し、設備申請情報Dtoリストを返却します.")
	@TestInitDataFile("TestgetUseSetsubiInit.xlsx")
	public void TestgetUseSetsubi2() throws Exception {
		short startTime = 1100;
		short endTime = 1200;

		ShinseiDto shinseiDto = new ShinseiDto();
		
		shinseiDto.setKanriCode((short)10);
		shinseiDto.setShinseiNumber(445);

		ShinseiMeisaiDto meisaiDto = new ShinseiMeisaiDto();
		meisaiDto.setKanriCode((short)10);
		meisaiDto.setShinseiNumber(444);
		meisaiDto.setBashoCode((short)10);
		
		SimpleDateFormat sd = new SimpleDateFormat("yyyy/M/d");
		Date shiyoDate = sd.parse("2018/4/19");
		meisaiDto.setShiyoDate(shiyoDate);
		
		List<SetsubiShinseiKomaDto> ret = tSetsubiShinseiKomaLogic.getUseSetsubi(shinseiDto, meisaiDto,
				startTime, endTime);
		exportJsonData(ret, "TestgetUseSetsubi2.json");
	}
	
	@Test
	@DisplayName("引数の明細IDリストを基にT設備申請コマ情報を取得し返却します.")
	public void TestgetDao() throws Exception {
		GenericDao<TSetsubiShinseiKoma, ?> ret = tSetsubiShinseiKomaLogic.getDao() ;
	 //Stagia2 - TestJUnit 2018/06/21
	}
}
