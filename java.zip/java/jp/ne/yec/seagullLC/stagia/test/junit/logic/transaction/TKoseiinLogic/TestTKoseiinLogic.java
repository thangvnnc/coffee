package jp.ne.yec.seagullLC.stagia.test.junit.logic.transaction.TKoseiinLogic;

import static org.junit.Assert.*;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.entity.TKoseiin;
import jp.ne.yec.seagullLC.stagia.logic.transaction.TKoseiinLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestTKoseiinLogic extends JunitBase {

	@Autowired
	TKoseiinLogic tKoseiinLogic;

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetTKoseiinListInit.xlsx")
	public void TestgetTKoseiinList() throws Exception
	{
		String loginId = "100";
		List<TKoseiin> ret =  tKoseiinLogic.getTKoseiinList(loginId);
		exportJsonData(ret, "TestgetTKoseiinList.json");
	}

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetTKoseiinList_ListInit.xlsx")
	public void TestgetTKoseiinList_List() throws Exception
	{
		String kLoginId = "100";
		String kLoginIdMuchSelect = "1";
		String kYakuwariSelect = "0";
		String kKanaName = "u";
		String kYubinBango = "0";
		String kJusho = "h";
		String kDenwaBango = "8";

		List<TKoseiin> ret =  tKoseiinLogic.getTKoseiinList(kLoginId,kLoginIdMuchSelect,kYakuwariSelect,
					kKanaName, kYubinBango,kJusho, kDenwaBango);
		exportJsonData(ret, "TestgetTKoseiinList_List.json");
	}
	
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetTKoseiinList_ListInit.xlsx")
	public void TestgetTKoseiinList_List2() throws Exception
	{
		String kLoginId = null;
		String kLoginIdMuchSelect = null;
		String kYakuwariSelect = "0";
		String kKanaName = "u";
		String kYubinBango = "0";
		String kJusho = "h";
		String kDenwaBango = "8";

		List<TKoseiin> ret =  tKoseiinLogic.getTKoseiinList(kLoginId,kLoginIdMuchSelect,kYakuwariSelect,
					kKanaName, kYubinBango,kJusho, kDenwaBango);
		exportJsonData(ret, "TestgetTKoseiinList_List2.json");
	}
	
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetTKoseiinList_ListInit.xlsx")
	public void TestgetTKoseiinList_List3() throws Exception
	{
		String kLoginId = "100";
		String kLoginIdMuchSelect = null;
		String kYakuwariSelect = "";
		String kKanaName = "";
		String kYubinBango = "";
		String kJusho = "";
		String kDenwaBango = "";

		List<TKoseiin> ret =  tKoseiinLogic.getTKoseiinList(kLoginId,kLoginIdMuchSelect,kYakuwariSelect,
					kKanaName, kYubinBango,kJusho, kDenwaBango);
		exportJsonData(ret, "TestgetTKoseiinList_List3.json");
	}
	
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetTKoseiinList_ListInit.xlsx")
	public void TestgetTKoseiinList_List4() throws Exception
	{
		String kLoginId = null;
		String kLoginIdMuchSelect = "1";
		String kYakuwariSelect = "";
		String kKanaName = "";
		String kYubinBango = "";
		String kJusho = "";
		String kDenwaBango = "";

		List<TKoseiin> ret =  tKoseiinLogic.getTKoseiinList(kLoginId,kLoginIdMuchSelect,kYakuwariSelect,
					kKanaName, kYubinBango,kJusho, kDenwaBango);
		exportJsonData(ret, "TestgetTKoseiinList_List4.json");
	}
	
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetTKoseiinList_ListInit.xlsx")
	public void TestgetTKoseiinList_List5() throws Exception
	{
		String kLoginId = "100";
		String kLoginIdMuchSelect = "0";
		String kYakuwariSelect = "";
		String kKanaName = "";
		String kYubinBango = "";
		String kJusho = "";
		String kDenwaBango = "";

		List<TKoseiin> ret =  tKoseiinLogic.getTKoseiinList(kLoginId,kLoginIdMuchSelect,kYakuwariSelect,
					kKanaName, kYubinBango,kJusho, kDenwaBango);
		exportJsonData(ret, "TestgetTKoseiinList_List5.json");
	}
	
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetTKoseiinList_ListInit.xlsx")
	public void TestgetTKoseiinList_List6() throws Exception
	{
		String kLoginId = "100";
		String kLoginIdMuchSelect = "2";
		String kYakuwariSelect = "";
		String kKanaName = "";
		String kYubinBango = "";
		String kJusho = "";
		String kDenwaBango = "";

		List<TKoseiin> ret =  tKoseiinLogic.getTKoseiinList(kLoginId,kLoginIdMuchSelect,kYakuwariSelect,
					kKanaName, kYubinBango,kJusho, kDenwaBango);
		exportJsonData(ret, "TestgetTKoseiinList_List6.json");
	}

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetKoseiinForOverLapCheckInit.xlsx")
	public void TestgetKoseiinForOverLapCheck1() throws Exception
	{
		String loginId = "100";
		String checkNameKana = "u";
		String checkName = "u";
		Date checkBirthDay = new Date();
		DateFormat df = new SimpleDateFormat("yyyy/M/d");
		checkBirthDay = df.parse("2017/8/7");
		String checkTel1 = "8";
		String checkTel2 = "0456645383";
		String checkZip = "9";
		String checkAddr1 = "j";
		String checkAddr2 = "test45556679";
		String checkMailAddr = "mail-address@test.jp";

		int ret = tKoseiinLogic.getKoseiinForOverLapCheck(loginId,checkNameKana,checkName,checkBirthDay,
				checkTel1,checkTel2,checkZip, checkAddr1,checkAddr2,checkMailAddr);
		assertEquals(0, ret);
	}
	
	@Test
	@TestInitDataFile("TestgetKoseiinForOverLapCheckInit.xlsx")
	public void TestgetKoseiinForOverLapCheck2() throws Exception
	{
		String loginId = "100";
		String checkNameKana = "";
		String checkName = "";
		Date checkBirthDay = null;
		String checkTel1 = "";
		String checkTel2 = "";
		String checkZip = "";
		String checkAddr1 = "";
		String checkAddr2 = "";
		String checkMailAddr = "";

		int ret = tKoseiinLogic.getKoseiinForOverLapCheck(loginId,checkNameKana,checkName,checkBirthDay,
				checkTel1,checkTel2,checkZip, checkAddr1,checkAddr2,checkMailAddr);
		assertEquals(0, ret);
	}
	
	@Test
	public void TestgetDao() throws Exception
	{
		GenericDao<TKoseiin, ?> ret =  tKoseiinLogic.getDao() ;
	}
}