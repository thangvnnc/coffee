package jp.ne.yec.seagullLC.stagia.test.junit.logic.master.MKoenJikanLogic;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.entity.MKoenJikan;
import jp.ne.yec.seagullLC.stagia.logic.master.MKoenJikanLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestMKoenJikanLogic extends JunitBase {

	@Autowired
	MKoenJikanLogic mKyukanLogic;

	@Test
	@DisplayName("引数の管理コード、施設コード、貸出単位コードを検索条件として貸出単位マスタを取得し返却します")
	@TestInitDataFile("TestgetMKoenJikan.xlsx")
	public void TestgetMKoenJikan() throws Exception
	{
		Short kanriCodes = 10;
		Short bashoCodes = 10;
		Short koenJikanCodes = 1;
		MKoenJikan ret = mKyukanLogic.getMKoenJikan(kanriCodes, bashoCodes, koenJikanCodes);
		exportJsonData(ret, "TestgetMKoenJikan.json");
	}
	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	public void TestgetDao() throws Exception
	{
		GenericDao<MKoenJikan, ?> ret = mKyukanLogic.getDao();
	}
}