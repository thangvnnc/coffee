package jp.ne.yec.seagullLC.stagia.test.junit.logic.master.MChusenGroupKanrenLogic;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.entity.MChusenGroupKanren;
import jp.ne.yec.seagullLC.stagia.logic.master.MChusenGroupKanrenLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestMChusenGroupKanrenLogic extends JunitBase {

	@Autowired
	MChusenGroupKanrenLogic mChusenGroupKanrenLogic;

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	//@TestInitDataFile("TestgetMBashoList.xlsx")
	public void TestgetDao() throws Exception
	{
		GenericDao<MChusenGroupKanren, ?> ret = mChusenGroupKanrenLogic.getDao();
	}

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestgetMChusenGroupKanrenByChusenGroupCode.xlsx")
	public void TestgetMChusenGroupKanrenByChusenGroupCode() throws Exception
	{
		List<Short> chusenGroupCodes = new ArrayList<Short> ();
		Short chusenGroupCode = 12;
		chusenGroupCodes.add(chusenGroupCode);
		List<List<MChusenGroupKanren>> mList = new ArrayList<> ();
		List<MChusenGroupKanren> ret = mChusenGroupKanrenLogic.getMChusenGroupKanrenByChusenGroupCode(chusenGroupCodes);
		exportJsonData(ret, "TestgetMChusenGroupKanrenByChusenGroupCode.json");
	}

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestgetMChusenGroupKanrenByChusenGroupCode.xlsx")
	public void TestgetMChusenGroupKanrenByKanriCode() throws Exception
	{
		List<Short> kanriCodes = new ArrayList<Short> ();
		Short kanriCode = 10;
		kanriCodes.add(kanriCode);
		List<MChusenGroupKanren> ret = mChusenGroupKanrenLogic.getMChusenGroupKanrenByKanriCode(kanriCodes);
		exportJsonData(ret, "TestgetMChusenGroupKanrenByKanriCode.json");
	}
}