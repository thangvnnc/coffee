package jp.ne.yec.seagullLC.stagia.test.junit.support;

import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;
@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestSupport extends JunitBase {

	/**
	 * Đọc file txt ra map<T, List<U>>
	 * @throws Exception
	 *
	 * Chú ý các kiểu dữ liệu hổ trợ String, Short, Integer, Long, Double, Float, Boolean
	 */
	@Test
	public void sampleReadMapFile() throws Exception {
		Map<Boolean, List<String>> map = readMapFile("mapkeylist.txt", Boolean.class, String.class);
		List<String> list = map.get(true);
		List<String> list2 = map.get(false);
		System.out.println("Log list item 0:" + list.get(0));
		System.out.println("Log list2 item 0:" + list2.get(0));
	}

}
