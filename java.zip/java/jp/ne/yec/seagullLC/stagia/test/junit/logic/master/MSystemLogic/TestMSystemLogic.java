package jp.ne.yec.seagullLC.stagia.test.junit.logic.master.MSystemLogic;

import static org.junit.Assert.*;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.entity.MSystem;
import jp.ne.yec.seagullLC.stagia.logic.master.MSystemLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestMSystemLogic extends JunitBase {

	@Autowired
	MSystemLogic mSystemLogic;

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestupdateMSystem.xlsx")
	public void TestgetMSystem() throws Exception
	{
		MSystem  ret = mSystemLogic.getMSystem();
		exportJsonData(ret, "TestgetMSystem.json");
	}

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestupdateMSystem.xlsx")
	public void TestupdateMSystem() throws Exception
	{
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/M/d HH:mm");
		Date dateCreate = new Date();
		dateCreate = dateFormat.parse("2018/6/15 14:15");
		long timeCreate = dateCreate.getTime();
		Timestamp tCreate = new Timestamp(timeCreate);

		Date dateUpdate = new Date();
		dateUpdate = dateFormat.parse("2018/6/15 15:38");
		long timeUpdate= dateUpdate.getTime();
		Timestamp tUpdate = new Timestamp(timeUpdate);
		
		String updatedBy = "0-378";
		MSystem mSystems = new MSystem();
		mSystems.setVersion(1);
		mSystems.setUserName("YEC");
		mSystems.setRiyotorokuShoninsha("承認者");
		mSystems.setServiceStartTime((short)0);
		mSystems.setServiceEndTime((short)0);
		mSystems.setUketsukeStartTime((short)0);
		mSystems.setUketsukeEndTime((short)0);
		mSystems.setNijutorokuHanteiHani("1");
		mSystems.setNinzuTani("人");
		mSystems.setRirekiDataHojiKikan((short)12);
		mSystems.setRiyoshaYukonensuKiteichi((short)12);
		mSystems.setRiyoshaGroupKiteichiWeb((short)1);
		mSystems.setEnabledRiyoshaTorokuWeb(true);
		mSystems.setEnabledRiyoshaShuseiWeb(true);
		mSystems.setEnabledRirekiWeb(true);
		mSystems.setEnabledAkijokyoWeb(true);
		mSystems.setEnabledShinseiWeb(true);
		mSystems.setCreatedAt(tCreate);
		mSystems.setCreatedBy("0-3718");
		mSystems.setUpdatedAt(tUpdate);
		mSystems.setUpdatedBy("0-3718");
		
		mSystemLogic.updateMSystem(mSystems, updatedBy);
	}
	
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestupdateMSystem.xlsx")
	public void TestupdateMSystem2() throws Exception
	{
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/M/d HH:mm");
		Date dateCreate = new Date();
		dateCreate = dateFormat.parse("2018/6/15 14:15");
		long timeCreate = dateCreate.getTime();
		Timestamp tCreate = new Timestamp(timeCreate);

		Date dateUpdate = new Date();
		dateUpdate = dateFormat.parse("2018/6/15 15:38");
		long timeUpdate= dateUpdate.getTime();
		Timestamp tUpdate = new Timestamp(timeUpdate);
		
		String updatedBy = "0-378";
		MSystem mSystems = new MSystem();
		mSystems.setVersion(0);
		mSystems.setUserName("YEC");
		mSystems.setRiyotorokuShoninsha("承認者");
		mSystems.setServiceStartTime((short)0);
		mSystems.setServiceEndTime((short)0);
		mSystems.setUketsukeStartTime((short)0);
		mSystems.setUketsukeEndTime((short)0);
		mSystems.setNijutorokuHanteiHani("1");
		mSystems.setNinzuTani("人");
		mSystems.setRirekiDataHojiKikan((short)12);
		mSystems.setRiyoshaYukonensuKiteichi((short)12);
		mSystems.setRiyoshaGroupKiteichiWeb((short)1);
		mSystems.setEnabledRiyoshaTorokuWeb(true);
		mSystems.setEnabledRiyoshaShuseiWeb(true);
		mSystems.setEnabledRirekiWeb(true);
		mSystems.setEnabledAkijokyoWeb(true);
		mSystems.setEnabledShinseiWeb(true);
		mSystems.setCreatedAt(tCreate);
		mSystems.setCreatedBy("0-3718");
		mSystems.setUpdatedAt(tUpdate);
		mSystems.setUpdatedBy("0-3718");
		
		try
		{
			mSystemLogic.updateMSystem(mSystems, updatedBy);
		}
		catch (Exception e) {
			
			String messageExp = "m_system Optimistic lock error";
			assertEquals(messageExp, e.getMessage());
		}
		
	}
	
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	public void TestgetDao() throws Exception
	{
		GenericDao<MSystem, ?> ret = mSystemLogic.getDao();
	}
}