package jp.ne.yec.seagullLC.stagia.test.junit.logic.master.MSystemLogic;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.entity.MSystem;
import jp.ne.yec.seagullLC.stagia.logic.master.MSystemLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestMSystemLogic extends JunitBase {

	@Autowired
	MSystemLogic mSystemLogic;

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestupdateMSystem.xlsx")
	public void TestgetMSystem() throws Exception
	{
		List<MSystem> exports = new ArrayList<>();
		MSystem  ret = mSystemLogic.getMSystem();
		exports.add(ret);
		exportJsonData(exports, "TestgetMSystem.json");
	}

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestupdateMSystem.xlsx")
	public void TestupdateMSystem() throws Exception
	{
		List<String> updatedBys = new ArrayList<>();
		updatedBys.add("0-3718");

		MSystem mSystems = mSystemLogic.getMSystem();
		for(int item = 0; item < updatedBys.size(); item ++)
		{
			mSystemLogic.updateMSystem(mSystems, updatedBys.get(item));
		}
	}
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	public void TestgetDao() throws Exception
	{
		GenericDao<MSystem, ?> ret = mSystemLogic.getDao();
	}
}