package jp.ne.yec.seagullLC.stagia.test.junit.logic.master.MRyokinKeisanShikiLogic;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.entity.MRyokinKeisanShiki;
import jp.ne.yec.seagullLC.stagia.logic.master.MRyokinKeisanShikiLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestMRyokinKeisanShikiLogic extends JunitBase {

	@Autowired
	MRyokinKeisanShikiLogic mRyokinKeisanShikiLogic;


	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetMRyokinKeisanShiki_List.xlsx")
	public void TestgetMRyokinKeisanShiki() throws Exception
	{
		Short kanriCode =  10;
		List<MRyokinKeisanShiki> ret =  mRyokinKeisanShikiLogic.getMRyokinKeisanShiki(kanriCode);
		exportJsonData(ret, "TestgetMKashidashiTani_map.json");
	}

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetMRyokinKeisanShiki_List.xlsx")
	public void TestgetMRyokinKeisanShiki_List() throws Exception
	{
		List<Short> kanriCodes =  new ArrayList<Short>();
		Short kanriCode = 10;
		kanriCodes.add(kanriCode);
		List<MRyokinKeisanShiki> ret = mRyokinKeisanShikiLogic.getMRyokinKeisanShiki(kanriCodes);
		exportJsonData(ret, "TestgetMRyokinKeisanShiki_List.json");
	}

	@Test
	@DisplayName("検索条件なしで場所マスタを取得し、返却します")
	@TestInitDataFile("TestgetMRyokinKeisanShiki_List.xlsx")
	public void TestInsertMRyokinKeisanShiki() throws Exception
	{
		String loginId = "123123123";
	
		List<MRyokinKeisanShiki> mRyokinKeisanShikis = new ArrayList<>();
		MRyokinKeisanShiki mRyokinKeisanShiki = new MRyokinKeisanShiki();
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/M/d HH:mm");
		Date dateCreate = new Date();
		dateCreate = dateFormat.parse("2018/3/9 18:09");
		long timeCreate = dateCreate.getTime();
		Timestamp tCreate = new Timestamp(timeCreate);

		Date dateUpdate = new Date();
		dateUpdate = dateFormat.parse("2018/3/9 18:09");
		long timeUpdate= dateUpdate.getTime();
		Timestamp tUpdate = new Timestamp(timeUpdate);
		
		mRyokinKeisanShiki.setKanriCode((short)10);
		mRyokinKeisanShiki.setKeisanTani("0");
		mRyokinKeisanShiki.setKeisanKomokuCode((short)5);
		mRyokinKeisanShiki.setCell("G6");
		mRyokinKeisanShiki.setKeisanShiki("G5*E6");
		mRyokinKeisanShiki.setCreatedAt(tCreate);
		mRyokinKeisanShiki.setCreatedBy("hirata");
		mRyokinKeisanShiki.setUpdatedAt(tUpdate);
		mRyokinKeisanShiki.setUpdatedBy("hirata");
		mRyokinKeisanShiki.setVersion(1);
		
		mRyokinKeisanShikis.add(mRyokinKeisanShiki);
		
		mRyokinKeisanShikiLogic.insertMRyokinKeisanShiki(mRyokinKeisanShikis, loginId);
	}
	@Test
	@DisplayName("検索条件なしで場所マスタを取得し、返却します")
	//@TestInitDataFile("TestgetMBashoList.xlsx")
	public void TestgetDao() throws Exception
	{
		GenericDao<MRyokinKeisanShiki, ?> ret= mRyokinKeisanShikiLogic.getDao();
	}
}