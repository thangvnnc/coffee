package jp.ne.yec.seagullLC.stagia.test.junit.logic.master.MFurikomisakiKozaLogic;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.entity.MFurikomisakiKoza;
import jp.ne.yec.seagullLC.stagia.logic.master.MFurikomisakiKozaLogic;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestMFurikomisakiKozaLogic extends JunitBase {

	@Autowired
	MFurikomisakiKozaLogic mFurikomisakiKozaLogic;

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	//@TestInitDataFile("TestgetMBashoList.xlsx")
	public void TestgetDao() throws Exception
	{
		GenericDao<MFurikomisakiKoza, ?>  ret = mFurikomisakiKozaLogic.getDao();
	}
}