package jp.ne.yec.seagullLC.stagia.test.junit.logic.transaction.TRiyoshaLogic;

import static org.junit.Assert.*;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.beans.enums.JokenHukumu;
import jp.ne.yec.seagullLC.stagia.beans.riyosha.RiyoshaDto;
import jp.ne.yec.seagullLC.stagia.beans.shokai.SearchRiyoshaConditionsDto;
import jp.ne.yec.seagullLC.stagia.entity.TRiyosha;
import jp.ne.yec.seagullLC.stagia.logic.transaction.TRiyoshaLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestTRiyoshaLogic extends JunitBase {

	@Autowired
	TRiyoshaLogic tRiyoshaLogic;
	@Test
	@TestInitDataFile("TestgetTRiyoshaInit.xlsx")
	public void TestgetTRiyosha() throws Exception
	{
		String loginId = "1";
		TRiyosha ret = tRiyoshaLogic.getTRiyosha(loginId);
		exportJsonData(ret, "TestgetTRiyosha.json");
	}

	@Test
	@TestInitDataFile("TestgetRiyoshaKozaInfoCountInit.xlsx")
	public void TestgetRiyoshaKozaInfoCount() throws Exception
	{
		long ret =  tRiyoshaLogic.getRiyoshaKozaInfoCount();
		assertEquals(2, ret);
	}

	@Test
	@TestInitDataFile("TestgetRiyoshaKoseiinCountInit.xlsx")
	public void TestgetRiyoshaKoseiinCount() throws Exception
	{
		long ret = tRiyoshaLogic.getRiyoshaKoseiinCount();
		assertEquals(0, ret);
	}

	@Test
	@TestInitDataFile("TestgetRiyoshaForOverLapCheckInit.xlsx")
	public void TestgetRiyoshaForOverLapCheck() throws Exception
	{
		String loginKind = "0";

		String loginId = "1";

		String checkNameKana = "ジュウミンテストリヨウシャ";

		String checkName = "test";

		SimpleDateFormat sd = new SimpleDateFormat("yyyy/M/d");
		Date birthDay = new Date();
		birthDay = sd.parse("1969/9/10");

		String checkTel1 = "0456645381";

		String checkTel2 = "0456645381";

		String checkZip = "2210001";

		String checkAddr1 = "test45556677";

		String checkAddr2 = "test45556677";

		String checkMailAddr = "mail-address@test.jp";

		Integer ret =  tRiyoshaLogic.getRiyoshaForOverLapCheck(loginKind,loginId,
				checkNameKana, checkName, birthDay, checkTel1, checkTel2, checkZip,
				checkAddr1, checkAddr2, checkMailAddr);

		Integer expected = 0;

		assertEquals(expected, ret);
	}

	@Test
	@TestInitDataFile("TestgetRiyoshaListByDispConditionInit.xlsx")
	public void TestgetRiyoshaListByDispCondition1() throws Exception
	{
		SearchRiyoshaConditionsDto searchRiyoshaConditionsDto = new SearchRiyoshaConditionsDto();

		searchRiyoshaConditionsDto.setRLoginId("2");
		searchRiyoshaConditionsDto.setLoginIdMuchSelect(JokenHukumu.ICCHI.getCode());
		searchRiyoshaConditionsDto.setShiyoMokutekiCd((short)1030);
		searchRiyoshaConditionsDto.setRShiyoNinzu(0);

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy/M/d");
		LocalDate createdStartDate = LocalDate.parse("2017/11/29",formatter);
		searchRiyoshaConditionsDto.setCreatedStartDate(createdStartDate);

		LocalDate createdEndDate = LocalDate.parse("2017/12/1",formatter);
		searchRiyoshaConditionsDto.setCreatedEndDate(createdEndDate);

		LocalDate yukokikanStartDate = LocalDate.parse("2017/4/1",formatter);
		searchRiyoshaConditionsDto.setYukokikanStartDate(yukokikanStartDate);

		LocalDate yukokikanEndDate = LocalDate.parse("2020/3/31",formatter);
		searchRiyoshaConditionsDto.setYukokikanEndDate(yukokikanEndDate);

		LocalDate shinseiTeishiStartDate = LocalDate.parse("2017/12/12",formatter);
		searchRiyoshaConditionsDto.setShinseiTeishiStartDate(shinseiTeishiStartDate);

		String shinseiTeishiEndDate = "2017/12/16";
		LocalDate shinseiTeishiStartLocalDate = LocalDate.parse(shinseiTeishiEndDate,formatter);
		searchRiyoshaConditionsDto.setRShinseiTeishiEndDate(shinseiTeishiEndDate);
		searchRiyoshaConditionsDto.setShinseiTeishiEndDate(shinseiTeishiStartLocalDate);

		searchRiyoshaConditionsDto.setPenaltySelect("1");
		searchRiyoshaConditionsDto.setRKanaName("ジュウミンテストリヨウシャ");
		searchRiyoshaConditionsDto.setRYubinBango("2210001");
		searchRiyoshaConditionsDto.setRJusho("横浜市中区");
		searchRiyoshaConditionsDto.setRDenwaBango("0456645381");
		searchRiyoshaConditionsDto.setGinkoCode((short)1);
		searchRiyoshaConditionsDto.setShitenCode((short)1);
		searchRiyoshaConditionsDto.setKozaMeigininKanaName("ﾒｲｷﾞﾆﾝ");
		searchRiyoshaConditionsDto.setKozaShubetsu("1");
		searchRiyoshaConditionsDto.setKoseiinYakuwari("0");
		searchRiyoshaConditionsDto.setRKoseiinKanaName("u");
		searchRiyoshaConditionsDto.setRKoseiinYubinBango("0");
		searchRiyoshaConditionsDto.setRKoseiinJusho("h");
		searchRiyoshaConditionsDto.setRKoseiinDenwaBango("8");

		List<RiyoshaDto> ret = tRiyoshaLogic.getRiyoshaListByDispCondition(searchRiyoshaConditionsDto);
		exportJsonDataIfMultipleFields(ret, "TestgetRiyoshaListByDispCondition1.json");
	}



	@Test
	@TestInitDataFile("TestgetRiyoshaListByDispConditionInit2.xlsx")
	public void TestgetRiyoshaListByDispCondition2() throws Exception
	{
		SearchRiyoshaConditionsDto searchRiyoshaConditionsDto = new SearchRiyoshaConditionsDto();

		searchRiyoshaConditionsDto.setRLoginId("2");
		searchRiyoshaConditionsDto.setLoginIdMuchSelect(JokenHukumu.HUKUMU.getCode());
		searchRiyoshaConditionsDto.setShiyoMokutekiCd((short)1030);
		searchRiyoshaConditionsDto.setRShiyoNinzu(0);

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy/M/d");
		LocalDate createdStartDate = LocalDate.parse("2017/11/29",formatter);
		searchRiyoshaConditionsDto.setCreatedStartDate(createdStartDate);

		LocalDate createdEndDate = LocalDate.parse("2017/12/1",formatter);
		searchRiyoshaConditionsDto.setCreatedEndDate(createdEndDate);

		LocalDate yukokikanStartDate = LocalDate.parse("2017/4/1",formatter);
		searchRiyoshaConditionsDto.setYukokikanStartDate(yukokikanStartDate);

		LocalDate shinseiTeishiStartDate = LocalDate.parse("2017/12/12",formatter);
		searchRiyoshaConditionsDto.setShinseiTeishiStartDate(shinseiTeishiStartDate);

		searchRiyoshaConditionsDto.setPenaltySelect("0");
		searchRiyoshaConditionsDto.setRKanaName("ジュウミンテストリヨウシャ");
		searchRiyoshaConditionsDto.setRYubinBango("2210001");
		searchRiyoshaConditionsDto.setRJusho("横浜市中区");
		searchRiyoshaConditionsDto.setRDenwaBango("0456645381");
		searchRiyoshaConditionsDto.setGinkoCode((short)1);
		searchRiyoshaConditionsDto.setShitenCode((short)1);
		searchRiyoshaConditionsDto.setKozaMeigininKanaName("ﾒｲｷﾞﾆﾝ");
		searchRiyoshaConditionsDto.setKozaShubetsu("1");
		searchRiyoshaConditionsDto.setKoseiinYakuwari("0");
		searchRiyoshaConditionsDto.setRKoseiinKanaName("u");
		searchRiyoshaConditionsDto.setRKoseiinYubinBango("0");
		searchRiyoshaConditionsDto.setRKoseiinJusho("h");
		searchRiyoshaConditionsDto.setRKoseiinDenwaBango("8");

		List<RiyoshaDto> ret = tRiyoshaLogic.getRiyoshaListByDispCondition(searchRiyoshaConditionsDto);
		exportJsonDataIfMultipleFields(ret, "TestgetRiyoshaListByDispCondition2.json");
	}

	@Test
	@TestInitDataFile("TestgetRiyoshaListByDispConditionInit2.xlsx")
	public void TestgetRiyoshaListByDispCondition3() throws Exception
	{
		SearchRiyoshaConditionsDto searchRiyoshaConditionsDto = new SearchRiyoshaConditionsDto();

		searchRiyoshaConditionsDto.setRLoginId("2");
		searchRiyoshaConditionsDto.setLoginIdMuchSelect(JokenHukumu.HUKUMU.getCode());
		searchRiyoshaConditionsDto.setShiyoMokutekiCd((short)1030);
		searchRiyoshaConditionsDto.setRShiyoNinzu(0);

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy/M/d");
		LocalDate createdStartDate = LocalDate.parse("2017/11/29",formatter);
		searchRiyoshaConditionsDto.setCreatedStartDate(createdStartDate);

		LocalDate createdEndDate = LocalDate.parse("2017/12/1",formatter);
		searchRiyoshaConditionsDto.setCreatedEndDate(createdEndDate);

		LocalDate yukokikanEndDate = LocalDate.parse("2020/3/31",formatter);
		searchRiyoshaConditionsDto.setYukokikanEndDate(yukokikanEndDate);

		String shinseiTeishiEndDate = "2017/12/16";
		LocalDate shinseiTeishiStartLocalDate = LocalDate.parse(shinseiTeishiEndDate,formatter);
		searchRiyoshaConditionsDto.setRShinseiTeishiEndDate(shinseiTeishiEndDate);
		searchRiyoshaConditionsDto.setShinseiTeishiEndDate(shinseiTeishiStartLocalDate);

		searchRiyoshaConditionsDto.setPenaltySelect("2");
		searchRiyoshaConditionsDto.setRKanaName("ジュウミンテストリヨウシャ");
		searchRiyoshaConditionsDto.setRYubinBango("2210001");
		searchRiyoshaConditionsDto.setRJusho("横浜市中区");
		searchRiyoshaConditionsDto.setRDenwaBango("0456645381");
		searchRiyoshaConditionsDto.setGinkoCode((short)1);
		searchRiyoshaConditionsDto.setShitenCode((short)1);
		searchRiyoshaConditionsDto.setKozaMeigininKanaName("ﾒｲｷﾞﾆﾝ");
		searchRiyoshaConditionsDto.setKozaShubetsu("1");
		searchRiyoshaConditionsDto.setKoseiinYakuwari("0");
		searchRiyoshaConditionsDto.setRKoseiinKanaName("u");
		searchRiyoshaConditionsDto.setRKoseiinYubinBango("0");
		searchRiyoshaConditionsDto.setRKoseiinJusho("h");
		searchRiyoshaConditionsDto.setRKoseiinDenwaBango("8");

		List<RiyoshaDto> ret = tRiyoshaLogic.getRiyoshaListByDispCondition(searchRiyoshaConditionsDto);
		exportJsonDataIfMultipleFields(ret, "TestgetRiyoshaListByDispCondition3.json");
	}

	@Test
	@TestInitDataFile("TestgetRiyoshaListByDispConditionInit2.xlsx")
	public void TestgetRiyoshaListByDispCondition4() throws Exception
	{
		SearchRiyoshaConditionsDto searchRiyoshaConditionsDto = new SearchRiyoshaConditionsDto();

		searchRiyoshaConditionsDto.setRLoginId("2");
		searchRiyoshaConditionsDto.setLoginIdMuchSelect(null);
		searchRiyoshaConditionsDto.setShiyoMokutekiCd((short)1030);
		searchRiyoshaConditionsDto.setRShiyoNinzu(0);

		searchRiyoshaConditionsDto.setPenaltySelect(null);
		searchRiyoshaConditionsDto.setRKanaName("ジュウミンテストリヨウシャ");
		searchRiyoshaConditionsDto.setRYubinBango("2210001");
		searchRiyoshaConditionsDto.setRJusho("横浜市中区");
		searchRiyoshaConditionsDto.setRDenwaBango("0456645381");
		searchRiyoshaConditionsDto.setGinkoCode((short)1);
		searchRiyoshaConditionsDto.setShitenCode((short)1);
		searchRiyoshaConditionsDto.setKozaMeigininKanaName("ﾒｲｷﾞﾆﾝ");
		searchRiyoshaConditionsDto.setKozaShubetsu("1");

		searchRiyoshaConditionsDto.setKozaNumber("1");

		searchRiyoshaConditionsDto.setKoseiinYakuwari("0");
		searchRiyoshaConditionsDto.setRKoseiinKanaName("u");
		searchRiyoshaConditionsDto.setRKoseiinYubinBango("0");
		searchRiyoshaConditionsDto.setRKoseiinJusho("h");
		searchRiyoshaConditionsDto.setRKoseiinDenwaBango("8");

		List<RiyoshaDto> ret = tRiyoshaLogic.getRiyoshaListByDispCondition(searchRiyoshaConditionsDto);
		exportJsonDataIfMultipleFields(ret, "TestgetRiyoshaListByDispCondition4.json");
	}

	@Test
	public void TestgetDao() throws Exception
	{
		GenericDao<TRiyosha, ?> ret = tRiyoshaLogic.getDao();
	}
}