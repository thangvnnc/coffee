package jp.ne.yec.seagullLC.stagia.test.junit.logic.transaction.TRiyoshaLogic;

import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.beans.enums.JokenHukumu;
import jp.ne.yec.seagullLC.stagia.beans.riyosha.RiyoshaDto;
import jp.ne.yec.seagullLC.stagia.beans.shokai.SearchRiyoshaConditionsDto;
import jp.ne.yec.seagullLC.stagia.entity.TRiyosha;
import jp.ne.yec.seagullLC.stagia.logic.transaction.TRiyoshaLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestTRiyoshaLogic extends JunitBase {

	@Autowired
	TRiyoshaLogic tRiyoshaLogic;
//	@Test
//	@DisplayName("検索条件なしでM_管理を取得します")
//	@TestInitDataFile("TestgetTRiyoshaInit.xlsx")
//	public void TestgetTRiyosha() throws Exception
//	{
//		List<String> loginId = new ArrayList<>();
//		loginId.add("1");
//		loginId.add("10");
//		loginId.add("100");
//
//		List<TRiyosha> tList = new ArrayList<>();
//		for(int item = 0; item < loginId .size(); item ++)
//		{
//			String loginIds =  loginId.get(item);
//			TRiyosha ret = tRiyoshaLogic.getTRiyosha(loginIds);
//			tList.add(ret);
//		}
//		exportJsonData(tList, "TestgetTRiyosha.json");
//	}
//
//	@Test
//	@DisplayName("検索条件なしでM_管理を取得します")
//	@TestInitDataFile("TestgetRiyoshaKozaInfoCountInit.xlsx")
//	public void TestgetRiyoshaKozaInfoCount() throws Exception
//	{
//		long ret =  tRiyoshaLogic.getRiyoshaKozaInfoCount();
//		assertEquals(6, ret);
////		exportJsonData(tList, "TestgetRiyoshaKozaInfoCount.json");
//	}
//
//	@Test
//	@DisplayName("検索条件なしでM_管理を取得します")
//	@TestInitDataFile("TestgetRiyoshaKoseiinCountInit.xlsx")
//	public void TestgetRiyoshaKoseiinCount() throws Exception
//	{
//		long ret = tRiyoshaLogic.getRiyoshaKoseiinCount();
//		assertEquals(0, ret);
//	}
//
//	@Test
//	@DisplayName("検索条件なしでM_管理を取得します")
//	@TestInitDataFile("TestgetRiyoshaForOverLapCheckInit.xlsx")
//	public void TestgetRiyoshaForOverLapCheck() throws Exception
//	{
//		List<String> loginKind = new ArrayList<>();
//		loginKind.add("0");
//
//		List<String> loginId = new ArrayList<>();
//		loginId.add("1");
//
//		List<String> checkNameKana = new ArrayList<>();
//		checkNameKana.add("ジュウミンテストリヨウシャ");
//
//		List<String> checkName = new ArrayList<>();
//		checkName.add("test");
//
//		List<Date> checkBirthDay = new ArrayList<>();
//		SimpleDateFormat sd = new SimpleDateFormat("yyyy/M/d");
//		Date birthDay = new Date();
//		birthDay = sd.parse("1969/9/10");
//		checkBirthDay.add(birthDay);
//
//		List<String> checkTel1 = new ArrayList<>();
//		checkTel1.add("0456645381");
//
//		List<String> checkTel2 = new ArrayList<>();
//		checkTel2.add("0456645381");
//
//		List<String> checkZip = new ArrayList<>();
//		checkZip.add("2210001");
//
//		List<String> checkAddr1 = new ArrayList<>();
//		checkAddr1.add("test45556677");
//
//		List<String> checkAddr2 = new ArrayList<>();
//		checkAddr2.add("test45556677");
//
//		List<String> checkMailAddr = new ArrayList<>();
//		checkMailAddr.add("mail-address@test.jp");
//
//		List<Integer> tList = new ArrayList<>();
//		Integer[] expecteds = {0};
//
//		for(int item = 0; item < loginKind .size(); item ++)
//		{
//			String loginKinds = loginKind.get(item);
//			String loginIds = loginId.get(item);
//			String checkNameKanas = checkNameKana.get(item);
//			String checkNames = checkName.get(item);
//			Date checkBirthDays = checkBirthDay.get(item);
//			String checkTel1s = checkTel1.get(item);
//			String checkTel2s = checkTel2.get(item);
//			String checkZips = checkZip.get(item);
//			String checkAddr1s = checkAddr1.get(item);
//			String checkAddr2s = checkAddr2.get(item);
//			String checkMailAddrs = checkMailAddr.get(item);
//			Integer ret =  tRiyoshaLogic.getRiyoshaForOverLapCheck(loginKinds,loginIds,
//						checkNameKanas, checkNames, checkBirthDays, checkTel1s, checkTel2s, checkZips,
//						checkAddr1s, checkAddr2s, checkMailAddrs);
//			tList.add(ret);
//		}
//		
//		Integer[] actuals = tList.stream().toArray(Integer[]::new);
//		assertArrayEquals(expecteds, actuals);
//	}
//	@Test
//	@DisplayName("検索条件なしでM_管理を取得します")
//	@TestInitDataFile("TestgetRiyoshaListByDispConditionInit.xlsx")
//	public void TestgetRiyoshaListByDispCondition1() throws Exception
//	{
//		List<List<RiyoshaDto>>tList = new ArrayList<>();
//		SearchRiyoshaConditionsDto searchRiyoshaConditionsDto = new SearchRiyoshaConditionsDto();
//		
//		searchRiyoshaConditionsDto.setRLoginId("1");
//		searchRiyoshaConditionsDto.setLoginIdMuchSelect(JokenHukumu.HUKUMU.getCode());
////		searchRiyoshaConditionsDto.setShiyoMokutekiCd((short)1030);
////		searchRiyoshaConditionsDto.setRShiyoNinzu(rShiyoNinzu);
//		
////		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy/M/d");
////		LocalDate createdStartDate = LocalDate.parse("2017/12/13",formatter);
////		searchRiyoshaConditionsDto.setCreatedStartDate(createdStartDate);
////		
////		LocalDate createdEndDate = LocalDate.parse("2017/12/14",formatter);
////		searchRiyoshaConditionsDto.setCreatedEndDate(createdEndDate);
////		
////		LocalDate yukokikanStartDate = LocalDate.parse("2020/4/1",formatter);
////		searchRiyoshaConditionsDto.setYukokikanStartDate(yukokikanStartDate);
////		
////		LocalDate yukokikanEndDate = LocalDate.parse("2020/3/31",formatter);
////		searchRiyoshaConditionsDto.setYukokikanEndDate(yukokikanEndDate);
////		
////		LocalDate shinseiTeishiStartDate = LocalDate.parse("2017/12/13",formatter);
////		searchRiyoshaConditionsDto.setShinseiTeishiStartDate(shinseiTeishiStartDate);
////		
////		LocalDate shinseiTeishiEndDate = LocalDate.parse("2017/12/14",formatter);
////		searchRiyoshaConditionsDto.setShinseiTeishiEndDate(shinseiTeishiEndDate);
//		
//		List<RiyoshaDto> ret = tRiyoshaLogic.getRiyoshaListByDispCondition(searchRiyoshaConditionsDto);
//		tList.add(ret);
//		exportJsonData(tList, "TestgetRiyoshaListByDispCondition1.json");
//	}
	
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetRiyoshaListByDispConditionInit.xlsx")
	public void TestgetRiyoshaListByDispCondition2() throws Exception
	{
		SearchRiyoshaConditionsDto searchRiyoshaConditionsDto = new SearchRiyoshaConditionsDto();
		
		searchRiyoshaConditionsDto.setRLoginId("1");
		searchRiyoshaConditionsDto.setLoginIdMuchSelect(JokenHukumu.ICCHI.getCode());
		
//		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy/M/d");
//		LocalDate createdStartDate = LocalDate.parse("2017/12/13",formatter);
//		searchRiyoshaConditionsDto.setCreatedStartDate(createdStartDate);
//		
//		LocalDate createdEndDate = LocalDate.parse("2017/12/14",formatter);
//		searchRiyoshaConditionsDto.setCreatedEndDate(createdEndDate);
//		
//		LocalDate yukokikanStartDate = LocalDate.parse("2017/4/1",formatter);
//		searchRiyoshaConditionsDto.setYukokikanStartDate(yukokikanStartDate);
//		
//		LocalDate yukokikanEndDate = LocalDate.parse("2020/3/31",formatter);
//		searchRiyoshaConditionsDto.setYukokikanEndDate(yukokikanEndDate);
		
		List<RiyoshaDto> ret = tRiyoshaLogic.getRiyoshaListByDispCondition(searchRiyoshaConditionsDto);
		exportJsonData(ret, "TestgetRiyoshaListByDispCondition2.json");
	}
	
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	//@TestInitDataFile("TestgetMBashoList.xlsx")
	public void TestgetDao() throws Exception
	{
		GenericDao<TRiyosha, ?> ret = tRiyoshaLogic.getDao();
	}
}