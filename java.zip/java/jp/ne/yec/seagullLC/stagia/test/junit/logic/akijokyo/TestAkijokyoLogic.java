package jp.ne.yec.seagullLC.stagia.test.junit.logic.akijokyo;

import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.seagullLC.stagia.logic.akijokyo.AkijokyoLogic;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestAkijokyoLogic extends JunitBase {

	@Autowired
	AkijokyoLogic akijokyoLogic;

//	@Test
//	@DisplayName("引数のコマ情報から申請明細DTOListを生成し返却します.")
//	//@TestInitDataFile("TestRiyoshaServiceInit.xlsx")
//	public void TestKomaToMeisaiDto() throws Exception {
//		List<Set<String>> params = new ArrayList<Set<String>>();
//		Set<String> selectedKomaSet = new HashSet<String>();
//		selectedKomaSet.add("10101101201806160110020011102");
//		selectedKomaSet.add("10102101201806160110020011102");
//		selectedKomaSet.add("10103101201806160110020012102");
//		selectedKomaSet.add("10104101999999990110020008102");
//		params.add(selectedKomaSet);
//
//		List<Integer> startMeisaiIds = new ArrayList<>();
//		startMeisaiIds.add(10);
//
//		List<List<ShinseiMeisaiDto>> exports = new ArrayList<>();
//		for (int item = 0; item < params.size(); item++)
//		{
//			List<ShinseiMeisaiDto> ret = akijokyoLogic.komaToMeisaiDto(params.get(item), startMeisaiIds.get(item));
//			exports.add(ret);
//		}
//		exportJsonData(exports, "TestKomaToMeisaiDto.json");
//	}
//
//	@Test
//	@DisplayName("引数のコマ情報から申請明細DTOListを生成し返却します.")
//	//@TestInitDataFile("TestRiyoshaServiceInit.xlsx")
//	public void TestisHyojiKirikaeKikan() throws Exception {
//		List<MKomaPattern> mKomaPatterns = new ArrayList<>();
//		mKomaPatterns.add(new MKomaPattern());
//
//		List<LocalDate> dates = new ArrayList<>();
//		dates.add(LocalDate.now());
//
//		List<Boolean> exports = new ArrayList<>();
//		for (int item = 0; item < mKomaPatterns.size(); item++)
//		{
//			 Boolean ret = akijokyoLogic.isHyojiKirikaeKikan(mKomaPatterns.get(item), dates.get(item));
//			 exports.add(ret);
//		}
//		exportJsonData(exports,	"TestisHyojiKirikaeKikan.json");
//	}

}
