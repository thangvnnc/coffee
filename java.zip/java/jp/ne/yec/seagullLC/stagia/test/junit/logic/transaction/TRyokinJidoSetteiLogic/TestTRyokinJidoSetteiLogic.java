package jp.ne.yec.seagullLC.stagia.test.junit.logic.transaction.TRyokinJidoSetteiLogic;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.entity.TRyokinJidoSettei;
import jp.ne.yec.seagullLC.stagia.logic.transaction.TRyokinJidoSetteiLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestTRyokinJidoSetteiLogic extends JunitBase {

	@Autowired
	TRyokinJidoSetteiLogic tRyokinJidoSetteiLogic;
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetRyokinJidoListInit.xlsx")
	public void TestgetRyokinJidoList() throws Exception
	{
		String loginId = "1";
		List<TRyokinJidoSettei> ret =  tRyokinJidoSetteiLogic.getRyokinJidoList(loginId);
		exportJsonData(ret, "TestgetRyokinJidoList.json");
	}

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetRyokinJidoList_ListInit.xlsx")
	public void TestGetRyokinJidoList_List() throws Exception
	{
		String loginId = "1";
		List<Short> kanriCode = new ArrayList<>();
		kanriCode.add((short)10);
		kanriCode.add((short)10);

		List<TRyokinJidoSettei> ret =  tRyokinJidoSetteiLogic.getRyokinJidoList(loginId, kanriCode);
		exportJsonData(ret, "TestgetRyokinJidoList_ListInit.json");
	}
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	//@TestInitDataFile("TestgetMBashoList.xlsx")
	public void TestgetDao() throws Exception
	{
		GenericDao<TRyokinJidoSettei, ?> ret = tRyokinJidoSetteiLogic.getDao();
	}
}