package jp.ne.yec.seagullLC.stagia.test.junit.logic.master.MRyokinTaikeiLogic;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.beans.StringCodeNamePair;
import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.entity.MRyokinTaikei;
import jp.ne.yec.seagullLC.stagia.logic.master.MRyokinTaikeiLogic;
import jp.ne.yec.seagullLC.stagia.service.shinsei.MeisaiJohoSetteiService;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestMRyokinTaikeiLogic extends JunitBase {

	@Autowired
	MRyokinTaikeiLogic mRyokinTaikeiLogic;

	@Autowired
	MeisaiJohoSetteiService meisaiJohoSetteiService;

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetMRyokinTaikeiList.xlsx")
	public void TestgetMRyokinTaikeiList() throws Exception
	{
		List<MRyokinTaikei> ret = mRyokinTaikeiLogic.getMRyokinTaikeiList();
		exportJsonData(ret, "TestgetMRyokinTaikeiList.json");
	}

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetMRyokinTaikeiList.xlsx")
	public void TestgetMRyokinTaikeiList_Short() throws Exception
	{
		List<Short> codes = new ArrayList<>();
		Short code = 10 ;
		codes.add(code);
		List<MRyokinTaikei> ret = mRyokinTaikeiLogic.getMRyokinTaikeiList(code);

		exportJsonData(ret, "TestgetMRyokinTaikeiList_Short.json");
	}


	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetMRyokinTaikeiList.xlsx")
	public void TestgetStringCodeNamePairList_List() throws Exception
	{
		Short kanriCode =  10;
		List<StringCodeNamePair> ret = mRyokinTaikeiLogic.getStringCodeNamePairList(kanriCode);
		
		exportJsonData(ret, "TestgetStringCodeNamePairList_List.json");
	}
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetMRyokinTaikeiList.xlsx")
	public void TestgetMRyokinTaikei() throws Exception
	{
		Short kanriCode = 10;
		Short ryoukinTaikeiCode =  1;
		
		MRyokinTaikei ret =  mRyokinTaikeiLogic.getMRyokinTaikei(kanriCode,ryoukinTaikeiCode);
		exportJsonData(ret, "TestgetMRyokinTaikei.json");
	}


	@Test
	@DisplayName("検索条件なしで場所マスタを取得し、返却します")
	//@TestInitDataFile("TestgetMBashoList.xlsx")
	public void TestgetDao() throws Exception
	{
		GenericDao<MRyokinTaikei, ?>ret = mRyokinTaikeiLogic.getDao();
	}
}
