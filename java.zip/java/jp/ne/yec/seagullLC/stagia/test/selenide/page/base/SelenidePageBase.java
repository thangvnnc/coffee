package jp.ne.yec.seagullLC.stagia.test.selenide.page.base;

import static com.codeborne.selenide.Selectors.*;
import static com.codeborne.selenide.Selenide.*;

import java.util.Objects;

import org.openqa.selenium.Keys;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.codeborne.selenide.Condition;
import com.codeborne.selenide.Configuration;
import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.Screenshots;
import com.codeborne.selenide.Selenide;
import com.codeborne.selenide.SelenideElement;

import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestServer.Browzer;
import jp.ne.yec.seagullLC.stagia.test.selenide.page.akijokyo.AkijokyoKensakuTest;
import jp.ne.yec.seagullLC.stagia.test.selenide.page.login.LoginTest;

/**
 * Selenideで使用するPageの基底クラス.
 *
 * @author nao-hirata
 *
 */
public class SelenidePageBase {

	/**
	 * ホームページクラス.
	 */
	private Class<? extends SelenidePageBase> homePageClass = AkijokyoKensakuTest.class;

	@FindBy(how = How.CSS, using = "a[wicketpath=headerMenu_menuList_6_loginButton]")
	private SelenideElement loginButton;

	@FindBy(how = How.CSS, using = "a[wicketpath=headerMenu_menuList_6_logoutButton]")
	private SelenideElement logoutButton;

	@FindBy(how = How.CSS, using = "body > div.wrapper > aside > div > section > ul li")
	private ElementsCollection sidebarMenu;

	protected SelenideElement confirmYes = $(byText("はい"));
	protected SelenideElement confirmNo = $(byText("いいえ"));


	/**
	 * コンストラクタ.<br>
	 * 画面表示時にスクリーンショットを撮ります.
	 */
	public SelenidePageBase() {
		sleep(200);
		takeScreenShot();
	}

	/**
	 * ログインボタンをクリックします.
	 *
	 * @return - LoginTestのインスタンス
	 */
	public LoginTest clickLoginButton() {
		return takeScreenShotAndMovePage(loginButton, LoginTest.class);
	}

	/**
	 * ログアウトボタンをクリックします.
	 *
	 * @return - ホームページクラスのインスタンス
	 */
	public SelenidePageBase clickLogoutButton() {
		click(logoutButton);
		sleep(500);
		return takeScreenShotAndMovePage($$(byText("ログアウト")).find(Condition.type("button")), homePageClass);
	}

	/**
	 * 渡された名称をサイドメニューから検索し、クリックします.
	 *
	 * @param openPageClass - クリック後に表示されるページに対応するテストページクラス
	 * @param menuNames - クリックするメニューの名称
	 * @return
	 */
	public <T extends SelenidePageBase> T clickSidebarMenu(Class<T> openPageClass, String... menuNames) {
		SelenideElement element = null;
		for (String menuName : menuNames) {
			element = findSidebarMenuElement(element, menuName);
			element.click();
		}
		return page(openPageClass);
	}

	/**
	 * メニューの名称から該当するSelenideElementを検索し返却します.
	 *
	 * @param element - 親階層メニュー
	 * @param menuName - 検索するメニューの名称
	 * @return
	 */
	private SelenideElement findSidebarMenuElement(SelenideElement element, String menuName) {
		sleep(1000);
		ElementsCollection sidebarMenu;
		if (Objects.isNull(element)) {
			sidebarMenu = this.sidebarMenu;
		} else {
			sidebarMenu = element.findAll("ul li");
		}
		return sidebarMenu.stream()
			.filter(e -> !e.attr("class").equals("header"))
			.filter(e -> e.find("a > span").text().equals(menuName))
			.findFirst()
			.orElse(null)
		;
	}

	/**
	 * 引数のSelenideElementをクリックします.
	 *
	 * <p>
	 * WebDriverがIEの場合、SelenideElementのクリックイベントがうまく発火しない事象が発生する為、<br>
	 * 一度対象のSelenideElementにフォーカスを当てる処理を行った後、クリックイベントを実施します.<br>
	 * WebDriverがIE以外の場合はフォーカスを当てる処理を行わず、通常のクリックイベントのみを実施します.
	 * </p>
	 *
	 * @param selenideElement
	 */
	protected void click(SelenideElement selenideElement) {
		if (Configuration.browser.equals(Browzer.IE.getWebDriverRunner())) {
			selenideElement.sendKeys(Keys.CONTROL);
		}
		selenideElement.click();
	}

	/**
	 * 確認ダイアログのはいをクリックします.
	 */
	public <T extends SelenidePageBase> T clickConfirmYes(Class<T> openPageClass) {
		sleep(500);
		return takeScreenShotAndMovePage(confirmYes, openPageClass);
	}

	/**
	 * スクリーンショットを撮ります.
	 */
	protected void takeScreenShot() {
		Screenshots.takeScreenShot(String.valueOf(System.currentTimeMillis()));
	}

	/**
	 * 画面のスクリーンショットを撮った後、引数のSelenideElementをクリックします.
	 *
	 * @param clickableElement - clickイベントを行うSelenideElement
	 */
	protected void takeScreenShotAndClickElement(SelenideElement clickableElement) {
		takeScreenShot();
		click(clickableElement);
	}

	/**
	 * 画面のスクリーンショットを撮った後、引数のページへ遷移します.
	 *
	 * @param clickableElement - clickイベントを行うSelenideElement
	 * @param nextPageClass - 遷移先のページクラス.
	 * @return
	 */
	protected <T extends SelenidePageBase> T takeScreenShotAndMovePage(SelenideElement clickableElement, Class<T> nextPageClass) {
		takeScreenShotAndClickElement(clickableElement);
		return Selenide.page(nextPageClass);
	}
}
