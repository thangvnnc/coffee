package jp.ne.yec.seagullLC.stagia.test.junit.logic.master.MShisetsuRyokinLogic;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.entity.MShisetsuRyokin;
import jp.ne.yec.seagullLC.stagia.logic.master.MShisetsuRyokinLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestMShisetsuRyokinLogic extends JunitBase {

	@Autowired
	MShisetsuRyokinLogic mShisetsuRyokinLogic;

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetMShisetsuRyokin.xlsx")
	public void TestgetMShisetsuRyokin() throws Exception
	{
		SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
		String ryokinKeisanKijyunDate = "4/1/2016";
		Date ryokinKeisanKijyunDatet  = formatter.parse(ryokinKeisanKijyunDate);

		Short kanriCode = 10;
		Short shisetsuCode = 10;
		Short shiyoDate = 101;
		String yobiPattern = "0";
		Date ryokinKeisanKijyunDatea = ryokinKeisanKijyunDatet;
		List<MShisetsuRyokin> ret =  mShisetsuRyokinLogic.getMShisetsuRyokin(
				kanriCode,shisetsuCode , shiyoDate,yobiPattern,ryokinKeisanKijyunDatea);
		exportJsonData(ret, "TestgetMShisetsuRyokin.json");
	}
	@Test
	@DisplayName("検索条件なしで場所マスタを取得し、返却します")
	@TestInitDataFile("TestgetMShisetsuRyokin.xlsx")
	public void TestGetMShisetsuRyokin_Map() throws Exception
	{
		Map<Short, List<Short>> mapShort = new HashMap<>();
		List<Short> shorts = new ArrayList<>();
		shorts.add((short)10);
		mapShort.put((short)10, shorts);

		List<MShisetsuRyokin> ret = mShisetsuRyokinLogic.getMShisetsuRyokin(mapShort);
		exportJsonData(ret, "TestGetMShisetsuRyokin_Map.json");
	}

	@Test
	@DisplayName("検索条件なしで場所マスタを取得し、返却します")
	//@TestInitDataFile("TestgetMBashoList.xlsx")
	public void TestgetDao() throws Exception
	{
		GenericDao<MShisetsuRyokin, ?> ret = mShisetsuRyokinLogic.getDao();
	}
}