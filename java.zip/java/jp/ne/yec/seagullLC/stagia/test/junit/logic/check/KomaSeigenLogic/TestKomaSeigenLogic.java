package jp.ne.yec.seagullLC.stagia.test.junit.logic.check.KomaSeigenLogic;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.google.gson.reflect.TypeToken;

import jp.ne.yec.seagullLC.stagia.beans.riyosha.KoseiinJohoDto;
import jp.ne.yec.seagullLC.stagia.beans.shinsei.ShinseiMeisaiDto;
import jp.ne.yec.seagullLC.stagia.entity.MKoma;
import jp.ne.yec.seagullLC.stagia.entity.MShisetsu;
import jp.ne.yec.seagullLC.stagia.logic.check.KomaSeigenLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestKomaSeigenLogic extends JunitBase {


	@Autowired
	KomaSeigenLogic komaSeigenLogic;

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestSetNewMeisaiDtoInfo_Step1_Init.xlsx")
	public void TestKoseiinJohoEntityToKoseiinJohoDto() throws Exception
	{
		List<List<KoseiinJohoDto>> jsonData = new ArrayList<List<KoseiinJohoDto>>();
		List<ShinseiMeisaiDto> meisaiDtos = readJson("TestSetNewMeisaiDtoInfo_Step1_meisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>(){}.getType());
		Map<Short, MKoma> mKomaMap = new HashMap<>();
		MKoma mKoma = new MKoma();
		mKoma.setAllowedTandokuKashidashi(false);
		mKomaMap.put((short)1, mKoma);
		meisaiDtos.get(0).setMKomaMap(mKomaMap);
		meisaiDtos.get(0).setBashoName("生涯学習センター");
		MShisetsu MShisetsu = new MShisetsu();
		MShisetsu.setShisetsuName("会議室");
		meisaiDtos.get(0).setMShisetsu(MShisetsu);

		Map<Short, MKoma> mKomaMap1 = new HashMap<>();
		MKoma mKoma1 = new MKoma();
		mKoma1.setAllowedTandokuKashidashi(false);
		mKomaMap1.put((short)1, mKoma1);
		meisaiDtos.get(1).setMKomaMap(mKomaMap1);
		meisaiDtos.get(1).setBashoName("生涯学習センター");
		MShisetsu MShisetsu1 = new MShisetsu();
		MShisetsu1.setShisetsuName("会議室");
		meisaiDtos.get(0).setMShisetsu(MShisetsu1);


		try
		{
			komaSeigenLogic.tandokuKashidashiKomaCheck(meisaiDtos);
		}
		catch(Exception ex)
		{
			String a = ex.getMessage();
			assertEquals("生涯学習センター 会議室の09：00～10：00のコマは単独での貸出を行っていません。09：00～10：00のコマの前後の時間帯と併せて申請をしてください。", ex.getMessage());
		}

	}

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestSetNewMeisaiDtoInfo_Step1_Init.xlsx")
	public void TestKoseiinJohoEntityToKoseiinJohoDto_step2() throws Exception
	{
		List<List<KoseiinJohoDto>> jsonData = new ArrayList<List<KoseiinJohoDto>>();
		List<ShinseiMeisaiDto> meisaiDtos = readJson("TestSetNewMeisaiDtoInfo_Step1_meisaiDtos.pra", new TypeToken<List<ShinseiMeisaiDto>>(){}.getType());
		Map<Short, MKoma> mKomaMap = new HashMap<>();
		MKoma mKoma = new MKoma();
		mKoma.setAllowedTandokuKashidashi(true);
		mKomaMap.put((short)1, mKoma);
		meisaiDtos.get(0).setMKomaMap(mKomaMap);
		meisaiDtos.get(0).setBashoName("生涯学習センター");
		MShisetsu MShisetsu = new MShisetsu();
		MShisetsu.setShisetsuName("会議室");
		meisaiDtos.get(0).setMShisetsu(MShisetsu);

		Map<Short, MKoma> mKomaMap1 = new HashMap<>();
		MKoma mKoma1 = new MKoma();
		mKoma1.setAllowedTandokuKashidashi(true);
		mKomaMap1.put((short)1, mKoma1);
		meisaiDtos.get(1).setMKomaMap(mKomaMap1);
		meisaiDtos.get(1).setBashoName("生涯学習センター");
		MShisetsu MShisetsu1 = new MShisetsu();
		MShisetsu1.setShisetsuName("会議室");
		meisaiDtos.get(0).setMShisetsu(MShisetsu1);


		try
		{
			komaSeigenLogic.tandokuKashidashiKomaCheck(meisaiDtos);
		}
		catch(Exception ex)
		{
			String a = ex.getMessage();
			assertEquals("生涯学習センター 会議室の09：00～10：00のコマは単独での貸出を行っていません。09：00～10：00のコマの前後の時間帯と併せて申請をしてください。", ex.getMessage());
		}

	}
}

