package jp.ne.yec.seagullLC.stagia.test.junit.logic.master.MRehearsalLogic;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.entity.MRehearsal;
import jp.ne.yec.seagullLC.stagia.logic.master.MRehearsalLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestMRehearsalLogic extends JunitBase {

	@Autowired
	MRehearsalLogic mRehearsalLogic;

	@Test
	@DisplayName("管理コードを条件として、M_リハーサルを取得します")
	@TestInitDataFile("TestgetMRehearsal.xlsx")
	public void TestgetMRehearsal() throws Exception
	{
		Short kanriCode = 10;
		List<MRehearsal>  ret = mRehearsalLogic.getMRehearsal(kanriCode);
		exportJsonData(ret, "TestgetMRehearsal.json");

	}
	@Test
	@DisplayName("引数の管理コードで設定されているマスタ数を返却します")
	@TestInitDataFile("TestgetMRehearsal.xlsx")
	public void TestgetRehearsalSettingCount() throws Exception
	{
		Short kanriCode = 10;
		long ret = mRehearsalLogic.getRehearsalSettingCount(kanriCode);
		assertEquals(4, ret);
	}
	@Test
	@DisplayName("引数の管理コードで設定されているマスタ数を返却します")
	//@TestInitDataFile("TestgetMBashoList.xlsx")
	public void TestgetDao() throws Exception
	{
		GenericDao<MRehearsal, ?>ret =  mRehearsalLogic.getDao();
	}
}