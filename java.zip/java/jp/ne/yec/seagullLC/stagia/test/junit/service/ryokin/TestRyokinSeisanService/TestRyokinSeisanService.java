package jp.ne.yec.seagullLC.stagia.test.junit.service.ryokin.TestRyokinSeisanService;

import static org.junit.Assert.*;

import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Queue;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.google.common.reflect.TypeToken;

import jp.ne.yec.seagullLC.stagia.beans.shuno.KampuDto;
import jp.ne.yec.seagullLC.stagia.beans.shuno.RyokinSeisanDto;
import jp.ne.yec.seagullLC.stagia.beans.shuno.RyoshuDto;
import jp.ne.yec.seagullLC.stagia.entity.MBasho;
import jp.ne.yec.seagullLC.stagia.entity.MGinko;
import jp.ne.yec.seagullLC.stagia.entity.MKampuKikan;
import jp.ne.yec.seagullLC.stagia.entity.MKampuRiyu;
import jp.ne.yec.seagullLC.stagia.entity.MKanri;
import jp.ne.yec.seagullLC.stagia.entity.MKashidashiTani;
import jp.ne.yec.seagullLC.stagia.entity.MShisetsu;
import jp.ne.yec.seagullLC.stagia.entity.MShiten;
import jp.ne.yec.seagullLC.stagia.entity.TShinseiMeisai;
import jp.ne.yec.seagullLC.stagia.service.ryokin.RyokinSeisanService;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestRyokinSeisanService extends JunitBase{

	@Autowired
	RyokinSeisanService ryokinSeisanService;

	@Test
	@DisplayName("M_管理を取得します。")
	@TestInitDataFile("TestGetMKanri_Init.xlsx")
	public void TestGetMKanri() throws Exception {
		Short kanriCode = 10;
		MKanri ret = ryokinSeisanService.getMKanri(kanriCode);
		exportJsonData(ret, "TestGetMKanri.json");
	}

	@Test
	@DisplayName("取消明細も含め引数に紐付くT_申請明細を取得します.")
	@TestInitDataFile("TestGetTShinseiMeisai_Init.xlsx")
	public void TestGetTShinseiMeisai() throws Exception {
		short kanriCode = 10;
		int shinseiNumber = 444;;
		List<TShinseiMeisai> ret = ryokinSeisanService.getTShinseiMeisai(kanriCode, shinseiNumber);
		exportJsonData(ret, "TestGetTShinseiMeisai.json");
	}

	@Test
	@DisplayName("全てのM_場所を返却します.")
	@TestInitDataFile("TestgetMBashoList_Init.xlsx")
	public void TestGetMBasho() throws Exception {
		List<MBasho> ret = ryokinSeisanService.getMBasho();
		exportJsonData(ret, "TestGetMBasho.json");
	}

	@Test
	public void TestGetBashoMap() throws Exception {
		List<MBasho> mBashos = readJson("TestGetBashoMap_mBashos.pra", new TypeToken<List<MBasho>>() {}.getType());
		List<TShinseiMeisai> shinseiMeisais = readJson("TestGetBashoMap_shinseiMeisais.pra", new TypeToken<List<TShinseiMeisai>>() {}.getType());;
		Map<Integer, MBasho> ret = ryokinSeisanService.getBashoMap(mBashos, shinseiMeisais);
		exportJsonData(ret, "TestGetBashoMap.json");
	}

	@Test
	@DisplayName("引数のT_申請明細.id毎のM_施設のMapを返却します.")
	@TestInitDataFile("TestGetShisetsuMap_Init.xlsx")
	public void TestGetShisetsuMap() throws Exception {
		List<TShinseiMeisai> shinseiMeisais = readJson("TestGetShisetsuMap_shinseiMeisais.pra", new TypeToken<List<TShinseiMeisai>>() {}.getType());
		Map<Integer, MShisetsu> ret = ryokinSeisanService.getShisetsuMap(shinseiMeisais);
		exportJsonData(ret, "TestGetShisetsuMap.json");
	}

	@Test
	@DisplayName("引数のT_申請明細.id毎のM_貸出単位のMapを返却します.")
	@TestInitDataFile("TestGetKashidashiTaniMap_Init.xlsx")
	public void TestGetKashidashiTaniMap() throws Exception {
		List<TShinseiMeisai> shinseiMeisais = readJson("TestGetKashidashiTaniMap_shinseiMeisais.pra", new TypeToken<List<TShinseiMeisai>>() {}.getType());
		Map<Integer, MKashidashiTani> ret = ryokinSeisanService.getKashidashiTaniMap(shinseiMeisais);
		exportJsonData(ret, "TestGetKashidashiTaniMap.json");
	}

	@Test
	@DisplayName("M_還付理由を返却します.")
	@TestInitDataFile("TestGetMKampuRiyu_Init.xlsx")
	public void TestGetMKampuRiyu() throws Exception {
		List<MKampuRiyu> ret = ryokinSeisanService.getMKampuRiyu((short)10);
		exportJsonData(ret, "TestGetMKampuRiyu.json");
	}

	@Test
	@DisplayName("管理コード施設コード別のMapにM_還付期間を格納し返却します.")
	@TestInitDataFile("TestGetKampuKikan_Init.xlsx")
	public void TestGetKampuKikan() throws Exception {
		List<TShinseiMeisai> tShinseiMeisais = readJson("TestGetKampuKikan_tShinseiMeisais.pra", new TypeToken<List<TShinseiMeisai>>() {}.getType());
		Map<Short, Map<Short, List<MKampuKikan>>> ret = ryokinSeisanService.getKampuKikan(tShinseiMeisais);
		exportJsonData(ret, "TestGetKampuKikan.json");
	}

	@Test
	@DisplayName("M_支店を銀行コード毎に格納したMapを返却します.")
	@TestInitDataFile("TestGetMShiten_Init.xlsx")
	public void TestGetMShiten() throws Exception {
		Map<Short, List<MShiten>> ret = ryokinSeisanService.getMShiten();
		exportJsonData(ret, "TestGetMShiten.json");
	}

	@Test
	@DisplayName("引数に紐付くT_料金を返却します.")
	@TestInitDataFile("TestGetRyokinSeisanDtos_Step1_Init.xlsx")
	public void TestGetRyokinSeisanDtos_Step1() throws Exception {
		Map<Integer, TShinseiMeisai> shinseiMeisaiMap = readJson("TestGetRyokinSeisanDtos_Step1_shinseiMeisaiMap.pra", new TypeToken<Map<Integer, TShinseiMeisai>>() {}.getType());
		List<RyokinSeisanDto> ret = ryokinSeisanService.getRyokinSeisanDtos(shinseiMeisaiMap, true);
		exportJsonData(ret, "TestGetRyokinSeisanDtos_Step1.json");
	}

	@Test
	@DisplayName("引数に紐付くT_料金を返却します.")
	@TestInitDataFile("TestGetRyokinSeisanDtos_Step2_Init.xlsx")
	public void TestGetRyokinSeisanDtos_Step2() throws Exception {
		Map<Integer, TShinseiMeisai> shinseiMeisaiMap = readJson("TestGetRyokinSeisanDtos_Step2_shinseiMeisaiMap.pra", new TypeToken<Map<Integer, TShinseiMeisai>>() {}.getType());
		List<RyokinSeisanDto> ret = ryokinSeisanService.getRyokinSeisanDtos(shinseiMeisaiMap, false);
		exportJsonData(ret, "TestGetRyokinSeisanDtos_Step2.json");
	}

	@Test
	@DisplayName("引数に紐付くT_料金を返却します.")
	@TestInitDataFile("TestGetRyokinSeisanDtos_Step3_Init.xlsx")
	public void TestGetRyokinSeisanDtos_Step3() throws Exception {
		Map<Integer, TShinseiMeisai> shinseiMeisaiMap = readJson("TestGetRyokinSeisanDtos_Step3_shinseiMeisaiMap.pra", new TypeToken<Map<Integer, TShinseiMeisai>>() {}.getType());
		List<RyokinSeisanDto> ret = ryokinSeisanService.getRyokinSeisanDtos(shinseiMeisaiMap, true);
		exportJsonData(ret, "TestGetRyokinSeisanDtos_Step3.json");
	}

	@Test
	@DisplayName("引数に紐付くT_料金を返却します.")
	@TestInitDataFile("TestGetRyokinSeisanDtos_Step4_Init.xlsx")
	public void TestGetRyokinSeisanDtos_Step4() throws Exception {
		Map<Integer, TShinseiMeisai> shinseiMeisaiMap = readJson("TestGetRyokinSeisanDtos_Step4_shinseiMeisaiMap.pra", new TypeToken<Map<Integer, TShinseiMeisai>>() {}.getType());
		List<RyokinSeisanDto> ret = ryokinSeisanService.getRyokinSeisanDtos(shinseiMeisaiMap, true);
		exportJsonData(ret, "TestGetRyokinSeisanDtos_Step4.json");
	}

	@Test
	public void TestGetUketsukeBashoKiteichi_Step1() throws Exception {
		List<MBasho> uketsukeBashoList = readJson("TestGetUketsukeBashoKiteichi_Step1_uketsukeBashoList.pra", new TypeToken<List<MBasho>>() {}.getType());
		MBasho ret = ryokinSeisanService.getUketsukeBashoKiteichi(uketsukeBashoList, null);
		exportJsonData(ret, "TestGetUketsukeBashoKiteichi_Step1.json");
	}

	@Test
	public void TestGetUketsukeBashoKiteichi_Step2() throws Exception {
		List<MBasho> uketsukeBashoList = readJson("TestGetUketsukeBashoKiteichi_Step2_uketsukeBashoList.pra", new TypeToken<List<MBasho>>() {}.getType());
		MBasho ret = ryokinSeisanService.getUketsukeBashoKiteichi(uketsukeBashoList, (short)10);
		exportJsonData(ret, "TestGetUketsukeBashoKiteichi_Step2.json");
	}

	@Test
	@TestInitDataFile("TestGetKampuDtos_Init.xlsx")
	public void TestGetKampuDtos() throws Exception {
		List<Integer> ids = new ArrayList<>();
		ids.add(38242);
		ids.add(38243);
		List<KampuDto> ret = ryokinSeisanService.getKampuDtos(ids);
		exportJsonData(ret, "TestGetKampuDtos.json");
	}

	@Test
	@DisplayName("引数に紐付く領収DTOをT_領収明細Listをセットした状態で返却します.")
	@TestInitDataFile("TestGetRyoshuDtos_Init.xlsx")
	public void TestGetRyoshuDtos() throws Exception {
		List<Integer> ids = new ArrayList<>();
		ids.add(38242);
		List<RyoshuDto> ret = ryokinSeisanService.getRyoshuDtos(ids);
		exportJsonData(ret, "TestGetRyoshuDtos.json");
	}

	@Test
	@DisplayName("M_銀行を返却します.")
	@TestInitDataFile("TestGetMGinko_Init.xlsx")
	public void TestGetMGinko() throws Exception {
		List<MGinko> ret = ryokinSeisanService.getMGinko();
		exportJsonData(ret, "TestGetMGinko.json");
	}

	@Test
	@DisplayName(" 引数の料金精算DTO、T_領収、T_領収明細、T_還付、T_還付明細のデータ更新を行います.")
	public void TestInsertUpdateRyoshuKampuData_Step1() throws Exception {
		List<RyokinSeisanDto> ryokinSeisanDtos = readJson("TestInsertUpdateRyoshuKampuData_Step1_ryokinSeisanDtos.pra", new TypeToken<List<RyokinSeisanDto>>() {}.getType());
		List<RyoshuDto> insertRyoshuList = readJson("TestInsertUpdateRyoshuKampuData_Step1_insertRyoshuList.pra", new TypeToken<List<RyoshuDto>>() {}.getType());
		List<RyoshuDto> modifiedRyoshuList = readJson("TestInsertUpdateRyoshuKampuData_Step1_modifiedRyoshuList.pra", new TypeToken<List<RyoshuDto>>() {}.getType());
		Queue<Integer> ryoshuNumberQueue = new ArrayDeque<>();
		ryoshuNumberQueue.add(10);
		List<KampuDto> insertKampuList = readJson("TestInsertUpdateRyoshuKampuData_Step1_insertKampuList.pra", new TypeToken<List<KampuDto>>() {}.getType());
		List<KampuDto> modifiedKampuList = readJson("TestInsertUpdateRyoshuKampuData_Step1_modifiedKampuList.pra", new TypeToken<List<KampuDto>>() {}.getType());
		Queue<Integer> kampuNumberQueue = new ArrayDeque<>();
		kampuNumberQueue.add(10);
		String updatedBy = "1-tnt";

		ryokinSeisanService.insertUpdateRyoshuKampuData(
				ryokinSeisanDtos,
				insertRyoshuList,
				modifiedRyoshuList,
				ryoshuNumberQueue,
				insertKampuList,
				modifiedKampuList,
				kampuNumberQueue,
				updatedBy
		);
	}


//	@Test
//  Hàm này chưa xử lý
//	@DisplayName(" 引数の料金精算DTO、T_領収、T_領収明細、T_還付、T_還付明細のデータ更新を行います.")
//	public void TestInsertUpdateRyoshuKampuData_Step2() throws Exception {
//		List<RyokinSeisanDto> ryokinSeisanDtos = readJson("TestInsertUpdateRyoshuKampuData_Step2_ryokinSeisanDtos.pra", new TypeToken<List<RyokinSeisanDto>>() {}.getType());
//		List<RyoshuDto> insertRyoshuList = readJson("TestInsertUpdateRyoshuKampuData_Step2_insertRyoshuList.pra", new TypeToken<List<RyoshuDto>>() {}.getType());
//		List<RyoshuDto> modifiedRyoshuList = readJson("TestInsertUpdateRyoshuKampuData_Step2_modifiedRyoshuList.pra", new TypeToken<List<RyoshuDto>>() {}.getType());
//		Queue<Integer> ryoshuNumberQueue = new ArrayDeque<>();
//		ryoshuNumberQueue.add(10);
//		List<KampuDto> insertKampuList = readJson("TestInsertUpdateRyoshuKampuData_Step2_insertKampuList.pra", new TypeToken<List<KampuDto>>() {}.getType());
//		List<KampuDto> modifiedKampuList = readJson("TestInsertUpdateRyoshuKampuData_Step2_modifiedKampuList.pra", new TypeToken<List<KampuDto>>() {}.getType());
//		Queue<Integer> kampuNumberQueue = new ArrayDeque<>();
//		kampuNumberQueue.add(10);
//		String updatedBy = "1-tnt";
//
//		ryokinSeisanService.insertUpdateRyoshuKampuData(
//				ryokinSeisanDtos,
//				insertRyoshuList,
//				modifiedRyoshuList,
//				ryoshuNumberQueue,
//				insertKampuList,
//				modifiedKampuList,
//				kampuNumberQueue,
//				updatedBy
//		);
//	}

	@Test
	@DisplayName("引数より適用する還付率を返却します. 対象が存在しなかった場合、nullを返却します.")
	public void TestGetkampuRitsu_Step1() throws Exception {
		SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
		TShinseiMeisai meisai = readJson("TestGetkampuRitsu_Step1_meisai.pra", new TypeToken<TShinseiMeisai>() {}.getType());
		Date toshoUketsukeDate = format.parse("2018/07/09");
		MShisetsu mShisetsu = readJson("TestGetkampuRitsu_Step1_mShisetsu.pra", new TypeToken<MShisetsu>() {}.getType());
		Map<Short, Map<Short, List<MKampuKikan>>> kampuKikanMap = readJson("TestGetkampuRitsu_Step1_kampuKikanMap.pra", new TypeToken<Map<Short, Map<Short, List<MKampuKikan>>>>() {}.getType());
		Optional<Short> ret = ryokinSeisanService.getkampuRitsu(meisai, toshoUketsukeDate, mShisetsu, kampuKikanMap);
		Short ret2 = ret.orElse(null);
		Short exp = Short.valueOf((short)0);
		assertEquals(exp, ret2);
	}

	@Test
	@DisplayName("引数より適用する還付率を返却します. 対象が存在しなかった場合、nullを返却します.")
	public void TestGetkampuRitsu_Step2() throws Exception {
		SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
		TShinseiMeisai meisai = readJson("TestGetkampuRitsu_Step2_meisai.pra", new TypeToken<TShinseiMeisai>() {}.getType());
		Date toshoUketsukeDate = format.parse("2018/07/09");
		MShisetsu mShisetsu = readJson("TestGetkampuRitsu_Step2_mShisetsu.pra", new TypeToken<MShisetsu>() {}.getType());
		Map<Short, Map<Short, List<MKampuKikan>>> kampuKikanMap = new HashMap<>();
		Optional<Short> ret = ryokinSeisanService.getkampuRitsu(meisai, toshoUketsukeDate, mShisetsu, kampuKikanMap);
		Short ret2 = ret.orElse(null);
		assertNull(ret2);
	}

	@Test
	@DisplayName("引数より適用する還付率を返却します. 対象が存在しなかった場合、nullを返却します.")
	public void TestGetkampuRitsu_Step3() throws Exception {
		SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
		TShinseiMeisai meisai = readJson("TestGetkampuRitsu_Step3_meisai.pra", new TypeToken<TShinseiMeisai>() {}.getType());
		Date toshoUketsukeDate = format.parse("2018/07/09");
		MShisetsu mShisetsu = readJson("TestGetkampuRitsu_Step3_mShisetsu.pra", new TypeToken<MShisetsu>() {}.getType());
		Map<Short, Map<Short, List<MKampuKikan>>> kampuKikanMap = readJson("TestGetkampuRitsu_Step3_kampuKikanMap.pra", new TypeToken<Map<Short, Map<Short, List<MKampuKikan>>>>() {}.getType());
		Optional<Short> ret = ryokinSeisanService.getkampuRitsu(meisai, toshoUketsukeDate, mShisetsu, kampuKikanMap);
		Short ret2 = ret.orElse(null);
		Short exp = Short.valueOf((short)100);
		assertEquals(exp, ret2);
	}
}
