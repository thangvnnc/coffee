package jp.ne.yec.seagullLC.stagia.test.junit.logic.master.MKashidashiGroupLogic;

import static org.junit.Assert.*;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.entity.MKashidashiGroup;
import jp.ne.yec.seagullLC.stagia.logic.master.MKashidashiGroupLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestMKashidashiGroupLogic extends JunitBase {

	@Autowired
	MKashidashiGroupLogic mKashidashiGroupLogic;

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetMKashidashiGroupList.xlsx")
	public void TestgetMKashidashiGroupList() throws Exception
	{
	    Short kanriCode = 10;
	    Short kashidashiGroupCode = 101;
	  	List<MKashidashiGroup> ret = mKashidashiGroupLogic.getMKashidashiGroupList(kanriCode, kashidashiGroupCode);
	 	exportJsonData(ret, "TestgetMKashidashiGroupList.json");
	}

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetMKashidashiGroupList.xlsx")
	public void TestgetMKashidashiGroupByShisetsu() throws Exception
	{
	    SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
	    Short kanriCD = 10;
	    Short shisetsuCD = 10;
	    String startDates = "4/1/2010";
	    String endDates =  "3/31/2100";
	    Date startDate = formatter.parse(startDates);
	    Date endDate = formatter.parse(endDates);
	    List<MKashidashiGroup> ret = mKashidashiGroupLogic.getMKashidashiGroupByShisetsu(kanriCD, shisetsuCD,
	    									startDate,endDate);
	  	exportJsonData(ret, "TestgetMKashidashiGroupByShisetsu.json");
	}
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetMKashidashiGroupList.xlsx")
	public void TestgetMKashidashiGroupList_Map() throws Exception
	{
		Map<Short, Set<Short>> kanriKashidashiGroupMap = new HashMap<>();
		Set<Short> setShort = new HashSet<Short>();
		setShort.add((short)101);
		setShort.add((short)10);
		kanriKashidashiGroupMap.put((short)10, setShort);
		LocalDate date = LocalDate.now();
		List<MKashidashiGroup> ret =  mKashidashiGroupLogic.getMKashidashiGroupList(kanriKashidashiGroupMap, date);
		exportJsonData(ret, "TestgetMKashidashiGroupList_Map.json");
	}
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetMKashidashiGroupList.xlsx")
	public void TestgetMKashidashiGroupList_List() throws Exception
	{
		Map<Short, List<Short>> kanriKashidashiGroupMap = new HashMap<>();
		List<Short> mList = new ArrayList<>();
		mList.add((short)10);
		mList.add((short)101);
		kanriKashidashiGroupMap.put((short) 10, mList);
		List<MKashidashiGroup> ret = mKashidashiGroupLogic.getMKashidashiGroupList(kanriKashidashiGroupMap);
		exportJsonData(ret, "TestgetMKashidashiGroupList_List.json");
	}

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetMKashidashiGroupList.xlsx")
	public void TestgetKomaPatternCode() throws Exception
	{
		MKashidashiGroup mKashidashiGroup = new MKashidashiGroup();
		mKashidashiGroup.setShukujitsuPattern((short)1);
		mKashidashiGroup.setHeijitsuPattern((short)2);
		mKashidashiGroup.setNichiyoPattern((short)3);
		mKashidashiGroup.setDoyoPattern((short)4);		
		SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss");
		String startDatess = "6/27/2018 4:30:00";
		Date shiyoDate = formatter.parse(startDatess);
		Short ret = mKashidashiGroupLogic.getKomaPatternCode(mKashidashiGroup, shiyoDate);
		Short exp = (short)2;
		assertEquals(exp, ret);
	}
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetMKashidashiGroupList.xlsx")
	public void TestgetKomaPatternCode_Short1() throws Exception
	{

		MKashidashiGroup mKashidashiGroup = new MKashidashiGroup();
		mKashidashiGroup.setShukujitsuPattern((short)1);
		mKashidashiGroup.setHeijitsuPattern((short)2);
		mKashidashiGroup.setNichiyoPattern((short)3);
		mKashidashiGroup.setDoyoPattern((short)4);

		LocalDate shiyoDate = LocalDate.of(2018, 1, 1);

		Short ret =  mKashidashiGroupLogic.getKomaPatternCode(mKashidashiGroup, shiyoDate);
		Short exp = (short)1;
		assertEquals(exp, ret);
	}
	
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetMKashidashiGroupList.xlsx")
	public void TestgetKomaPatternCode_Short2() throws Exception
	{

		MKashidashiGroup mKashidashiGroup = new MKashidashiGroup();
		mKashidashiGroup.setShukujitsuPattern((short)1);
		mKashidashiGroup.setHeijitsuPattern((short)2);
		mKashidashiGroup.setNichiyoPattern((short)3);
		mKashidashiGroup.setDoyoPattern((short)4);

		LocalDate shiyoDate = LocalDate.of(2018, 7, 1);

		Short ret =  mKashidashiGroupLogic.getKomaPatternCode(mKashidashiGroup, shiyoDate);
		Short exp = (short)3;
		assertEquals(exp, ret);
	}
	
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetMKashidashiGroupList.xlsx")
	public void TestgetKomaPatternCode_Short3() throws Exception
	{

		MKashidashiGroup mKashidashiGroup = new MKashidashiGroup();
		mKashidashiGroup.setShukujitsuPattern((short)1);
		mKashidashiGroup.setHeijitsuPattern((short)2);
		mKashidashiGroup.setNichiyoPattern((short)3);
		mKashidashiGroup.setDoyoPattern((short)4);

		LocalDate shiyoDate = LocalDate.of(2018, 6, 30);

		Short ret =  mKashidashiGroupLogic.getKomaPatternCode(mKashidashiGroup, shiyoDate);
		Short exp = (short)4;
		assertEquals(exp, ret);
	}
	
	@Test
	public void TestgetDao() throws Exception
	{
		GenericDao<MKashidashiGroup, ?>  ret = mKashidashiGroupLogic.getDao();
	}
}