package jp.ne.yec.seagullLC.stagia.test.selenide.page.shinsei;

import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.codeborne.selenide.SelenideElement;

import jp.ne.yec.seagullLC.stagia.test.selenide.page.base.SelenidePageBase;

/**
 * 申請確認画面のテストクラス.
 *
 * @author nao-hirata
 *
 */
public class ShinseiKakuninTest extends SelenidePageBase {

	@FindBy(how = How.CSS, using = "button[wicketpath=form_shinseiKakutei]")
	protected SelenideElement shinseiKakuteiButton;

	/**
	 * 確定ボタンをクリックします.
	 */
	public void kakuteiButtonClick () {
		click(shinseiKakuteiButton);
	}
}
