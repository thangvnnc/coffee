package jp.ne.yec.seagullLC.stagia.test.junit.logic.transaction.TRyoshuLogic;

import static org.junit.Assert.*;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.beans.criteria.SearchIKeshikomiDto;
import jp.ne.yec.seagullLC.stagia.beans.enums.JokenHukumu;
import jp.ne.yec.seagullLC.stagia.beans.enums.domain.RyokinKubun;
import jp.ne.yec.seagullLC.stagia.beans.enums.domain.base.StagiaEnum;
import jp.ne.yec.seagullLC.stagia.beans.madoguchi.RyoshuKeshikomiDto;
import jp.ne.yec.seagullLC.stagia.entity.MBasho;
import jp.ne.yec.seagullLC.stagia.entity.MKanri;
import jp.ne.yec.seagullLC.stagia.entity.MShisetsu;
import jp.ne.yec.seagullLC.stagia.entity.TRyoshu;
import jp.ne.yec.seagullLC.stagia.logic.transaction.TRyoshuLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestTRyoshuLogic extends JunitBase {

	@Autowired
	TRyoshuLogic tRyoshuLogic;

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestGetTRyoshuInit.xlsx")
	public void TestGetTRyoshu1() throws Exception
	{
		Map<Short, List<Integer>> kanriRyoshuMap = new HashMap<Short, List<Integer>>();
		List<Integer> kanriRyoshuValue = new ArrayList<>();
		kanriRyoshuValue.add(420);
		kanriRyoshuMap.put((short)10, kanriRyoshuValue);
		List<TRyoshu> ret = tRyoshuLogic.getTRyoshu(kanriRyoshuMap);
		exportJsonData(ret, "TestGetTRyoshu1.json");
	}
	
	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestGetTRyoshuInit.xlsx")
	public void TestGetTRyoshu2() throws Exception
	{
		Map<Short, List<Integer>> kanriRyoshuMap = new HashMap<Short, List<Integer>>();
		List<TRyoshu> ret = tRyoshuLogic.getTRyoshu(kanriRyoshuMap);
		assertEquals(0, ret.size());
	}

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestGetRyokinSeisanDto.xlsx")
	public void TestGetRyokinSeisanDto1() throws Exception
	{
		SimpleDateFormat sd = new SimpleDateFormat("yyyy/M/d");
		SearchIKeshikomiDto searchCriteriaDto = new SearchIKeshikomiDto();
		searchCriteriaDto.setLoginId("37987");

		MKanri mKanri = new MKanri();
		mKanri.setKanriCode((short)10);

		searchCriteriaDto.setMKanri(mKanri);
		searchCriteriaDto.setJoken(JokenHukumu.ICCHI);

		List<MShisetsu> mShisetsuList = new ArrayList<>();
		MShisetsu mShisetsu = new MShisetsu();
		mShisetsu.setKanriCode((short)10);
		mShisetsu.setBashoCode((short)10);
		mShisetsu.setShisetsuCode((short)10);
		mShisetsuList.add(mShisetsu);

		List<RyokinKubun> ryokinKubunList = new ArrayList<>();
		ryokinKubunList.add(RyokinKubun.SHISETSU);

		searchCriteriaDto.setMShisetsuList(mShisetsuList);
		searchCriteriaDto.setRyokinKubunList(ryokinKubunList);
		
		StagiaEnum stagiaEnum2 = RyokinKubun.SHISETSU;
		List<StagiaEnum> kampuHohoList = new ArrayList<>();
		kampuHohoList.add(stagiaEnum2);
		
		List<StagiaEnum> kampuJotaiList = new ArrayList<>();
		StagiaEnum stagiaEnum = RyokinKubun.SETSUBI;
		kampuJotaiList.add(stagiaEnum);

		searchCriteriaDto.setSeisanHohoList(kampuHohoList);
		searchCriteriaDto.setSeisanJotaiList(kampuJotaiList);

		searchCriteriaDto.setShinseiNoFrom(443);
		searchCriteriaDto.setShinseiNoTo(445);
		
		MBasho mBasho = new MBasho();
		mBasho.setBashoCode((short)10);
		searchCriteriaDto.setMBasho(mBasho);
		
		Date yoteiDateFrom = new Date();
		yoteiDateFrom = sd.parse("2018/5/24");
		Date yoteiDateTo = new Date();
		yoteiDateTo = sd.parse("2018/5/27");
		searchCriteriaDto.setYoteiDateFrom(yoteiDateFrom);
		searchCriteriaDto.setYoteiDateTo(yoteiDateTo);

		Date shiyoDateFrom = new Date();
		shiyoDateFrom = sd.parse("2018/4/18");
		Date shiyoDateTo = new Date();
		shiyoDateTo = sd.parse("2018/4/20");
		searchCriteriaDto.setShiyoDateFrom(shiyoDateFrom);
		searchCriteriaDto.setShiyoDateTo(shiyoDateTo);
		
		Date choteiDateFrom = new Date();
		choteiDateFrom = sd.parse("2018/5/25");
		Date choteiDateTo = new Date();
		choteiDateTo = sd.parse("2018/5/27");
		searchCriteriaDto.setChoteiDateFrom(choteiDateFrom);
		searchCriteriaDto.setChoteiDateTo(choteiDateTo);
		
		Date uketsukeDateFrom = new Date();
		uketsukeDateFrom = sd.parse("2018/5/24");
		Date uketsukeDateTo = new Date();
		uketsukeDateTo = sd.parse("2018/5/26");
		searchCriteriaDto.setUketsukeDateFrom(uketsukeDateFrom);
		searchCriteriaDto.setUketsukeDateTo(uketsukeDateTo);
		
		MBasho uketsukeBasho = new MBasho();
		uketsukeBasho.setBashoCode((short)10);
		searchCriteriaDto.setUketsukeBasho(uketsukeBasho);
		
		Date seisanDateFrom = new Date();
		seisanDateFrom = sd.parse("2018/5/25");
		Date seisanDateTo = new Date();
		seisanDateTo = sd.parse("2018/5/27");
		searchCriteriaDto.setSeisanDateFrom(seisanDateFrom);
		searchCriteriaDto.setSeisanDateTo(seisanDateTo);
		
		searchCriteriaDto.setSeisanNoFrom(419);
		searchCriteriaDto.setSeisanNoTo(421);
		
		List<RyoshuKeshikomiDto> ret = tRyoshuLogic.getRyoshuKeshikomiDto(searchCriteriaDto);
		exportJsonData(ret, "TestGetRyokinSeisanDto1.json");
	}
	
	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestGetRyokinSeisanDto.xlsx")
	public void TestGetRyokinSeisanDto2() throws Exception
	{
		SimpleDateFormat sd = new SimpleDateFormat("yyyy/M/d");
		SearchIKeshikomiDto searchCriteriaDto = new SearchIKeshikomiDto();
		searchCriteriaDto.setLoginId("37987");

		MKanri mKanri = new MKanri();
		mKanri.setKanriCode((short)10);

		searchCriteriaDto.setMKanri(mKanri);
		searchCriteriaDto.setJoken(JokenHukumu.HUKUMU);

		searchCriteriaDto.setShinseiNoFrom(443);
		searchCriteriaDto.setShinseiNoTo(445);
		
		MBasho mBasho = new MBasho();
		mBasho.setBashoCode((short)10);
		searchCriteriaDto.setMBasho(mBasho);
		
		Date yoteiDateFrom = new Date();
		yoteiDateFrom = sd.parse("2018/5/24");
		Date yoteiDateTo = new Date();
		yoteiDateTo = sd.parse("2018/5/27");
		searchCriteriaDto.setYoteiDateFrom(yoteiDateFrom);
		searchCriteriaDto.setYoteiDateTo(yoteiDateTo);

		Date shiyoDateFrom = new Date();
		shiyoDateFrom = sd.parse("2018/4/18");
		Date shiyoDateTo = new Date();
		shiyoDateTo = sd.parse("2018/4/20");
		searchCriteriaDto.setShiyoDateFrom(shiyoDateFrom);
		searchCriteriaDto.setShiyoDateTo(shiyoDateTo);
		
		Date choteiDateFrom = new Date();
		choteiDateFrom = sd.parse("2018/5/25");
		Date choteiDateTo = new Date();
		choteiDateTo = sd.parse("2018/5/27");
		searchCriteriaDto.setChoteiDateFrom(choteiDateFrom);
		searchCriteriaDto.setChoteiDateTo(choteiDateTo);
		
		Date uketsukeDateFrom = new Date();
		uketsukeDateFrom = sd.parse("2018/5/24");
		Date uketsukeDateTo = new Date();
		uketsukeDateTo = sd.parse("2018/5/26");
		searchCriteriaDto.setUketsukeDateFrom(uketsukeDateFrom);
		searchCriteriaDto.setUketsukeDateTo(uketsukeDateTo);
		
		MBasho uketsukeBasho = new MBasho();
		uketsukeBasho.setBashoCode((short)10);
		searchCriteriaDto.setUketsukeBasho(uketsukeBasho);
		
		Date seisanDateFrom = new Date();
		seisanDateFrom = sd.parse("2018/5/25");
		Date seisanDateTo = new Date();
		seisanDateTo = sd.parse("2018/5/27");
		searchCriteriaDto.setSeisanDateFrom(seisanDateFrom);
		searchCriteriaDto.setSeisanDateTo(seisanDateTo);
		
		searchCriteriaDto.setSeisanNoFrom(419);
		searchCriteriaDto.setSeisanNoTo(421);
		
		List<RyoshuKeshikomiDto> ret = tRyoshuLogic.getRyoshuKeshikomiDto(searchCriteriaDto);
		exportJsonData(ret, "TestGetRyokinSeisanDto2.json");
	}
	
	@Test
	@DisplayName("IDを検索条件としてTRyoshuMeisaiを取得します.")
	public void TestgetDao() throws Exception {
		GenericDao<TRyoshu, ?> ret = tRyoshuLogic.getDao();
	}
}