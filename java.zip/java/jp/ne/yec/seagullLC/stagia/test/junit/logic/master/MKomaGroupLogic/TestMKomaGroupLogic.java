package jp.ne.yec.seagullLC.stagia.test.junit.logic.master.MKomaGroupLogic;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.entity.MKomaGroup;
import jp.ne.yec.seagullLC.stagia.logic.master.MKomaGroupLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestMKomaGroupLogic extends JunitBase {

	@Autowired
	MKomaGroupLogic mKomaGroupLogic;

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetMKomaGroup.xlsx")
	public void TestgetMKomaGroup() throws Exception
	{
		List<Short> komaPattrernCodeLists = new ArrayList<Short>();
		Short  komaPattrernCodeList = 112;
		komaPattrernCodeLists.add(komaPattrernCodeList);
		List<MKomaGroup>  ret = mKomaGroupLogic.getMKomaGroup(komaPattrernCodeLists);
		exportJsonData(ret, "TestgetMKomaGroup.json");
	}
	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	public void TestgetDao() throws Exception
	{
		GenericDao<MKomaGroup, ?> ret = mKomaGroupLogic.getDao();
	}
}
