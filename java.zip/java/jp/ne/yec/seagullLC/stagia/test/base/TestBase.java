package jp.ne.yec.seagullLC.stagia.test.base;

import static org.junit.Assert.*;

import java.lang.reflect.Method;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Savepoint;
import java.sql.Statement;

import org.dbunit.DatabaseUnitException;
import org.dbunit.database.IDatabaseConnection;
import org.dbunit.database.QueryDataSet;
import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.excel.XlsDataSet;
import org.dbunit.operation.DatabaseOperation;
import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.jupiter.api.DisplayName;
import org.junit.rules.TestName;
import org.springframework.jdbc.CannotGetJdbcConnectionException;

import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestDeleteDataFile;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;

public abstract class TestBase {

	protected IDatabaseConnection iDatabaseConnection;

	protected IDataSet dataSet = null;

	@Rule
	public TestName testName = new TestName();

	/**
	 * DbUnit用のコネクションを返します.
	 *
	 * @return
	 * @throws CannotGetJdbcConnectionException
	 * @throws DatabaseUnitException
	 */
	protected abstract IDatabaseConnection getIConnection() throws Exception;

	/**
	 * 初期処理
	 *
	 * @throws Exception
	 */
	@Before
	public void setUp() throws Exception {
		iDatabaseConnection = getIConnection();
		setUpTestDataCreanInsert();
	}

	/**
	 * 終了処理
	 *
	 * @throws DatabaseUnitException
	 * @throws SQLException
	 */
	@After
	public void tearDown() throws Exception {
		clearDatabase();
		if (null != dataSet) {
			DatabaseOperation.DELETE.execute(iDatabaseConnection, dataSet);
		}
		iDatabaseConnection.close();
	}

	public void clearDatabase() throws SQLException{
		DatabaseMetaData databaseMetaData = iDatabaseConnection.getConnection().getMetaData();
        String[] types = {"TABLE"};
        ResultSet resultSet = databaseMetaData.getTables(null, null, "%", types);
        StringBuilder stringBuilder = new StringBuilder();
        while (resultSet.next()) {
        	String deleteTableSql = "DELETE FROM " + resultSet.getString("TABLE_NAME") + ";";
            stringBuilder.append(deleteTableSql);
        }
        Statement statement = iDatabaseConnection.getConnection().createStatement();
        statement.execute(stringBuilder.toString());
        statement.close();
	}

//	public void deleteDataFile(){
//		String fileDelName = getTestDeleteDataFile();
//		if (fileDelName == null) {
//			return;
//		}
//		try {
//			IDataSet dataSetDel = new XlsDataSet(this.getClass().getResourceAsStream(fileDelName));
//			DatabaseOperation.DELETE.execute(iDatabaseConnection, dataSetDel);
//		} catch (Exception e) {
//			System.out.println(e.getMessage());
//			assertFalse(true);
//		}
//	}

	/**
	 * EXCELファイルからテストデータをクリーンインサートします
	 *
	 * @param testDataFile
	 *            テストファイル名
	 *
	 */
	protected void setUpTestDataCreanInsert() {
		String fileName = getTestDataFile();
		if (fileName == null) {
			return;
		}
		try {
			dataSet = new XlsDataSet(this.getClass().getResourceAsStream(fileName));
			DatabaseOperation.CLEAN_INSERT.execute(iDatabaseConnection, dataSet);
		} catch (Exception e) {
			System.out.println(e.getMessage());
			assertFalse(true);
		}
	}

	/**
	 * 実行中のテストメソッドのTestFileNameアノテーションを返します.
	 *
	 * @return
	 */
	protected String getTestDataFile() {
		for (Method method : getClass().getMethods()) {
			if (!method.getName().equals(testName.getMethodName())) {
				continue;
			}
			TestInitDataFile testDataFile = method.getDeclaredAnnotation(TestInitDataFile.class);
			if (null != testDataFile) {
				return testDataFile.value();
			}
		}
		return null;
	}

	protected String getTestDeleteDataFile() {
		for (Method method : getClass().getMethods()) {
			if (!method.getName().equals(testName.getMethodName())) {
				continue;
			}
			TestDeleteDataFile testDataFile = method.getDeclaredAnnotation(TestDeleteDataFile.class);
			if (null != testDataFile) {
				return testDataFile.value();
			}
		}
		return null;
	}

	/**
	 * 実行中のテストメソッドのDisplayNameアノテーションを返します.
	 *
	 * @return
	 */
	protected String getDisplayName() {
		for (Method method : getClass().getMethods()) {
			if (!method.getName().equals(testName.getMethodName())) {
				continue;
			}
			DisplayName displayName = method.getDeclaredAnnotation(DisplayName.class);
			if (null != displayName) {
				return displayName.value();
			}
		}
		return "";
	}
}
