package jp.ne.yec.seagullLC.stagia.test.junit.logic.master.MKembaikiButtonLogic;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

//import jp.ne.yec.seagullLC.stagia.entity.MJusho;
//import jp.ne.yec.seagullLC.stagia.logic.master.MJushoLogic;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestMKembaikiButtonLogic extends JunitBase {

	@Autowired
	//MJushoLogic mJushoLogic;

	@Test
	@DisplayName("引数なしでM_料金体系を取得します.")
	//@TestInitDataFile("TestRiyoshaServiceInit.xlsx")
	public void TestGetDAO() throws Exception {
		//GenericDao<MJusho, ?> ret = mJushoLogic.getDao();
		//assertEquals(mRyokinTaikeiDao, ret);
	}
}
