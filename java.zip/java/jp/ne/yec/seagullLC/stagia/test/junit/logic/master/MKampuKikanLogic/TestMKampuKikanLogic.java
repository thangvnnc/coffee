package jp.ne.yec.seagullLC.stagia.test.junit.logic.master.MKampuKikanLogic;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.entity.MKampuKikan;
import jp.ne.yec.seagullLC.stagia.logic.master.MKampuKikanLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestMKampuKikanLogic extends JunitBase {

	@Autowired
	MKampuKikanLogic mKampuKikanLogic;

	@Test
	@DisplayName("検索条件なしでM_銀行を取得しStringCodeNamePairの形式で返却します")
	@TestInitDataFile("TestGetMKampuKikan.xlsx")
	public void TestGetMKampuKikan() throws Exception
	{
		Short kanriShisetsuMapKey = 10;

		List<Short> kanriShisetsuMapValue = new ArrayList<>();
		kanriShisetsuMapValue.add((short)10);

		Map<Short, List<Short>> kanriShisetsuMap = new HashMap<Short, List<Short>>();
		kanriShisetsuMap.put(kanriShisetsuMapKey, kanriShisetsuMapValue);

		List<MKampuKikan>  ret = mKampuKikanLogic.getMKampuKikan(kanriShisetsuMap);
		exportJsonData(ret, "TestGetMKampuKikan.json");
	}
	@Test
	@DisplayName("検索条件なしでM_銀行を取得しStringCodeNamePairの形式で返却します")
	//@TestInitDataFile("TestGetMKampuKikan.xlsx")
	public void TestgetDao() throws Exception
	{
		GenericDao<MKampuKikan, ?> ret = mKampuKikanLogic.getDao();
	}
}