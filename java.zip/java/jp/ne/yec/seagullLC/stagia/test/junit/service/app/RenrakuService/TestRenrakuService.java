package jp.ne.yec.seagullLC.stagia.test.junit.service.app.RenrakuService;

import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.seagullLC.stagia.service.app.RenrakuService;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = { "classpath:TestApplicationContext.xml" })
@WebAppConfiguration
public class TestRenrakuService extends JunitBase {

	@Autowired
	RenrakuService renrakuService;

//	@Test
//	public void TestAppGetRenraku() throws Exception {
//		//Map<String, String> mapUnit = readMapFileSimple("TestAppGetRenraku_maptext.txt", String.class, String.class);
//		List<Map<String, String>> listText = new ArrayList<Map<String, String>>();
//		Map<String, String> mapUnit = new HashMap<String, String>();
//		mapUnit.put("renrakuKubun", "oshirase");
//		listText.add(mapUnit);
//
//		Map<String, String> mapUnit1 = new HashMap<String, String>();
//		mapUnit1.put("renrakuKubun", "oshirase1");
//		listText.add(mapUnit1);
//
//		Map<String, String> mapUnit2 = new HashMap<String, String>();
//		listText.add(mapUnit2);
//
//		List<Map<String, String>[]> jsonData = new ArrayList<Map<String, String>[]>();
//		for (int idx = 0; idx < listText.size(); idx++)
//		{
//			Map<String, String>[] mapArray = renrakuService.appGetRenraku(listText.get(idx));
//			jsonData.add(mapArray);
//		}
//
//		exportJsonData(jsonData, "TestAppGetRenraku.json");
//	}
//
//	@Test
//	public void TestAppReadRenraku() throws Exception {
//		List<String> listText =  new ArrayList<String>();
//		listText.add("1");
//
//		List<String> jsonData = new ArrayList<String>();
//		for (String text : listText) {
//			String result = renrakuService.appReadRenraku(text);
//			jsonData.add(result);
//		}
//
//		exportJsonData(jsonData, "TestAppReadRenraku.json");
//	}
}