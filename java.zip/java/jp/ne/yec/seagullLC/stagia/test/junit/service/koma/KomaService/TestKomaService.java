package jp.ne.yec.seagullLC.stagia.test.junit.service.koma.KomaService;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.seagullLC.stagia.entity.MKoma;
import jp.ne.yec.seagullLC.stagia.entity.MKomaGroup;
import jp.ne.yec.seagullLC.stagia.entity.MKomaPattern;
import jp.ne.yec.seagullLC.stagia.entity.MShisetsu;
import jp.ne.yec.seagullLC.stagia.service.koma.KomaService;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = { "classpath:TestApplicationContext.xml" })
@WebAppConfiguration
public class TestKomaService extends JunitBase {

	@Autowired
	KomaService komaService;

	@Test
	@TestInitDataFile("TestGetMKomaListInit.xlsx")
	@DisplayName("コマパターン、コマコード毎のMコマを格納した{@code Map}を返却します.")
	public void TestGetMKomaList() throws Exception {
		String shiyoDate = "2018/06/26";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy/MM/dd");
		List<MKoma> list = komaService.getMKomaList(
					(short)10,
					(short)101,
					simpleDateFormat.parse(shiyoDate));

		exportJsonData(list, "TestGetMKomaList.json");
	}

	@Test
	@TestInitDataFile("TestGetMKomaMapWithDateInit.xlsx")
	@DisplayName("コマパターン毎のMコマを格納した{@code Map}を返却します. 引数の開始、終了時間がNullの場合、検索条件に含めません。")
	public void TestGetMKomaMapWithDateStep1() throws Exception {
		List<List<Short>> komaPattrernCodeLists = new ArrayList<>();
		List<Short> komaPattrernCodes = new ArrayList<>();
		komaPattrernCodes.add((short)2);
		komaPattrernCodeLists.add(komaPattrernCodes);
		komaPattrernCodeLists.add(komaPattrernCodes);
		komaPattrernCodeLists.add(komaPattrernCodes);

		List<LocalTime> startTimes = new ArrayList<>();
		LocalTime startTime = LocalTime.of(15, 35, 0);
		startTimes.add(null);
		startTimes.add(startTime);
		startTimes.add(startTime);

		List<LocalTime> endTimes = new ArrayList<>();
		LocalTime endTime = LocalTime.of(15, 35, 0);
		endTimes.add(null);
		endTimes.add(null);
		endTimes.add(endTime);

		Map<Short, List<MKoma>> map = komaService.getMKomaMap(komaPattrernCodes, null, null);
		exportJsonData(map,	"TestGetMKomaMapWithDateStep1.json");
	}

	@Test
	@TestInitDataFile("TestGetMKomaMapWithDateInit.xlsx")
	@DisplayName("コマパターン毎のMコマを格納した{@code Map}を返却します. 引数の開始、終了時間がNullの場合、検索条件に含めません。")
	public void TestGetMKomaMapWithDateStep2() throws Exception {
		List<List<Short>> komaPattrernCodeLists = new ArrayList<>();
		List<Short> komaPattrernCodes = new ArrayList<>();
		komaPattrernCodes.add((short)2);
		komaPattrernCodeLists.add(komaPattrernCodes);
		komaPattrernCodeLists.add(komaPattrernCodes);
		komaPattrernCodeLists.add(komaPattrernCodes);

		List<LocalTime> startTimes = new ArrayList<>();
		LocalTime startTime = LocalTime.of(15, 35, 0);
		startTimes.add(null);
		startTimes.add(startTime);
		startTimes.add(startTime);

		List<LocalTime> endTimes = new ArrayList<>();
		LocalTime endTime = LocalTime.of(15, 35, 0);
		endTimes.add(null);
		endTimes.add(null);
		endTimes.add(endTime);

		Map<Short, List<MKoma>> map = komaService.getMKomaMap(komaPattrernCodes, startTime, null);
		exportJsonData(map,	"TestGetMKomaMapWithDateStep2.json");
	}


	@Test
	@TestInitDataFile("TestGetMKomaMapWithDateInit.xlsx")
	@DisplayName("コマパターン毎のMコマを格納した{@code Map}を返却します. 引数の開始、終了時間がNullの場合、検索条件に含めません。")
	public void TestGetMKomaMapWithDateStep3() throws Exception {
		List<List<Short>> komaPattrernCodeLists = new ArrayList<>();
		List<Short> komaPattrernCodes = new ArrayList<>();
		komaPattrernCodes.add((short)2);
		komaPattrernCodeLists.add(komaPattrernCodes);
		komaPattrernCodeLists.add(komaPattrernCodes);
		komaPattrernCodeLists.add(komaPattrernCodes);

		List<LocalTime> startTimes = new ArrayList<>();
		LocalTime startTime = LocalTime.of(15, 35, 0);
		startTimes.add(null);
		startTimes.add(startTime);
		startTimes.add(startTime);

		List<LocalTime> endTimes = new ArrayList<>();
		LocalTime endTime = LocalTime.of(15, 35, 0);
		endTimes.add(null);
		endTimes.add(null);
		endTimes.add(endTime);

		Map<Short, List<MKoma>> map = komaService.getMKomaMap(komaPattrernCodes, startTime, endTime);
		exportJsonData(map,	"TestGetMKomaMapWithDateStep3.json");
	}

	@Test
	@TestInitDataFile("TestGetMKomaMapInit.xlsx")
	@DisplayName("コマパターン毎のMコマを格納した{@code Map}を返却します.")
	public void TestGetMKomaMap() throws Exception {
		List<Short> komaPattrernCodes = new ArrayList<>();
		komaPattrernCodes.add((short)2);
		Map<Short, List<MKoma>> map = komaService.getMKomaMap(komaPattrernCodes);
		exportJsonData(map, "TestGetMKomaMap.json");
	}

	@Test
	@TestInitDataFile("TestGetDateToMKomaPatternMapInit.xlsx")
	@DisplayName("日付毎のMコマパターンを格納した{@code Map}を返却します. 日付に対応するMコマパターンが存在しない場合、XXXXExceptionをthrowします。")
	public void TestGetDateToMKomaPatternMap() throws Exception {
		List<Short> listKanriCode = new ArrayList<>();
		listKanriCode.add((short)10);

		List<Short> listKashidashiGroupCode = new ArrayList<>();
		listKashidashiGroupCode.add((short)103);

		List<LocalDate> days = new ArrayList<LocalDate>();
		days.add(LocalDate.now());
		List<List<LocalDate>> dayLists = new ArrayList<>();
		dayLists.add(days);

		List<Map<LocalDate, MKomaPattern>> exports = new ArrayList<>();
		for (int idx = 0; idx < listKanriCode.size(); idx++) {
			Map<LocalDate, MKomaPattern> map = komaService.getDateToMKomaPatternMap(
					listKanriCode.get(idx),
					listKashidashiGroupCode.get(idx),
					dayLists.get(idx)
					);
			exports.add(map);
		}
		exportJsonData(exports, "TestGetDateToMKomaPatternMap.json");
	}

	@Test
	@TestInitDataFile("TestGetKanrimeiListInit.xlsx")
	@DisplayName("引数のコマパターンコードに合致するMkomaGroupのリストを取得し、コマパターン、コマグループコードをキーとしたMapに整形後、返却します.")
	public void TestGetKanrimeiList() throws Exception {
		List<Short> komaPattrernCodes = new ArrayList<>();
		komaPattrernCodes.add((short)312);
		Map<Short, Map<Short, MKomaGroup>> map = komaService.getMKomaGroup(komaPattrernCodes);
		exportJsonData(map, "TestGetKanrimeiList.json");
	}

	@Test
	@TestInitDataFile("TestGetShisetsuToMKomaPatternMapInit.xlsx")
	@DisplayName("引数のコマパターンコードに合致するMkomaGroupのリストを取得し、コマパターン、コマグループコードをキーとしたMapに整形後、返却します.")
	public void TestGetShisetsuToMKomaPatternMap() throws Exception {
		List<MShisetsu> mShisetsuss = new ArrayList<MShisetsu>();
		MShisetsu mShisetsus = new MShisetsu();
		mShisetsus.setKanriCode((short)10);
		mShisetsus.setKashidashiGroupCode((short)101);
		mShisetsuss.add(mShisetsus);
		mShisetsuss.add(mShisetsus);

		String date = "2018/06/26";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy/MM/dd");

		Map<String, MKomaPattern> map = komaService.getShisetsuToMKomaPatternMap(mShisetsuss, simpleDateFormat.parse(date));
		exportJsonData(map, "TestGetShisetsuToMKomaPatternMap.json");
	}

	@Test
	@DisplayName("引数のコマパターンコードに合致するMkomaGroupのリストを取得し、コマパターン、コマグループコードをキーとしたMapに整形後、返却します.")
	public void TestGetStartEndKomaByTime() throws Exception {
		List<MKoma> mShisetsuss = new ArrayList<MKoma>();

		MKoma mShisetsus = new MKoma();
		mShisetsus.setStartTime((short)1);
		mShisetsus.setEndTime((short)100);
		mShisetsus.setKomaCode((short)10);
		mShisetsuss.add(mShisetsus);
		Short[] ret = komaService.getStartEndKomaByTime((short)1, (short)100, mShisetsuss);
		exportJsonData(ret, "TestGetStartEndKomaByTime.json");
	}
}
