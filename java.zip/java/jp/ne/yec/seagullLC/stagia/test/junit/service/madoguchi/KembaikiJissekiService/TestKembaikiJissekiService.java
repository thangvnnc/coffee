package jp.ne.yec.seagullLC.stagia.test.junit.service.madoguchi.KembaikiJissekiService;

import static org.junit.Assert.*;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.google.gson.reflect.TypeToken;

import jp.ne.yec.seagullLC.stagia.beans.madoguchi.MKembaikiDto;
import jp.ne.yec.seagullLC.stagia.beans.madoguchi.TKembaikiDto;
import jp.ne.yec.seagullLC.stagia.entity.MKanri;
import jp.ne.yec.seagullLC.stagia.service.madoguchi.KembaikiJissekiService;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = { "classpath:TestApplicationContext.xml" })
@WebAppConfiguration
public class TestKembaikiJissekiService extends JunitBase {

	@Autowired
	KembaikiJissekiService kembaikiJissekiService;

//	@Test
//	@DisplayName("管理コードと収納日をもとに券売機情報を取得します")
//	@TestInitDataFile("TestGetKanrimeiListInit.xlsx")
//	public void TestGetKanrimeiList() throws Exception {
//		List<List<MKanri>> jsonData = new ArrayList<List<MKanri>>();
//		List<Short> kanriCodes = new ArrayList<>();
//		kanriCodes.add((short)10);
//		List<MKanri> list = kembaikiJissekiService.getKanrimeiList(kanriCodes);
//		//assertEquals(2, list.size());
//		jsonData.add(list);
//		exportJsonData(jsonData, "TestGetKanrimeiList.json");
//	}
//
//	@Test
//	@DisplayName("管理コードと収納日をもとに券売機情報を取得します")
//	@TestInitDataFile("TestgetKembaikiJohoList.xlsx")
//	public void TestGetMKanri() throws Exception {
//		List<List<Map<MKembaikiDto,List<TKembaikiDto>>>> jsonData = new ArrayList<List<Map<MKembaikiDto,List<TKembaikiDto>>>>();
//		List<List<Short>> params = new ArrayList<List<Short>>();
//
//		List<Short> kanriCodes1 = new ArrayList<Short>();
//		kanriCodes1.add((short)10);
//		params.add(kanriCodes1);
//
//		List<Date> paramDates = new ArrayList<Date>();
//		String date = 2018 + "/" + 04 + "/" + 02;
//		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
//		Date shunoDate = formatter.parse(date);
//		paramDates.add(shunoDate);
//
//
//
//		List<Map<MKembaikiDto,List<TKembaikiDto>>> list = kembaikiJissekiService.getKembaikiList(params.get(0).get(0), paramDates.get(0));
//		//assertEquals(2, list.size());
//		jsonData.add(list);
//		exportJsonData(jsonData, "TestGetMKanri.json");
//	}

	@Test
	@DisplayName("管理コードと収納日をもとに券売機情報を取得します")
	public void TestInsertAndUpdateTKembaikiList() throws Exception {

		List<TKembaikiDto> kembaikiDtosForInsertOrUpdate = readJson("TestgetKembaikiJohoList_para.json", new TypeToken<List<TKembaikiDto>>(){}.getType());

		List<TKembaikiDto> kembaikiDtosForInsertOrUpdateBk = readJson("TestgetKembaikiJohoList_para.json", new TypeToken<List<TKembaikiDto>>(){}.getType());


		List<Date> shunoDates = new ArrayList<Date>();
//		String date = 2018 + "/" + 06 + "/" + 19;
//		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
//		Date shunoDate = formatter.parse(date);
		Date shunoDate = new Date();
		shunoDates.add(shunoDate);

		String updateBy = "8000";
		// List<TKembaikiDto> kembaikiDtosForInsertOrUpdate,
		// List<TKembaikiDto> kembaikiDtosForInsertOrUpdateBk, Date shunoDate
			kembaikiJissekiService.insertAndUpdateTKembaikiList(kembaikiDtosForInsertOrUpdate, kembaikiDtosForInsertOrUpdateBk, shunoDates.get(0), updateBy);
	}

	@Test
	@DisplayName("管理コードと収納日をもとに券売機情報を取得します")
	@TestInitDataFile("TestgetKembaikiJohoListInit.xlsx")
	public void TestInsertAndUpdateTKembaikiList_Step2() throws Exception {

		List<TKembaikiDto> kembaikiDtosForInsertOrUpdate = readJson("TestgetKembaikiJohoList_para.json", new TypeToken<List<TKembaikiDto>>(){}.getType());
		kembaikiDtosForInsertOrUpdate.get(1).setShunoDate(null);
		//kembaikiDtosForInsertOrUpdate.get(1).setGenkinShunoKensu(null);
//		kembaikiDtosForInsertOrUpdate.get(1).setGenkinShunogaku(null);
//		kembaikiDtosForInsertOrUpdate.get(1).setPuripeidoShunoKensu(null);
//		kembaikiDtosForInsertOrUpdate.get(1).setPuripeidoShunogaku(null);
//		kembaikiDtosForInsertOrUpdate.get(1).setHeiyoShunoKensu(null);
//		kembaikiDtosForInsertOrUpdate.get(1).setHeiyoGenkinShunogaku(null);
//		kembaikiDtosForInsertOrUpdate.get(1).setHeiyoPuripeidoShunogaku(null);
//		kembaikiDtosForInsertOrUpdate.get(1).setSeisanKensu(null);
//		kembaikiDtosForInsertOrUpdate.get(1).setSeisangaku(null);

		List<TKembaikiDto> kembaikiDtosForInsertOrUpdateBk = readJson("TestgetKembaikiJohoList_para.json", new TypeToken<List<TKembaikiDto>>(){}.getType());
		kembaikiDtosForInsertOrUpdateBk.get(0).setKembaikiCode((short)50);
		kembaikiDtosForInsertOrUpdateBk.get(0).setButtonCode((short)50);
		kembaikiDtosForInsertOrUpdateBk.get(0).setKanriCode((short)50);

		List<Date> shunoDates = new ArrayList<Date>();
//		String date = 2018 + "/" + 06 + "/" + 19;
//		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
//		Date shunoDate = formatter.parse(date);
		Date shunoDate = new Date();
		shunoDates.add(shunoDate);

		String updateBy = "8000";
		// List<TKembaikiDto> kembaikiDtosForInsertOrUpdate,
		// List<TKembaikiDto> kembaikiDtosForInsertOrUpdateBk, Date shunoDate
			kembaikiJissekiService.insertAndUpdateTKembaikiList(kembaikiDtosForInsertOrUpdate, kembaikiDtosForInsertOrUpdateBk, shunoDates.get(0), updateBy);
	}

	@Test
	@DisplayName("管理コードと収納日をもとに券売機情報を取得します")
	public void TestInsertAndUpdateTKembaikiList_Step3() throws Exception {

		List<TKembaikiDto> kembaikiDtosForInsertOrUpdate = readJson("TestgetKembaikiJohoList_para.json", new TypeToken<List<TKembaikiDto>>(){}.getType());
		kembaikiDtosForInsertOrUpdate.get(1).setKembaikiCode((short)10);
		kembaikiDtosForInsertOrUpdate.get(1).setButtonCode((short)20);
		kembaikiDtosForInsertOrUpdate.get(1).setKanriCode((short)10);
		String date = 2018 + "/" + 07 + "/" + 10;
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
		Date shunoDate1 = formatter.parse(date);
		kembaikiDtosForInsertOrUpdate.get(1).setShunoDate(shunoDate1);

		kembaikiDtosForInsertOrUpdate.get(1).setShunoDate(null);
		kembaikiDtosForInsertOrUpdate.get(1).setGenkinShunoKensu(null);
//		kembaikiDtosForInsertOrUpdate.get(1).setGenkinShunogaku(null);
//		kembaikiDtosForInsertOrUpdate.get(1).setPuripeidoShunoKensu(null);
//		kembaikiDtosForInsertOrUpdate.get(1).setPuripeidoShunogaku(null);
//		kembaikiDtosForInsertOrUpdate.get(1).setHeiyoShunoKensu(null);
//		kembaikiDtosForInsertOrUpdate.get(1).setHeiyoGenkinShunogaku(null);
//		kembaikiDtosForInsertOrUpdate.get(1).setHeiyoPuripeidoShunogaku(null);
//		kembaikiDtosForInsertOrUpdate.get(1).setSeisanKensu(null);
//		kembaikiDtosForInsertOrUpdate.get(1).setSeisangaku(null);

		List<TKembaikiDto> kembaikiDtosForInsertOrUpdateBk = readJson("TestgetKembaikiJohoList_para.json", new TypeToken<List<TKembaikiDto>>(){}.getType());
//		kembaikiDtosForInsertOrUpdateBk.get(0).setKembaikiCode((short)10);
//		kembaikiDtosForInsertOrUpdateBk.get(0).setButtonCode((short)20);
//		kembaikiDtosForInsertOrUpdateBk.get(0).setKanriCode((short)10);
//		String date1 = 2018 + "/" + 07 + "/" + 10;
//		//SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
//		Date shunoDate2 = formatter.parse(date1);
//		kembaikiDtosForInsertOrUpdateBk.get(0).setShunoDate(shunoDate2);

		List<Date> shunoDates = new ArrayList<Date>();
//		String date = 2018 + "/" + 06 + "/" + 19;
//		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
//		Date shunoDate = formatter.parse(date);
		Date shunoDate = new Date();
		shunoDates.add(shunoDate);

		String updateBy = "8000";
		// List<TKembaikiDto> kembaikiDtosForInsertOrUpdate,
		// List<TKembaikiDto> kembaikiDtosForInsertOrUpdateBk, Date shunoDate
			kembaikiJissekiService.insertAndUpdateTKembaikiList(kembaikiDtosForInsertOrUpdate, kembaikiDtosForInsertOrUpdateBk, shunoDates.get(0), updateBy);
	}

	@Test
	@DisplayName("管理コードと収納日をもとに券売機情報を取得します")
	public void TestInsertAndUpdateTKembaikiList_Step4() throws Exception {

		List<TKembaikiDto> kembaikiDtosForInsertOrUpdate = readJson("TestgetKembaikiJohoList_para.json", new TypeToken<List<TKembaikiDto>>(){}.getType());
		kembaikiDtosForInsertOrUpdate.get(1).setKembaikiCode((short)10);
		kembaikiDtosForInsertOrUpdate.get(1).setButtonCode((short)20);
		kembaikiDtosForInsertOrUpdate.get(1).setKanriCode((short)10);
		String date = 2018 + "/" + 07 + "/" + 10;
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
		Date shunoDate1 = formatter.parse(date);
		kembaikiDtosForInsertOrUpdate.get(1).setShunoDate(shunoDate1);

		kembaikiDtosForInsertOrUpdate.get(1).setShunoDate(null);
		kembaikiDtosForInsertOrUpdate.get(1).setGenkinShunoKensu(null);
		kembaikiDtosForInsertOrUpdate.get(1).setGenkinShunogaku(null);
//		kembaikiDtosForInsertOrUpdate.get(1).setPuripeidoShunoKensu(null);
//		kembaikiDtosForInsertOrUpdate.get(1).setPuripeidoShunogaku(null);
//		kembaikiDtosForInsertOrUpdate.get(1).setHeiyoShunoKensu(null);
//		kembaikiDtosForInsertOrUpdate.get(1).setHeiyoGenkinShunogaku(null);
//		kembaikiDtosForInsertOrUpdate.get(1).setHeiyoPuripeidoShunogaku(null);
//		kembaikiDtosForInsertOrUpdate.get(1).setSeisanKensu(null);
//		kembaikiDtosForInsertOrUpdate.get(1).setSeisangaku(null);

		List<TKembaikiDto> kembaikiDtosForInsertOrUpdateBk = readJson("TestgetKembaikiJohoList_para.json", new TypeToken<List<TKembaikiDto>>(){}.getType());
//		kembaikiDtosForInsertOrUpdateBk.get(0).setKembaikiCode((short)10);
//		kembaikiDtosForInsertOrUpdateBk.get(0).setButtonCode((short)20);
//		kembaikiDtosForInsertOrUpdateBk.get(0).setKanriCode((short)10);
//		String date1 = 2018 + "/" + 07 + "/" + 10;
//		//SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
//		Date shunoDate2 = formatter.parse(date1);
//		kembaikiDtosForInsertOrUpdateBk.get(0).setShunoDate(shunoDate2);

		List<Date> shunoDates = new ArrayList<Date>();
//		String date = 2018 + "/" + 06 + "/" + 19;
//		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
//		Date shunoDate = formatter.parse(date);
		Date shunoDate = new Date();
		shunoDates.add(shunoDate);

		String updateBy = "8000";
		// List<TKembaikiDto> kembaikiDtosForInsertOrUpdate,
		// List<TKembaikiDto> kembaikiDtosForInsertOrUpdateBk, Date shunoDate
			kembaikiJissekiService.insertAndUpdateTKembaikiList(kembaikiDtosForInsertOrUpdate, kembaikiDtosForInsertOrUpdateBk, shunoDates.get(0), updateBy);
	}

	@Test
	@DisplayName("管理コードと収納日をもとに券売機情報を取得します")
	public void TestInsertAndUpdateTKembaikiList_Step5() throws Exception {

		List<TKembaikiDto> kembaikiDtosForInsertOrUpdate = readJson("TestgetKembaikiJohoList_para.json", new TypeToken<List<TKembaikiDto>>(){}.getType());
		kembaikiDtosForInsertOrUpdate.get(1).setKembaikiCode((short)10);
		kembaikiDtosForInsertOrUpdate.get(1).setButtonCode((short)20);
		kembaikiDtosForInsertOrUpdate.get(1).setKanriCode((short)10);
		String date = 2018 + "/" + 07 + "/" + 10;
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
		Date shunoDate1 = formatter.parse(date);
		kembaikiDtosForInsertOrUpdate.get(1).setShunoDate(shunoDate1);

		kembaikiDtosForInsertOrUpdate.get(1).setShunoDate(null);
		kembaikiDtosForInsertOrUpdate.get(1).setGenkinShunoKensu(null);
		kembaikiDtosForInsertOrUpdate.get(1).setGenkinShunogaku(null);
		kembaikiDtosForInsertOrUpdate.get(1).setPuripeidoShunoKensu(null);
//		kembaikiDtosForInsertOrUpdate.get(1).setPuripeidoShunogaku(null);
//		kembaikiDtosForInsertOrUpdate.get(1).setHeiyoShunoKensu(null);
//		kembaikiDtosForInsertOrUpdate.get(1).setHeiyoGenkinShunogaku(null);
//		kembaikiDtosForInsertOrUpdate.get(1).setHeiyoPuripeidoShunogaku(null);
//		kembaikiDtosForInsertOrUpdate.get(1).setSeisanKensu(null);
//		kembaikiDtosForInsertOrUpdate.get(1).setSeisangaku(null);

		List<TKembaikiDto> kembaikiDtosForInsertOrUpdateBk = readJson("TestgetKembaikiJohoList_para.json", new TypeToken<List<TKembaikiDto>>(){}.getType());
//		kembaikiDtosForInsertOrUpdateBk.get(0).setKembaikiCode((short)10);
//		kembaikiDtosForInsertOrUpdateBk.get(0).setButtonCode((short)20);
//		kembaikiDtosForInsertOrUpdateBk.get(0).setKanriCode((short)10);
//		String date1 = 2018 + "/" + 07 + "/" + 10;
//		//SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
//		Date shunoDate2 = formatter.parse(date1);
//		kembaikiDtosForInsertOrUpdateBk.get(0).setShunoDate(shunoDate2);

		List<Date> shunoDates = new ArrayList<Date>();
//		String date = 2018 + "/" + 06 + "/" + 19;
//		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
//		Date shunoDate = formatter.parse(date);
		Date shunoDate = new Date();
		shunoDates.add(shunoDate);

		String updateBy = "8000";
		// List<TKembaikiDto> kembaikiDtosForInsertOrUpdate,
		// List<TKembaikiDto> kembaikiDtosForInsertOrUpdateBk, Date shunoDate
			kembaikiJissekiService.insertAndUpdateTKembaikiList(kembaikiDtosForInsertOrUpdate, kembaikiDtosForInsertOrUpdateBk, shunoDates.get(0), updateBy);
	}

	@Test
	@DisplayName("管理コードと収納日をもとに券売機情報を取得します")
	public void TestInsertAndUpdateTKembaikiList_Step6() throws Exception {

		List<TKembaikiDto> kembaikiDtosForInsertOrUpdate = readJson("TestgetKembaikiJohoList_para.json", new TypeToken<List<TKembaikiDto>>(){}.getType());
		kembaikiDtosForInsertOrUpdate.get(1).setKembaikiCode((short)10);
		kembaikiDtosForInsertOrUpdate.get(1).setButtonCode((short)20);
		kembaikiDtosForInsertOrUpdate.get(1).setKanriCode((short)10);
		String date = 2018 + "/" + 07 + "/" + 10;
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
		Date shunoDate1 = formatter.parse(date);
		kembaikiDtosForInsertOrUpdate.get(1).setShunoDate(shunoDate1);

		kembaikiDtosForInsertOrUpdate.get(1).setShunoDate(null);
		kembaikiDtosForInsertOrUpdate.get(1).setGenkinShunoKensu(null);
		kembaikiDtosForInsertOrUpdate.get(1).setGenkinShunogaku(null);
		kembaikiDtosForInsertOrUpdate.get(1).setPuripeidoShunoKensu(null);
		kembaikiDtosForInsertOrUpdate.get(1).setPuripeidoShunogaku(null);
//		kembaikiDtosForInsertOrUpdate.get(1).setHeiyoShunoKensu(null);
//		kembaikiDtosForInsertOrUpdate.get(1).setHeiyoGenkinShunogaku(null);
//		kembaikiDtosForInsertOrUpdate.get(1).setHeiyoPuripeidoShunogaku(null);
//		kembaikiDtosForInsertOrUpdate.get(1).setSeisanKensu(null);
//		kembaikiDtosForInsertOrUpdate.get(1).setSeisangaku(null);

		List<TKembaikiDto> kembaikiDtosForInsertOrUpdateBk = readJson("TestgetKembaikiJohoList_para.json", new TypeToken<List<TKembaikiDto>>(){}.getType());
//		kembaikiDtosForInsertOrUpdateBk.get(0).setKembaikiCode((short)10);
//		kembaikiDtosForInsertOrUpdateBk.get(0).setButtonCode((short)20);
//		kembaikiDtosForInsertOrUpdateBk.get(0).setKanriCode((short)10);
//		String date1 = 2018 + "/" + 07 + "/" + 10;
//		//SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
//		Date shunoDate2 = formatter.parse(date1);
//		kembaikiDtosForInsertOrUpdateBk.get(0).setShunoDate(shunoDate2);

		List<Date> shunoDates = new ArrayList<Date>();
//		String date = 2018 + "/" + 06 + "/" + 19;
//		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
//		Date shunoDate = formatter.parse(date);
		Date shunoDate = new Date();
		shunoDates.add(shunoDate);

		String updateBy = "8000";
		// List<TKembaikiDto> kembaikiDtosForInsertOrUpdate,
		// List<TKembaikiDto> kembaikiDtosForInsertOrUpdateBk, Date shunoDate
			kembaikiJissekiService.insertAndUpdateTKembaikiList(kembaikiDtosForInsertOrUpdate, kembaikiDtosForInsertOrUpdateBk, shunoDates.get(0), updateBy);
	}

	@Test
	@DisplayName("管理コードと収納日をもとに券売機情報を取得します")
	public void TestInsertAndUpdateTKembaikiList_Step7() throws Exception {

		List<TKembaikiDto> kembaikiDtosForInsertOrUpdate = readJson("TestgetKembaikiJohoList_para.json", new TypeToken<List<TKembaikiDto>>(){}.getType());
		kembaikiDtosForInsertOrUpdate.get(1).setKembaikiCode((short)10);
		kembaikiDtosForInsertOrUpdate.get(1).setButtonCode((short)20);
		kembaikiDtosForInsertOrUpdate.get(1).setKanriCode((short)10);
		String date = 2018 + "/" + 07 + "/" + 10;
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
		Date shunoDate1 = formatter.parse(date);
		kembaikiDtosForInsertOrUpdate.get(1).setShunoDate(shunoDate1);

		kembaikiDtosForInsertOrUpdate.get(1).setShunoDate(null);
		kembaikiDtosForInsertOrUpdate.get(1).setGenkinShunoKensu(null);
		kembaikiDtosForInsertOrUpdate.get(1).setGenkinShunogaku(null);
		kembaikiDtosForInsertOrUpdate.get(1).setPuripeidoShunoKensu(null);
		kembaikiDtosForInsertOrUpdate.get(1).setPuripeidoShunogaku(null);
		kembaikiDtosForInsertOrUpdate.get(1).setHeiyoShunoKensu(null);
//		kembaikiDtosForInsertOrUpdate.get(1).setHeiyoGenkinShunogaku(null);
//		kembaikiDtosForInsertOrUpdate.get(1).setHeiyoPuripeidoShunogaku(null);
//		kembaikiDtosForInsertOrUpdate.get(1).setSeisanKensu(null);
//		kembaikiDtosForInsertOrUpdate.get(1).setSeisangaku(null);

		List<TKembaikiDto> kembaikiDtosForInsertOrUpdateBk = readJson("TestgetKembaikiJohoList_para.json", new TypeToken<List<TKembaikiDto>>(){}.getType());
//		kembaikiDtosForInsertOrUpdateBk.get(0).setKembaikiCode((short)10);
//		kembaikiDtosForInsertOrUpdateBk.get(0).setButtonCode((short)20);
//		kembaikiDtosForInsertOrUpdateBk.get(0).setKanriCode((short)10);
//		String date1 = 2018 + "/" + 07 + "/" + 10;
//		//SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
//		Date shunoDate2 = formatter.parse(date1);
//		kembaikiDtosForInsertOrUpdateBk.get(0).setShunoDate(shunoDate2);

		List<Date> shunoDates = new ArrayList<Date>();
//		String date = 2018 + "/" + 06 + "/" + 19;
//		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
//		Date shunoDate = formatter.parse(date);
		Date shunoDate = new Date();
		shunoDates.add(shunoDate);

		String updateBy = "8000";
		// List<TKembaikiDto> kembaikiDtosForInsertOrUpdate,
		// List<TKembaikiDto> kembaikiDtosForInsertOrUpdateBk, Date shunoDate
			kembaikiJissekiService.insertAndUpdateTKembaikiList(kembaikiDtosForInsertOrUpdate, kembaikiDtosForInsertOrUpdateBk, shunoDates.get(0), updateBy);
	}

	@Test
	@DisplayName("管理コードと収納日をもとに券売機情報を取得します")
	public void TestInsertAndUpdateTKembaikiList_Step8() throws Exception {

		List<TKembaikiDto> kembaikiDtosForInsertOrUpdate = readJson("TestgetKembaikiJohoList_para.json", new TypeToken<List<TKembaikiDto>>(){}.getType());
		kembaikiDtosForInsertOrUpdate.get(1).setKembaikiCode((short)10);
		kembaikiDtosForInsertOrUpdate.get(1).setButtonCode((short)20);
		kembaikiDtosForInsertOrUpdate.get(1).setKanriCode((short)10);
		String date = 2018 + "/" + 07 + "/" + 10;
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
		Date shunoDate1 = formatter.parse(date);
		kembaikiDtosForInsertOrUpdate.get(1).setShunoDate(shunoDate1);

		kembaikiDtosForInsertOrUpdate.get(1).setShunoDate(null);
		kembaikiDtosForInsertOrUpdate.get(1).setGenkinShunoKensu(null);
		kembaikiDtosForInsertOrUpdate.get(1).setGenkinShunogaku(null);
		kembaikiDtosForInsertOrUpdate.get(1).setPuripeidoShunoKensu(null);
		kembaikiDtosForInsertOrUpdate.get(1).setPuripeidoShunogaku(null);
		kembaikiDtosForInsertOrUpdate.get(1).setHeiyoShunoKensu(null);
		kembaikiDtosForInsertOrUpdate.get(1).setHeiyoGenkinShunogaku(null);
//		kembaikiDtosForInsertOrUpdate.get(1).setHeiyoPuripeidoShunogaku(null);
//		kembaikiDtosForInsertOrUpdate.get(1).setSeisanKensu(null);
//		kembaikiDtosForInsertOrUpdate.get(1).setSeisangaku(null);

		List<TKembaikiDto> kembaikiDtosForInsertOrUpdateBk = readJson("TestgetKembaikiJohoList_para.json", new TypeToken<List<TKembaikiDto>>(){}.getType());
//		kembaikiDtosForInsertOrUpdateBk.get(0).setKembaikiCode((short)10);
//		kembaikiDtosForInsertOrUpdateBk.get(0).setButtonCode((short)20);
//		kembaikiDtosForInsertOrUpdateBk.get(0).setKanriCode((short)10);
//		String date1 = 2018 + "/" + 07 + "/" + 10;
//		//SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
//		Date shunoDate2 = formatter.parse(date1);
//		kembaikiDtosForInsertOrUpdateBk.get(0).setShunoDate(shunoDate2);

		List<Date> shunoDates = new ArrayList<Date>();
//		String date = 2018 + "/" + 06 + "/" + 19;
//		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
//		Date shunoDate = formatter.parse(date);
		Date shunoDate = new Date();
		shunoDates.add(shunoDate);

		String updateBy = "8000";
		// List<TKembaikiDto> kembaikiDtosForInsertOrUpdate,
		// List<TKembaikiDto> kembaikiDtosForInsertOrUpdateBk, Date shunoDate
			kembaikiJissekiService.insertAndUpdateTKembaikiList(kembaikiDtosForInsertOrUpdate, kembaikiDtosForInsertOrUpdateBk, shunoDates.get(0), updateBy);
	}

	@Test
	@DisplayName("管理コードと収納日をもとに券売機情報を取得します")
	public void TestInsertAndUpdateTKembaikiList_Step9() throws Exception {

		List<TKembaikiDto> kembaikiDtosForInsertOrUpdate = readJson("TestgetKembaikiJohoList_para.json", new TypeToken<List<TKembaikiDto>>(){}.getType());
		kembaikiDtosForInsertOrUpdate.get(1).setKembaikiCode((short)10);
		kembaikiDtosForInsertOrUpdate.get(1).setButtonCode((short)20);
		kembaikiDtosForInsertOrUpdate.get(1).setKanriCode((short)10);
		String date = 2018 + "/" + 07 + "/" + 10;
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
		Date shunoDate1 = formatter.parse(date);
		kembaikiDtosForInsertOrUpdate.get(1).setShunoDate(shunoDate1);

		kembaikiDtosForInsertOrUpdate.get(1).setShunoDate(null);
		kembaikiDtosForInsertOrUpdate.get(1).setGenkinShunoKensu(null);
		kembaikiDtosForInsertOrUpdate.get(1).setGenkinShunogaku(null);
		kembaikiDtosForInsertOrUpdate.get(1).setPuripeidoShunoKensu(null);
		kembaikiDtosForInsertOrUpdate.get(1).setPuripeidoShunogaku(null);
		kembaikiDtosForInsertOrUpdate.get(1).setHeiyoShunoKensu(null);
		kembaikiDtosForInsertOrUpdate.get(1).setHeiyoGenkinShunogaku(null);
		kembaikiDtosForInsertOrUpdate.get(1).setHeiyoPuripeidoShunogaku(null);
//		kembaikiDtosForInsertOrUpdate.get(1).setSeisanKensu(null);
//		kembaikiDtosForInsertOrUpdate.get(1).setSeisangaku(null);

		List<TKembaikiDto> kembaikiDtosForInsertOrUpdateBk = readJson("TestgetKembaikiJohoList_para.json", new TypeToken<List<TKembaikiDto>>(){}.getType());
//		kembaikiDtosForInsertOrUpdateBk.get(0).setKembaikiCode((short)10);
//		kembaikiDtosForInsertOrUpdateBk.get(0).setButtonCode((short)20);
//		kembaikiDtosForInsertOrUpdateBk.get(0).setKanriCode((short)10);
//		String date1 = 2018 + "/" + 07 + "/" + 10;
//		//SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
//		Date shunoDate2 = formatter.parse(date1);
//		kembaikiDtosForInsertOrUpdateBk.get(0).setShunoDate(shunoDate2);

		List<Date> shunoDates = new ArrayList<Date>();
//		String date = 2018 + "/" + 06 + "/" + 19;
//		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
//		Date shunoDate = formatter.parse(date);
		Date shunoDate = new Date();
		shunoDates.add(shunoDate);

		String updateBy = "8000";
		// List<TKembaikiDto> kembaikiDtosForInsertOrUpdate,
		// List<TKembaikiDto> kembaikiDtosForInsertOrUpdateBk, Date shunoDate
			kembaikiJissekiService.insertAndUpdateTKembaikiList(kembaikiDtosForInsertOrUpdate, kembaikiDtosForInsertOrUpdateBk, shunoDates.get(0), updateBy);
	}

	@Test
	@DisplayName("管理コードと収納日をもとに券売機情報を取得します")
	public void TestInsertAndUpdateTKembaikiList_Step10() throws Exception {

		List<TKembaikiDto> kembaikiDtosForInsertOrUpdate = readJson("TestgetKembaikiJohoList_para.json", new TypeToken<List<TKembaikiDto>>(){}.getType());
		kembaikiDtosForInsertOrUpdate.get(1).setKembaikiCode((short)10);
		kembaikiDtosForInsertOrUpdate.get(1).setButtonCode((short)20);
		kembaikiDtosForInsertOrUpdate.get(1).setKanriCode((short)10);
		String date = 2018 + "/" + 07 + "/" + 10;
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
		Date shunoDate1 = formatter.parse(date);
		kembaikiDtosForInsertOrUpdate.get(1).setShunoDate(shunoDate1);

		kembaikiDtosForInsertOrUpdate.get(1).setShunoDate(null);
		kembaikiDtosForInsertOrUpdate.get(1).setGenkinShunoKensu(null);
		kembaikiDtosForInsertOrUpdate.get(1).setGenkinShunogaku(null);
		kembaikiDtosForInsertOrUpdate.get(1).setPuripeidoShunoKensu(null);
		kembaikiDtosForInsertOrUpdate.get(1).setPuripeidoShunogaku(null);
		kembaikiDtosForInsertOrUpdate.get(1).setHeiyoShunoKensu(null);
		kembaikiDtosForInsertOrUpdate.get(1).setHeiyoGenkinShunogaku(null);
		kembaikiDtosForInsertOrUpdate.get(1).setHeiyoPuripeidoShunogaku(null);
		kembaikiDtosForInsertOrUpdate.get(1).setSeisanKensu(null);
//		kembaikiDtosForInsertOrUpdate.get(1).setSeisangaku(null);

		List<TKembaikiDto> kembaikiDtosForInsertOrUpdateBk = readJson("TestgetKembaikiJohoList_para.json", new TypeToken<List<TKembaikiDto>>(){}.getType());
//		kembaikiDtosForInsertOrUpdateBk.get(0).setKembaikiCode((short)10);
//		kembaikiDtosForInsertOrUpdateBk.get(0).setButtonCode((short)20);
//		kembaikiDtosForInsertOrUpdateBk.get(0).setKanriCode((short)10);
//		String date1 = 2018 + "/" + 07 + "/" + 10;
//		//SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
//		Date shunoDate2 = formatter.parse(date1);
//		kembaikiDtosForInsertOrUpdateBk.get(0).setShunoDate(shunoDate2);

		List<Date> shunoDates = new ArrayList<Date>();
//		String date = 2018 + "/" + 06 + "/" + 19;
//		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
//		Date shunoDate = formatter.parse(date);
		Date shunoDate = new Date();
		shunoDates.add(shunoDate);

		String updateBy = "8000";
		// List<TKembaikiDto> kembaikiDtosForInsertOrUpdate,
		// List<TKembaikiDto> kembaikiDtosForInsertOrUpdateBk, Date shunoDate
			kembaikiJissekiService.insertAndUpdateTKembaikiList(kembaikiDtosForInsertOrUpdate, kembaikiDtosForInsertOrUpdateBk, shunoDates.get(0), updateBy);
	}

	@Test
	@DisplayName("管理コードと収納日をもとに券売機情報を取得します")
	public void TestInsertAndUpdateTKembaikiList_Step11() throws Exception {

		List<TKembaikiDto> kembaikiDtosForInsertOrUpdate = readJson("TestgetKembaikiJohoList_para.json", new TypeToken<List<TKembaikiDto>>(){}.getType());
		kembaikiDtosForInsertOrUpdate.get(1).setKembaikiCode((short)10);
		kembaikiDtosForInsertOrUpdate.get(1).setButtonCode((short)20);
		kembaikiDtosForInsertOrUpdate.get(1).setKanriCode((short)10);
		String date = 2018 + "/" + 07 + "/" + 10;
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
		Date shunoDate1 = formatter.parse(date);
		kembaikiDtosForInsertOrUpdate.get(1).setShunoDate(shunoDate1);

		kembaikiDtosForInsertOrUpdate.get(1).setShunoDate(null);
		kembaikiDtosForInsertOrUpdate.get(1).setGenkinShunoKensu(null);
		kembaikiDtosForInsertOrUpdate.get(1).setGenkinShunogaku(null);
		kembaikiDtosForInsertOrUpdate.get(1).setPuripeidoShunoKensu(null);
		kembaikiDtosForInsertOrUpdate.get(1).setPuripeidoShunogaku(null);
		kembaikiDtosForInsertOrUpdate.get(1).setHeiyoShunoKensu(null);
		kembaikiDtosForInsertOrUpdate.get(1).setHeiyoGenkinShunogaku(null);
		kembaikiDtosForInsertOrUpdate.get(1).setHeiyoPuripeidoShunogaku(null);
		kembaikiDtosForInsertOrUpdate.get(1).setSeisanKensu(null);
		kembaikiDtosForInsertOrUpdate.get(1).setSeisangaku(null);

		List<TKembaikiDto> kembaikiDtosForInsertOrUpdateBk = readJson("TestgetKembaikiJohoList_para.json", new TypeToken<List<TKembaikiDto>>(){}.getType());
//		kembaikiDtosForInsertOrUpdateBk.get(0).setKembaikiCode((short)10);
//		kembaikiDtosForInsertOrUpdateBk.get(0).setButtonCode((short)20);
//		kembaikiDtosForInsertOrUpdateBk.get(0).setKanriCode((short)10);
//		String date1 = 2018 + "/" + 07 + "/" + 10;
//		//SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
//		Date shunoDate2 = formatter.parse(date1);
//		kembaikiDtosForInsertOrUpdateBk.get(0).setShunoDate(shunoDate2);

		List<Date> shunoDates = new ArrayList<Date>();
//		String date = 2018 + "/" + 06 + "/" + 19;
//		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
//		Date shunoDate = formatter.parse(date);
		Date shunoDate = new Date();
		shunoDates.add(shunoDate);

		String updateBy = "8000";
		// List<TKembaikiDto> kembaikiDtosForInsertOrUpdate,
		// List<TKembaikiDto> kembaikiDtosForInsertOrUpdateBk, Date shunoDate
			kembaikiJissekiService.insertAndUpdateTKembaikiList(kembaikiDtosForInsertOrUpdate, kembaikiDtosForInsertOrUpdateBk, shunoDates.get(0), updateBy);
	}

	@Test
	@DisplayName("管理コードと収納日をもとに券売機情報を取得します")
	public void TestInsertAndUpdateTKembaikiList_Step12() throws Exception {

		List<TKembaikiDto> kembaikiDtosForInsertOrUpdate = readJson("TestgetKembaikiJohoList_para.json", new TypeToken<List<TKembaikiDto>>(){}.getType());
		kembaikiDtosForInsertOrUpdate.get(1).setKembaikiCode((short)10);
		kembaikiDtosForInsertOrUpdate.get(1).setButtonCode((short)20);
		kembaikiDtosForInsertOrUpdate.get(1).setKanriCode((short)10);
		String date = 2018 + "/" + 07 + "/" + 10;
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
		Date shunoDate1 = formatter.parse(date);
		kembaikiDtosForInsertOrUpdate.get(1).setShunoDate(shunoDate1);

		kembaikiDtosForInsertOrUpdate.get(1).setShunoDate(new Date());
		kembaikiDtosForInsertOrUpdate.get(1).setGenkinShunoKensu(100);
//		kembaikiDtosForInsertOrUpdate.get(1).setGenkinShunogaku(null);
//		kembaikiDtosForInsertOrUpdate.get(1).setPuripeidoShunoKensu(null);
//		kembaikiDtosForInsertOrUpdate.get(1).setPuripeidoShunogaku(null);
//		kembaikiDtosForInsertOrUpdate.get(1).setHeiyoShunoKensu(null);
//		kembaikiDtosForInsertOrUpdate.get(1).setHeiyoGenkinShunogaku(null);
//		kembaikiDtosForInsertOrUpdate.get(1).setHeiyoPuripeidoShunogaku(null);
//		kembaikiDtosForInsertOrUpdate.get(1).setSeisanKensu(null);
//		kembaikiDtosForInsertOrUpdate.get(1).setSeisangaku(null);

		List<TKembaikiDto> kembaikiDtosForInsertOrUpdateBk = readJson("TestgetKembaikiJohoList_para.json", new TypeToken<List<TKembaikiDto>>(){}.getType());
//		kembaikiDtosForInsertOrUpdateBk.get(0).setKembaikiCode((short)10);
//		kembaikiDtosForInsertOrUpdateBk.get(0).setButtonCode((short)20);
//		kembaikiDtosForInsertOrUpdateBk.get(0).setKanriCode((short)10);
//		String date1 = 2018 + "/" + 07 + "/" + 10;
//		//SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
//		Date shunoDate2 = formatter.parse(date1);
//		kembaikiDtosForInsertOrUpdateBk.get(0).setShunoDate(shunoDate2);

		List<Date> shunoDates = new ArrayList<Date>();
//		String date = 2018 + "/" + 06 + "/" + 19;
//		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
//		Date shunoDate = formatter.parse(date);
		Date shunoDate = new Date();
		shunoDates.add(shunoDate);

		String updateBy = "8000";
		// List<TKembaikiDto> kembaikiDtosForInsertOrUpdate,
		// List<TKembaikiDto> kembaikiDtosForInsertOrUpdateBk, Date shunoDate
			kembaikiJissekiService.insertAndUpdateTKembaikiList(kembaikiDtosForInsertOrUpdate, kembaikiDtosForInsertOrUpdateBk, shunoDates.get(0), updateBy);
	}
	@Test
	@DisplayName("管理コードと収納日をもとに券売機情報を取得します")
	public void TestInsertAndUpdateTKembaikiList_Step13() throws Exception {

		List<TKembaikiDto> kembaikiDtosForInsertOrUpdate = readJson("TestgetKembaikiJohoList_para.json", new TypeToken<List<TKembaikiDto>>(){}.getType());
		kembaikiDtosForInsertOrUpdate.get(1).setKembaikiCode((short)10);
		kembaikiDtosForInsertOrUpdate.get(1).setButtonCode((short)20);
		kembaikiDtosForInsertOrUpdate.get(1).setKanriCode((short)10);
		String date = 2018 + "/" + 07 + "/" + 10;
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
		Date shunoDate1 = formatter.parse(date);
		kembaikiDtosForInsertOrUpdate.get(1).setShunoDate(shunoDate1);

		kembaikiDtosForInsertOrUpdate.get(1).setShunoDate(new Date());
		kembaikiDtosForInsertOrUpdate.get(1).setGenkinShunoKensu(100);
		kembaikiDtosForInsertOrUpdate.get(1).setGenkinShunogaku(100);
		kembaikiDtosForInsertOrUpdate.get(1).setPuripeidoShunoKensu(100);
		kembaikiDtosForInsertOrUpdate.get(1).setPuripeidoShunogaku(100);
		kembaikiDtosForInsertOrUpdate.get(1).setHeiyoShunoKensu(100);
		kembaikiDtosForInsertOrUpdate.get(1).setHeiyoGenkinShunogaku(100);
		kembaikiDtosForInsertOrUpdate.get(1).setHeiyoPuripeidoShunogaku(100);
		kembaikiDtosForInsertOrUpdate.get(1).setSeisanKensu(100);
		kembaikiDtosForInsertOrUpdate.get(1).setSeisangaku(100);

		List<TKembaikiDto> kembaikiDtosForInsertOrUpdateBk = readJson("TestgetKembaikiJohoList_para.json", new TypeToken<List<TKembaikiDto>>(){}.getType());
//		kembaikiDtosForInsertOrUpdateBk.get(0).setKembaikiCode((short)10);
//		kembaikiDtosForInsertOrUpdateBk.get(0).setButtonCode((short)20);
//		kembaikiDtosForInsertOrUpdateBk.get(0).setKanriCode((short)10);
//		String date1 = 2018 + "/" + 07 + "/" + 10;
//		//SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
//		Date shunoDate2 = formatter.parse(date1);
//		kembaikiDtosForInsertOrUpdateBk.get(0).setShunoDate(shunoDate2);

		List<Date> shunoDates = new ArrayList<Date>();
//		String date = 2018 + "/" + 06 + "/" + 19;
//		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
//		Date shunoDate = formatter.parse(date);
		Date shunoDate = new Date();
		shunoDates.add(shunoDate);

		String updateBy = "8000";
		// List<TKembaikiDto> kembaikiDtosForInsertOrUpdate,
		// List<TKembaikiDto> kembaikiDtosForInsertOrUpdateBk, Date shunoDate
			kembaikiJissekiService.insertAndUpdateTKembaikiList(kembaikiDtosForInsertOrUpdate, kembaikiDtosForInsertOrUpdateBk, shunoDates.get(0), updateBy);
	}
}
