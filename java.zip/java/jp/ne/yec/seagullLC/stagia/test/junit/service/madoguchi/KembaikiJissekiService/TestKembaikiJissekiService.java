package jp.ne.yec.seagullLC.stagia.test.junit.service.madoguchi.KembaikiJissekiService;

import static org.junit.Assert.*;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.seagullLC.stagia.beans.madoguchi.MKembaikiDto;
import jp.ne.yec.seagullLC.stagia.beans.madoguchi.TKembaikiDto;
import jp.ne.yec.seagullLC.stagia.entity.MKanri;
import jp.ne.yec.seagullLC.stagia.service.madoguchi.KembaikiJissekiService;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = { "classpath:TestApplicationContext.xml" })
@WebAppConfiguration
public class TestKembaikiJissekiService extends JunitBase {

	@Autowired
	KembaikiJissekiService kembaikiJissekiService;

	@Test
	@DisplayName("管理コードと収納日をもとに券売機情報を取得します")
	public void TestGetKanrimeiList() throws Exception {
		List<List<MKanri>> jsonData = new ArrayList<List<MKanri>>();
		List<Short> kanriCodes = new ArrayList<>();
		List<MKanri> list = kembaikiJissekiService.getKanrimeiList(kanriCodes);
		assertEquals(2, list.size());
		jsonData.add(list);
		exportJsonData(jsonData, "TestGetKanrimeiList.json");
	}

	@Test
	@DisplayName("管理コードと収納日をもとに券売機情報を取得します")
	@TestInitDataFile("TestGetKembaikiListInit.xlsx")
	public void TestGetMKanri() throws Exception {
		List<List<Map<MKembaikiDto,List<TKembaikiDto>>>> jsonData = new ArrayList<List<Map<MKembaikiDto,List<TKembaikiDto>>>>();
		List<List<Short>> params = new ArrayList<List<Short>>();

		List<Short> kanriCodes1 = new ArrayList<Short>();
		kanriCodes1.add((short)10);
		params.add(kanriCodes1);

		List<Short> kanriCodes2 = new ArrayList<Short>();
		kanriCodes2.add((short)20);
		params.add(kanriCodes2);

		List<Date> paramDates = new ArrayList<Date>();
		String date = 2018 + "/" + 04 + "/" + 01;
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
		Date shunoDate = formatter.parse(date);
		Date shunoDate2 = formatter.parse(date);
		paramDates.add(shunoDate);
		paramDates.add(shunoDate2);



		List<Map<MKembaikiDto,List<TKembaikiDto>>> list = kembaikiJissekiService.getKembaikiList(params.get(0).get(0), paramDates.get(0));
		assertEquals(2, list.size());
		jsonData.add(list);
		exportJsonData(jsonData, "TestGetMKanri.json");
	}

	@Test
	@DisplayName("管理コードと収納日をもとに券売機情報を取得します")
	public void TestInsertAndUpdateTKembaikiList() throws Exception {

		List<TKembaikiDto> kembaikiDtosForInsertOrUpdate = new ArrayList<TKembaikiDto>();
		TKembaikiDto tKembaikiDto = new TKembaikiDto();
		kembaikiDtosForInsertOrUpdate.add(tKembaikiDto);

		List<TKembaikiDto> kembaikiDtosForInsertOrUpdateBk = new ArrayList<TKembaikiDto>();
		TKembaikiDto tKembaikiDto1 = new TKembaikiDto();
		kembaikiDtosForInsertOrUpdateBk.add(tKembaikiDto1);

		List<Date> shunoDates = new ArrayList<Date>();
		String date = 2018 + "/" + 06 + "/" + 19;
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
		Date shunoDate = formatter.parse(date);
		shunoDates.add(shunoDate);

		String updateBy = "";
		// List<TKembaikiDto> kembaikiDtosForInsertOrUpdate,
		// List<TKembaikiDto> kembaikiDtosForInsertOrUpdateBk, Date shunoDate
			kembaikiJissekiService.insertAndUpdateTKembaikiList(kembaikiDtosForInsertOrUpdate, kembaikiDtosForInsertOrUpdateBk, shunoDates.get(0), updateBy);
	}
}
