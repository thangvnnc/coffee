package jp.ne.yec.seagullLC.stagia.test.junit.logic.transaction.TSetsubiHaitaWorkLogic;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.seagullLC.stagia.beans.shinsei.SetsubiShinseiDto;
import jp.ne.yec.seagullLC.stagia.beans.shinsei.ShinseiMeisaiDto;
import jp.ne.yec.seagullLC.stagia.logic.transaction.TSetsubiHaitaWorkLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = { "classpath:TestApplicationContext.xml" })
@WebAppConfiguration
public class TestTSetsubiHaitaWorkLogic extends JunitBase {

	@Autowired
	TSetsubiHaitaWorkLogic tSetsubiHaitaWorkLogic;

	@Test
	@DisplayName("引数の申請明細IDリストを基に設備情報を取得し、設備予約があるIDリストを返却します.")
	@TestInitDataFile("TestInsertSetsubiBashoInit.xlsx")
	public void TestInsertSetsubiBasho() throws Exception {
		List<ShinseiMeisaiDto> meisaiDtos = new ArrayList<>();
		
		List<SetsubiShinseiDto> setsubiShinseiDtos = new ArrayList<>();
		SetsubiShinseiDto set = new SetsubiShinseiDto();
		//set.setka
		
		setsubiShinseiDtos.add(set);
		
		ShinseiMeisaiDto shinseiMeisaiDto = new ShinseiMeisaiDto();
		shinseiMeisaiDto.setKanriCode((short)10);
		shinseiMeisaiDto.setBashoCode((short)10);
		shinseiMeisaiDto.setShiyoDate(new Date());
		shinseiMeisaiDto.setSetsubiShinseiDtos(setsubiShinseiDtos);
		
		meisaiDtos.add(shinseiMeisaiDto);
		String sessionId = "d";
		String updatedBy = "d";
		tSetsubiHaitaWorkLogic.insertSetsubiBasho(meisaiDtos, sessionId, updatedBy);
	}
	
	@Test
	@DisplayName("引数の申請明細IDリストを基に設備情報を取得し、設備予約があるIDリストを返却します.")
	@TestInitDataFile("TestInsertSetsubiBashoInit.xlsx")
	public void TestInsertSetsubiBasho2() throws Exception {
		List<ShinseiMeisaiDto> meisaiDtos = new ArrayList<>();
		
		List<SetsubiShinseiDto> setsubiShinseiDtos = new ArrayList<>();
		
		ShinseiMeisaiDto shinseiMeisaiDto = new ShinseiMeisaiDto();
		shinseiMeisaiDto.setKanriCode((short)10);
		shinseiMeisaiDto.setBashoCode((short)10);
		shinseiMeisaiDto.setShiyoDate(new Date());
		shinseiMeisaiDto.setSetsubiShinseiDtos(setsubiShinseiDtos);
		
		meisaiDtos.add(shinseiMeisaiDto);
		String sessionId = "d";
		String updatedBy = "d";
		tSetsubiHaitaWorkLogic.insertSetsubiBasho(meisaiDtos, sessionId, updatedBy);
	}

	@Test
	@DisplayName("引数の明細IDを基にT設備申請の情報を取得し、設備申請情報Dtoリストを返却します.")
	@TestInitDataFile("TestDeleteBySessionIdInit.xlsx")
	public void TestDeleteBySessionId() throws Exception {
		String sessionId = "d";
		tSetsubiHaitaWorkLogic.deleteBySessionId(sessionId);
	}

}

