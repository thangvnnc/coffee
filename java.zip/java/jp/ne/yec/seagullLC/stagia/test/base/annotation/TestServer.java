package jp.ne.yec.seagullLC.stagia.test.base.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import com.codeborne.selenide.WebDriverRunner;

@Retention(RetentionPolicy.RUNTIME)
@Target({ElementType.TYPE})
public @interface TestServer {
	public enum Os {
		WINDOWS, LINUX
	};

	public enum Browzer {
		FireFox(WebDriverRunner.FIREFOX, "geckodriver.exe", "webdriver.gecko.driver")
		, Chrome(WebDriverRunner.CHROME, "chromedriver.exe", "webdriver.chrome.driver")
		, IE(WebDriverRunner.INTERNET_EXPLORER, "IEDriverServer.exe", "webdriver.ie.driver")
		, Edge(WebDriverRunner.EDGE, "MicrosoftWebDriver.exe", "webdriver.edge.driver")
		;

		private String webDriverRunner;
		private String driverName;
		private String propertyKey;

		private Browzer(String webDriverRunner, String driverName, String propertyKey) {
			this.webDriverRunner = webDriverRunner;
			this.driverName = driverName;
			this.propertyKey = propertyKey;
		}

		public String getWebDriverRunner() {
			return this.webDriverRunner;
		}

		public String getDriverName() {
			return this.driverName;
		}

		public String getPropertyKey() {
			return this.propertyKey;
		}

	};

	String serverIp() default "127.0.0.1:8080";
	Os serverOs() default Os.WINDOWS;
	String context() default "stagia2";
	Browzer testBrowzer() default Browzer.Chrome;
}
