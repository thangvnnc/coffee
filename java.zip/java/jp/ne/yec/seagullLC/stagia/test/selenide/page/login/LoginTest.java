package jp.ne.yec.seagullLC.stagia.test.selenide.page.login;

import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.codeborne.selenide.SelenideElement;

import jp.ne.yec.seagullLC.stagia.test.selenide.page.akijokyo.AkijokyoKensakuTest;
import jp.ne.yec.seagullLC.stagia.test.selenide.page.base.SelenidePageBase;

/**
 * ログインページのテストクラス
 *
 * @author nao-hirata
 *
 */
public class LoginTest extends SelenidePageBase {

	@FindBy(how = How.CSS, using = "input[wicketpath=form_loginId]")
	private SelenideElement loginIdText;

	@FindBy(how = How.CSS, using = "input[wicketpath=form_password]")
	private SelenideElement passwordText;

	@FindBy(how = How.CSS, using = "button[wicketpath=form_loginButton]")
	private SelenideElement loginButton;

	/**
	 * 引数をそれぞれのテキストボックスにセットし、ログインボタンをクリックします.
	 *
	 * @param loginId
	 * @param password
	 * @return - AkijokyoKensakuTestのインスタンス
	 */
	public AkijokyoKensakuTest login(String loginId, String password) {
		loginIdText.setValue(loginId);
		passwordText.val(password);
		return takeScreenShotAndMovePage(loginButton, AkijokyoKensakuTest.class);
	}
}
