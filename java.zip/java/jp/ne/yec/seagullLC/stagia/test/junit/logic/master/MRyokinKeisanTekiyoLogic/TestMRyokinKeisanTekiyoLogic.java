package jp.ne.yec.seagullLC.stagia.test.junit.logic.master.MRyokinKeisanTekiyoLogic;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.entity.MRyokinKeisanTekiyo;
import jp.ne.yec.seagullLC.stagia.logic.master.MRyokinKeisanTekiyoLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestMRyokinKeisanTekiyoLogic extends JunitBase {

	@Autowired
	MRyokinKeisanTekiyoLogic mRyokinKeisanTekiyoLogic;

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetMRyokinKeisanShiki.xlsx")
	public void TestgetMRyokinKeisanShiki() throws Exception
	{
		Short kanriCode =  10;
		Short shisetsuCode =  10;
		Short ryokintaikeiCode =  1;
		SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
		String ryokinKeisanKijunDates = "4/1/2017";
		Date ryokinKeisanKijunDate = formatter.parse(ryokinKeisanKijunDates);
		List<MRyokinKeisanTekiyo> ret =  mRyokinKeisanTekiyoLogic.getMRyokinKeisanTekiyoList(kanriCode
											,shisetsuCode,  ryokintaikeiCode,ryokinKeisanKijunDate);
		exportJsonData(ret, "TestgetMRyokinKeisanShiki.json");
	}

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetMRyokinKeisanShiki.xlsx")
	public void TestgetMRyokinKeisanTekiyoList() throws Exception
	{
		Short kanriCode =  10;
		Short shisetsuCode =  10;
		SimpleDateFormat formatter = new SimpleDateFormat("MM/dd/yyyy");
		String ryokinKeisanKijunDates = "4/1/2017";
		Date ryokinKeisanKijunDate = formatter.parse(ryokinKeisanKijunDates);
		List<MRyokinKeisanTekiyo> ret = mRyokinKeisanTekiyoLogic.getMRyokinKeisanTekiyoList(kanriCode
											,shisetsuCode,ryokinKeisanKijunDate);
		exportJsonData(ret, "TestgetMRyokinKeisanTekiyoList.json");
	}
	@Test
	@DisplayName("検索条件なしで場所マスタを取得し、返却します")
	@TestInitDataFile("TestgetMRyokinKeisanShiki.xlsx")
	public void TestGetMRyokinKeisanTekiyoList_map() throws Exception
	{
		Map<Short, List<Short>> kanriShisetsuCodeMap = new HashMap<>();
		List<Short> mListShort = new ArrayList<Short>();
		Short mShort = 10;
		mListShort.add(mShort);
		kanriShisetsuCodeMap.put(mShort, mListShort);
	
		List<MRyokinKeisanTekiyo>  ret = mRyokinKeisanTekiyoLogic.getMRyokinKeisanTekiyoList(kanriShisetsuCodeMap);
		exportJsonData(ret, "TestGetMRyokinKeisanTekiyoList_map.json");
	}

	@Test
	@DisplayName("検索条件なしで場所マスタを取得し、返却します")
	//@TestInitDataFile("TestgetMBashoList.xlsx")
	public void TestgetDao() throws Exception
	{
		GenericDao<MRyokinKeisanTekiyo, ?>ret = mRyokinKeisanTekiyoLogic.getDao() ;
	}
}