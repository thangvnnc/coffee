package jp.ne.yec.seagullLC.stagia.test.junit.logic.master.MSetsubiRyokinLogic;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.beans.shinsei.SetsubiShinseiDto;
import jp.ne.yec.seagullLC.stagia.beans.shinsei.ShinseiMeisaiDto;
import jp.ne.yec.seagullLC.stagia.entity.MSetsubiRyokin;
import jp.ne.yec.seagullLC.stagia.logic.master.MSetsubiRyokinLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestMSetsubiRyokinLogic extends JunitBase {


	@Autowired
	MSetsubiRyokinLogic mSetsubiRyokinLogic;

	@Test
	@DisplayName("検索条件なしで場所マスタを取得し、返却します")
	@TestInitDataFile("TestGetSetsubiRyokinsInit.xlsx")
	public void TestGetSetsubiRyokins() throws Exception
	{
		List<SetsubiShinseiDto> setsubiShinseiDtos = new ArrayList<>();
		SetsubiShinseiDto set = new SetsubiShinseiDto();
		set.setSetsubiBunruiCode((short)1);
		setsubiShinseiDtos.add(set);
		
		SimpleDateFormat sd = new SimpleDateFormat("yyyy/M/d");
		Date shiyoDate = new Date();
		shiyoDate = sd.parse("2017/1/1");
		
		ShinseiMeisaiDto shinseiMeisaiDto = new ShinseiMeisaiDto();
		shinseiMeisaiDto.setKanriCode((short)10);
		shinseiMeisaiDto.setBashoCode((short)10);
		shinseiMeisaiDto.setShisetsuCode((short)10);
		shinseiMeisaiDto.setSetsubiShinseiDtos(setsubiShinseiDtos);
		shinseiMeisaiDto.setShiyoDate(shiyoDate);
		shinseiMeisaiDto.setStartKoma((short)1);
		shinseiMeisaiDto.setEndKoma((short)1);

		List<MSetsubiRyokin> ret = mSetsubiRyokinLogic.getSetsubiRyokins(shinseiMeisaiDto);
		exportJsonData(ret, "TestGetJidoSetsubiInfo.json");
	}
	@Test
	@DisplayName("検索条件なしで場所マスタを取得し、返却します")
	//@TestInitDataFile("TestgetMBashoList.xlsx")
	public void TestgetDao() throws Exception
	{
		GenericDao<MSetsubiRyokin, ?> ret = mSetsubiRyokinLogic.getDao();
	}
}

