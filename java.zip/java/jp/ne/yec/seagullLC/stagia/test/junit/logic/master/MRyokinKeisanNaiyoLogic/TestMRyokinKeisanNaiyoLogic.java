package jp.ne.yec.seagullLC.stagia.test.junit.logic.master.MRyokinKeisanNaiyoLogic;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.beans.StringCodeNamePair;
import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.entity.MRyokinKeisanNaiyo;
import jp.ne.yec.seagullLC.stagia.logic.master.MRyokinKeisanNaiyoLogic;
import jp.ne.yec.seagullLC.stagia.service.shinsei.MeisaiJohoSetteiService;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestMRyokinKeisanNaiyoLogic extends JunitBase {

	@Autowired
	MRyokinKeisanNaiyoLogic mRyokinKeisanNaiyoLogic;
	@Autowired
	MeisaiJohoSetteiService meisaiJohoSetteiService;

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetRyokinKeisanNaiyoList.xlsx")
	public void TestgetRyokinKeisanNaiyoList() throws Exception
	{
		List<MRyokinKeisanNaiyo> ret =  mRyokinKeisanNaiyoLogic.getRyokinKeisanNaiyoList();
		exportJsonData(ret, "TestgetRyokinKeisanNaiyoList.json");
	}
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetRyokinKeisanNaiyoList.xlsx")
	public void TestgetMRyokinKeisanList() throws Exception
	{
		List<Short> kanriCodes = new ArrayList<>();
		Short kanriCode =  10;
		kanriCodes.add(kanriCode);
		Short ryokinKeisanKomokuCode =  1;
		List<Short> ryokinKeisanKomokuCodes = new ArrayList<>();
		ryokinKeisanKomokuCodes.add(ryokinKeisanKomokuCode);
		List<MRyokinKeisanNaiyo> ret =  mRyokinKeisanNaiyoLogic.getMRyokinKeisanList(kanriCode,
					ryokinKeisanKomokuCode);
		exportJsonData(ret, "TestgetMRyokinKeisanList.json");
	}
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetRyokinKeisanNaiyoList.xlsx")
	public void TestgetStringCodeNamePairList() throws Exception
	{
		List<Short> kanriCodes = new ArrayList<>();
		Short kanriCode =  10;
		kanriCodes.add(kanriCode);
		Short ryokinKeisanKomokuCode =  1;
		List<Short> ryokinKeisanKomokuCodes = new ArrayList<>();
		ryokinKeisanKomokuCodes.add(ryokinKeisanKomokuCode);
		List<StringCodeNamePair> ret =  mRyokinKeisanNaiyoLogic.getStringCodeNamePairList(kanriCode,
				ryokinKeisanKomokuCode);
			exportJsonData(ret, "TestgetStringCodeNamePairList.json");
	}
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetRyokinKeisanNaiyoList.xlsx")
	public void TestgetMRyokinKeisanList_List() throws Exception
	{
		List<Short> kanriCodeLists =  new ArrayList<Short>();
		Short kanriCodeList = 10;
		kanriCodeLists.add(kanriCodeList);
		List<Short> ryokinKeisanKomokuCodeLists =  new ArrayList<Short>();
		Short ryokinKeisanKomokuCodeList = 1;
		ryokinKeisanKomokuCodeLists.add(ryokinKeisanKomokuCodeList);
		List<Short> ryokinKeisanCodeLists=  new ArrayList<Short>();
		Short ryokinKeisanCodeList = 1;
		ryokinKeisanCodeLists.add(ryokinKeisanCodeList);
		
		List<MRyokinKeisanNaiyo>  ret = mRyokinKeisanNaiyoLogic.getMRyokinKeisanList(kanriCodeLists,
				ryokinKeisanKomokuCodeLists,ryokinKeisanCodeLists);
		exportJsonData(ret, "TestgetMRyokinKeisanList_List.json");
	}
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetRyokinKeisanNaiyoList.xlsx")
	public void TestgetMRyokinKeisanList_ListSort() throws Exception
	{
		List<Short> KanriCodes = new ArrayList<>();
		Short kanriCode =  10;
		KanriCodes.add(kanriCode);
		
		List<MRyokinKeisanNaiyo> ret =mRyokinKeisanNaiyoLogic.getMRyokinKeisanList(kanriCode);
		exportJsonData(ret, "TestgetMRyokinKeisanList_ListSort.json");
	}
	@Test
	@DisplayName("検索条件なしで場所マスタを取得し、返却します")
	@TestInitDataFile("TestgetRyokinKeisanNaiyoList.xlsx")
	public void TestToStringCodeNamePair() throws Exception
	{
		List<List<MRyokinKeisanNaiyo>> params = new ArrayList<List<MRyokinKeisanNaiyo>>();
		List<MRyokinKeisanNaiyo> list = new ArrayList<>();
		MRyokinKeisanNaiyo mRyokinKeisanNaiyo = new MRyokinKeisanNaiyo();
		mRyokinKeisanNaiyo.setRyokinKeisanNaiyoCode((short)1);
		mRyokinKeisanNaiyo.setRyokinKeisanNaiyoName("営利加算１");
		
		list.add(mRyokinKeisanNaiyo);

		List<StringCodeNamePair>  ret = mRyokinKeisanNaiyoLogic.toStringCodeNamePair(list);
		exportJsonData(ret, "TestToStringCodeNamePair.json");
	}
	@Test
	@DisplayName("検索条件なしで場所マスタを取得し、返却します")
	//@TestInitDataFile("TestgetMBashoList.xlsx")
	public void TestgetDao() throws Exception
	{
		GenericDao<MRyokinKeisanNaiyo, ?> ret = mRyokinKeisanNaiyoLogic.getDao();
	}
}