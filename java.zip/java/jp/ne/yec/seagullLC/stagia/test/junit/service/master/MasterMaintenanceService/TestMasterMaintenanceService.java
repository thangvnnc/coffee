package jp.ne.yec.seagullLC.stagia.test.junit.service.master.MasterMaintenanceService;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.google.gson.reflect.TypeToken;

import jp.ne.yec.seagullLC.stagia.beans.master.MBashoDto;
import jp.ne.yec.seagullLC.stagia.service.master.MasterMaintenanceService;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestMasterMaintenanceService extends JunitBase{

	@Autowired
	MasterMaintenanceService masterMaintenanceService;

	@Test
	@DisplayName("「m_system」の情報を取得し返却します.")
	public void TestGetMSystem() throws Exception{
		//MSystemDto dto = masterMaintenanceService.getMSystem();
	}

//	@Test
//	@DisplayName("利用者グループリストを取得します")
//	@TestInitDataFile("TestgetRiyoshaGroupListInit.xlsx")
//	public void TestGetRiyoshaGroupList() throws Exception{
//		 List<StringCodeNamePair> list = masterMaintenanceService.getRiyoshaGroupList();
//		 exportJsonData(list, "TestGetRiyoshaGroupList.json");
//	}
//
//	@Test
//	@DisplayName("利用者グループリストを取得します")
//	@TestInitDataFile("TestgetSystemMaintenanceInfoInit.xlsx")
//	public void TestGetSystemMaintenanceInfo() throws Exception{
//		 MSystemDto ret = masterMaintenanceService.getSystemMaintenanceInfo();
//		 exportJsonData(ret, "TestGetSystemMaintenanceInfo.json");
//	}
//
//	@Test
//	@DisplayName("利用者グループリストを取得します")
//	@TestInitDataFile("TestgetSystemMaintenanceInfoInit2.xlsx")
//	public void TestGetSystemMaintenanceInfo2() throws Exception{
//		 MSystemDto ret = masterMaintenanceService.getSystemMaintenanceInfo();
//		 exportJsonData(ret, "TestGetSystemMaintenanceInfo2.json");
//	}
//
//	@Test
//	@DisplayName("利用者グループリストを取得します")
//	@TestInitDataFile("TestgetSystemMaintenanceInfoInit3.xlsx")
//	public void TestGetSystemMaintenanceInfo3() throws Exception{
//		 MSystemDto ret = masterMaintenanceService.getSystemMaintenanceInfo();
//		 exportJsonData(ret, "TestGetSystemMaintenanceInfo3.json");
//	}
//
//	@Test
//	@DisplayName("利用者グループリストを取得します")
//	@TestInitDataFile("TestTorokuSystemMaintenanceInfoInit.xlsx")
//	public void TestTorokuSystemMaintenanceInfo() throws Exception{
//		 MSystemDto mSystemDto = readJson("MSystemDto_GetVersion_Available.json", new TypeToken<MSystemDto>(){}.getType());
//		 String updatedBy = "d";
//		 masterMaintenanceService.torokuSystemMaintenanceInfo(mSystemDto, updatedBy);
//
//	}
//
//	@Test
//	@DisplayName("利用者グループリストを取得します")
//	@TestInitDataFile("TestGetMKanriInit.xlsx")
//	public void TestGetMKanri() throws Exception{
//		Short kanriCode = 10;
//		MKanriDto ret = masterMaintenanceService.getMKanri(kanriCode);
//		exportJsonData(ret, "TestGetMKanri.json");
//	}
//
//	@Test
//	@DisplayName("利用者グループリストを取得します")
//	@TestInitDataFile("TestGetMKanriInit.xlsx")
//	public void TestGetMKanri2() throws Exception{
//		Short kanriCode = 100;
//		MKanriDto ret = masterMaintenanceService.getMKanri(kanriCode);
//		assertNull(ret);
//	}
//
//	@Test
//	@DisplayName("利用者グループリストを取得します")
//	@TestInitDataFile("TestGetMKanriInit.xlsx")
//	public void TestRegisterKanri() throws Exception{
//		String updatedBy = "a";
//		MKanriDto mKanriDto = readJson("MKanriDto_GetVersion_Available.json", new TypeToken<MKanriDto>(){}.getType());
//		masterMaintenanceService.registerKanri(mKanriDto, updatedBy);
//
//	}
//
//	@Test
//	@DisplayName("利用者グループリストを取得します")
//	@TestInitDataFile("TestGetMKanriInit.xlsx")
//	public void TestRegisterKanri2() throws Exception{
//		String updatedBy = "a";
//		MKanriDto mKanriDto = readJson("MKanriDto_GetVersion_Available.json", new TypeToken<MKanriDto>(){}.getType());
//		mKanriDto.setVersion(null);
//		mKanriDto.setKanriCode((short)20);
//		masterMaintenanceService.registerKanri(mKanriDto, updatedBy);
//	}
//
//	@Test
//	@DisplayName("利用者グループリストを取得します")
//	@TestInitDataFile("TestGetMKanriInit.xlsx")
//	public void TestDeleteKanri() throws Exception{
//		String updatedBy = "a";
//		MKanriDto mKanriDto = readJson("MKanriDto_GetVersion_Available.json", new TypeToken<MKanriDto>(){}.getType());
//		masterMaintenanceService.deleteKanri(mKanriDto, updatedBy);
//
//	}
//
//	@Test
//	@DisplayName("利用者グループリストを取得します")
//	@TestInitDataFile("TestGetMKanriInit.xlsx")
//	public void TestGetKanriMap() throws Exception{
//		Map<Short, MKanri> ret = masterMaintenanceService.getKanriMap();
//		exportJsonData(ret, "TestGetKanriMap.json");
//	}
//	@Test
//	@DisplayName("利用者グループリストを取得します")
//	@TestInitDataFile("TestGetUketukeBashoListInit.xlsx")
//	public void TestGetUketukeBashoList() throws Exception{
//		List<StringCodeNamePair> ret = masterMaintenanceService.getUketukeBashoList();
//		exportJsonData(ret, "TestGetUketukeBashoList.json");
//	}
//	@Test
//	@DisplayName("利用者グループリストを取得します")
//	@TestInitDataFile("TestGetRyokinTaikeiListInit.xlsx")
//	public void TestGetRyokinTaikeiList() throws Exception{
//		List<MRyokinTaikei> ret = masterMaintenanceService.getRyokinTaikeiList();
//		exportJsonData(ret, "TestGetRyokinTaikeiListInit.json");
//	}
//	@Test
//	@DisplayName("利用者グループリストを取得します")
//	@TestInitDataFile("TestSetShokuinInfoInit.xlsx")
//	public void TestSetShokuinInfo() throws Exception{
//		ShokuinDto shokuinDto = new ShokuinDto();
//		shokuinDto.setLoginId("1");
//		shokuinDto.setUketsukeBashoCode((short)10);
//		masterMaintenanceService.setShokuinInfo(shokuinDto);
//	}
//	@Test
//	@DisplayName("利用者グループリストを取得します")
//	@TestInitDataFile("TestSetShokuinInfoInit.xlsx")
//	public void TestSetShokuinInfo2() throws Exception{
//		ShokuinDto shokuinDto = new ShokuinDto();
//		masterMaintenanceService.setShokuinInfo(shokuinDto);
//	}
//	@Test
//	@DisplayName("利用者グループリストを取得します")
//	@TestInitDataFile("TestSetShokuinInfoInit.xlsx")
//	public void TestSetShokuinInfo3() throws Exception{
//		ShokuinDto shokuinDto = new ShokuinDto();
//		shokuinDto.setLoginId("0_test");
//		masterMaintenanceService.setShokuinInfo(shokuinDto);
//	}
//	@Test
//	@DisplayName("利用者グループリストを取得します")
//	@TestInitDataFile("TestSetShokuinInfoInit.xlsx")
//	public void TestRegisterShokuin() throws Exception{
//		Map<Short, MKanri> mKanriMap = new HashMap<>();
//		MKanri mKanri = new MKanri();
//		mKanri.setKanriCode((short)12);
//		mKanriMap.put((short)10, mKanri);
//		String updatedBy = "a";
//		ShokuinDto shokuinDto = readJson("ShokuinDto.json", new TypeToken<ShokuinDto>(){}.getType());
//		shokuinDto.setVersion(null);
//
//		try
//		{
//			masterMaintenanceService.registerShokuin(mKanriMap, shokuinDto, updatedBy);
//		}
//		catch (Exception e) {
//			String messageExp = "入力されたログインIDは既に使用されています。";
//			assertEquals(messageExp, e.getMessage());
//		}
//	}
//
//	@Test
//	@DisplayName("利用者グループリストを取得します")
//	@TestInitDataFile("TestSetShokuinInfoInit.xlsx")
//	public void TestRegisterShokuin2() throws Exception{
//		Map<Short, MKanri> mKanriMap = new HashMap<>();
//		MKanri mKanri = new MKanri();
//		mKanri.setKanriCode((short)12);
//		mKanriMap.put((short)10, mKanri);
//		String updatedBy = "a";
//		ShokuinDto shokuinDto = new ShokuinDto();
//		shokuinDto.setLoginId("0t");
//		shokuinDto.setUserName("test");
//		shokuinDto.setPassword("123");
//		shokuinDto.setSyokuinKanaName("test");
//		shokuinDto.setUketsukeBashoCode((short)10);
//
//		masterMaintenanceService.registerShokuin(mKanriMap, shokuinDto, updatedBy);
//	}
//
//	@Test
//	@DisplayName("利用者グループリストを取得します")
//	@TestInitDataFile("TestSetShokuinInfoInit.xlsx")
//	public void TestRegisterShokuin3() throws Exception{
//		Map<Short, MKanri> mKanriMap = new HashMap<>();
//		MKanri mKanri = new MKanri();
//		mKanri.setKanriCode((short)12);
//		mKanriMap.put((short)12, mKanri);
//		String updatedBy = "a";
//		ShokuinDto shokuinDto = readJson("ShokuinDto.json", new TypeToken<ShokuinDto>(){}.getType());
//		shokuinDto.setPassword("000000");
//		List<MKanri> kanriCodeCK = new ArrayList<>();
//		kanriCodeCK.add(mKanri);
//
//		List<MShokuinKengen> mShokuinKengenList = new ArrayList<>();
//
//		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/M/d HH:mm");
//		Date dateCreate = new Date();
//		dateCreate = dateFormat.parse("2018/1/22 14:17");
//		long timeCreate = dateCreate.getTime();
//		Timestamp tCreate = new Timestamp(timeCreate);
//
//		Date dateUpdate = new Date();
//		dateUpdate = dateFormat.parse("2018/1/22 14:19");
//		long timeUpdate= dateUpdate.getTime();
//		Timestamp tUpdate = new Timestamp(timeUpdate);
//
//		MShokuinKengen mSho = new MShokuinKengen();
//		mSho.setKanriCode((short)10);
//		mSho.setVersion(5);
//		mSho.setAllowedUpdate(false);
//		mSho.setLoginId("1");
//		mSho.setUpdatedAt(tUpdate);
//		mSho.setUpdatedBy("test");
//		mSho.setCreatedAt(tCreate);
//		mSho.setCreatedBy("test");
//		mShokuinKengenList.add(mSho);
//
//		shokuinDto.setMShokuinKengenList(mShokuinKengenList);
//
//		shokuinDto.setKanriCodeCK(kanriCodeCK);
//
//		masterMaintenanceService.registerShokuin(mKanriMap, shokuinDto, updatedBy);
//	}
//
//	@Test
//	@DisplayName("利用者グループリストを取得します")
//	@TestInitDataFile("TestSetShokuinInfoInit2.xlsx")
//	public void TestRegisterShokuin4() throws Exception{
//		Map<Short, MKanri> mKanriMap = new HashMap<>();
//		MKanri mKanri = new MKanri();
//		mKanri.setKanriCode((short)12);
//		mKanriMap.put((short)12, mKanri);
//		String updatedBy = "a";
//		ShokuinDto shokuinDto = readJson("ShokuinDto.json", new TypeToken<ShokuinDto>(){}.getType());
//		shokuinDto.setPassword("000000");
//		List<MKanri> kanriCodeCK = new ArrayList<>();
//		kanriCodeCK.add(mKanri);
//
//		List<MShokuinKengen> mShokuinKengenList = new ArrayList<>();
//
//		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/M/d HH:mm");
//		Date dateCreate = new Date();
//		dateCreate = dateFormat.parse("2018/1/22 14:17");
//		long timeCreate = dateCreate.getTime();
//		Timestamp tCreate = new Timestamp(timeCreate);
//
//		Date dateUpdate = new Date();
//		dateUpdate = dateFormat.parse("2018/1/22 14:19");
//		long timeUpdate= dateUpdate.getTime();
//		Timestamp tUpdate = new Timestamp(timeUpdate);
//
//		MShokuinKengen mSho = new MShokuinKengen();
//		mSho.setKanriCode((short)10);
//		mSho.setVersion(5);
//		mSho.setAllowedUpdate(false);
//		mSho.setLoginId("1");
//		mSho.setUpdatedAt(tUpdate);
//		mSho.setUpdatedBy("test");
//		mSho.setCreatedAt(tCreate);
//		mSho.setCreatedBy("test");
//		mShokuinKengenList.add(mSho);
//
//		shokuinDto.setMShokuinKengenList(mShokuinKengenList);
//
//		shokuinDto.setKanriCodeCK(kanriCodeCK);
//
//		try
//		{
//			masterMaintenanceService.registerShokuin(mKanriMap, shokuinDto, updatedBy);
//		}
//		catch (Exception e) {
//			String messageExp = "入力されたパスワードは過去に使用されたパスワードのため、変更できません。";
//			assertEquals(messageExp, e.getMessage());
//		}
//	}

	@Test
	@DisplayName("利用者グループリストを取得します")
	@TestInitDataFile("TestGetMBashoInit.xlsx")
	public void TestGetMBasho() throws Exception{
		short bashoCode = 10;
		MBashoDto ret = masterMaintenanceService.getMBasho(bashoCode);
		exportJsonData(ret, "TestGetMBasho.json");
	}

	@Test
	@DisplayName("利用者グループリストを取得します")
	@TestInitDataFile("TestGetMBashoInit.xlsx")
	public void TestGetMBasho2() throws Exception{
		Short bashoCode = null;
		MBashoDto ret = masterMaintenanceService.getMBasho(bashoCode);
		assertNull(ret);
	}
	@Test
	@DisplayName("利用者グループリストを取得します")
	@TestInitDataFile("TestGetMBashoInit.xlsx")
	public void TestRegisterBasho() throws Exception{
		MBashoDto mBashoDto = readJson("MBashoDto.json", new TypeToken<MBashoDto>(){}.getType());
		String updatedBy = "a";
		masterMaintenanceService.registerBasho(mBashoDto, updatedBy);

	}
	
	@Test
	@DisplayName("利用者グループリストを取得します")
	@TestInitDataFile("TestGetMBashoInit.xlsx")
	public void TestRegisterBasho2() throws Exception{
		MBashoDto mBashoDto = readJson("MBashoDto.json", new TypeToken<MBashoDto>(){}.getType());
		mBashoDto.setVersion(null);
		mBashoDto.setBashoCode((short)11);
		String updatedBy = "a";
		masterMaintenanceService.registerBasho(mBashoDto, updatedBy);

	}
	
	@Test
	@DisplayName("利用者グループリストを取得します")
	@TestInitDataFile("TestGetMBashoInit.xlsx")
	public void TestDeleteBasho() throws Exception{
		MBashoDto mBashoDto = readJson("MBashoDto.json", new TypeToken<MBashoDto>(){}.getType());
		String updatedBy = "a";
		masterMaintenanceService.deleteBasho(mBashoDto, updatedBy);

	}

}
