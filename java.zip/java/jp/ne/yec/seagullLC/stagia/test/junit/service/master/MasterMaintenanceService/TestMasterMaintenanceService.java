package jp.ne.yec.seagullLC.stagia.test.junit.service.master.MasterMaintenanceService;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.beans.StringCodeNamePair;
import jp.ne.yec.seagullLC.stagia.beans.master.MSystemDto;
import jp.ne.yec.seagullLC.stagia.service.master.MasterMaintenanceService;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestMasterMaintenanceService extends JunitBase{

	@Autowired
	MasterMaintenanceService masterMaintenanceService;

	@Test
	@DisplayName("「m_system」の情報を取得し返却します.")
	public void TestGetMSystem() throws Exception{
		//MSystemDto dto = masterMaintenanceService.getMSystem();
	}

	@Test
	@DisplayName("利用者グループリストを取得します")
	@TestInitDataFile("TestgetRiyoshaGroupListInit.xlsx")
	public void TestGetRiyoshaGroupList() throws Exception{
		 List<StringCodeNamePair> list = masterMaintenanceService.getRiyoshaGroupList();
		 assertEquals(2, list.size());
		 exportJsonData(list, "TestGetRiyoshaGroupList.json");
	}

	@Test
	@DisplayName("利用者グループリストを取得します")
	@TestInitDataFile("TestgetSystemMaintenanceInfoInit.xlsx")
	public void TestgetSystemMaintenanceInfo() throws Exception{
		 List<MSystemDto> jsonData = new ArrayList<>();
		 MSystemDto ret = masterMaintenanceService.getSystemMaintenanceInfo();
		 assertNotNull(ret);
		 jsonData.add(ret);
		 exportJsonData(jsonData, "TestgetSystemMaintenanceInfo.json");
	}

	@Test
	@DisplayName("利用者グループリストを取得します")
	@TestInitDataFile("TestgetSystemMaintenanceInfoInit2.xlsx")
	public void TestgetSystemMaintenanceInfo_null() throws Exception{
		 List<MSystemDto> jsonData = new ArrayList<>();
		 MSystemDto ret = masterMaintenanceService.getSystemMaintenanceInfo();
		 assertNotNull(ret);
		 jsonData.add(ret);
		 exportJsonData(jsonData, "TestgetSystemMaintenanceInfo_null.json");
	}

}
