package jp.ne.yec.seagullLC.stagia.test.junit.base;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.wicket.ajax.json.JSONArray;
import org.dbunit.Assertion;
import org.dbunit.DatabaseUnitException;
import org.dbunit.database.DatabaseConnection;
import org.dbunit.database.IDatabaseConnection;
import org.dbunit.dataset.DataSetException;
import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.excel.XlsDataSet;
import org.dbunitng.dataset.BeanListConverter;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceUtils;
import org.springframework.test.context.junit4.SpringRunner;

import com.google.gson.ExclusionStrategy;
import com.google.gson.FieldAttributes;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import jp.ne.yec.seagullLC.stagia.test.base.TestBase;

/**
 * @author nao-hirata
 *
 */
@RunWith(SpringRunner.class)
public class JunitBase extends TestBase {
	private final static String TAG = "---------------------------------JunitBase---------------------------------";

	@Autowired
	protected JdbcTemplate jdbcTemplate;

	/* (非 Javadoc)
	 * @see jp.ne.yec.seagullLC.stagia.base.TestBase#getIConnection()
	 */
	@Override
	protected IDatabaseConnection getIConnection() throws CannotGetJdbcConnectionException, DatabaseUnitException {
		return new DatabaseConnection(DataSourceUtils.getConnection(jdbcTemplate.getDataSource()));
	}

	/**
	 * オブジェクトと期待値リストを比較します.
	 * @throws Exception
	 * @throws IOException
	 * @throws InvalidFormatException
	 * @throws EncryptedDocumentException
	 * @throws DataSetException
	 *
	 */
	protected <T> void assertList(String fileName, Map<String, List<T>> expectedList) throws Exception {
		try {
			Workbook workbook = WorkbookFactory.create(this.getClass().getResourceAsStream(fileName));
			Iterator<Sheet> iterator = workbook.iterator();
			while (iterator.hasNext()) {
				Sheet sheet = iterator.next();
				List<T> list = expectedList.get(sheet.getSheetName());
				if (0 == list.size()) {
					continue;
				}
				BeanListConverter beanListConverter = new BeanListConverter(list);
				IDataSet dataSet = beanListConverter.convert();
				XlsDataSet expected = new XlsDataSet(this.getClass().getResourceAsStream(fileName));
				Assertion.assertEquals(expected, dataSet);
			}
		} catch (Exception e) {
			throw e;
		}
	}

	/**
	 * Đọc danh sách từ file
	 * @param fileName : tên file (sử dụng tương tự assertList)
	 * @return : Danh sách short
	 * @throws Exception
	 */
	public List<Short> readArrShort(String fileName) throws Exception {
		List<Short> list = null;
		BufferedReader bufferedReader = null;

		try {
			list = new ArrayList<Short>();
			bufferedReader = new BufferedReader(new InputStreamReader(this.getClass().getResourceAsStream(fileName)));
			String line = bufferedReader.readLine();

			String[] splits = line.split(";");
			for (String string : splits) {
				Short item = Short.parseShort(string);
				list.add(item);
			}

		} finally {

			if (bufferedReader != null) {
				bufferedReader.close();
			}
		}
		return list;
	}


	/**
	 * Đọc danh sách từ file
	 * @param fileName : tên file (sử dụng tương tự assertList)
	 * @return : Danh sách boolean
	 * @throws Exception
	 */
	public List<Boolean> readArrBoolean(String fileName) throws Exception {
		List<Boolean> list = null;
		BufferedReader bufferedReader = null;

		try {
			list = new ArrayList<Boolean>();
			bufferedReader = new BufferedReader(new InputStreamReader(this.getClass().getResourceAsStream(fileName)));
			String line = bufferedReader.readLine();

			String[] splits = line.split(";");
			for (String string : splits) {
				Boolean item = Boolean.parseBoolean(string);
				list.add(item);
			}

		} finally {

			if (bufferedReader != null) {
				bufferedReader.close();
			}
		}
		return list;
	}

	/**
	 * Đọc danh sách từ file
	 * @param fileName : tên file (sử dụng tương tự assertList)
	 * @return : Danh sách string
	 * @throws Exception
	 */
	public List<String> readArrString(String fileName) throws Exception {
		List<String> list = null;
		BufferedReader bufferedReader = null;

		try {
			list = new ArrayList<String>();
			bufferedReader = new BufferedReader(new InputStreamReader(this.getClass().getResourceAsStream(fileName)));
			String line = bufferedReader.readLine();
			String[] splits = line.split(";");
			for (String string : splits) {
				list.add(string);
			}

		} finally {

			if (bufferedReader != null) {
				bufferedReader.close();
			}
		}
		return list;
	}

	/**
	 * Đọc danh sách từ file
	 * @param fileName : tên file (sử dụng tương tự assertList)
	 * @return : Danh sách Date
	 * @throws Exception
	 */
	public List<Date> readArrDate(String fileName) throws Exception {
		List<Date> list = null;
		BufferedReader bufferedReader = null;

		try {
			list = new ArrayList<Date>();
			bufferedReader = new BufferedReader(new InputStreamReader(this.getClass().getResourceAsStream(fileName)));
			String line = bufferedReader.readLine();
			String[] splits = line.split(";");
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
			for (String string : splits) {
				Date item = formatter.parse(string);
				list.add(item);
			}
		} finally {

			if (bufferedReader != null) {
				bufferedReader.close();
			}
		}
		return list;
	}

	/**
	 * Đọc danh sách từ file
	 * @param fileName : tên file (sử dụng tương tự assertList)
	 * @return : Danh sách integer
	 * @throws Exception
	 */
	public List<Integer> readArrInteger(String fileName) throws Exception {
		List<Integer> list = null;
		BufferedReader bufferedReader = null;

		try {
			list = new ArrayList<Integer>();
			bufferedReader = new BufferedReader(new InputStreamReader(this.getClass().getResourceAsStream(fileName)));
			String line = bufferedReader.readLine();
			String[] splits = line.split(";");
			for (String string : splits) {
				Integer item = Integer.parseInt(string);
				list.add(item);
			}

		} finally {

			if (bufferedReader != null) {
				bufferedReader.close();
			}
		}
		return list;
	}

	/**
	 *  Đọc danh Map<String, List<String>>
	 *  Trong file txt
	 *     Key nằm ở đầu dòng đến dấu ":"
	 *     Value là danh sách các phần tử ở sau dấu ":" và cách nhau 1 tab
	 * @param fileName : Tên file
	 * @return : Map
	 * Các kiểu dữ liệu hổ trợ String, Short, Integer, Long, Double, Float, Boolean
	 */
	@SuppressWarnings("unchecked")
	public <T,U> Map<T, List<U>> readMapFile(String fileName, Class<T> classOfT, Class<U> classOfU) throws Exception
	{
		Map<T, List<U>> mapList = null;
		BufferedReader bufferedReader = null;

		try {
			mapList = new HashMap<T, List<U>>();
			bufferedReader = new BufferedReader(new InputStreamReader(this.getClass().getResourceAsStream(fileName)));
			String line = bufferedReader.readLine();

			while (line != null) {
				List<U> listU = new ArrayList<U>();
				String[] splits = line.split(":");
				String[] splitValue = splits[1].split(";");

				T t = getValue(splits[0], classOfT);
				for (String string : splitValue) {
					U u = getValue(string, classOfU);
					listU.add(u);
				}

				mapList.put(t, listU);
				line = bufferedReader.readLine();
			}
		} finally {

			if (bufferedReader != null) {
				bufferedReader.close();
			}
		}
		return mapList;
	}

	public <T,U> Map<T, U> readMapFileSimple(String fileName, Class<T> classOfT, Class<U> classOfU) throws Exception
	{
		Map<T, List<U>> mapTest = readMapFile(fileName, classOfT, classOfU);
		Map<T, U> mapUnitTest = new HashMap<>();
		for (Map.Entry<T, List<U>> entry : mapTest.entrySet()) {
			mapUnitTest.put(entry.getKey(), entry.getValue().get(0));
		}
		return mapUnitTest;
	}

	/**
	 * Kiểm tra là chuổi
	 * @param classOfU : dạng hình
	 * @return : true là chuổi - false không là chuổi
	 */
	@SuppressWarnings("unchecked")
	private <U> U getValue(String string, Class<U> classOfU) throws Exception
	{
		U u = null;
		String nameClass = classOfU.getSimpleName();
		if (nameClass.equals("String") != false)
		{
			u = (U) string;
		}

		if (nameClass.equals("Short") != false)
		{
			Short short1 = Short.parseShort(string);
			u = (U) short1;
		}

		if (nameClass.equals("Integer") != false)
		{
			Integer integer1 = Integer.parseInt(string);
			u = (U) integer1;
		}

		if (nameClass.equals("Long") != false)
		{
			Long long1 = Long.parseLong(string);
			u = (U) long1;
		}

		if (nameClass.equals("Double") != false)
		{
			Double double1 = Double.parseDouble(string);
			u = (U) double1;
		}

		if (nameClass.equals("Float") != false)
		{
			Float float1 = Float.parseFloat(string);
			u = (U) float1;
		}

		if (nameClass.equals("Boolean") != false)
		{
			Boolean boolean1 = Boolean.parseBoolean(string);
			u = (U) boolean1;
		}

		return u;

	}

	/*
	    Class model :
		class Demo
		{
			private String code;
			private String name;
			private boolean isAllow;
		}

    	Cách dùng :

		List<Demo> listDemo = readExcell("TestExcell.xlsx", Demo.class);

	 */

	/**
	 * Hàm chuyển file excell thành List<T>
	 * @param fileName : Tên file excell
	 * @param classOfT : Loại hình class cần chuyển
	 * @return : Danh sách sau khi chuyển
	 * @throws Exception
	 */
	@SuppressWarnings("resource")
	public <T> List<T> readExcell(String fileName, Class<T> classOfT) throws Exception {
		XSSFWorkbook workbook = new XSSFWorkbook(this.getClass().getResourceAsStream(fileName));
		XSSFSheet sheet = workbook.getSheet(classOfT.getSimpleName());
		Iterator<Row> rowIterator = sheet.iterator();

		// Tên sheet làm tên class
		String nameSheet = sheet.getSheetName();

		System.out.println(TAG);
		System.out.println("Excell class : " + nameSheet);
		List<String> columns = getColumnName(rowIterator);
		System.out.println("Excell fields : " + columns);

		JSONArray jsonArray = new JSONArray();

		// Dùng gson chuyển map thành List
		Gson gson = new Gson();

		while (rowIterator.hasNext()) {

			// Map vào object
			Map<String, Object> mapObject = new HashMap<>();

			Row row = rowIterator.next();
			Iterator<Cell> cellIterator = row.cellIterator();
			int cellIdx = 0;

			while (cellIterator.hasNext()) {
				// Lưu vào map theo tên map
				String field = "field";

				if (cellIdx < columns.size())
				{
					field = columns.get(cellIdx);
				}

				Cell cell = cellIterator.next();
				Object value = null;
				DataFormatter formatter = new DataFormatter();

				// Kiểm tra từng cell lưu vào map
				switch (cell.getCellType()) {
				case Cell.CELL_TYPE_NUMERIC:
					value = formatter.formatCellValue(cell);
					if (checkDate(field) != false)
					{
						value = null;
					}
					break;
				case Cell.CELL_TYPE_STRING:
					value = cell.getStringCellValue();
					break;
				case Cell.CELL_TYPE_BLANK:
					continue;
				case Cell.CELL_TYPE_BOOLEAN:
					value = cell.getBooleanCellValue();
					break;
				}
				mapObject.put(field, value);
				cellIdx++;
			}
			jsonArray.put(mapObject);
			mapObject.clear();
		}

		String jsonString = jsonArray.toString();
		List<T> list = gson.fromJson(jsonString, new ListOfJson<T>(classOfT));

		try
		{
		List<Map<String, Timestamp>> listMap = readExcellTimestamp(fileName, classOfT);
		for (int idx = 0; idx < list.size(); idx++) {
			Map<String, Timestamp> map = listMap.get(idx);
			for (Map.Entry<String, Timestamp> entry : map.entrySet())
			{
				set(list.get(idx), entry.getKey(), entry.getValue());
			}
		}
		}
		catch (Exception e) {
			// TODO: handle exception
		}
		return list;
	}

	public boolean set(Object object, String fieldName, Object fieldValue) {
	    Class<?> clazz = object.getClass();
	    while (clazz != null) {
	        try {
	            Field field = clazz.getDeclaredField(fieldName);
	            field.setAccessible(true);
	            field.set(object, fieldValue);
	            return true;
	        } catch (NoSuchFieldException e) {
	            clazz = clazz.getSuperclass();
	        } catch (Exception e) {
	            throw new IllegalStateException(e);
	        }
	    }
	    return false;
	}

	@SuppressWarnings({ "resource" })
	private <T> List<Map<String, Timestamp>> readExcellTimestamp(String fileName, Class<T> classOfT) throws Exception {
		XSSFWorkbook workbook = new XSSFWorkbook(this.getClass().getResourceAsStream(fileName));
		XSSFSheet sheet = workbook.getSheet(classOfT.getSimpleName());
		Iterator<Row> rowIterator = sheet.iterator();

		// Tên sheet làm tên class
		String nameSheet = sheet.getSheetName();

		System.out.println(TAG);
		System.out.println("Excell class : " + nameSheet);
		List<String> columns = getColumnName(rowIterator);
		System.out.println("Excell fields : " + columns);

		List<Map<String, Timestamp>> listTimeT = new ArrayList<Map<String, Timestamp>>();

		while (rowIterator.hasNext()) {
			Map<String, Timestamp> mapTimestamp = new HashMap<String, Timestamp>();
			Row row = rowIterator.next();

			Iterator<Cell> cellIterator = row.cellIterator();
			int cellIdx = 0;

			while (cellIterator.hasNext()) {
				// Lưu vào map theo tên map
				String field = columns.get(cellIdx);

				Cell cell = cellIterator.next();
				DataFormatter formatter = new DataFormatter();

				// Kiểm tra từng cell lưu vào map
				switch (cell.getCellType()) {
				case Cell.CELL_TYPE_NUMERIC:
					if (checkDate(field) != false)
					{
						Long longTime = new Long(formatter.formatCellValue(cell));
						Timestamp timestamp = new Timestamp(longTime);
						mapTimestamp.put(field, timestamp);
					}
					break;
				}
				cellIdx++;
			}
			listTimeT.add(mapTimestamp);
		}

		return listTimeT;
	}

	private boolean checkDate(String field)
	{
		if (field.contains("createdAt") || field.contains("updatedAt") || field.contains("deletedAt"))
		{
			return true;
		}
		return false;
	}

	/**
	 * Đọc toàn bộ tên cột
	 *
	 * @param rowIterator
	 * @return
	 */
	private List<String> getColumnName(Iterator<Row> rowIterator) {
		List<String> columnNames = new ArrayList<String>();
		if (rowIterator.hasNext()) {
			Row row = rowIterator.next();
			// For each row, iterate through all the columns
			Iterator<Cell> cellIterator = row.cellIterator();

			while (cellIterator.hasNext()) {
				Cell cell = cellIterator.next();
				// Check the cell type and format accordingly
				if (cell.getCellType() == Cell.CELL_TYPE_STRING) {
					columnNames.add(cell.getStringCellValue());
				}
			}
		}

		return columnNames;
	}

	/**
	 * Class hổ trợ parser
	 * @param <T>
	 */
	private class ListOfJson<T> implements ParameterizedType {
		private Class<?> wrapped;

		public ListOfJson(Class<T> wrapper) {
			this.wrapped = wrapper;
		}

		@Override
		public Type[] getActualTypeArguments() {
			return new Type[] { wrapped };
		}

		@Override
		public Type getRawType() {
			return List.class;
		}

		@Override
		public Type getOwnerType() {
			return null;
		}
	}

//	/**
//	 * Hàm xử lý xóa file result
//	 * @param name
//	 */
//	public void removeFileJson(String name)
//	{
//		String path = this.getClass().getPackage().getName();
//		String pathOutPutJson = "D:/stagia2/stagia2_svn/module/src-test/java/" + path.replaceAll("\\.", "/") + "/" + name;
//
//        File fileDir = new File(pathOutPutJson);
//        if (fileDir.exists() != false)
//        {
//            fileDir.delete();
//        }
//	}

	/**
	 * Hàm xử lý xuất json ra file excell
	 * @param object
	 * @param name
	 */
	public <T>void exportJsonData(List<T> ts, String name)
	{
		String path = this.getClass().getPackage().getName();
//		String pathOutPutJson = "D:/stagia2/stagia2_svn/module/src-test/java/" + path.replaceAll("\\.", "/");
		String pathOutPutJson = "E:/stagia/modules/src-test/java/" + path.replaceAll("\\.", "/");
		write(ts, name, pathOutPutJson);
	}

	/**
     * Hàm thực hiện ghi file
     * @param object nội dung cần ghi
     * @param directory đường dẫn thư mục chứ file ghi
     * @return true thành công, false thất bại
     */
	public void write(Object object, String name, String directory)
    {
    	Gson gson = new Gson();
		String content = gson.toJson(object);
    	StringBuilder stringBuilder = new StringBuilder();
    	stringBuilder.append(content);
        stringBuilder.append("\n");

    	FileOutputStream fileOutputStream = null;

        try
        {
            // Kiểm tra tạo thư mục lưu ghi file,
            // Tạo mới nếu chưa có
            File fileDir = new File(directory);
            if (fileDir.exists() == false)
            {
                fileDir.mkdirs();
            }

            // Kiểm tra tạo file TraceLog_yyyyMMdd.csv trong directory,
            // Tạo mới nếu chưa có
            String filePath = directory + "/" + name;
            File fileWrite = new File(filePath);
            if (fileWrite.exists() == false)
            {
                fileWrite.createNewFile();
            }

            // Ghi file TraceLog với nội dung là content
            fileOutputStream = new FileOutputStream(filePath, false);
            fileOutputStream.write(stringBuilder.toString().getBytes("UTF-8"));
        }
        catch (Exception ex)
        {
        	ex.printStackTrace();
        }
        finally
        {
            try
            {
                if (fileOutputStream != null)
                {
                    fileOutputStream.close();
                }
            }
            catch (Exception ex)
            {
                ex.printStackTrace();;
            }
        }
    }


	/**
     * Hàm thực hiện ghi file
     * @param object nội dung cần ghi
     * @param directory đường dẫn thư mục chứ file ghi
     * @return true thành công, false thất bại
     */
	public void writeAppend(Object object, String name, String directory)
    {
    	Gson gson = new Gson();
		String content = gson.toJson(object);
    	StringBuilder stringBuilder = new StringBuilder();
    	stringBuilder.append(content);
        stringBuilder.append("\n");

    	FileOutputStream fileOutputStream = null;

        try
        {
            // Kiểm tra tạo thư mục lưu ghi file,
            // Tạo mới nếu chưa có
            File fileDir = new File(directory);
            if (fileDir.exists() == false)
            {
                fileDir.mkdirs();
            }

            // Kiểm tra tạo file TraceLog_yyyyMMdd.csv trong directory,
            // Tạo mới nếu chưa có
            String filePath = directory + "/" + name;
            File fileWrite = new File(filePath);
            if (fileWrite.exists() == false)
            {
                fileWrite.createNewFile();
            }

            // Ghi file TraceLog với nội dung là content
            fileOutputStream = new FileOutputStream(filePath, true);
            fileOutputStream.write(stringBuilder.toString().getBytes("UTF-8"));
        }
        catch (Exception ex)
        {
        	ex.printStackTrace();
        }
        finally
        {
            try
            {
                if (fileOutputStream != null)
                {
                    fileOutputStream.close();
                }
            }
            catch (Exception ex)
            {
                ex.printStackTrace();;
            }
        }
    }


	public LocalDate CreateLocalDate(int year, int month, int date)
	{
		String dateValue = year + "/" + month + "/" + date;
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy/MM/dd");
		Date MudanDate = null;
		try
		{
			MudanDate = formatter.parse(dateValue);
		} catch (ParseException e) {
			e.printStackTrace();
		}

		Instant instant = Instant.ofEpochMilli(MudanDate.getTime());
		LocalDate baseDate = LocalDateTime.ofInstant(instant, ZoneId.systemDefault()).toLocalDate();
		return baseDate;
	}

	/**
	 * Hàm xử lý xuất json ra file excell
	 * @param object
	 * @param name
	 */
	public <T>void exportJsonData(T ts, String name)
	{
		String path = this.getClass().getPackage().getName();
//		String pathOutPutJson = "D:/stagia2/stagia2_svn/module/src-test/java/" + path.replaceAll("\\.", "/");
		String pathOutPutJson = "E:/stagia/modules/src-test/java/" + path.replaceAll("\\.", "/");
		write(ts, name, pathOutPutJson);
	}

	/**
	 * Đọc dữ liệu json
	 * @param fileName : tên file (sử dụng tương tự assertList)
	 * @return : T
	 * @throws Exception
	 *
	 *	VD: Map<String, MKomaPattern> shisetsuToMKomaPatternMap = readJson(
				"shisetsuToMKomaPatternMap.pra", new TypeToken<Map<String, MKomaPattern>>(){}.getType());
	 *
	 */
	public <T> T readJson(String fileName, Type type) throws Exception {
		BufferedReader bufferedReader = null;
		StringBuilder stringBuilder = new StringBuilder();

		try {
			bufferedReader = new BufferedReader(new InputStreamReader(this.getClass().getResourceAsStream(fileName)));
			stringBuilder.append(bufferedReader.readLine());
			Gson gson = new Gson();
			String jsonString = stringBuilder.toString();
			return gson.fromJson(jsonString, type);
		} finally {
			if (bufferedReader != null) {
				bufferedReader.close();
			}
		}
	}

	class SuperclassExclusionStrategy implements ExclusionStrategy
	{
	    public boolean shouldSkipClass(Class<?> arg0)
	    {
	        return false;
	    }

	    public boolean shouldSkipField(FieldAttributes fieldAttributes)
	    {
	        String fieldName = fieldAttributes.getName();
	        Class<?> theClass = fieldAttributes.getDeclaringClass();

	        return isFieldInSuperclass(theClass, fieldName);
	    }

	    private boolean isFieldInSuperclass(Class<?> subclass, String fieldName)
	    {
	        Class<?> superclass = subclass.getSuperclass();
	        Field field;

	        while(superclass != null)
	        {
	            field = getField(superclass, fieldName);

	            if(field != null)
	                return true;

	            superclass = superclass.getSuperclass();
	        }

	        return false;
	    }

	    private Field getField(Class<?> theClass, String fieldName)
	    {
	        try
	        {
	            return theClass.getDeclaredField(fieldName);
	        }
	        catch(Exception e)
	        {
	            return null;
	        }
	    }
	}

	public void writeIfMultipleFields(Object object, String name, String directory)
    {
		GsonBuilder gsonBuilder = new GsonBuilder();
		gsonBuilder.addDeserializationExclusionStrategy(new SuperclassExclusionStrategy());
	    gsonBuilder.addSerializationExclusionStrategy(new SuperclassExclusionStrategy());
    	Gson gson = gsonBuilder.create();
		String content = gson.toJson(object);
    	StringBuilder stringBuilder = new StringBuilder();
    	stringBuilder.append(content);
        stringBuilder.append("\n");

    	FileOutputStream fileOutputStream = null;

        try
        {
            // Kiểm tra tạo thư mục lưu ghi file,
            // Tạo mới nếu chưa có
            File fileDir = new File(directory);
            if (fileDir.exists() == false)
            {
                fileDir.mkdirs();
            }

            // Kiểm tra tạo file TraceLog_yyyyMMdd.csv trong directory,
            // Tạo mới nếu chưa có
            String filePath = directory + "/" + name;
            File fileWrite = new File(filePath);
            if (fileWrite.exists() == false)
            {
                fileWrite.createNewFile();
            }

            // Ghi file TraceLog với nội dung là content
            fileOutputStream = new FileOutputStream(filePath, false);
            fileOutputStream.write(stringBuilder.toString().getBytes("UTF-8"));
        }
        catch (Exception ex)
        {
        	ex.printStackTrace();
        }
        finally
        {
            try
            {
                if (fileOutputStream != null)
                {
                    fileOutputStream.close();
                }
            }
            catch (Exception ex)
            {
                ex.printStackTrace();;
            }
        }
    }

	/**
	 * Hàm xử lý xuất json ra file excell
	 * @param object
	 * @param name
	 */
	public <T>void exportJsonDataIfMultipleFields(T ts, String name)
	{
		String path = this.getClass().getPackage().getName();
		String pathOutPutJson = "D:/stagia2/stagia2_svn/module/src-test/java/" + path.replaceAll("\\.", "/");
		writeIfMultipleFields(ts, name, pathOutPutJson);
	}
}
