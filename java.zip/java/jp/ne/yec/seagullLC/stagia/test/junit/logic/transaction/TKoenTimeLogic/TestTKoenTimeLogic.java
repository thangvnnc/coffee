
package jp.ne.yec.seagullLC.stagia.test.junit.logic.transaction.TKoenTimeLogic;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.entity.TKoenTime;
import jp.ne.yec.seagullLC.stagia.logic.transaction.TKoenTimeLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestTKoenTimeLogic extends JunitBase {

	@Autowired
	TKoenTimeLogic tKoenTimeLogic;

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetTKoenTimeInit.xlsx")
	public void TestgetTKoenTime() throws Exception
	{
		int id = 37350;
		List<TKoenTime> ret =  tKoenTimeLogic.getTKoenTime(id);
		exportJsonData(ret, "TestgetTKoenTime.json");
	}
	
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetTKoenTime_ListInit.xlsx")
	public void TestgetTKoenTime_List() throws Exception
	{
		List<List<TKoenTime>> tListt = new ArrayList<>();
	
		List<Integer> id = new ArrayList<>();
		id.add(37350);
		id.add(37352);
		id.add(0);
		
		List<TKoenTime> ret = tKoenTimeLogic.getTKoenTime(id);
		exportJsonData(ret, "TestgetTKoenTime_List.json");
	}
	
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	//@TestInitDataFile("TestgetMBashoList.xlsx")
	public void TestgetDao() throws Exception
	{
		GenericDao<TKoenTime, ?> ret = tKoenTimeLogic.getDao();
	}
}