package jp.ne.yec.seagullLC.stagia.test.selenide.page.madoguchi;

import static com.codeborne.selenide.Selenide.*;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

import com.codeborne.selenide.ElementsCollection;
import com.codeborne.selenide.SelenideElement;

import jp.ne.yec.seagullLC.stagia.test.selenide.page.base.SelenidePageBase;
import jp.ne.yec.seagullLC.stagia.test.selenide.page.shinsei.MeisaiIchiranHenkoTest;

/**
 * 照会ページのテストクラス
 *
 * @author nao-hirata
 *
 */
public class ShokaiTest extends SelenidePageBase {

	@FindBy(how = How.CSS, using = "input[wicketpath=form_shinseiKensakuJokenArea_shiyouSDatepick_shiyouSDatepick__body_sShiyoStartDate]")
	private SelenideElement shiyoDateFromText;

	@FindBy(how = How.CSS, using = "input[wicketpath=form_shinseiKensakuJokenArea_shiyouEDatepick_shiyouEDatepick__body_sShiyoEndDate]")
	private SelenideElement shiyoDateToText;

	@FindBy(how = How.CSS, using = "select[wicketpath=form_shinseiKensakuJokenArea_sMeisaiJotaiList] + div > button")
	private SelenideElement meisaiJotaiButton;

	@FindBy(how = How.CSS, using = "select[wicketpath=form_shinseiKensakuJokenArea_sMeisaiJotaiList] + div > ul li")
	private ElementsCollection meisaiJotaiCheckBox;

	@FindBy(how = How.CSS, using = "body")
	private SelenideElement body;

	@FindBy(how = How.CSS, using = "button[wicketpath=form_shinseiKensakuJokenArea_sKensakuButon]")
	private SelenideElement searchButton;

	@FindBy(how = How.CSS, using = "button[wicketpath=form_shinseiKensakuKekkaArea_shinseiKensakuButtonArea_henko]")
	private SelenideElement henkoButton;

	/**
	 * 引数の行数に対応する明細行のセレクタを返却します.
	 *
	 * @param row
	 * @return
	 */
	private String getMeisaiSelector(int row) {
		return "tr[wicketpath=form_shinseiKensakuKekkaArea_tr_" + String.valueOf(row) + "]";
	}

	/**
	 * 使用日のFromを設定します.
	 *
	 * @param value
	 */
	public void setShiyoDateFrom(String value) {
		shiyoDateFromText.val(value);
	}

	/**
	 * 使用日のToを設定します.
	 *
	 * @param value
	 */
	public void setShiyoDateTo(String value) {
		shiyoDateToText.val(value);
	}

	/**
	 * 引数の明細状態をクリックします.<br>
	 * meisaiJotaiButtonクリックで開くselectが自動で閉じない為、
	 * 明細状態選択後bodyをクリックします.
	 *
	 * @param values
	 */
	public void setMeisaiJotai(String... values) {
		meisaiJotaiButton.click();
		Set<String> set = new HashSet<>(Arrays.asList(values));
		meisaiJotaiCheckBox.forEach(li -> {
			SelenideElement label = li.find("a > label");
			if (set.contains(label.text())) {
				label.click();
			}
		});
		body.click();
	}

	/**
	 * 検索ボタンをクリックします.
	 */
	public void search() {
		takeScreenShotAndClickElement(searchButton);
		sleep(1000);
		takeScreenShot();
	}

	/**
	 * 引数の行数に対応する検索結果の行をクリックします.
	 *
	 * @param row - クリックする行数
	 */
	public void clickMeisaiResult(int row) {
		click($(getMeisaiSelector(row)));
	}

	/**
	 * 変更ボタンをクリックします.
	 *
	 * @return - MeisaiIchiranHenkoTestのインスタンス
	 */
	public MeisaiIchiranHenkoTest clickHenkoButton() {
		return takeScreenShotAndMovePage(henkoButton, MeisaiIchiranHenkoTest.class);
	}
}
