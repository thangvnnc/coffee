package jp.ne.yec.seagullLC.stagia.test.junit.service.akijokyo.AkijokyoKensakuService;

import static org.junit.Assert.*;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.util.AppConfig;
import jp.ne.yec.seagullLC.stagia.beans.shinsei.ShinseiDto;
import jp.ne.yec.seagullLC.stagia.beans.shinsei.ShinseiMeisaiDto;
import jp.ne.yec.seagullLC.stagia.entity.MBasho;
import jp.ne.yec.seagullLC.stagia.entity.MFutaisetsubi;
import jp.ne.yec.seagullLC.stagia.entity.MShisetsu;
import jp.ne.yec.seagullLC.stagia.entity.MShiyoMokuteki;
import jp.ne.yec.seagullLC.stagia.service.akijokyo.AkijokyoKensakuService;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = { "classpath:TestApplicationContext.xml" })
@WebAppConfiguration
public class TestAkijokyoKensakuService extends JunitBase {

	@Autowired
	AkijokyoKensakuService akijokyoKensakuService;

	@Test
	@DisplayName("管理、施設コードをキーとしたM_施設のMapを返却します.")
	@TestInitDataFile("TestGetShisetsuMapInit.xlsx")
	public void TestGetShisetsuMap() throws Exception {
		List<Map<String, MShisetsu>> maps = new ArrayList<>();
		Map<String, MShisetsu>  map = akijokyoKensakuService.getShisetsuMap();
		maps.add(map);
		exportJsonData(maps, "TestGetShisetsuMap.json");
	}

	@Test
	@DisplayName("絞り込み条件となる場所リストを生成し返却します.")
	@TestInitDataFile("TestGetBashoListInit.xlsx")
	public void TestGetBashoList() throws Exception {
		List<MBasho> mBashos = akijokyoKensakuService.getBashoList();
		exportJsonData(mBashos, "TestGetBashoList.json");
	}

//	@Test
//	@DisplayName("絞り込み条件となる使用目的リストを生成し返却します.")
//	@TestInitDataFile("TestGetShiyoMokutekiListInit.xlsx")
//	public void TestGetShiyoMokutekiList() throws Exception {
//		List<List<MShiyoMokuteki>> mLists = new ArrayList<>();
//		List<MShiyoMokuteki> mShiyoMokutekis = akijokyoKensakuService.getShiyoMokutekiList();
//		mLists.add(mShiyoMokutekis);
//		exportJsonData(mLists, "TestGetShiyoMokutekiList.json");
//	}

	@Test
	@DisplayName("絞り込み条件となる付帯設備リストを生成し返却します.")
	@TestInitDataFile("TestGetFutaiSetsubiListInit.xlsx")
	public void TestGetFutaiSetsubiList() throws Exception {
		List<List<MFutaisetsubi>> mLists = new ArrayList<>();
		List<MFutaisetsubi> mFutaisetsubis = akijokyoKensakuService.getFutaiSetsubiList();
		mLists.add(mFutaisetsubis);
		exportJsonData(mLists, "TestGetFutaiSetsubiList.json");
	}

	@Test
	@DisplayName("付帯設備関連のMapを返却します.")
	@TestInitDataFile("TestGetFutaiSetsubiKanrenMapInit.xlsx")
	public void TestGetFutaiSetsubiKanrenMap() throws Exception {
		List<Map<Short, Short>> maps = new ArrayList<>();
		Map<Short, Short> map = akijokyoKensakuService.getFutaiSetsubiKanrenMap();
		maps.add(map);
		exportJsonData(maps, "TestGetFutaiSetsubiKanrenMap.json");
	}

//	@Test
//	@DisplayName("付帯設備関連のMapを返却します.")
//	@TestInitDataFile("TestMakeMeisaiDtoListInit.xlsx")
//	public void TestMakeMeisaiDtoList() throws ParseException{
//		List<ShinseiDto> shinseiDtosParam = new ArrayList<>();
//		ShinseiDto shinseiDto2 = new ShinseiDto();
//		ShinseiDto shinseiDto3 = new ShinseiDto();
//		shinseiDto3.setLoginId("tester1");
//		SimpleDateFormat fm = new SimpleDateFormat("yyyy-MM-dd");
//		Date date = fm.parse("2018-06-27");
//		shinseiDto3.setToshoUketsukeDate(date);
//		shinseiDtosParam.add(shinseiDto2);
//		shinseiDtosParam.add(shinseiDto3);
//
//		Set<String> selectedKomaSet = new HashSet<>();
//		selectedKomaSet.add("10103101201806160110020010122");
//		List<Set<String>> selectedKomaSets = new ArrayList<>();
//		selectedKomaSets.add(selectedKomaSet);
//		selectedKomaSets.add(selectedKomaSet);
//
//		List<Map<Short, MBasho>> bashoMaps = new ArrayList<>();
//		Map<Short, MBasho> mBashoMap = new HashMap<>();
//		MBasho mBasho = new MBasho();
//		mBasho.setBashoCode((short)1030);
//		mBasho.setBashoName("生涯学習セ");
//		mBashoMap.put((short)103, mBasho);
//		bashoMaps.add(mBashoMap);
//		bashoMaps.add(mBashoMap);
//
//		List<Map<String, MShisetsu>> shisetsuMaps = new ArrayList<>();
//		Map<String, MShisetsu> shisetsuMap = new HashMap<>();
//		MShisetsu mShisetsu = new MShisetsu();
//		mShisetsu.setKanriCode((short)10);
//		mShisetsu.setKashidashiGroupCode((short)103);
//		shisetsuMap.put("10101", mShisetsu);
//		shisetsuMaps.add(shisetsuMap);
//		shisetsuMaps.add(shisetsuMap);
//
//		List<List<ShinseiMeisaiDto>> exports = new ArrayList<>();
//		for(int idx = 0; idx < selectedKomaSets.size(); idx++)
//		{
//			List<ShinseiMeisaiDto> ret = akijokyoKensakuService.makeMeisaiDtoList(
//					shinseiDtosParam.get(idx),
//					selectedKomaSets.get(idx),
//					bashoMaps.get(idx),
//					shisetsuMaps.get(idx)
//					);
//			exports.add(ret);
//		}
//		exportJsonData(exports, "TestMakeMeisaiDtoList.json");
//	}

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestGetTRyoshu.xlsx")
	public void TestGetTRyoshu() throws Exception
	{
		List<MBasho> mBashos = new ArrayList<>();
		MBasho mBasho = new MBasho();
		mBasho.setBashoCode((short)10);
		mBashos.add(mBasho);
		List<List<MBasho>> mBashoLists = new ArrayList<List<MBasho>>();
		mBashoLists.add(new ArrayList<>());
		mBashoLists.add(mBashos);
		mBashoLists.add(mBashos);
		mBashoLists.add(mBashos);

		List<MShiyoMokuteki> selectedMokutekis = new ArrayList<>();
		MShiyoMokuteki mShiyoMokuteki = new MShiyoMokuteki();
		mShiyoMokuteki.setShiyoMokutekiCode((short)1010);
		selectedMokutekis.add(mShiyoMokuteki);
		List<MShiyoMokuteki> selectedMokutekis2 = new ArrayList<>();
		MShiyoMokuteki mShiyoMokuteki2 = new MShiyoMokuteki();
		mShiyoMokuteki2.setShiyoMokutekiCode((short)1060);
		selectedMokutekis2.add(mShiyoMokuteki2);

		List<List<MShiyoMokuteki>> selectedMokutekiLists = new ArrayList<>();
		selectedMokutekiLists.add(new ArrayList<>());
		selectedMokutekiLists.add(selectedMokutekis);
		selectedMokutekiLists.add(selectedMokutekis2);
		selectedMokutekiLists.add(selectedMokutekis);

		List<MFutaisetsubi> selectedFutaiSetsubis = new ArrayList<>();
		MFutaisetsubi mFutaisetsubi = new MFutaisetsubi();
		mFutaisetsubi.setFutaisetsubiCode((short)10);
		selectedFutaiSetsubis.add(mFutaisetsubi);
		List<List<MFutaisetsubi>> selectedFutaiSetsubiLists = new ArrayList<>();
		selectedFutaiSetsubiLists.add(new ArrayList<>());
		selectedFutaiSetsubiLists.add(selectedFutaiSetsubis);
		selectedFutaiSetsubiLists.add(selectedFutaiSetsubis);
		selectedFutaiSetsubiLists.add(selectedFutaiSetsubis);

		Map<Short, Short> futaisetsubiKanrenMap = new HashMap<>();
		futaisetsubiKanrenMap.put((short)10, (short)10);
		List<Map<Short, Short>> futaisetsubiKanrenMaps = new ArrayList<Map<Short, Short>>();
		futaisetsubiKanrenMaps.add(new HashMap<>());
		futaisetsubiKanrenMaps.add(futaisetsubiKanrenMap);
		futaisetsubiKanrenMaps.add(futaisetsubiKanrenMap);
		futaisetsubiKanrenMaps.add(futaisetsubiKanrenMap);

		List<String> enteredTexts = new ArrayList<>();
		enteredTexts.add("教室");
		List<String> enteredTexts3 = new ArrayList<>();
		enteredTexts3.add("test");
		List<List<String>> enteredTextLists = new ArrayList<List<String>>();
		enteredTextLists.add(new ArrayList<>());
		enteredTextLists.add(enteredTexts);
		enteredTextLists.add(enteredTexts);
		enteredTextLists.add(enteredTexts3);

		List<List<MShisetsu>> exports = new ArrayList<>();
		for (int item = 0; item < mBashoLists.size(); item++)
		{
			List<MShisetsu> ret = akijokyoKensakuService.getShisetsuList(
					mBashoLists.get(item),
					selectedMokutekiLists.get(item),
					selectedFutaiSetsubiLists.get(item),
					futaisetsubiKanrenMaps.get(item),
					enteredTextLists.get(item)
					);
			exports.add(ret);
		}
		exportJsonData(exports, "TestGetTRyoshu.json");
	}

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	public void TestGetTRyoshuCatchException() throws Exception
	{
		List<List<MBasho>> mBashoLists = new ArrayList<List<MBasho>>();
		mBashoLists.add(new ArrayList<>());

		List<List<MShiyoMokuteki>> selectedMokutekiLists = new ArrayList<>();
		selectedMokutekiLists.add(new ArrayList<>());

		List<List<MFutaisetsubi>> selectedFutaiSetsubiLists = new ArrayList<>();
		selectedFutaiSetsubiLists.add(new ArrayList<>());

		List<Map<Short, Short>> futaisetsubiKanrenMaps = new ArrayList<Map<Short, Short>>();
		futaisetsubiKanrenMaps.add(new HashMap<>());

		List<List<String>> enteredTextLists = new ArrayList<List<String>>();
		enteredTextLists.add(new ArrayList<>());

		for (int item = 0; item < mBashoLists.size(); item++)
		{
			try
			{
				akijokyoKensakuService.getShisetsuList(
					mBashoLists.get(item),
					selectedMokutekiLists.get(item),
					selectedFutaiSetsubiLists.get(item),
					futaisetsubiKanrenMaps.get(item),
					enteredTextLists.get(item)
					);
			}
			catch(Exception actual)
			{
				String messageActual = AppConfig.getMessage("error.akijokyo.search.empty");
				String expected = "条件に該当する施設はありません。検索条件を再設定してください。";
				assertEquals(expected, messageActual);
			}
		}
	}

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	public void TestKomaToMeisaiDtoAndSetName() throws Exception
	{
		List<Set<String>> selectedKomaSets = new ArrayList<Set<String>>();
		Set<String> selectedKomaSet = new HashSet<>();
		selectedKomaSet.add("10103101201806160110020010122");
		selectedKomaSets.add(selectedKomaSet);

		List<Map<Short, MBasho>> bashoMaps = new ArrayList<>();
		Map<Short, MBasho> mBashoMap = new HashMap<>();
		MBasho mBasho = new MBasho();
		mBasho.setBashoCode((short)1030);
		mBasho.setBashoName("生涯学習セ");
		mBashoMap.put((short)103, mBasho);
		bashoMaps.add(mBashoMap);

		List<Map<String, MShisetsu>> mShisetsuMaps = new ArrayList<Map<String, MShisetsu>>();
		Map<String, MShisetsu>  map = akijokyoKensakuService.getShisetsuMap();
		mShisetsuMaps.add(map);

		List<List<ShinseiMeisaiDto>> exports = new ArrayList<>();
		for (int item = 0; item < selectedKomaSets.size(); item++)
		{
			List<ShinseiMeisaiDto>  ret = akijokyoKensakuService.komaToMeisaiDtoAndSetName(
					selectedKomaSets.get(item),
					bashoMaps.get(item),
					mShisetsuMaps.get(item)
					);
			exports.add(ret);
		}
		exportJsonData(exports, "TestKomaToMeisaiDtoAndSetName.json");
	}

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	@TestInitDataFile("TestSetChohyoShukeiKomokuInit.xlsx")
	public void TestSetChohyoShukeiKomoku() throws Exception
	{
		ShinseiDto shinseiDto = new ShinseiDto();
		shinseiDto.setLoginId("tester1");
		SimpleDateFormat fm = new SimpleDateFormat("yyyy-MM-dd");
		Date date = fm.parse("2018-06-27");
		shinseiDto.setToshoUketsukeDate(date);

		List<ShinseiDto> shinseiDtosParam = new ArrayList<>();
		shinseiDtosParam.add(shinseiDto);
		shinseiDtosParam.add(shinseiDto);
		shinseiDtosParam.add(shinseiDto);
		shinseiDtosParam.add(shinseiDto);

		ShinseiMeisaiDto shinseiMeisaiDto = new ShinseiMeisaiDto();
		ShinseiMeisaiDto shinseiMeisaiDto2 = new ShinseiMeisaiDto();
		shinseiMeisaiDto2.setKanriCode((short)10);
		ShinseiMeisaiDto shinseiMeisaiDto3 = new ShinseiMeisaiDto();
		shinseiMeisaiDto3.setKanriCode((short)19);
		List<ShinseiMeisaiDto> meisaiDto = new ArrayList<ShinseiMeisaiDto>();
		meisaiDto.add(shinseiMeisaiDto);
		List<ShinseiMeisaiDto> meisaiDto2 = new ArrayList<ShinseiMeisaiDto>();
		meisaiDto2.add(shinseiMeisaiDto2);
		List<ShinseiMeisaiDto> meisaiDto3 = new ArrayList<ShinseiMeisaiDto>();
		meisaiDto3.add(shinseiMeisaiDto3);


		ShinseiMeisaiDto shinseiMeisaiDto4 = new ShinseiMeisaiDto();
		shinseiMeisaiDto4.setKanriCode((short)10);
		ShinseiMeisaiDto shinseiMeisaiDto44 = new ShinseiMeisaiDto();
		shinseiMeisaiDto44.setKanriCode((short)44);
		List<ShinseiMeisaiDto> meisaiDto4 = new ArrayList<ShinseiMeisaiDto>();
		meisaiDto4.add(shinseiMeisaiDto4);
		meisaiDto4.add(shinseiMeisaiDto44);

		List<List<ShinseiMeisaiDto>> meisaiDtos = new ArrayList<List<ShinseiMeisaiDto>>();
		meisaiDtos.add(meisaiDto);
		meisaiDtos.add(meisaiDto2);
		meisaiDtos.add(meisaiDto3);
		meisaiDtos.add(meisaiDto4);

		for (int item = 0; item < shinseiDtosParam.size(); item++)
		{
			akijokyoKensakuService.setChohyoShukeiKomoku(
					shinseiDtosParam.get(item),
					meisaiDtos.get(item)
					);
		}
	}

	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	//@TestInitDataFile("TestgetMBashoList.xlsx")
	public void TestSetMKanri() throws Exception
	{
		ShinseiDto shinseiDto = new ShinseiDto();
		shinseiDto.setLoginId("tester1");
		List<ShinseiDto> shinseiDtosParam = new ArrayList<>();
		shinseiDtosParam.add(shinseiDto);

		ShinseiMeisaiDto shinseiMeisaiDto = new ShinseiMeisaiDto();
		List<ShinseiMeisaiDto> meisaiDto = new ArrayList<ShinseiMeisaiDto>();
		meisaiDto.add(shinseiMeisaiDto);
		List<List<ShinseiMeisaiDto>> meisaiDtos = new ArrayList<List<ShinseiMeisaiDto>>();
		meisaiDtos.add(meisaiDto);

		for (int item = 0; item < shinseiDtosParam.size(); item++)
		{
			akijokyoKensakuService.setMKanri(
					shinseiDtosParam.get(item),
					meisaiDtos.get(item)
					);
		}
	}

//	@Test
//	Q&A
//	@DisplayName("session情報からT申請を生成し返却します.")
//	public void TestMakeShinseiDto() throws Exception {
//		List<ShinseiDto> mShinseiDtos = new ArrayList<>();
//		ShinseiDto shinseiDto = akijokyoKensakuService.makeShinseiDto();
//		mShinseiDtos.add(shinseiDto);
//		exportJsonData(mShinseiDtos, "TestMakeShinseiDto.json");
//	}

}
