package jp.ne.yec.seagullLC.stagia.test.junit.logic.master.MTeishiRiyuLogic;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.beans.StringCodeNamePair;
import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.entity.MTeishiRiyu;
import jp.ne.yec.seagullLC.stagia.logic.master.MTeishiRiyuLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestMTeishiRiyuLogic extends JunitBase {

	@Autowired
	MTeishiRiyuLogic mTeishiRiyuLogic;

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetMTeishiRiyu.xlsx")
	public void TestgetMTeishiRiyuList() throws Exception
	{
		List<MTeishiRiyu> ret = mTeishiRiyuLogic.getMTeishiRiyuList();
		exportJsonData(ret, "TestgetMTeishiRiyuList.json");
	}

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetMTeishiRiyu.xlsx")
	public void TestgetStringCodeNamePairList() throws Exception
	{
		List<StringCodeNamePair>  ret = mTeishiRiyuLogic.getStringCodeNamePairList();
		exportJsonData(ret, "TestgetStringCodeNamePairList.json");
	}

	@Test
	@DisplayName("検索条件なしで場所マスタを取得し、返却します")
	@TestInitDataFile("TestgetMTeishiRiyu.xlsx")
	public void TestToStringCodeNamePair() throws Exception
	{
		List<MTeishiRiyu>  list = new ArrayList<>();
		MTeishiRiyu mTei = new MTeishiRiyu();
		mTei.setTeishiRiyuCode((short)1);
		mTei.setTeishiRiyuName("停止理由１");
		list.add(mTei);
		List<StringCodeNamePair>  ret = mTeishiRiyuLogic.toStringCodeNamePair(list);
		exportJsonData(ret, "TestToStringCodeNamePair.json");
	}
	@Test
	@DisplayName("検索条件なしで場所マスタを取得し、返却します")
	//@TestInitDataFile("TestgetMBashoList.xlsx")
	public void TestgetDao() throws Exception
	{
		GenericDao<MTeishiRiyu, ?> ret =  mTeishiRiyuLogic.getDao();
	}
}