package jp.ne.yec.seagullLC.stagia.test.junit.logic.master.MKashidashiTaniLogic;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.beans.StringCodeNamePair;
import jp.ne.yec.sane.mybatis.dao.GenericDao;
import jp.ne.yec.seagullLC.stagia.entity.MKashidashiTani;
import jp.ne.yec.seagullLC.stagia.logic.master.MKashidashiTaniLogic;
import jp.ne.yec.seagullLC.stagia.test.base.annotation.TestInitDataFile;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestMKashidashiTaniLogic extends JunitBase {

	@Autowired
	MKashidashiTaniLogic mKashidashiTaniLogic;

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetMKashidashiTaniListByKanri.xlsx")
	public void TestgetMKashidashiTaniListByKanri() throws Exception
	{
		List<Short> kanriCodeListt = new ArrayList<Short>();
		Short kanriCodes = 10;
		kanriCodeListt.add(kanriCodes);
		List<MKashidashiTani>  ret = mKashidashiTaniLogic.getMKashidashiTaniListByKanri(kanriCodeListt);
		exportJsonData(ret, "TestgetMKashidashiTaniListByKanri.json");
	}

	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetMKashidashiTaniListByKanri.xlsx")
	public void TestgetMKashidashiTaniListByKanriShisetsu() throws Exception
	{
		Short kanriCodes = 10;
		Short shisetsuCodes = 10;
		List<MKashidashiTani>  ret =
					mKashidashiTaniLogic.getMKashidashiTaniListByKanriShisetsu(kanriCodes,shisetsuCodes);
		exportJsonData(ret, "TestgetMKashidashiTaniListByKanriShisetsu.json");
	}

	@Test
	@DisplayName("引数の管理コード、施設コード、貸出単位コードを検索条件として貸出単位マスタを取得し返却します")
	@TestInitDataFile("TestgetMKashidashiTaniListByKanri.xlsx")
	public void TestgetMKashidashiTani() throws Exception
	{
		Short kanriCodes = 10;
		Short shisetsuCodes = 10;
		Short kashidashiTaniCodes = 0;
		MKashidashiTani  ret = mKashidashiTaniLogic.getMKashidashiTani(kanriCodes,shisetsuCodes,
								kashidashiTaniCodes);
		List<MKashidashiTani> tList = new ArrayList<>();
		tList.add(ret);
		exportJsonData(ret, "TestgetMKashidashiTani.json");
	}
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetMKashidashiTaniListByKanri.xlsx")
	public void TestgetStringCodeNamePairList() throws Exception
	{
		Short kanriCodes = 10;
		Short shisetsuCodes = 10;
		List<StringCodeNamePair>  ret = mKashidashiTaniLogic.getStringCodeNamePairList(kanriCodes,
											shisetsuCodes);
		exportJsonData(ret, "TestgetStringCodeNamePairList.json");
	}
	@Test
	@DisplayName("検索条件なしでM_管理を取得します")
	@TestInitDataFile("TestgetMKashidashiTaniListByKanri.xlsx")
	public void TestgetMKashidashiTani_map() throws Exception
	{
		Map<Short, List<Short>> kanriShisetsuCodeMap = new HashMap<>();
		List<Short> List = new ArrayList<Short>();
		Short kanriShisetsuCode = 10;
		List.add(kanriShisetsuCode);
		kanriShisetsuCodeMap.put(kanriShisetsuCode, List);
		List<MKashidashiTani> ret =  mKashidashiTaniLogic.getMKashidashiTani(kanriShisetsuCodeMap);
		exportJsonData(ret, "TestgetMKashidashiTani_map.json");
	}
	@Test
	@DisplayName("データ更新に使用するDaoを取得します")
	public void TestgetDao() throws Exception
	{
		GenericDao<MKashidashiTani, ?> ret = mKashidashiTaniLogic.getDao();
	}
}