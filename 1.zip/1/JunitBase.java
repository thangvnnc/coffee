package jp.ne.yec.seagullLC.stagia.test.junit.base;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.wicket.ajax.json.JSONArray;
import org.dbunit.Assertion;
import org.dbunit.DatabaseUnitException;
import org.dbunit.database.DatabaseConnection;
import org.dbunit.database.IDatabaseConnection;
import org.dbunit.dataset.DataSetException;
import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.excel.XlsDataSet;
import org.dbunitng.dataset.BeanListConverter;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.CannotGetJdbcConnectionException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceUtils;
import org.springframework.test.context.junit4.SpringRunner;

import com.google.gson.Gson;

import jp.ne.yec.seagullLC.stagia.test.base.TestBase;

/**
 * @author nao-hirata
 *
 */
@RunWith(SpringRunner.class)
public class JunitBase extends TestBase {
	private final static String TAG = "---------------------------------JunitBase---------------------------------";

	@Autowired
	protected JdbcTemplate jdbcTemplate;

	/* (非 Javadoc)
	 * @see jp.ne.yec.seagullLC.stagia.base.TestBase#getIConnection()
	 */
	@Override
	protected IDatabaseConnection getIConnection() throws CannotGetJdbcConnectionException, DatabaseUnitException {
		return new DatabaseConnection(DataSourceUtils.getConnection(jdbcTemplate.getDataSource()));
	}

	/**
	 * オブジェクトと期待値リストを比較します.
	 * @throws Exception
	 * @throws IOException
	 * @throws InvalidFormatException
	 * @throws EncryptedDocumentException
	 * @throws DataSetException
	 *
	 */
	protected <T> void assertList(String fileName, Map<String, List<T>> expectedList) throws Exception {
		try {
			Workbook workbook = WorkbookFactory.create(this.getClass().getResourceAsStream(fileName));
			Iterator<Sheet> iterator = workbook.iterator();
			while (iterator.hasNext()) {
				Sheet sheet = iterator.next();
				List<T> list = expectedList.get(sheet.getSheetName());
				if (0 == list.size()) {
					continue;
				}
				BeanListConverter beanListConverter = new BeanListConverter(list);
				IDataSet dataSet = beanListConverter.convert();
				XlsDataSet expected = new XlsDataSet(this.getClass().getResourceAsStream(fileName));
				Assertion.assertEquals(expected, dataSet);
			}
		} catch (Exception e) {
			throw e;
		}
	}

	/**
	 * Đọc danh sách từ file
	 * @param fileName : tên file (sử dụng tương tự assertList)
	 * @return : Danh sách short
	 * @throws Exception
	 */
	public List<Short> readArrShort(String fileName) throws Exception {
		List<Short> list = null;
		BufferedReader bufferedReader = null;

		try {
			list = new ArrayList<Short>();
			bufferedReader = new BufferedReader(new InputStreamReader(this.getClass().getResourceAsStream(fileName)));
			String line = bufferedReader.readLine();

			String[] splits = line.split(";");
			for (String string : splits) {
				Short item = Short.parseShort(string);
				list.add(item);
			}

		} finally {

			if (bufferedReader != null) {
				bufferedReader.close();
			}
		}
		return list;
	}


	/**
	 * Đọc danh sách từ file
	 * @param fileName : tên file (sử dụng tương tự assertList)
	 * @return : Danh sách boolean
	 * @throws Exception
	 */
	public List<Boolean> readArrBoolean(String fileName) throws Exception {
		List<Boolean> list = null;
		BufferedReader bufferedReader = null;

		try {
			list = new ArrayList<Boolean>();
			bufferedReader = new BufferedReader(new InputStreamReader(this.getClass().getResourceAsStream(fileName)));
			String line = bufferedReader.readLine();

			String[] splits = line.split(";");
			for (String string : splits) {
				Boolean item = Boolean.parseBoolean(string);
				list.add(item);
			}

		} finally {

			if (bufferedReader != null) {
				bufferedReader.close();
			}
		}
		return list;
	}

	/**
	 * Đọc danh sách từ file
	 * @param fileName : tên file (sử dụng tương tự assertList)
	 * @return : Danh sách string
	 * @throws Exception
	 */
	public List<String> readArrString(String fileName) throws Exception {
		List<String> list = null;
		BufferedReader bufferedReader = null;

		try {
			list = new ArrayList<String>();
			bufferedReader = new BufferedReader(new InputStreamReader(this.getClass().getResourceAsStream(fileName)));
			String line = bufferedReader.readLine();
			String[] splits = line.split(";");
			for (String string : splits) {
				list.add(string);
			}

		} finally {

			if (bufferedReader != null) {
				bufferedReader.close();
			}
		}
		return list;
	}

	/**
	 * Đọc danh sách từ file
	 * @param fileName : tên file (sử dụng tương tự assertList)
	 * @return : Danh sách Date
	 * @throws Exception
	 */
	public List<Date> readArrDate(String fileName) throws Exception {
		List<Date> list = null;
		BufferedReader bufferedReader = null;

		try {
			list = new ArrayList<Date>();
			bufferedReader = new BufferedReader(new InputStreamReader(this.getClass().getResourceAsStream(fileName)));
			String line = bufferedReader.readLine();
			String[] splits = line.split(";");
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
			for (String string : splits) {
				Date item = formatter.parse(string);
				list.add(item);
			}
		} finally {

			if (bufferedReader != null) {
				bufferedReader.close();
			}
		}
		return list;
	}

	/**
	 * Đọc danh sách từ file
	 * @param fileName : tên file (sử dụng tương tự assertList)
	 * @return : Danh sách integer
	 * @throws Exception
	 */
	public List<Integer> readArrInteger(String fileName) throws Exception {
		List<Integer> list = null;
		BufferedReader bufferedReader = null;

		try {
			list = new ArrayList<Integer>();
			bufferedReader = new BufferedReader(new InputStreamReader(this.getClass().getResourceAsStream(fileName)));
			String line = bufferedReader.readLine();
			String[] splits = line.split(";");
			for (String string : splits) {
				Integer item = Integer.parseInt(string);
				list.add(item);
			}

		} finally {

			if (bufferedReader != null) {
				bufferedReader.close();
			}
		}
		return list;
	}

	/**
	 *  Đọc danh Map<String, List<String>>
	 *  Trong file txt
	 *     Key nằm ở đầu dòng đến dấu ":"
	 *     Value là danh sách các phần tử ở sau dấu ":" và cách nhau 1 tab
	 * @param fileName : Tên file
	 * @return : Map
	 * Các kiểu dữ liệu hổ trợ String, Short, Integer, Long, Double, Float, Boolean
	 */
	@SuppressWarnings("unchecked")
	public <T,U> Map<T, List<U>> readMapFile(String fileName, Class<T> classOfT, Class<U> classOfU) throws Exception
	{
		Map<T, List<U>> mapList = null;
		BufferedReader bufferedReader = null;

		try {
			mapList = new HashMap<T, List<U>>();
			bufferedReader = new BufferedReader(new InputStreamReader(this.getClass().getResourceAsStream(fileName)));
			String line = bufferedReader.readLine();

			while (line != null) {
				List<U> listU = new ArrayList<U>();
				String[] splits = line.split(":");
				String[] splitValue = splits[1].split(";");

				T t = getValue(splits[0], classOfT);
				for (String string : splitValue) {
					U u = getValue(string, classOfU);
					listU.add(u);
				}

				mapList.put(t, listU);
				line = bufferedReader.readLine();
			}
		} finally {

			if (bufferedReader != null) {
				bufferedReader.close();
			}
		}
		return mapList;
	}

	/**
	 * Kiểm tra là chuổi
	 * @param classOfU : dạng hình
	 * @return : true là chuổi - false không là chuổi
	 */
	@SuppressWarnings("unchecked")
	private <U> U getValue(String string, Class<U> classOfU) throws Exception
	{
		U u = null;
		String nameClass = classOfU.getSimpleName();
		if (nameClass.equals("String") != false)
		{
			u = (U) string;
		}

		if (nameClass.equals("Short") != false)
		{
			Short short1 = Short.parseShort(string);
			u = (U) short1;
		}

		if (nameClass.equals("Integer") != false)
		{
			Integer integer1 = Integer.parseInt(string);
			u = (U) integer1;
		}

		if (nameClass.equals("Long") != false)
		{
			Long long1 = Long.parseLong(string);
			u = (U) long1;
		}

		if (nameClass.equals("Double") != false)
		{
			Double double1 = Double.parseDouble(string);
			u = (U) double1;
		}

		if (nameClass.equals("Float") != false)
		{
			Float float1 = Float.parseFloat(string);
			u = (U) float1;
		}

		if (nameClass.equals("Boolean") != false)
		{
			Boolean boolean1 = Boolean.parseBoolean(string);
			u = (U) boolean1;
		}

		return u;

	}

	/*
	    Class model :
		class Demo
		{
			private String code;
			private String name;
			private boolean isAllow;
		}

    	Cách dùng :

		List<Demo> listDemo = readExcell("TestExcell.xlsx", Demo.class);

	 */

	/**
	 * Hàm chuyển file excell thành List<T>
	 * @param fileName : Tên file excell
	 * @param classOfT : Loại hình class cần chuyển
	 * @return : Danh sách sau khi chuyển
	 * @throws Exception
	 */
	public <T> List<T> readExcell(String fileName, Class<T> classOfT) throws Exception {
		XSSFWorkbook workbook = new XSSFWorkbook(this.getClass().getResourceAsStream(fileName));
		XSSFSheet sheet = workbook.getSheet(classOfT.getSimpleName());
		Iterator<Row> rowIterator = sheet.iterator();

		// Tên sheet làm tên class
		String nameSheet = sheet.getSheetName();

		System.out.println(TAG);
		System.out.println("Excell class : " + nameSheet);
		List<String> columns = getColumnName(rowIterator);
		System.out.println("Excell fields : " + columns);

		JSONArray jsonArray = new JSONArray();

		while (rowIterator.hasNext()) {

			// Map vào object
			Map<String, String> mapObject = new HashMap<>();

			Row row = rowIterator.next();
			Iterator<Cell> cellIterator = row.cellIterator();
			int cellIdx = 0;

			while (cellIterator.hasNext()) {

				Cell cell = cellIterator.next();
				String value = null;
				DataFormatter formatter = new DataFormatter();

				// Kiểm tra từng cell lưu vào map
				switch (cell.getCellType()) {
				case Cell.CELL_TYPE_NUMERIC:
					value = String.valueOf(formatter.formatCellValue(cell));
					break;
				case Cell.CELL_TYPE_STRING:
					value = cell.getStringCellValue();
					break;
				case Cell.CELL_TYPE_BLANK:
					continue;
				case Cell.CELL_TYPE_BOOLEAN:
					boolean bl = cell.getBooleanCellValue();
					value = String.valueOf(bl);
					break;
				}

				// Lưu vào map theo tên map
				String field = columns.get(cellIdx);
				mapObject.put(field, value);
				cellIdx++;
			}
			jsonArray.put(mapObject);
			mapObject.clear();
		}

		// Dùng gson chuyển map thành List
		Gson gson = new Gson();
		String jsonString = jsonArray.toString();
		List<T> list = gson.fromJson(jsonString, new ListOfJson<T>(classOfT));

		return list;
	}

	/**
	 * Đọc toàn bộ tên cột
	 *
	 * @param rowIterator
	 * @return
	 */
	private List<String> getColumnName(Iterator<Row> rowIterator) {
		List<String> columnNames = new ArrayList<String>();
		if (rowIterator.hasNext()) {
			Row row = rowIterator.next();
			// For each row, iterate through all the columns
			Iterator<Cell> cellIterator = row.cellIterator();

			while (cellIterator.hasNext()) {
				Cell cell = cellIterator.next();
				// Check the cell type and format accordingly
				if (cell.getCellType() == Cell.CELL_TYPE_STRING) {
					columnNames.add(cell.getStringCellValue());
				}
			}
		}

		return columnNames;
	}

	/**
	 * Class hổ trợ parser
	 * @param <T>
	 */
	private class ListOfJson<T> implements ParameterizedType {
		private Class<?> wrapped;

		public ListOfJson(Class<T> wrapper) {
			this.wrapped = wrapper;
		}

		@Override
		public Type[] getActualTypeArguments() {
			return new Type[] { wrapped };
		}

		@Override
		public Type getRawType() {
			return List.class;
		}

		@Override
		public Type getOwnerType() {
			return null;
		}
	}
}
