package jp.ne.yec.seagullLC.stagia.test.junit.service.unei.OshiraseService;

import java.time.LocalDate;
import java.util.List;

import org.junit.Test;
import org.junit.jupiter.api.DisplayName;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import jp.ne.yec.sane.beans.StringCodeNamePair;
import jp.ne.yec.seagullLC.stagia.beans.unei.OshiraseKensakuDto;
import jp.ne.yec.seagullLC.stagia.beans.unei.OshiraseSetteiDto;
import jp.ne.yec.seagullLC.stagia.beans.unei.OshiraseViewDto;
import jp.ne.yec.seagullLC.stagia.beans.unei.StagiaMessageDto;
import jp.ne.yec.seagullLC.stagia.service.unei.OshiraseService;
import jp.ne.yec.seagullLC.stagia.test.junit.base.JunitBase;

@RunWith(SpringRunner.class)
@ContextConfiguration(locations = {
		"classpath:TestApplicationContext.xml"
	})
@WebAppConfiguration
public class TestOshiraseService extends JunitBase{

	@Autowired
	OshiraseService oshiraseService;

	@Test
	@DisplayName("初期表示 情報(検索)を取得します。")
	public void TestGetInitData() throws Exception{
		OshiraseKensakuDto oshiraseKensakuDto = oshiraseService.getInitData();
	}

	@Test
	@DisplayName("引数の条件を基に職員・メディア全体 情報を取得します。")
	public void TestGetZentai() throws Exception{
		List<String> listHyojisakiShurui = readArrString("TestGetZentai_hyojisakiShurui.txt");
		LocalDate hyojiStartDate = LocalDate.now();
		LocalDate hyojiEndDate = LocalDate.now();
		List<Boolean> listIsIncludeDeleted = readArrBoolean("TestGetZentai_isIncludeDeleted.txt");

		for (int idx = 0; idx < listHyojisakiShurui.size(); idx++){
			List<OshiraseViewDto> list = oshiraseService.getZentai(
					listHyojisakiShurui.get(idx),
					hyojiStartDate,
					hyojiEndDate,
					listIsIncludeDeleted.get(idx)
					);
		}

	}

	@Test
	@DisplayName("引数の条件を基に職員所属 情報を取得します。")
	public void TestGetShokuinShozoku() throws Exception{

		List<String> listHyojisakiShurui = readArrString("TestGetShokuinShozoku_hyojisakiShurui.txt");
		List<StringCodeNamePair> kanriCodes = readExcell(
				"TestGetShokuinShozoku_shinseiGroupCodes.xlsx",
				StringCodeNamePair.class
				);
		LocalDate hyojiStartDate = LocalDate.now();
		LocalDate hyojiEndDate = LocalDate.now();
		List<Boolean> listIsIncludeDeleted = readArrBoolean("TestGetShokuinShozoku_isIncludeDeleted.txt");

		for (int idx = 0; idx < listHyojisakiShurui.size(); idx++){
			oshiraseService.getShokuinShozoku(
					listHyojisakiShurui.get(idx),
					kanriCodes,
					hyojiStartDate,
					hyojiEndDate,
					listIsIncludeDeleted.get(idx)
					);
		}

	}

	@Test
	@DisplayName("引数の条件を基に職員・利用者個人 情報を取得します。")
	public void TestGetKojin() throws Exception{
		List<String> listHyojisakiShurui = readArrString("TestGetKojin_hyojisakiShurui.txt");
		List<String> listLoginId = readArrString("TestGetKojin_loginId.txt");
		List<String> listLoginKind = readArrString("TestGetKojin_loginKind.txt");
		LocalDate hyojiStartDate = LocalDate.now();
		LocalDate hyojiEndDate = LocalDate.now();
		List<Boolean> listIsIncludeDeleted = readArrBoolean("TestGetKojin_isIncludeDeleted.txt");

		for (int idx = 0; idx < listHyojisakiShurui.size(); idx++){
			List<OshiraseViewDto> list = oshiraseService.getKojin(
					listHyojisakiShurui.get(idx),
					listLoginId.get(idx),
					listLoginKind.get(idx),
					hyojiStartDate,
					hyojiEndDate,
					listIsIncludeDeleted.get(idx)
					);
		}
	}

	@Test
	@DisplayName("引数の条件を基にメディア申請グループ 情報を取得します。")
	public void TestGetMedhiaShinseiGroup() throws Exception
	{
		List<String> listHyojisakiShurui = readArrString("TestGetMedhiaShinseiGroup_hyojisakiShurui.txt");
		List<StringCodeNamePair> listShinseiGroupCodes = readExcell(
				"TestGetMedhiaShinseiGroup_shinseiGroupCodes.xlsx",
				StringCodeNamePair.class
				);
		LocalDate hyojiStartDate = LocalDate.now();
		LocalDate hyojiEndDate = LocalDate.now();
		List<Boolean> listIsIncludeDeleted = readArrBoolean("TestGetMedhiaShinseiGroup_isIncludeDeleted.txt");

		for (int idx = 0; idx < listHyojisakiShurui.size(); idx++){
			List<OshiraseViewDto> list = oshiraseService.getMedhiaShinseiGroup(
					listHyojisakiShurui.get(idx),
					listShinseiGroupCodes,
					hyojiStartDate,
					hyojiEndDate,
					listIsIncludeDeleted.get(idx)
					);
		}

	}

	@Test
	@DisplayName("お知らせ設定画面の表示用情報を取得します.")
	public void TestGetOshiraseSetteiInitData() throws Exception
	{
		List<Integer> listOshiraseId = readArrInteger("TestGetOshiraseSetteiInitData.txt");
		for (Integer oshiraseId : listOshiraseId) {
			OshiraseSetteiDto oshiraseSetteiDto = oshiraseService.getOshiraseSetteiInitData(oshiraseId);
		}
	}

	@Test
	@DisplayName("画面ヘッダー部のドロップダウンに表示するお知らせ情報を取得し返却します.")
	public void TestGetHeaderMessageList() throws Exception
	{
		List<Boolean> listIsLogin = readArrBoolean("TestGetMessageList_isLogin.txt");
		List<Boolean> listIsShokuin = readArrBoolean("TestGetMessageList_isShokuin.txt");
		List<String> listLoginId = readArrString("TestGetMessageList_loginId.txt");

		for(int idx = 0; idx < listIsLogin.size(); idx++)
		{
			List<StagiaMessageDto> list = oshiraseService.getHeaderMessageList(
					listIsLogin.get(idx),
					listIsShokuin.get(idx),
					listLoginId.get(idx)
					);
		}
	}

	@Test
	@DisplayName("お知らせ選択後のダイアログに表示するお知らせ情報を取得し返却します.")
	public void TestGetMessageList() throws Exception
	{
		List<Boolean> listIsLogin = readArrBoolean("TestGetMessageList_isLogin.txt");
		List<Boolean> listIsShokuin = readArrBoolean("TestGetMessageList_isShokuin.txt");
		List<String> listLoginId = readArrString("TestGetMessageList_loginId.txt");

		for(int idx = 0; idx < listIsLogin.size(); idx++)
		{
			List<StagiaMessageDto> list = oshiraseService.getMessageList(
					listIsLogin.get(idx),
					listIsShokuin.get(idx),
					listLoginId.get(idx)
					);
		}

	}

	@Test
	@DisplayName("引数のお知らせIDの情報が既読扱いとなるように、DB更新を行います. 「T_お知らせ既読」へInsert処理を行います.")
	public void TestInsReadMessage() throws Exception {
		List<Integer> listOshiraseId = readArrInteger("TestInsReadMessage_oshiraseId.txt");
		List<String> listLoginId = readArrString("TestInsReadMessage_loginId.txt");
		List<String> listLoginKind = readArrString("TestInsReadMessage_loginKind.txt");
		List<String> listUpdateBy = readArrString("TestInsReadMessage_updateBy.txt");

		for (int idx = 0; idx < listOshiraseId.size(); idx++){
			oshiraseService.insReadMessage(
					listOshiraseId.get(idx),
					listLoginId.get(idx),
					listLoginKind.get(idx),
					listUpdateBy.get(idx)
					);
		}
	}
}
