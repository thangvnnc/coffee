﻿using System;
using System.Windows.Forms;

namespace SocketDemo
{
    public partial class FrmMain : Form
    {
        public FrmMain()
        {
            InitializeComponent();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            SocketInfo serverInfo = new SocketInfo(11000);
            TCPServer.StartListenner(serverInfo);
            TCPServer._recv = ReceiveByte;
        }

        private void ReceiveByte(byte[] bytes)
        {

        }

        private void btnSet_Click(object sender, EventArgs e)
        {
            SocketInfo socketInfo = new SocketInfo("192.168.1.103", 11000);
            TCPClient.Send(socketInfo, new byte[1]);
        }

        private void FrmMain_Load(object sender, EventArgs e)
        {
            TCPServer.TxtLog = txtLog;
            TCPClient.TxtLog = txtLog;
            TCPServer.FrmMain = this;
            TCPClient.FrmMain = this;
        }
    }
}
