﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Windows.Forms;

namespace SocketDemo
{
    public class TCPClient
    {
        public static TextBox TxtLog { get; set; }
        public static Form FrmMain { get; set; }

        public static void LogString(string log)
        {
            FrmMain.Invoke((MethodInvoker)delegate
            {
                if (TxtLog != null)
                {
                    TxtLog.AppendText(Environment.NewLine + "Client: " + log);
                }
            });
        }

        public static void Send(SocketInfo socketInfo, byte[] bytes)
        {
            try
            {
                byte[] byteSend = new byte[100];

                IPHostEntry ipHostInfo = Dns.GetHostEntry(socketInfo.Ip);
                IPAddress ipAddress = ipHostInfo.AddressList[0];
                IPEndPoint remoteEP = new IPEndPoint(ipAddress, socketInfo.Port);
                Socket socket = new Socket(ipAddress.AddressFamily,
                    SocketType.Stream, ProtocolType.Tcp);

                LogString("connect");

                socket.Connect(remoteEP);
                LogString("accepted");

                socket.Send(byteSend);
                LogString("sent");

                // Release the socket.  
                socket.Shutdown(SocketShutdown.Both);
                socket.Close();

            }
            catch (Exception e)
            {
                LogString(e.ToString());
            }
        }
    }
}
