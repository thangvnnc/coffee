﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace SocketDemo
{
    public class TCPServer
    {
        public delegate void Recv(byte[] byteRec);

        public static TextBox TxtLog { get; set; }

        public static Form FrmMain { get; set; }

        public static void LogString(string log)
        {
            FrmMain.Invoke((MethodInvoker)delegate
            {
                if (TxtLog != null)
                {
                    TxtLog.AppendText(Environment.NewLine + "Server: " + log);
                }
            });
        }

        private static byte[] _bufferRecv = new byte[1024*1024];
        private static List<Socket> _clientSockets = new List<Socket>();
        public static Recv _recv = null;

        private static Socket _serverSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

        public static void StartListenner(SocketInfo socketInfo)
        {
            LogString("Setup server...");
            _serverSocket.Bind(new IPEndPoint(IPAddress.Any, socketInfo.Port));
            _serverSocket.Listen(1);
            _serverSocket.BeginAccept(new AsyncCallback(AcceptCallBack), null);
        }

        public static void AcceptCallBack(IAsyncResult AR)
        {
            Socket socket = _serverSocket.EndAccept(AR);
            _clientSockets.Add(socket);
            socket.BeginReceive(_bufferRecv, 0, _bufferRecv.Length, SocketFlags.None, new AsyncCallback(ReceiveCallBack), socket);
            _serverSocket.BeginAccept(new AsyncCallback(AcceptCallBack), null);
        }

        private static void ReceiveCallBack(IAsyncResult AR)
        {
            Socket socket = (Socket)AR.AsyncState;
            if (IsSocketConnected(socket) == false)
            {
                _clientSockets.Remove(socket);
                LogString("Disconnect");
                return;
            }

            int received = socket.EndReceive(AR);
            byte[] dataBuffer = new byte[received];
            Array.Copy(_bufferRecv, dataBuffer, received);
            _recv.Invoke(dataBuffer);
            string textRecv = Encoding.UTF8.GetString(dataBuffer);
            LogString(textRecv);
            socket.BeginReceive(_bufferRecv, 0, _bufferRecv.Length, SocketFlags.None, new AsyncCallback(ReceiveCallBack), socket);
        }
        private static bool IsSocketConnected(Socket socket)
        {
            try
            {
                return !(socket.Poll(1, SelectMode.SelectRead) && socket.Available == 0);
            }
            catch (SocketException)
            {
                return false;
            }
        }

        //    public static void StartListening(SocketInfo socketInfo, Recv recv)
        //    {
        //        new Thread(() =>
        //        {
        //            IPHostEntry ipHostInfo = Dns.GetHostEntry(Dns.GetHostName());
        //            IPAddress ipAddress = ipHostInfo.AddressList[0];
        //            IPEndPoint localEndPoint = new IPEndPoint(IPAddress.Any, socketInfo.Port
        //            // Create a TCP/IP socket.  
        //            Socket listener = new Socket(AddressFamily.InterNetwork,
        //                SocketType.Stream, ProtocolType.Tcp
        //            // Bind the socket to the local endpoint and listen for incoming connections.  
        //            try
        //            {
        //                listener.Bind(localEndPoint);
        //                listener.Listen(100
        //                // Start listening for connections.  
        //                while (true)
        //                {
        //                    const int BUFFSIZE = 1024;
        //                    byte[] byteRecv = new byte[BUFFSIZE
        //                    LogString("waiting for a connection
        //                    Socket socket = listener.Accept();
        //                    LogString("accepted
        //                    int totalRecv = socket.Receive(byteRecv);
        //                    LogString("recv " + totalRecv + " byte
        //                }
        //            }
        //            catch (Exception e)
        //            {
        //                LogString(e.ToString());
        //            }
        //        }).Start();
        //    }
    }
}
