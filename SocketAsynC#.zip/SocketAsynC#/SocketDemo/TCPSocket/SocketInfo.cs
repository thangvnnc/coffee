﻿namespace SocketDemo
{
    public class SocketInfo
    {
        public string Ip { set; get; }

        public int Port { set; get; }

        public SocketInfo(int port)
        {
            Port = port;
        }

        public SocketInfo(string ip, int port)
        {
            Ip = ip;
            Port = port;
        }
    }
}
